<?php

namespace App\Presenters;

class GalleryPresenter
{
    public function formatTime($time)
    {
        /*
         * 时间标记规则；
            1小时内：显示 XX分钟前
            1天内：显示 XX小时前
            3天内：显示 X天前
            超过3天：显示日期  2017-3-17
         */
        $t0 = is_numeric($time) ? $time : strtotime($time);
        $t = time() - $t0;
        if ($t < 3600) {
            return round($t / 60) . '分钟前';
        } else if ($t < 24 * 3600) {
            return round($t / 3600) . '小时前';
        } else if ($t < 3 * 24 * 3600) {
            return round($t / 24 / 3600) . '天前';
        } else {
            return date('Y-m-d', $t0);
        }
    }

    public function showTags($tags){
        if(!$tags){
            return '';
        }
        if(is_array($tags)){
            $arr = $tags;
        }else{
            $arr = explode(',', trim($tags, ','));
        }
        $html = '';
        foreach($arr as $a){
            $html .= '<a class="m-label detail-label" target="_blank" href="/tag/'.rawurlencode($a).'">'.$a.'</a>';
        }
        return $html;
    }

    public function formatNumber($view){
        $str = $view;
        if ($view >= 10000) {
            $prefix = intval($view / 10000);
            $sub = intval($view % 10000 / 100);
            $sub = intval($sub / 10) . ($sub % 10 == 0 ? '' : $sub % 10);
            $str = $sub == 0 ? $prefix . 'w' : $prefix . '.' . $sub . 'w';
        } else if ($view >= 1000) {
            $prefix = intval($view / 1000);
            $sub = intval($view % 1000 / 100);
            $str = $sub == 0 ? $prefix . 'k' : $prefix . '.' . $sub . 'k';
        }
        return $str;
    }

    public function getLimitDesc($atlas, $length = 100)
    {
        $text = $atlas->description;
        if (!$text) {
            foreach($atlas->pictures as $pic) {
                $text .= $pic->content;
            }
        }
        $text = str_replace(["\r\n", "\n", "\r"], '', strip_tags($text));

        return str_limit($text, $length);
    }

    public function getFileType($name) {
        $arr = explode('.', $name);
        return count($arr) > 0 ? $arr[count($arr)-1] : '';
    }

    public function getModifyUrl ($archive) {
        if ($archive->hot_aid && $archive->ccid) {
            return '/game/picture-edit/'.$archive->id;
        } else {
            return '/resource/edit/'.$archive->id;
        }
    }
}
