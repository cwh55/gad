<?php

namespace App\Presenters;

use Carbon\Carbon;

class LundaoPresenter
{
    public function getBreadCrumbNav($course)
    {
        $catTable = [
            0 => ['name' => '未分类', 'url' => '/'],
            1 => ['name' => '游戏策划', 'url' => '/community/plan'],
            2 => ['name' => '游戏美术', 'url' => '/community/art'],
            3 => ['name' => '游戏开发', 'url' => '/community/program'],
            3595 => ['name' => 'VR/AR', 'url' => '/community/vr']
        ];
        $category = array_get($catTable, $course->first_type_id, $catTable[0]);

        $html = '<div class="m-breadcrumb">';
        $html .= '<a class="breadcrumb-item" href="/">首页</a>';
        $html .= '<span class="breadcrumb-spilt">&gt;</span>';
        $html .= '<a class="breadcrumb-item" href="/community">社区</a>';
        $html .= '<span class="breadcrumb-spilt">&gt;</span>';
        $html .= '<a class="breadcrumb-item" href="/lundao/list">论道</a>';
        $html .= '<span class="breadcrumb-spilt">&gt;</span>';
        $html .= '<span class="breadcrumb-item">'.e($course->title).'</span>';
        $html .= '</div>';

        return $html;
    }

    public function getLiveCountDown($lensson)
    {
        $begin = new Carbon($lensson->begin_date.' '.$lensson->begin_time);
        $now = Carbon::now();
        if ($now >=  $begin) {
            $label = '直播即将进行';
        } else {
            $diff = $now->diff($begin);
            $intval = [];
            switch (true) {
                case $diff->y:
                    $intval[] = $diff->y.'年';
                case $diff->m:
                    $intval[] = $diff->m.'个月';
                case $diff->d:
                    $intval[] = $diff->d.'天';
                case $diff->h:
                    $intval[] = $diff->h.'小时';
                case $diff->i:
                    $intval[] = $diff->i.'分';
                default:
                    break;
            }
            $label = '距开播还有'.implode('', $intval);
        }

        return $label;
    }

    public function getState($course)
    {
        if ($course->state == 'new') {
            return '<span class="tips">报名中</span>';
        } elseif ($course->state == 'living') {
            return '<span class="tips">直播中</span>';
        } elseif ($course->state == 'over') {
            if ($course->lesson AND $course->lesson->type == 'playback' AND $course->lesson->vod ==2) {
                return '<span class="tips">回放中</span>';
            } else {
                return '<span class="end">已结束</span>';
            }
        }
    }

    public function getLiveStateClass($course, $isLogined)
    {
        if ($course->state == 'living' AND $isLogined) {
            return '';
        }

        if ($course->state == 'living' AND !$isLogined) {
            return 'live-login-before';
        }

        if ($course->state == 'over') {
            if ($course->lesson AND $course->lesson->type == 'playback' AND $course->lesson->vod ==2) {
                return $isLogined ? 'live-playback live-login-after' : 'live-playback live-login-before';
            }

            return 'live-end';
        }
    }

    public function getQzoneShareLink($course)
    {
        $link = '<a _HOTTAG="X.LD.SHARE.QQZONE" href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=%s&desc=%s&title=%s&site=腾讯游戏开发者平台&summary=%s&pics=%s" title="分享到QQ空间" target="_blank" class="share-ico icon-share_space"></a>';

        return sprintf($link, rawurlencode(url('lundao/detail', $course->id)), $course->summary, $course->title, $course->summary, $course->thumbnail);
    }

    public function getWeiBoShareLink($course)
    {
        $link = '<a _HOTTAG="X.LD.SHARE.BLOG" href="http://service.weibo.com/share/share.php?appkey=1793213633&title=%s&url=%s&language=zh_cn&pic=%s" title="分享到微博" target="_blank" class="share-ico icon-share_wb"></a>';

        return sprintf($link, $course->title, rawurlencode(url('lundao/detail', $course->id)), $course->thumbnail);
    }

    public function getQQShareLink($course)
    {
        $link = '<a href="http://connect.qq.com/widget/shareqq/index.html?url=%s&showcount=0&desc=%s&summary=&title=%s&pics=%s&style=203&width=19&height=22" class="share-ico icon-share_qq" target="_blank"></a>';
        $url = rawurlencode(url('lundao/detail', $course->id));

        return sprintf($link, rawurlencode(url('lundao/detail', $course->id)), $course->summary, $course->title, $course->thumbnail);
    }

    public function getLessonVideos($lesson)
    {
        return json_encode($lesson->videos);
    }
}