<?php

namespace App\Presenters;

/**
 * Class TeamPresenter
 *
 * @package namespace App\Presenters;
 */
class TeamPresenter
{

    public function workYearState($ranges){
    	if($ranges == 0)
    		return '不限';

    	
        $range  = explode(',',$ranges);
        $starttext = $range[0]==0 ? "年以下" : $range[0];
        $endtext = $range[1]==0 ? "年以上" : "~".(11 - $range[1])."年";
        $text = $range[0] ? $starttext.$endtext : ($range[1] ? (11 - $range[1]).$starttext : "不限");
        return $text;
    }
}
