<?php

namespace App\Presenters;
/**
 * Class SearchPresenter
 *
 * @package namespace App\Presenters;
 */
class SearchPresenter
{
    public function keyWordHighLight($keyword,$str)
    {
        $pattern = '/'.$keyword.'/';
        $replacement = '<em class="hl-keyword">'.e($keyword).'</em>';
        return preg_replace($pattern, $replacement, e($str),1);
    }
}

