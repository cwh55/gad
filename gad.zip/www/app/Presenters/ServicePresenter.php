<?php

namespace App\Presenters;

/**
 * Class ServicePresenter
 *
 * @package namespace App\Presenters;
 */
class ServicePresenter
{

    public function getStage($stage){
    	switch ($stage) {
            case 1:
                return '天使轮';
            case 2:
                return 'Pre,A轮';
            case 3:
                return 'A轮';
            case 4:
                return 'B轮';
            case 5:
                return 'C轮';
            case 6:
                return 'D轮';
            case 7:
                return 'E轮及以后';
        }
        return '';
    }
}
