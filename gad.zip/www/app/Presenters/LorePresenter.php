<?php

namespace App\Presenters;
use Gate;

/**
 * Class LorePresenter
 *
 * @package namespace App\Presenters;
 */
class LorePresenter
{

	private  $sectionInfo = [
		"1" =>[
			"payType" =>'free-tips',
			"payTypeh5" => "tags-free",
			"sectionType"=>'article-ico',
			"sectionTypeh5" => 'ico-article',
			"payTypeWord"=>'免费'
		],
		"2" =>[
			"payType"=>'pay-tips',
			"payTypeh5"=>"tags-topay",
			"sectionType"=>'article-ico',
			"sectionTypeh5"=>'ico-article',
			"payTypeWord"=>'付费'
		],
		"3" =>[
			"payType"=>'free-tips',
			"payTypeh5" => "tags-free",
			"sectionType"=>'video-ico',
			"sectionTypeh5"=>'ico-video',
			"payTypeWord"=>'免费'
		],
		"4" =>[
			"payType"=>'pay-tips',
			"payTypeh5" => "tags-topay",
			"sectionType"=>'video-ico',
			"sectionTypeh5"=>'ico-video',
			"payTypeWord"=>'付费'
		]
	];
	public function getPurchaseBtn($lore,$from='',$tag=''){
		$a = ' <a class="purchase-btn" href="%s" %s>%s</a>';
		$m = '';
		if($from == 'h5'){
			$a = '  <a class="btn-learn" href="%s" %s>%s</a>';
			$m = '/m';

		}
		if(Gate::allows('access',$lore)){
			if(empty($lore->userLearn)){
				$text = ($lore->price == 0 ? '免费 |' : '').' 立即学习';
                $vueClick = "_HOTTAG=\"MANU.INDEX.BUY\"";

				$recentLearnSid = '';
				$chapter = $lore->chapters->first();
				if($chapter && $chapter->sections->first())
					$recentLearnSid = $chapter->sections->first()->id;

			}else{
				$text = '继续学习';
                $vueClick = "_HOTTAG=\"MANU.INDEX.LEARN\"";
				$recentLearnSid = $lore->userLearn->section_id;
			}
			$id =  $m.'/lore/detail/'.$recentLearnSid;
		}else {
			if($lore->price == 0){
				$recentLearnSid = '';
				$chapter = $lore->chapters->first();
				if($chapter && $chapter->sections->first())
					$recentLearnSid = $chapter->sections->first()->id;

				$id = $m.'/lore/detail/'.$recentLearnSid;
                $vueClick = "_HOTTAG=\"MANU.INDEX.BUY\"";
				$text =  '免费 | 立即学习';
			}else{
				$id =  'javascript:;';
				$vueClick = '@click="buy" data-url="'.$m.'/lore/catalog/'.$lore->id.'"' ."onclick=\"MtaH5.clickStat('".$tag."',{'buy':'true'})\"" ."_HOTTAG=\"MANU.INDEX.BUY\"";
				$text = "￥".$lore->price.' | 立即学习';
			}
		}

		return sprintf($a , $id, isset($vueClick) ? $vueClick : '', $text );
	}

	public function getTryBtn($lore,$from=''){
		$a = ' <a class="try-btn" href="%s" target="_blank"><span class="try-icon"></span>试 看</a>';
		$m = '';
		if($from == 'h5'){
			$m = '/m';
		}
		$recentLearnSid = '';
		$chapter = $lore->chapters->first();
		if($chapter && $chapter->sections->first()) {
			$recentLearnSid = $chapter->sections->first()->id;
		}
		$id =  $m.'/lore/detail/'.$recentLearnSid;
		return sprintf($a , $id);
	}

	public function getSectionList($chapter,$chapter_index,$lore,$from=""){
    	$p = '<p class="row" %s><em class="%s">%s</em><a %s target="_blank"><i class="knowledge-ico %s"></i>%s.%s %s<span class="time">%s</span></a></p>';
			$m = '';
      if($from == "h5"){
				$p = '<li class="section-item" %s><em class="%s">%s</em><a class="section-link f-hide-col-1" %s><i class="knowledge-ico %s"><!--文章--></i>%s.%s %s</a><span class="section-time">%s</span></li>';
				$m = '/m';
			}
    	$sections = [];
    	$isPayed =$lore->isPayed();
		foreach ($chapter->sections as $i => $section) {
            if ($section->state == 0) {
                $s_type = $section->section_type;
                $sectionInfo = $this->sectionInfo[$section->section_type];

                //vue渲染优化
                if($i > 2 && $from != 'h5')
                    $vue = "v-cloak v-show='chapters[".$chapter_index."].sectionShow'";
                else
                    $vue = '';

                //判断是需付费文章并且已购买
                if($s_type == 1 || $s_type == 3){
                    $pay_status_class = $sectionInfo['payType'.$from];
                    $pay_status_text = $sectionInfo['payTypeWord'];

                    $href = 'href="'.$m.'/lore/detail/'.$section->id.'"';
                }else if($isPayed){
									if($from == 'h5'){
										$pay_status_class = 'tags-paid';
										$pay_status_text = '已付费';
									} else {
                    $pay_status_class = 'had-purchased-tips';
                    $pay_status_text = '已购买';
									}
                    $href = 'href="'.$m.'/lore/detail/'.$section->id.'"';
                }else{
                    $pay_status_class = $sectionInfo['payType'.$from];
                    $pay_status_text = $sectionInfo['payTypeWord'];
                    $href='href="javascript:;" @click="buy" data-url="'.$m.'/lore/detail/'.$section->id.'"';
                }
                //tlog
                $tlogTag = self::getTlogTag($s_type,$i);
                $href = $href.$tlogTag;
                $sections[] = sprintf( $p
                            ,$vue
                            ,$pay_status_class
                            ,$pay_status_text
                            ,$href
                            ,$sectionInfo['sectionType'.$from]
                            ,$chapter->chapter_no
                            ,$section->section_no
                            ,$section->title
                            ,$section->duration
                );
            }
    	}

    	return implode('',$sections);

    }

    public function getRecommendSectionsList($articles){
    	$pArticle = '<p class="row"><i class="knowledge-ico %s"></i><a _HOTTAG="MANU.CATA.RALA" href="http://gad.qq.com/article/detail/%s" class="f-hide-col-1" target="_blank">%s</a></p>';
        $pCousrse = '<p class="row"><i class="knowledge-ico %s"></i><a _HOTTAG="MANU.CATA.RALA"  href="http://gad.qq.com/content/coursedetail/%s" class="f-hide-col-1" target="_blank">%s</a></p>';
    	$articleList = [];
    	foreach($articles as  $article) {
            if ($article->content->ShowType == 3) {
                $articleList[] = sprintf($pCousrse
                    ,"video-ico"
                    ,$article->Id
                    ,str_limit($article->content->Title,20)
                );
            } else {
                $articleList[] = sprintf($pArticle
                    ,"article-ico"
                    ,$article->Id
                    ,str_limit($article->content->Title,20)
                );
            }

    	}

    	return implode('',$articleList);

    }

	public function getLimitDesc($text, $length = 80)
	{
		$text = str_replace(["\r\n", "\n", "\r"], '', $text);

		return str_limit($text, $length);
	}

    public static function getTlogTag($s_type,$i)
    {
        if ( 0 == $i ) return '_HOTTAG="MANU.CATA.FIRST"';
        switch ($s_type ){
            case '1':
                return '_HOTTAG="MANU.CATA.MFWZ"';
                break;
            case '2':
                return '_HOTTAG="MANU.CATA.FFWZ"';
                break;
            case '3':
                return '_HOTTAG="MANU.CATA.MFSP"';
                break;
            case '4':
                return '_HOTTAG="MANU.CATA.FFSP"';
                break;
            default:
                return '';
                break;
        }

	}
}
