<?php

namespace App\Presenters;

class CommunityPresenter
{
    public function getTimeName()
    {
        //(早上好 北京时间6:00-09:59:59、上午好 北京时间 10:00-12:59:59 中午好 北京时间 13:00:00 – 14:59:59 下午好 北京时间15:00-18:59:59 晚上好 北京时间19:00-5:59:59)
        $time = date('H:i:s');
        if($time>='06:00:00' && $time<='09:59:59'){
            return '早上好';
        }else if($time>='10:00:00' && $time<='12:59:59'){
            return '上午好';
        }else if($time>='13:00:00' && $time<='14:59:59'){
            return '中午好';
        }else if($time>='15:00:00' && $time<='18:59:59'){
            return '下午好';
        }else{
            return '晚上好';
        }
    }

	public function viewFormat($view)
    {
        $str = $view;
        if ($view >= 10000) {
            $prefix = intval($view / 10000);
            $sub = intval($view % 10000 / 100);
            $sub = intval($sub / 10) . ($sub % 10 == 0 ? '' : $sub % 10);
            $str = $sub == 0 ? $prefix . 'w' : $prefix . '.' . $sub . 'w';
        } else if ($view >= 1000) {
            $prefix = intval($view / 1000);
            $sub = intval($view % 1000 / 100);
            $str = $sub == 0 ? $prefix . 'k' : $prefix . '.' . $sub . 'k';
        }
        return $str;
    }

    public function formatTime($time)
    {
        /*
         * 时间标记规则；
            1小时内：显示 XX分钟前
            1天内：显示 XX小时前
            3天内：显示 X天前
            超过3天：显示日期  2017-3-17
         */
        $t0 = is_numeric($time) ? $time : strtotime($time);
        $t = time() - $t0;
        if ($t < 3600) {
            return round($t / 60) . '分钟前';
        } else if ($t < 24 * 3600) {
            return round($t / 3600) . '小时前';
        } else if ($t < 3 * 24 * 3600) {
            return round($t / 24 / 3600) . '天前';
        } else {
            return date('Y-m-d', $t0);
        }
    }

    //回答时间
    public function formatAnswerTime($time)
    {
        $time = strtotime($time);
        $diff = time() - $time;
        $hour = $diff / 3600;
        if ($hour > 24) {
            return date('Y-m-d H:i', $time);
        } else if ($hour > 1 && $hour < 24) {
            return intval($hour) . '小时前';
        } else if (intval($hour * 60)) {
            return intval($hour * 60) . '分钟前';
        } else {
            return '刚刚';
        }
    }

    public function showTags($tags){
        if(!$tags){
            return '';
        }
        if(is_array($tags)){
            $arr = $tags;
        }else{
            $arr = explode(',', $tags);
        }
        $html = '';
        foreach($arr as $a){
            $html .= '<a class="m-label umetadata-label" target="_blank" href="/tag/'.rawurlencode($a).'">'.$a.'</a>';
        }
        return $html;
    }

    public function formatNumber($view)
    {
        $str = $view;
        if ($view >= 10000) {
            $prefix = intval($view / 10000);
            $sub = intval($view % 10000 / 100);
            $sub = intval($sub / 10) . ($sub % 10 == 0 ? '' : $sub % 10);
            $str = $sub == 0 ? $prefix . 'w' : $prefix . '.' . $sub . 'w';
        } else if ($view >= 1000) {
            $prefix = intval($view / 1000);
            $sub = intval($view % 1000 / 100);
            $str = $sub == 0 ? $prefix . 'k' : $prefix . '.' . $sub . 'k';
        }
        return $str;
    }

    public function getTagPageClassId($category)
    {
        return array_get([
            'all' => 'p-all',
            'article' => 'p-article',
            'question' => 'p-wenda',
            'topic' => 'p-wenda',
            'gallery' => 'p-works'
        ], $category, 'p-all');
    }

    public function showPicture($work, $lino, $title='')
    {
        if (count($work->mylike)) {
            if ($work->mylike[0]->status) {
                $style = 'red';
            } else {
                $style = 'white';
            }
            $likeid = $work->mylike[0]->id;
        } else {
            $style = 'white';
            $likeid = 0;
        }
        $swidth = $work->width;
        $sheight = $work->height;
        $ratio =  $swidth / 275;
        if ($ratio > 1) {
            $swidth = 275;
            $sheight = $sheight / $ratio;
        }
        $gifhtml = preg_match('/gif$/', e($work->url)) ? '<i class="tips cyico-gif"></i>' : '';
        $tutorhtml = !empty($work->tutoranswer) ?   '<div class="item-comment js_commenttype">'.
                                                    '<p class="tit">晨星专家点评</p>'.
                                                    '<p class="intro"><span class="name f-hide-col-1">'.$work->tutoranswer->user_name.'</span><span class="badge"><i class="'.($work->tutoranswer->user->type==1 ? "gicos-bluev-s" : ($work->tutoranswer->user->type == 2 ? "gicos-redv-s" : "") ).'"></i></span><i>：</i>'.$work->tutoranswer->comment.'</p>'.
                                                    '<div class="opt-line">'.
                                                        '<div class="opt-down js_optdown"><span class="gicos-arrow-down"></span></div>'.
                                                        '<div class="opt-up js_optup"><span class="gicos-arrow-up"></span></div>'.
                                                    '</div>'.
                                                    '</div>' : '';
        $html = '<li class="list-item firstpage">'.
                    '<a class="item-link js_liimg"  data-aid="'.$work->archive_id.'" data-id="'.$work->id.'" id="liimg'.$lino.'" data-liid="'.$lino.'" data-likeid="'.$likeid.'" data-likestatus="'.$style.'" href="javascript:;">'.
                        '<div class="item-img show-uwokpraise-more">'.
                            '<img src="'.e($work->url).'?imageView2/2/w/275"  class="js_image" width="'.$swidth.'" height="'.$sheight.'" alt="'.$title.'">'.
                            '<div class="uwokpraise">'.
                                '<span class="uwokpraise-item" href="javascript:;">'.
                                    '<i class="uwokpraise-ico cyico-like-s-'.$style.' js_imglike"></i><!--cyico-like-s-red-->'.
                                    '<span class="item-num js_likecount">'.$this->formatNumber($work->like_count).'</span>'.
                                '</span>'.
                                '<span class="uwokpraise-item" href="javascript:;">'.
                                    '<i class="uwokpraise-ico cyico-commt-s-white"></i>'.
                                    '<span class="item-num">'.$this->formatNumber($work->comment_count).'</span>'.
                                '</span>'.
                            '</div>'.
                            $gifhtml.
                        '</div>'.
                    '</a>'.
                    '<h3 class="item-tit f-hide-col-1">'.($work->content).'</h3>'.
                    '<div class="item-info">'.
                        '<a href="http://gad.qq.com/user?id='.$work->user_id.'" target="_blank">'.
                            '<img class="info-img f-circle" src="'.e($work->avatar).'" width="30" height="30">'.
                            '<em class="info-name f-hide-col-1">'.$work->user_name.'</em>'.
                            '<span class="badge"><i class="'.($work->user->type==1 ? "gicos-bluev-s" : ($work->user->type == 2 ? "gicos-redv-s" : "") ).'"></i></span>'.
                        '</a>'.
                        '<span class="info-time">'.$this->formatTime($work->created_at).'</span>'.
                    '</div>'.
                    $tutorhtml.
                '</li>';
        return $html;
    }

    public function getLimitDesc($text, $length = 100)
    {
        $text = str_replace(["\r\n", "\n", "\r"], '', strip_tags($text));

        return str_limit($text, $length);
    }

    public function getPictureUrl($url)    {
        if (mb_strpos($url, '/') === 0) {
            return 'http://gad.qq.com'.$url;
        }

        if (mb_strpos($url, 'http://gadimg-10045137') === 0) {
            return $url.'?imageView2/2/w/250';
        }

        return $url;
    }


    protected  $ACTION = [
                            11=>"关注了用户",
                            12=>"关注了机构",
                            21=>"赞了文章",
                            22=>"赞了作品",
                            23=>"赞了问题回答",
                            24=>"赞了话题回答",
                            25=>"赞了评论",
                            31=>"收藏了日志",
                            32=>"收藏了作品",
                            33=>"收藏了问题",
                            34=>"收藏了话题",
                            41=>"发表了日志",
                            42=>"发表了作品",
                            43=>"发表了问题",
                            44=>"发表了话题",
                            45=>"评论了文章",
                            46=>"评论了作品",
                            47=>"参与了二级评论",
                            51=>"回答了问题",
                            52=>"参与了话题讨论",
                            61=>"参与了live"
                        ];

    public function getActionName($id)
    {
        return $this->ACTION[$id];
    }

    public function getChannelName ($id) {
        switch ($id) {
            case 10877:
                return 'VR';
            case 10591:
                return '开发';
            case 10396:
                return '美术';
            default:
                return '策划';
        }
    }
}
