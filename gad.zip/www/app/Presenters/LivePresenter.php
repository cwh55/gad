<?php

namespace App\Presenters;

use Carbon\Carbon;

class LivePresenter
{
    public function getStateClass($live)
    {
        if ($live->state) {
            return 'end';
        }

        $now = Carbon::now();
        if ($now >=  $live->begin_time) {
            return 'conduct';
        } else {
            return '';
        }
    }

    public function getAllTeacherName($teachers)
    {
        $link = '<a href="javascript:;" class="tips">%s</a>';
        $names = [];
        foreach ($teachers as $teacher) {
            $names[] = sprintf($link, e($teacher->nickname));
        }

        return implode('<span>、</span>', $names);
    }

    public function getMAllTeacherName($teachers)
    {
        $link = '<a class="userguest-name" href="javascript:;">%s</a>';
        $names = [];
        foreach ($teachers as $teacher) {
            $names[] = sprintf($link, mb_substr(e($teacher['nickname']),0,7).(mb_strlen($teacher['nickname'])>7?'...':''));
        }

        return implode('<span>、</span>', $names);
    }

    public function getAllTeacherLink($teachers)
    {
        $userTypeClass = ['' , '<span class="badge"><i class="gicos-bluev-s"></i></span>','<span class="badge"><i class="gicos-redv-s"></i></span>'];
        $link = '<a href="http://gad.qq.com/user/index?id=%s" class="name-wrap"><span class="tips f-hide-col-1">%s</span>%s</a>';
        $names = [];
        foreach ($teachers as $teacher) {
            $names[] = sprintf($link, $teacher->user_id, e($teacher->nickname),$userTypeClass[$teacher->user->type]);
        }

        return implode('<span>、</span>', $names);
    }

    public function getMTime($start, $end)
    {
        $tstart = strtotime($start);
        $tend = strtotime($end);
        return date('n', $tstart).'月'.date('j',$tstart).'日 '.date('H', $tstart).':'.date('i', $tstart).'-'.date('H', $tend).':'.date('i', $tend);
    }

    public function getDetailNav($request)
    {
        if ($request->is('m/live/list')) {
            return '<a href="/m/live/list" _HOTTAG="LIVE.LIST.ALL" ><em class="item curr">全部</em></a><a href="/m/live/my" _HOTTAG="LIVE.LIST.MY" ><em class="item">我的</em></a>';
        } else {
            return '<a href="/m/live/list" _HOTTAG="LIVE.DETAIL.ALL"><em class="item">全部</em></a><a href="/m/live/my" _HOTTAG="LIVE.DETAIL.MY"><em class="item curr">我的</em></a>';
        }
    }

    public function getPrice($live)
    {
        return floatval($live->price) ? $live->price.'元' : '免费';
    }

    public function getStateLabel($live)
    {
        $label = '';
        if ($live->state) {
            $label = '已结束';
            return $label;
        }

        $now = Carbon::now();
        if ($now >=  $live->begin_time) {
            $label = '进行中';
        } elseif ($days = $live->begin_time->diffInDays($now)) {
            $label = $days.'天后开始';
        } elseif ($hours = $live->begin_time->diffInHours($now)) {
            $label = $hours.'小时后开始';
        } else {
            $minutes = $live->begin_time->diffInMinutes($now);
            $label = max($minutes, 1).'分钟后开始';
        }

        return $label;
    }

    public function getLimitDesc($text, $length = 80)
    {
        $text = str_replace(["\r\n", "\n", "\r"], '', $text);

        return str_limit($text, $length);
    }

    public function getFirstTeacherHeadUrl($teachers)
    {
        $teacher = $teachers->first();
        $url = ($teacher AND $teacher->avatar) ? e($teacher->avatar) : 'http://q3.qlogo.cn/g?b=qq&k=d2ouia2pjyQd86BrdSeSYtw&s=100';

        return $url;
    }
}