<?php

use Illuminate\Support\Facades\Log;

function mock_course_user_count($count) {
    if ($count <= 8) {
        return $count;
    }

    $rand = $count > 5 ? ($count % 5) : 0;

    return $count * 5 + $rand;
}

function mock_course_online_count($count, $times = 5) {
    $rand = $count % $times;

    return $count * $times + $rand;
}

function create_lvb_channel($channelName, $sourceName) {
    $url = sprintf('http://10.213.154.2:8080/api/Live.php?act=createChannel&channelName=%s&sourceName=%s', $channelName, $sourceName);
    $res = file_get_contents($url);
    if ($res === false) {
        Log::error('创建直播频道失败', ['url' => $url]);

        return ['code' => 5100, 'message' => '创建直播频道失败'];
    }

    $result = (array) json_decode($res);
    if ($result === null OR empty($result['channel_id'])) {
        Log::error('创建直播频道返回结果出错', ['res' => $result]);

        return ['code' => 5101, 'message' => '创建直播频道失败'];
    }

    return $result;
}

function describe_lvb_channel($channelId) {
    $url = sprintf('http://10.213.154.2:8080/api/Live.php?act=describeChannel&channelId=%s', $channelId);
    $res = file_get_contents($url);
    if ($res === false) {
        Log::error('查询直播频道信息失败', ['url' => $url]);

        return ['code' => 5201, 'message' => '查询直播频道信息失败'];
    }

    $result = (array) json_decode($res);
    if ($result === null OR empty($result['channelInfo'])) {
        Log::error('查询直播频道信息返回结果出错', ['res' => $result]);

        return ['code' => 5202, 'message' => '查询直播频道信息失败'];
    }

    return $result;
}

function fetch_and_start_lvb_channel() {
    $channelRet = describe_lvb_channel_list();
    if ($channelRet['code'] == 0 AND $channelRet['all_count'] > 0) {
        $channel = array_first($channelRet['channelSet']);
        $channelInfo = describe_lvb_channel($channel->channel_id);
        if ($channelInfo['code'] === 0) {
            $channelInfo = $channelInfo['channelInfo'][0];
            $source = $channelInfo->upstream_list[0];
            $result = start_lvb_channel($channel->channel_id);
            if ($result['code'] == 0) {
                $result = create_lvb_record($channelInfo->channel_id);
                if ($result['code'] == 0) {
                    return ['code' => 0, 'channelId' => $channelInfo->channel_id,
                        'sourceId' => $source->sourceID, 'taskId' => $result['task_id']];
                }
            }
        }
    }

    return ['code' => 5301, 'message' => '查询空闲和启动频道失败'];
}

function describe_lvb_channel_list($channelStatus = 3) {
    $url = sprintf('http://10.213.154.2:8080/api/Live.php?act=describeChannelList&channelStatus=%s', $channelStatus);
    $res = file_get_contents($url);
    if ($res === false) {
        Log::error('查询空闲频道出错', ['url' => $url]);

        return ['code' => 5401, 'message' => '查询空闲频道失败'];
    }

    $result = (array) json_decode($res);
    if (!empty($result['code'])) {
        Log::error('查询空闲频道出错', ['res' => $result]);

        return ['code' => $result['code'], 'message' => $result['message']];
    }

    return $result;
}

function start_lvb_channel($channelId) {
    $url = sprintf('http://10.213.154.2:8080/api/Live.php?act=startChannel&channelId=%s', $channelId);
    $res = file_get_contents($url);
    if ($res === false) {
        Log::error('启用频道出错', ['url' => $url]);

        return ['code' => 5501, 'message' => '启用频道失败'];
    }

    $result = (array) json_decode($res);
    if (!empty($result['code'])) {
        Log::error('启用频道出错', ['res' => $result]);

        return ['code' => $result['code'], 'message' => $result['message']];
    }

    return $result;
}

function stop_lvb_channel($channelId) {
    $url = sprintf('http://10.213.154.2:8080/api/Live.php?act=stopChannel&channelId=%s', $channelId);
    $res = file_get_contents($url);
    if ($res === false) {
        Log::error('关闭频道出错', ['url' => $url]);

        return ['code' => 5601, 'message' => '关闭频道失败'];
    }

    $result = (array) json_decode($res);
    if (!empty($result['code'])) {
        Log::error('关闭频道出错', ['res' => $result]);

        return ['code' => $result['code'], 'message' => $result['message']];
    }

    return $result;
}

function create_lvb_record($channelId) {
    $url = sprintf('http://10.213.154.2:8080/api/Live.php?act=createRecord&channelId=%s', $channelId);
    $res = file_get_contents($url);
    if ($res === false) {
        Log::error('创建录制任务失败', ['url' => $url]);

        return ['code' => 5701, 'message' => '创建录制任务失败'];
    }

    $result = (array) json_decode($res);
    if ($result === null OR empty($result['task_id'])) {
        Log::error('创建录制任务返回结果出错', ['res' => $result]);

        return ['code' => 5702, 'message' => '创建录制任务失败'];
    }

    return $result;
}

function stop_lvb_record($channelId, $taskId) {
    $url = sprintf('http://10.213.154.2:8080/api/Live.php?act=stopRecord&channelId=%s&taskId=%s', $channelId, $taskId);
    $res = file_get_contents($url);
    if ($res === false) {
        Log::error('终止录制任务失败', ['url' => $url]);

        return ['code' => 5801, 'message' => '终止录制任务失败'];
    }

    $result = (array) json_decode($res);
    if ($result === null) {
        Log::error('终止录制任务返回结果出错', ['res' => $result]);

        return ['code' => 5802, 'message' => '终止录制任务失败'];
    }

    return $result;
}

/**
 * xss等相关过滤处理
 * @param unknown $param
 * @param bool isNormal true 非富文本 false 富文本内容  默认为true
 */
function xssFilter1(& $param, $isNormal=true){
    if(empty($param)){
        return $param;
    }
    if(is_array($param) || is_object($param)) {
        foreach ($param as & $val){
            call_user_func(__FUNCTION__, $val);
        }
        return $param;
    }
    //首先进行解码操作
    $param = urldecode($param);
    if($isNormal){
        $param = addslashes(strip_tags($param));
        //非数字进行实体转义
        if(!is_numeric($param)){
            $param = js_encode($param);
            $param = SECAPI_HtmlEncode($param);
        }
    }else{
        // 富文本对html标签属性进行过滤
        $param = SECAPI_fileterHtml($param);
    }

    return $param;
}

/**
 *安全api过滤富文本
 *@param	string	$str	字符串
 *@encode	string	$encode	编码(utf-8)
 *@return string
 */
function xssFilter($param){
	static $secApi;
	static $config;
    if(empty($param)){
        return $param;
    }
    if(is_array($param) || is_object($param)) {
        foreach ($param as & $val){
            $val = call_user_func(__FUNCTION__, $val);
        }
        return $param;
    }
    //首先进行解码操作
    //$param = urldecode($param);

    try{
        if (!$secApi) {
            $secApi  = new SECAPI_AntiXss(true);
        }
        if (!$config) {
			$path = config_path();
			$path .= '/secapi.conf';
			//$fh = fopen($path.'secapi.conf', "rb");
            $config = file_get_contents($path);
        }

        //$str = iconv('utf-8', 'gbk//ignore', $str);
        $param = str_replace(['{', '}'], ['｛', '｝'], $param);
        $returnstr = $secApi->FilterAllActiveContent($config, $param);
        $returnstr = preg_replace('/{{/','',$returnstr);
        /*$returnstr = iconv('gbk', 'utf-8//ignore', $returnstr);
        $filterwords = array("script", "onload", "onerror", "iframe", "onfocus", "onblur", "onchange" ,"onclick");
        foreach($filterwords as $key => $val){
            $returnstr = preg_replace("/{$val}/si", "", $returnstr);
        }*/
        $returnstr = preg_replace('/{{/','',$returnstr);
        return $returnstr;
    }catch(Exception $e){
        return $param;
    }
}

/**
 *安全api urI 实体转义
 *@param	string	$str	字符串
 *@encode	string	$encode	编码(utf-8)
 *@return string
 */
function filterBySecApi($str = '', $type=''){
    try{
        $str = iconv('utf-8', 'gbk//ignore', $str);
        switch($type) {
            case 'json':
                $returnstr = SECAPI_AntiXss::JsonEncode($str);
                break;
            case 'js':
                $returnstr = SECAPI_AntiXss::JavaScriptEncode($str); //对uri安全过滤
                break;
            case 'url':
                $returnstr = SECAPI_AntiXss::UrlFilterAndEncode($str); //对uri安全过滤
                break;
            case 'urlcomponent':
                $returnstr = SECAPI_AntiXss::UriComponentEncode($str); //对uri安全过滤
                break;
            default:
                $returnstr = $str;
        }
        $returnstr = iconv('gbk', 'utf-8//ignore', $returnstr);
        return $returnstr;
    }catch(Exception $e){
        return $str;
    }
}

/**
 *安全api过滤富文本
 *@param	string	$str	字符串
 *@encode	string	$encode	编码(utf-8)
 *@return string
 */
function SECAPI_fileterHtml($str){
    try{
        $str = iconv('utf-8', 'gbk//ignore', $str);
        $path = config_path();
        $fh = fopen($path.'secapi.conf', "rb");
        $data = fread($fh, 4096*2);
        $returnstr = SECAPI_AntiXss::FilterAllActiveContent($data,$str);
        $returnstr = iconv('gbk', 'utf-8//ignore', $returnstr);
        $filterwords = array("script", "onload", "onerror", "iframe", "onfocus", "onblur", "onchange" ,"onclick");
        foreach($filterwords as $key => $val){
            $returnstr = preg_replace("/{$val}/si", "", $returnstr);
        }
        return $returnstr;
    }catch(Exception $e){
        return $str;
    }
}

/**
 *安全api URI 实体转义
 *@param	string	$str	字符串
 *@encode	string	$encode	编码(utf-8)
 *@return string
 */
function SECAPI_HtmlEncode($str = ''){
    try{
        $str = iconv('utf-8', 'gbk//ignore', $str);
        $returnstr = SECAPI_AntiXss::HtmlEncode($str); //对html的编码
        $returnstr = iconv('gbk', 'utf-8//ignore', $returnstr);
        return $returnstr;
    }catch(Exception $e){
        return $str;
    }
}

/**
 *安全api URI 实体转义
 *@param	string	$str	字符串
 *@encode	string	$encode	编码(utf-8)
 *@return string
 */
function SECAPI_HtmlAttributeEncode($str = ''){
    try{
        $str = iconv('utf-8', 'gbk//ignore', $str);
        $returnstr = SECAPI_AntiXss::HtmlAttributeEncode($str); //对html属性的编码过滤 但是不适用于style src href等属性的过滤
        $returnstr = iconv('gbk', 'utf-8//ignore', $returnstr);
        return $returnstr;
    }catch(Exception $e){
        return $str;
    }
}

function fileterNumber($str = 0){
    if(is_numeric($str)){
        return $str;
    }
    return 0;
}

/*
 * 过滤uri url中不带http:
 * @param string $str
 * @return string
 */
function filterUristr($str = ''){
    if(empty($str)){
        return '';
    }
    $filterwords = array("script", "onload", "onerror", "iframe", "onfocus", "onblur", "onchange" ,"onclick", "%0a", "%0d","\/r" ,"\/n"," ","\r\n");
    foreach($filterwords as $key => $val){
        $str = preg_replace("/{$val}/si", "", $str);
    }
    $str = filterBySecApi($str, 'urlcomponent');
    return $str;
}

/**
 * 对javascript的编码 调用安全api存在问题 须手动写了
 * 过滤规则 需要将红色的不可信内容中做如下的转码: [a-zA-Z0-9.-_,]以及ASC值大于0x80之外的所有字符转化为\x**这种形式，
 * @param string $str
 * @return string
 */
function js_encode($str){
    try{
        $replacestr = $str;
        for($i=0;$i<strlen($str);$i++){
            if(preg_match("/^[0-9a-zA-Z-\.,_~'\"&<>%]$/", $str[$i]) || ord($str[$i]) >= 0x80 ){
                continue;
            }else{
                $rep = sprintf("\\x%02d", ord($str[$i]));
                $replacestr = str_replace($str[$i], $rep, $replacestr);
            }
        }
        return $replacestr;
    }catch(Exception $e){

        return $str;
    }

}

/*
 * 字符串超过限制长度加省略号
 */
function str_cut($str,$limite_length){
   if(mb_strlen($str,'UTF-8')>$limite_length)
        return mb_substr($str,0,$limite_length,'UTF-8').'...';
    
    return $str;
}

/*
 * 获取archive对应的channel_id
 */
function getChannelId($tags) {
    if(!empty($tags)) {
        $tArr = array(1 => 10001, 2 => 10396, 3 => 10591, 4 => 10877, 5 => 11102, 6 => 11104, 7 => 10168, 8=> 11223);
        foreach ($tags as $val1) {
            foreach($tArr as $key => $val) {
                if ($val == $val1['id'] || $val == $val1['p1']) {
                    return $key;
                }
            }
        }
    }
    return 0;
}