<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        Commands\Inspire::class,
        Commands\Jnh::class,
        Commands\SiteMap::class,
        Commands\Feeds::class,
        Commands\FeedsLike::class,
        Commands\FeedsFollow::class,
        Commands\FeedsFavorite::class,
        Commands\FeedsLive::class,
        Commands\FetchVodConvertResult::class,
        Commands\Weixin\Notify::class,
        Commands\Weixin\Subscriber::class,
        Commands\Weixin\Live::class,
        Commands\PushProjectToExpert::class,
        Commands\SetImagesize::class,
        Commands\CommentInit::class,
        Commands\AtlasInit::class,
        Commands\SyncTgdUser::class,
        Commands\ImportMofangAssets::class,
        Commands\UpdateMofangAssets::class,
        Commands\SearchDataSync::class,
        Commands\SubmitArchiveToBaidu::class
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('weixin:live:notify')->everyMinute();
        //$schedule->command('my:feeds:sync')->everyMinute();
        //$schedule->command('my:feeds:like:sync')->everyMinute();
        $schedule->command('my:feeds:follow:sync')->everyMinute();
        //$schedule->command('my:feeds:favorite:sync')->everyMinute();
        //$schedule->command('my:feeds:live:sync')->everyFiveMinutes();

        $schedule->command('my:pushProject')->weekly()->mondays()->at('15:00'); // 推送项目给专家点评
    }
}
