<?php

namespace App\Console\Commands;

use App\Gad\Mofang;
use App\Repositories\ArchiveRepository;
use App\Repositories\AtlasRepository;
use App\Repositories\PictureRepository;
use Exception;
use Illuminate\Console\Command;

class UpdateMofangAssets extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'update:asset {id?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '更新磨坊导入作品';

    /**
     * @var ArchiveRepository
     */
    protected $archiveRepository;

    /**
     * @var AtlasRepository
     */
    protected $atlasRepository;

    /**
     * @var PictureRepository
     */
    protected $pictureRepository;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(ArchiveRepository $archiveRepository, AtlasRepository $atlasRepository,
                                PictureRepository $pictureRepository)
    {
        parent::__construct();

        $this->archiveRepository = $archiveRepository;
        $this->atlasRepository = $atlasRepository;
        $this->pictureRepository = $pictureRepository;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $id = $this->argument('id');
        if ($id) {
            $pictures = $this->pictureRepository->findWhere(['mofang_id', $id]);
        } else {
            $pictures = $this->pictureRepository->findWhere(['mofang_id', '<>', 0]);
        }

        foreach ($pictures as $picture) {
            try {
                if (is_null($picture->archive)) {
                    continue;
                }

                $asset = $this->getAssetData($picture->mofang_id);
                $this->updateAsset($picture->archive, $asset);
            } catch (Exception $e) {
                $this->error($e->getMessage());
            }
        }
    }

    public function updateAsset($archive, $asset)
    {
        $this->archiveRepository->update($archive, ['description' => $asset->desc]);
        $this->atlasRepository->update($archive->atlas, ['rights' => $this->getRightId($asset)]);
        $this->info('更新完成：'.$asset->id.', '.$archive->id);
    }

    private function getAssetData($id)
    {
        $asset = Mofang::getDetail($id);
        if (empty($asset->id)) {
            throw new Exception('模型已下架：'.$id);
        }

        return $asset;
    }

    private function getRightId($asset)
    {
        $extInfo = json_decode($asset->extr_info, true);
        if (empty($extInfo) OR empty($extInfo['license'])) {
            return 0;
        }

        return Mofang::getRightType($extInfo['license']);
    }
}
