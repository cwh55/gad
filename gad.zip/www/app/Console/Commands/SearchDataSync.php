<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use App\Qcloud\Search\Api as QcloudSearch;
use App\Repositories\ArchiveRepository;
use App\Repositories\UserRepository;
use App\Repositories\TagRepository;
class SearchDataSync extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'search:sync {type=archive}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '向云搜推送用于搜索的数据';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(
        QcloudSearch $search,
        ArchiveRepository $archiveRepository
    ){
        parent::__construct();
        $this->search = $search;
        $this->archive = $archiveRepository;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $actionType = $this->argument('type');
        switch ($actionType){
            case 'archive' :
                $this->archiveSync();
                break;
            case 'user' :
                $this->userInfoSync();
                break;
            case 'tag' :
                $this->tagSync();
                break;
            default :
                $this->archiveSync();
                $this->userInfoSync();
                $this->tagSync();
        }
    }
    public function archiveSync()
    {
        $this->comment('上传Archive任务开始');
        $flag = true;
        $page = 1;
        $pageSize = 1;
        while($flag) {
            $archives =  $this->archive->paginate($pageSize, ['*'], 'page', $page);
            $this->comment('装载archive_id:'.$archives[0]->id."数据,第{$page}页");
            $res = $this->search->add('ARCHIVE',$archives);
            $this->responseHandle($res);
            if(!$archives->hasMorePages()) {
                $flag = false;
            }else{
                $page++;
            }
        }
    }
    public function userInfoSync(){
        $this->comment('上传user任务开始');
        $flag = true;
        $page = 1;
        $pageSize = 10;
        $user = new UserRepository();
        while($flag) {
            $users = $user->paginate($pageSize, ['*'], 'page', $page);
            $this->comment('装载user_id:'.$users[0]->UserId.'~'.$users[count($users) - 1]->UserId."数据");
            $res = $this->search->add('USER',$users);
            $this->responseHandle($res);
            if(!$users->hasMorePages()) {
                $flag = false;
            }else{
                $page++;
            }
        }
    }
    public function tagSync(){
        $this->comment('上传tag任务开始');
        $flag = true;
        $page = 1;
        $pageSize = 10;
        $tagRepository= new TagRepository();
        while($flag) {
            $tags = $tagRepository->paginate($pageSize, ['*'], 'page', $page);
            $this->comment('装载tag_id:'.$tags[0]->id.'~'.$tags[count($tags) - 1]->id."数据");
            $res = $this->search->add('TAG',$tags);
            $this->responseHandle($res);
            if(!$tags->hasMorePages()) {
                $flag = false;
            }else{
                $page++;
            }
        }
    }
    private function responseHandle($res)
    {
        if ($res['status'] === -1) {
            // 请求失败，解析错误信息
            $this->error('Error Code :'.$res['code']."\nMessage : ".$res['message']);
            return false;
            // 对于异步任务接口，可以通过下面的方法获取对应任务执行的信息
            // $detail = $error->getExt();
        } else {
            // 请求成功
           $this->comment('数据提交成功');
           return true;
        }
    }
}

