<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-11-7
 * Time: 上午10:19
 */

namespace App\Console\Commands;


use App\Models\Content;
use Illuminate\Console\Command;
use Redis;

class Jnh extends Command
{
    /**
     * The name and signature of the console command.
     *create 生成
     * delete 删除
     * @var string
     */
    protected $signature = 'jnh:user';

    /**
     * The console command description.
     *将嘉年华用户名单写到redis 里面
     * @var string
     */
    protected $description = '生成嘉年华抽奖名单';

    //redis key
    const WHITE_LIST_KEY = 'gad:act:user:jnh:whitelist';
    const QQ_WHITE_LIST_KEY = 'gad:act:user:jnh:qqwhitelist';

    /**
     * Execute the console command.
     *
     * @return mixed
     */

    public function handle()
    {
        $userIds = Content::getJnhUserIds();
        $userQQs = Content::getJnhUserQQs($userIds);
        $redis = Redis::connection('act');
        $redis->del(self::WHITE_LIST_KEY);
        $redis->del(self::QQ_WHITE_LIST_KEY);
        foreach ($userIds as $id) {
            $redis->sAdd(self::WHITE_LIST_KEY,$id);
        }
        foreach ($userQQs as $qq) {
            $redis->sAdd(self::QQ_WHITE_LIST_KEY,$qq);
        }
        $tmp = $redis->sMembers(self::QQ_WHITE_LIST_KEY);

        $this->info('嘉年华白名单生成完成,共'.count($tmp).'人');
    }
} 