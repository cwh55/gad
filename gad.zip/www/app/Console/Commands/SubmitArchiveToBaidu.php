<?php

namespace App\Console\Commands;

use App\Exceptions\GadException;
use App\Repositories\ArchiveRepository;
use Illuminate\Console\Command;

class SubmitArchiveToBaidu extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'community:baidu';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '提交文档到百度';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @param ArchiveRepository $archiveRepository
     */
    public function handle(ArchiveRepository $archiveRepository)
    {
        $page = 0;
        do {
            $archives = $this->getArchives($archiveRepository, $page);
            foreach ($archives as $archive) {
                $url = $this->getUrl($archive);
                dispatch(new \App\Jobs\SubmitBaidu($url));
            }

            $page++;
        } while ($archives->count() == 20);
    }

    private function getArchives(ArchiveRepository $archiveRepository, $page)
    {
        $result = $archiveRepository->where('status', '=', 0)
            ->where('publish_time', '>', '2017-12-27')
            ->limit(20)->offset($page * 20)->findAll();

        return $result;
    }

    private function getUrl($archive)
    {
        if (app()->isLocal()) {
            throw new GadException('测试环境无须提交百度');
        }

        $path = '';
        switch ($archive->class_id) {
            case 1:
                $path = '/article/detail/'.$archive->id;
                break;
            case 2:
                $path = '/resource/detail/'.$archive->id;
                break;
            case 3:
                $path = '/question/detail/'.$archive->id;
                break;
            case 4:
                $path = '/topic/detail/'.$archive->id;
                break;
        }

        return sprintf('http://gad.qq.com%s', $path);
    }
}
