<?php

namespace App\Console\Commands;

use App\Entities\Archive;
use App\Gad\Mofang;
use App\Gad\Tgd;
use App\Models\User;
use App\Repositories\ArchiveRepository;
use App\Repositories\AtlasRepository;
use App\Repositories\PictureRepository;
use App\Repositories\TagRepository;
use Exception;
use GuzzleHttp\Client;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Collection;
use Tencent\CL5\Client as CL5;

class ImportMofangAssets extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:asset {file}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '从csv导入磨坊作品';

    /**
     * @var Client
     */
    protected $client;

    /**
     * @var ArchiveRepository
     */
    protected $archiveRepository;

    /**
     * @var AtlasRepository
     */
    protected $atlasRepository;

    /**
     * @var PictureRepository
     */
    protected $pictureRepository;

    /**
     * @var TagRepository
     */
    protected $tagRepository;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(ArchiveRepository $archiveRepository, AtlasRepository $atlasRepository,
                                PictureRepository $pictureRepository, TagRepository $tagRepository)
    {
        parent::__construct();

        $this->archiveRepository = $archiveRepository;
        $this->atlasRepository = $atlasRepository;
        $this->pictureRepository = $pictureRepository;
        $this->tagRepository = $tagRepository;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $file = $this->argument('file');
        $filePath = realpath($file);
        if ($filePath === false) {
            return $this->error('文件不存在：'.$file);
        }

        $rows = file($filePath);
        $num = 0;
        foreach ($rows as $row) {
            $id = trim($row);
            try {
                $exist = $this->pictureRepository->findBy('mofang_id', $id);
                if ($exist) {
                    continue;
                }

                $asset = $this->getAssetData($id);
                $user = $this->getUserData($asset->account);
                $this->saveAsset($asset, $user);
                $num++;
            } catch (Exception $e) {
                $this->error($e->getMessage());
            }
        }

        $this->info('导入完成：'.$num.'条');
    }

    private function saveAsset($asset, $user)
    {

        $publishTime = strtotime($asset->publish_time);
        $archiveData = [
            'title' => $asset->name,
            'description' => $asset->desc,
            'status' => 0,
            'tag' => '3D',
            'cover' => $asset->thumbnails,
            'channel_id' => 2,
            'class_id' => Archive::TYPE_WORKS,
            'user_id' => $user->UserId,
            'user_name' => $user->NickName,
            'creator' => $user->UserId,
            'sort_time' => $publishTime,
            'extra' => [],
            'total' => 1,
            'publish_time' => date('Y-m-d H:i:s', $publishTime)
        ];
        list($result, $archive) = $this->archiveRepository->create($archiveData);
        if ($result === false) {
            throw new Exception('Archive创建失败：'.$asset->id);
        }

        $atlasData = [
            'archive_id' => $archive->id,
            'rights' => $this->getRightId($asset),
            'from_type' => 1,
            'type' => 1,
            'modelface_count' => $asset->model_face_count,
            'attachments' => [],
            'match_qq' => '',
            'city' => ''
        ];
        list($result, $atlas) = $this->atlasRepository->create($atlasData);
        if ($result === false) {
            throw new Exception('Atlas创建失败：'.$asset->id);
        }

        $imageSize = $this->getImgSize($archive->cover);
        $pictureData = [
            'archive_id' => $archive->id,
            'channel_id' => 15,
            'type' => 1,
            'user_id' => $user->UserId,
            'user_name' => $user->NickName,
            'url' => $archive->cover,
            'content' => '',
            'sort' => 1,
            'status' => 0,
            'publish_time' => $archive->publish_time,
            'width' => $imageSize['width'],
            'height' => $imageSize['height'],
            'source_type' => 'model',
            'mofang_id' => $asset->id,
            'videourl' => ''
        ];
        list($result, $picture) = $this->pictureRepository->create($pictureData);
        if ($result === false) {
            throw new Exception('作品model创建失败：'.$asset->id);
        }

        $tag = $this->tagRepository->find('10506');
        if ($tag) {
            $this->archiveRepository->addTags($archive, new Collection([$tag]));
        }

        $this->archiveRepository->update($archive, ['extra' => [['id' => $picture->id, 'url' => $archive->cover]]]);
    }

    private function getAssetData($id)
    {
        $asset = Mofang::getDetail($id);
        if (empty($asset->id)) {
            throw new Exception('模型已下架：'.$id);
        }

        if (strpos($asset->thumbnails, 'http') === false) {
            $asset->thumbnails = 'http:'.$asset->thumbnails;
        } else {
            $asset->thumbnails = str_replace('https', 'http', $asset->thumbnails);
        }

        $asset->account = Mofang::getAccount($asset->account_id);

        return $asset;
    }

    private function getUserData($account)
    {
        static $users = [];

        if (isset($users[$account->authuid])) {
            return $users[$account->authuid];
        }

        $id = (int) trim(strstr($account->authuid, '_'), '_');
        if (empty($id)) {
            throw new Exception('用户TGD帐号ID异常：'.$account->authuid);
        }

        $user = User::where('tgd_uid', $id)->first();
        if ($user) {
            $users[$account->authuid] = $user;

            return $user;
        }

        $ret = Tgd::getUser($id);
        $tgdUser = $ret->data;
        $userData = [
            'NickName' => $tgdUser->nickname,
            'Avatar' => $tgdUser->head_img_url,
            'tgd_uid' => $tgdUser->id,
            'Created' => date('Y-m-d h:i:s'),
            'Modified' => date('Y-m-d h:i:s')
        ];
        if ($tgdUser->source == 'qq') {
            $userData['QQNo'] = $tgdUser->uid;
        } else {
            $userData['WeixinId'] = $tgdUser->uid;
        }

        $user = User::create($userData);
        $users[$account->authuid] = $user;

        return $user;
    }

    private function getImgSize($url) {
        $config = [
            'modId' => config('app.http_proxy_cl5_modId'),
            'cmdId' => config('app.http_proxy_cl5_cmdId'),
            'default' => ['hostIp' => '10.213.154.2', 'hostPort' => 8080]
        ];
        $server = CL5::getRoute($config, app()->isLocal());
        $proxy = $server['hostIp'].':'.$server['hostPort'];
        $opts = array(
            'http'=>array(
                'method'=>"GET",
                'proxy' => $proxy,
                'request_fulluri'=>true
            )
        );
        $imginfo = [];
        try {
            $context = stream_context_create($opts);
            $data = @file_get_contents($url,FALSE,$context);
            $image = imagecreatefromstring($data);
            $imginfo['width'] = imagesx($image);
            $imginfo['height'] = imagesy($image);
        } catch (\Exception $e) {
            $imginfo = ['width' => 0, 'height' => 0];
        }

        return $imginfo;
    }

    private function getRightId($asset)
    {
        $extInfo = json_decode($asset->extr_info, true);
        if (empty($extInfo) OR empty($extInfo['license'])) {
            return 0;
        }

        return Mofang::getRightType($extInfo['license']);
    }
}
