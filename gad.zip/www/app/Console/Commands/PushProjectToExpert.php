<?php

namespace App\Console\Commands;

use App\Repositories\HatchProjectRepository;
use Illuminate\Console\Command;
use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Cache;

class PushProjectToExpert extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'my:pushProject';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = "推送项目给专家点评";

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $push_mail_status = Cache::get('push_mail_status', false); // 是否开始自动推送状态
        if ($push_mail_status) {
            $hatchProjectRepository = new  HatchProjectRepository();
            $hatchProjectRepository->pushMailToExpert();
            $this->info('推送项目给专家点评完成');
        }
    }
}
