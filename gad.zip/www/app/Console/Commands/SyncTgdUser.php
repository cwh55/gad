<?php

namespace App\Console\Commands;

use App\Repositories\TagRepository;
use App\Repositories\UserRepository;
use Exception;
use GuzzleHttp\Client;
use Illuminate\Console\Command;

class SyncTgdUser extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sync:tgd:user';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '同步特定GAD用户到TGD';

    /**
     * @var Client
     */
    protected $client;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();

        $tgdHost = app()->isLocal() ? 'http://dev.tgd.qq.com' : 'http://tgd.qq.com';
        $this->client = new Client([
            'base_uri' => $tgdHost,
            'timeout' => 10,
            'auth' => ['gad', 'gad666'],
            'http_errors' => false
        ]);
    }

    /**
     * @param UserRepository $userRepository
     * @param TagRepository $tagRepository
     */
    public function handle(UserRepository $userRepository, TagRepository $tagRepository)
    {
        $this->comment('同步TGD用户中...');
        $page = 1;
        $tag = $tagRepository->find(10506);
        $syncedUsers = [];
        do {
            $archives = $tagRepository->getArchiveListForMofang($tag, $page);
            foreach ($archives as $archive) {
                if ($archive->user->tgd_uid OR in_array($archive->user_id, $syncedUsers)) {
                    continue;
                }

                try {
                    $result = $this->syncUser($archive->user);
                    if ($result->code == 0 AND !empty($result->data->id)) {
                        list($updated, $user) = $userRepository->update($archive->user, ['tgd_uid' => $result->data->id]);
                        if ($updated) {
                            $syncedUsers[] = $archive->user_id;
                        }
                    } else {
                        $this->error($result->message);
                    }
                } catch (Exception $e) {
                    $this->error('用户['.$archive->user_id.']向TGD同步失败:'.$e->getMessage());
                }
            }
            $page += 1;
        } while ($archives->count() === 50);

        $this->info('同步TGD用户完毕');
    }

    public function syncUser($user)
    {
        $data = [
            'uid' => $user->QQNo ? $user->QQNo : $user->WeixinId,
            'source' => $user->QQNo ? 'qq' : 'weixin',
            'nickname' => $user->NickName,
            'sex' => 0,
            'head_img_url' => $user->Avatar,
            'ip' => $user->ip ? $user->ip : ''
        ];

        $response = $this->client->request('GET', '/auth/token/sync', [
            'query' => [
                'platformId' => 100003,
                'user' => $data
            ],
            'proxy' => ''
        ]);

        if ($response->getStatusCode() != 200) {
            throw new Exception('TGD sync接口请求失败：'.$response->getReasonPhrase());
        }
        $body = $response->getBody();
        $result = json_decode($body);
        if ($result === null) {
            throw new Exception('TGD sync接口请求返回异常：'.$body);
        }

        return $result;
    }
}
