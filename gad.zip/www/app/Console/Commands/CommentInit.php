<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Repositories\ArchiveRepository;
use App\Repositories\CommentRepository;
use App\Repositories\PictureRepository;
use Mockery\CountValidator\Exception;

class CommentInit extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'comment:init';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'init all comments of works';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $picture = new PictureRepository();
        $comment = new CommentRepository();
        $picturelist = $picture->where('type', '=', 1)->findAll(['id', 'archive_id']);
        //$picturelist = $this->picture->whereIn('archive_id', [17648, 3134])->findAll(['id', 'archive_id']);
        $this->output->progressStart(count($picturelist));
        foreach ($picturelist as $item) {
            $commentlist = $comment->where('model_type', '=', "App\\Entities\\Picture")->where('model_id', '=', $item->id)->findAll();
            //一级评论
            foreach ($commentlist as $com) {
                $old1 = $comment->where('model_type', '=', "App\\Entities\\Archive")->where('model_id', '=', $item->archive_id)
                    ->where('user_id', '=', $com->user_id)->where('created_at', '=', $com->created_at)->findAll();
                //图集里没有对应一级评论，添加
                if (!count($old1)) {
                    $data = [
                        'model_id' => $item->archive_id,
                        'model_type' => "App\\Entities\\Archive",
                        'comment' => $com->comment,
                        'image' => $com->image,
                        'user_id' => $com->user_id,
                        'user_name' => $com->user_name,
                        'at_user' => $com->at_user,
                        'at_name' => $com->at_name,
                        'like_count' => $com->like_count,
                        'comment_count' => 0,
                        'status' => $com->status,
                        'updater' => $com->updater,
                        'created_at' => $com->created_at

                    ];
                    $res1 = $comment->create($data);
                }
                if (count($old1)) {
                    $obj = $old1[0];
                } else {
                    if ($res1[0]) {
                        $obj = $res1[1];
                    } else {
                        continue;
                    }
                }
                //旧评论的二级评论添加到新的图集评论中
                $sublist = $comment->where('model_type', '=', "App\\Entities\\Comment")->where('model_id', '=', $com->id)->findAll();
                foreach ($sublist as $sub) {
                    $old2 = $comment->where('model_type', '=', "App\\Entities\\Comment")->where('model_id', '=', $obj->id)
                        ->where('user_id', '=', $sub->user_id)->where('created_at', '=', $sub->created_at)->findAll();
                    if (!count($old2)) {
                        $subdata = [
                            'model_id' => $obj->id,
                            'model_type' => "App\\Entities\\Comment",
                            'comment' => $sub->comment,
                            'image' => $sub->image,
                            'user_id' => $sub->user_id,
                            'user_name' => $sub->user_name,
                            'at_user' => $sub->at_user,
                            'at_name' => $sub->at_name,
                            'like_count' => $sub->like_count,
                            'comment_count' => $sub->comment_count,
                            'status' => $sub->status,
                            'updater' => $sub->updater,
                            'created_at' => $sub->created_at
                        ];
                        $res2 = $comment->create($subdata);
                        if ($res2[0]) {
                            $obj->increment('comment_count', 1);
                        }
                    }
                }
            }
            $this->output->progressAdvance();
        }
        $this->output->progressFinish();
    }
}
