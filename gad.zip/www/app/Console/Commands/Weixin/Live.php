<?php

namespace App\Console\Commands\Weixin;

use App\Jobs\SendLiveStartNotify;
use App\Repositories\LiveRepositoryEloquent;
use App\Repositories\LiveSignRepositoryEloquent;
use Carbon\Carbon;
use Illuminate\Console\Command;

class Live extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'weixin:live:notify';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Live课前5分钟发送微信提醒';

    protected $live;
    protected $sign;

    public function __construct(LiveRepositoryEloquent $live, LiveSignRepositoryEloquent $sign)
    {
        parent::__construct();

        $this->live = $live;
        $this->sign = $sign;
    }

    public function handle()
    {
        $lives = $this->live->findWhere([
            'state' => 0,
            'rowstatus' => 0,
            'weixin_tips' => 0
        ]);
        $now = Carbon::today()->setTime(date('H'), date('i'));
        foreach ($lives as $live) {
            $interval = $now->diffInMinutes($live->begin_time, false);
            if ($interval > 0 AND $interval <= 5) {
                $signers = $this->sign->getSignersByLive($live);
                $this->sendLiveUserNotify($live, $signers);
            }
        }
    }

    private function sendLiveUserNotify($live, $signers)
    {
        foreach ($signers as $signer) {
            if ($signer->user->WeixinId) {
                $job = new SendLiveStartNotify($live, $signer->user);
                dispatch($job);
            }
        }

        $this->live->update(['weixin_tips' => 1], $live->id);
    }
}