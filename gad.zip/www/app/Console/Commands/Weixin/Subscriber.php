<?php

namespace App\Console\Commands\Weixin;

use App\Gad\Weixin;
use Illuminate\Console\Command;
use Redis;

class Subscriber extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'weixin:subscriber';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '缓存微信公众号关注用户';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $subscribers = Weixin::getSubscriber();
        if ($subscribers) {
            foreach ($subscribers as $subscriber) {
                Redis::sAdd(Weixin::SUBSCRIBER_KEY, $subscriber);
            }
        }

        $this->info('微信公众号关注用户缓存成功');
    }

}