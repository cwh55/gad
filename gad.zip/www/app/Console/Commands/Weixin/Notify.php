<?php

namespace App\Console\Commands\Weixin;

use App\Gad\Weixin;
use Illuminate\Console\Command;

class Notify extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'weixin:notify';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '发送微信提醒通知';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        //$r = Weixin::getTemplateId('OPENTM406161891');
        //$this->info($r);
        //\Log::info('asdasd');
        //$a = Weixin::getAccessToken();
        //$this->info($a);

        $r = Weixin::commonId2openId();
    }

}