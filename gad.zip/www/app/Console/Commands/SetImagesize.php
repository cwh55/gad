<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Repositories\PictureRepository;
use Mockery\CountValidator\Exception;

class SetImagesize extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'image:setsize';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Set the size of all pictures';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $ch = curl_init();
        $req = array('modId' => '64220033', 'cmdId' => '131072');
        L5ApiGetRoute($req, 0.2);
        curl_setopt($ch, CURLOPT_PROXY, $req['hostIp']);
        curl_setopt($ch, CURLOPT_PROXYPORT, $req['hostPort']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        $picture = new PictureRepository();
        $piclist = $picture->where('width', '=', 0)->findAll(['id', 'url', 'width', 'height']);
        $this->output->progressStart(count($piclist));
        foreach ($piclist as $pic) {
            if (!empty($pic->url) && empty($pic->width) && empty($pic->height) && strpos($pic->url, 'image.myqcloud.com')) {
                $url = $pic->url . "?imageInfo";
                try {
                    //@$res = file_get_contents($url);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    @$res = curl_exec($ch);
                    if ($res) {
                        $res = json_decode($res);
                        if ($res) {
                            $picture->update($pic->id,['width' => $res->width, 'height' => $res->height]);
                        }
                    }
                } catch (Exception $e) {
                    echo 'Message: ' .$e->getMessage();
                }
            }
            $this->output->progressAdvance();
        }
        curl_close($ch);
        $this->output->progressFinish();
    }
}
