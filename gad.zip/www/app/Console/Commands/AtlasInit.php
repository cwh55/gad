<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Repositories\ArchiveRepository;
use App\Entities\Atlas;
use App\Repositories\PictureRepository;
use Mockery\CountValidator\Exception;

class AtlasInit extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'atlas:init';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'init all atlas info';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $picture = new PictureRepository();
        $picturelist = $picture->where('type', '=', 1)->findAll(['id', 'archive_id']);
        //$picturelist = $this->picture->whereIn('archive_id', [17648, 3134])->findAll(['id', 'archive_id']);
        $this->output->progressStart(count($picturelist));
        foreach ($picturelist as $item) {
            $atlas = Atlas::where('archive_id', $item->archive_id)
                ->get();
            if (!count($atlas)) {
                $newAtlas = new Atlas;
                $newAtlas->archive_id = $item->archive_id;
                $newAtlas->type = 1;
                $newAtlas->save();
            }
            $this->output->progressAdvance();
        }
        $this->output->progressFinish();
    }
}
