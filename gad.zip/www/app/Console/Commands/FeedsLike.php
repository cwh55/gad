<?php

namespace App\Console\Commands;

use App\Models\Feed;
use Gate;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class FeedsLike extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'my:feeds:like:sync';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '同步feeds信息';

    /**
     * @var array
     */
    protected $cache = [];

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // 赞信息
        $flag = true;
        $from = 0;
        $size = 100;
        $date = date('Y-m-d H:i:s', strtotime('-70 seconds'));
        //$date = date('Y-m-d H:i:s', strtotime('-6 month'));
        while($flag) {
            $likes = DB::table('gad_likes as l')
                ->join('User as u', 'l.user_id', '=', 'u.UserId')
                ->select('l.*','u.UserId','u.NickName as user_name','u.Avatar as avatar', 'u.breif')
                //->where('l.model_type', '=', 'App\Entities\Archive') //调试用
                ->where('l.status', '=', 1)
                ->whereNull('l.deleted_at')
                ->where('l.updated_at', '>', $date)
                ->offset($from)
                ->limit($size)
                ->get();
            //return response()->json($likes);
            $nums = count($likes);
            if ($nums > 0) {
                foreach($likes as $like) {
                    $arr = explode('\\', $like->model_type);
                    if(isset($arr[2])) {
                        switch ($arr[2]) {
                            case 'Archive':
                                // 赞文章
                                $data = $this->getArchiveContent($like, 21);
                                //return response()->json($data);
                                break;
                            case 'Picture':
                                // 赞作品
                                $data = $this->getPictureContent($like, 22);
                                //return response()->json($data);
                                break;
                            case 'Answer':
                                // 赞问题的回答或话题的回答
                                // 23赞问回答/24赞话题回答
                                $data = $this->getAnswersContent($like, 23);
                                break;
                            case 'Comment':
                                // 赞评论
                                // 25赞评论
                                break;
                        }
                        //return response()->json($data);
                        $this->generateFeeds($data);
                    }
                }
                $from += $size;
            }
            if($nums < $size) {
                $flag = false;
            }
        }
    }

    // 获取文章内容生成feeds内容
    protected function getArchiveContent($object, $action_id)
    {
        $data = array();
        $archive = DB::table('gad_archives')
            ->select('*')
            ->where('id', '=', $object->model_id)
            ->where('status', '=', 0)
            ->whereNull('deleted_at')
            ->first();
        if($archive->class_id == 2) {
            $action_id = 22;
        }
        if(!empty($archive)) {

            $data = array(
                'archive_id' => $archive->id,
                'class_id' => $archive->class_id,
                'action_id' => $action_id,
                'title' => addslashes(stripslashes($archive->title)),
                'description' => addslashes(stripslashes($archive->description)),
                'cover' => $archive->cover,
                'tag' => $archive->tag,
                'user_id' => $archive->user_id,
                'user_name' => addslashes(stripslashes($archive->user_name)),
                'creator' => $object->user_id,
                'comment_count' => $archive->comment_count,
                'like_count' => $archive->like_count,
                'favorite_count' => $archive->favorite_count,
                'view_count' => $archive->view_count,
                'is_video' => $archive->is_video,
                'answer_id' => 0,
                'total' => $archive->total,
                'extra' => addslashes($archive->extra),
                'sort_time' => strtotime($object->created_at),
                'created_at' => $object->created_at,
                'updated_at' => $object->updated_at,
            );
        }
        return $data;
    }

    protected function getPictureContent($object, $action_id)
    {
        $data = array();
        $picture = DB::table('gad_pictures')
            ->select('*')
            ->where('id', '=', $object->model_id)
            ->where('status', '=', 0)
            ->whereNull('deleted_at')
            ->first();
        if(!empty($picture)) {
            $extra[] = $picture;
            $data = array(
                'archive_id' => $picture->archive_id,
                'class_id' => 2,
                'action_id' => $action_id,
                'title' => addslashes(stripslashes($picture->content)),
                'description' => '',
                'cover' => $picture->url,
                'tag' => '',
                'user_id' => $picture->user_id,
                'user_name' => addslashes(stripslashes($picture->user_name)),
                'creator' => $object->user_id,
                'comment_count' => $picture->comment_count,
                'like_count' => $picture->like_count,
                'favorite_count' => $picture->favorite_count,
                'view_count' => $picture->view_count,
                'is_video' => 0,
                'answer_id' => 0,
                'total' => 0,
                'extra' => addslashes(\GuzzleHttp\json_encode($extra)),
                'sort_time' => strtotime($object->created_at),
                'created_at' => $object->created_at,
                'updated_at' => $object->updated_at,
            );
        }
        return $data;
    }


    // 获取回答、话题对应的archive文档内容生产feeds
    protected function getAnswersContent($object, $action_id)
    {
        $archive = DB::table('gad_archives as f')
            ->join('gad_answers as a', 'f.id', '=', 'a.archive_id')
            ->select('f.*')
            ->where('a.id', '=', $object->model_id)
            ->where('f.status', '=', 0)
            ->whereNull('f.deleted_at')
            ->first();

        $data = array();

        if(!empty($archive)) {
            if($action_id == 23) {
                if($archive->class_id == 4) {
                    $action_id = 24;
                }
            }
            if($action_id == 33) {
                if($archive->class_id == 4) {
                    $action_id = 34;
                }
            }
            $data = array(
                'archive_id' => $archive->id,
                'class_id' => $archive->class_id,
                'action_id' => $action_id,
                'title' => addslashes(stripslashes($archive->title)),
                'description' => addslashes(stripslashes($archive->description)),
                'cover' => $archive->cover,
                'tag' => $archive->tag,
                'user_id' => $archive->user_id,
                'user_name' => addslashes(stripslashes($archive->user_name)),
                'creator' => $object->user_id,
                'comment_count' => $archive->comment_count,
                'like_count' => $archive->like_count,
                'favorite_count' => $archive->favorite_count,
                'view_count' => $archive->view_count,
                'is_video' => $archive->is_video,
                'answer_id' => 0,
                'total' => $archive->total,
                'extra' => addslashes($archive->extra),
                'sort_time' => strtotime($object->created_at),
                'created_at' => $object->created_at,
                'updated_at' => $object->updated_at,
            );
        }
        return $data;
    }

    protected function generateFeeds($data)
    {
        if(!empty($data)) {
            $res = $this->checkExsits($data);
            if (!empty($res)) {
                $this->updateFeeds($data, $res->id);
            } else {
                $this->insertFeeds($data);
            }
            $this->updateCommonInfo($data);
        }
    }

    protected  function checkExsits($data) {
        return DB::table('gad_feeds')
            ->select('id')
            ->where('archive_id', '=', $data['archive_id'])
            ->where('class_id', '=', $data['class_id'])
            ->where('action_id', '=', $data['action_id'])
            ->where('user_id', '=', $data['user_id'])
            ->where('creator', '=', $data['creator'])
            ->where('answer_id', '=', $data['answer_id'])
            ->first();
    }

    protected function updateFeeds($data, $id) {
        $sql = "UPDATE gad_feeds SET class_id='{$data['class_id']}',action_id='{$data['action_id']}',title='{$data['title']}',description='{$data['description']}',cover='{$data['cover']}',tag='{$data['tag']}',user_id='{$data['user_id']}',user_name='{$data['user_name']}',creator='{$data['creator']}',comment_count='{$data['comment_count']}',like_count='{$data['like_count']}',favorite_count='{$data['favorite_count']}',view_count='{$data['view_count']}',is_video='{$data['is_video']}',answer_id='{$data['answer_id']}',total='{$data['total']}',extra='{$data['extra']}',created_at='{$data['created_at']}',updated_at='{$data['updated_at']}' WHERE id='{$id}'";
        $res = DB::update($sql);
    }

    protected function insertFeeds($data) {
        $sql = "REPLACE INTO gad_feeds SET archive_id='{$data['archive_id']}',class_id='{$data['class_id']}',action_id='{$data['action_id']}',title='{$data['title']}',description='{$data['description']}',cover='{$data['cover']}',tag='{$data['tag']}',user_id='{$data['user_id']}',user_name='{$data['user_name']}',creator='{$data['creator']}',comment_count='{$data['comment_count']}',like_count='{$data['like_count']}',favorite_count='{$data['favorite_count']}',view_count='{$data['view_count']}',is_video='{$data['is_video']}',answer_id='{$data['answer_id']}',total='{$data['total']}',extra='{$data['extra']}',sort_time='{$data['sort_time']}',created_at='{$data['created_at']}',updated_at='{$data['updated_at']}'";
        $res = DB::update($sql);
    }

    protected function updateCommonInfo($data) {
        $sql = "UPDATE gad_feeds SET comment_count='{$data['comment_count']}',like_count='{$data['like_count']}',favorite_count='{$data['favorite_count']}',view_count='{$data['view_count']}' WHERE archive_id='{$data['archive_id']}'";
        $res = DB::update($sql);
    }

}