<?php

namespace App\Console\Commands;

use App\Qcloud\Qcloud;
use App\Repositories\LessonRepositoryEloquent;
use App\Repositories\LessonVodRepositoryEloquent;
use Illuminate\Console\Command;

class FetchVodConvertResult extends Command
{
    protected $lessonRepository;
    protected $lessonVodRepository;

    public function __construct(LessonRepositoryEloquent $lessonRepository, LessonVodRepositoryEloquent $lessonVodRepository)
    {
        parent::__construct();

        $this->lessonRepository = $lessonRepository;
        $this->lessonVodRepository = $lessonVodRepository;
    }

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'vod:convert:result:fetch';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '获取腾讯云点播转码事件结果';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $result = Qcloud::vod('PullEvent', []);
        if ($result['code']) {
            return;
        }

        $events = array_get($result, 'data.eventList', []);
        foreach ($events as $event) {
            $eventContent = $event['eventContent'];
            if ($eventContent['eventType'] !== 'TranscodeComplete') {
                continue;
            }

            $eventData = $eventContent['data'];
            $lessonVod = $this->lessonVodRepository->findByField('file_id', $eventData['fileId'])->first();
            if ($lessonVod) {
                $this->lessonVodRepository->update([
                    'img_url' => $eventData['coverUrl'],
                    'duration' => $eventData['duration'],
                    'status' => 1
                ], $lessonVod->id);

                // 课时全部转码完成更新状态
                if ($this->lessonVodRepository->checkState($lessonVod->lesson_id)) {
                    $this->lessonRepository->update(['vod' => 2], $lessonVod->lesson_id);
                }

                Qcloud::vod('ConfirmEvent', ['msgHandle.0' => $event['msgHandle']]);
            }
        }
    }
}
