<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-11-21
 * Time: 下午5:29
 */

namespace App\Console\Commands;


use Illuminate\Support\Facades\DB;
use Illuminate\Console\Command;

class SiteMap extends Command {

    /**
     * The name and signature of the console command.
     *create 生成
     * delete 删除
     * update 更新
     * @var string
     */
    protected $signature = 'sitemap:tool';

    /**
     * The console command description.
     *生成sitemap
     * @var string
     */
    protected $description = '生成站点sitemap';

    //定义站定域名,idc 正常，dev测试
    protected $domain = [
        'idc' => 'http://gad.qq.com/'
    ];

    //固定模块，v1对应老系统，v2 对应新系统
    protected $module = [
        'v1' => [
            'program',
            'program/wz',
            'program/wen',
            'program/course',
            'program/dreamtutor',
            'activity/index',
            'salon/home',
            'gadc',
            'tool/home',
            'plan',
            'plan/news',
            'plan/article',
            'plan/wen',
            'plan/course',
            'plan/dreamtutor',
            'art',
            'art/work',
            'art/wen#2',
            'art/yuedu',
            'art/course',
            'art/dreamtutor',
            'vr/news',
            'vr/wz',
            'vr/wen',
            'vr/course',
            'tool/home?showtype=4',
            'college/index',
            'demos/book',
            'joins/findteam',
            'joins/findpeople',
            'plan/game',
        ],
        'v2' => [
            'vr'
        ]
    ];

//    'v1' => [
//    'article' => ['url'=>'article/detail/','method'=>'Content','args'=>[1],'priority' => 1],
//    'wen' => ['url'=>'content/wendetail/','method'=>'Content','args'=>[2],'priority' => 0.6],
//    'course' => ['url'=> 'content/coursedetail/','method'=>'Content','args'=>[3],'priority' => 1],
//    'resourceDP' =>  ['url'=> 'content/groupresourcedetail/','method'=>'Content','args'=>[7],'priority' => 0.6],
//    'resourceWork' =>  ['url'=> 'content/groupresourcedetail/','method'=>'Content','args'=>[8],'priority' => 0.6],
//    'tool' =>  ['url'=> 'tool/detail/','method'=>'Tool','args'=>[],'priority' => 0.6],
//    'activity'=> ['url'=> 'activity/subjectdetail/','method'=>'Activity','args'=>[] ,'priority' => 0.8],
//    'salon' => ['url'=> 'salon/show/','method'=>'Salon','args'=>[1],'priority' => 0.6],
//    'megagameIndex' => ['url'=> 'megagame/index/','method'=>'Megagame','args'=>[] ,'priority' => 0.6],
//    'megagameIntro' => ['url'=> 'megagame/intro/','method'=>'Megagame','args'=>[],'priority' => 0.6],
//    'megagamePrizeWorks' => ['url'=> 'megagame/prizeworks/','method'=>'Megagame','args'=>[],'priority' => 0.6],
//    'megagameWorks' => ['url'=> 'megagame/works/','method'=>'Megagame','args'=>[],'priority' => 0.6],
//    'project' => ['url'=> 'joins/projectDetail/','method'=>'Project','args'=>[],'priority' => 0.8],
//    'gameview' => ['url'=> 'plan/gameview/','method'=>'GameView','args'=>[],'priority' => 0.6],
//    'gameforum' => ['url'=> 'gameforum/index/','method'=>'GameForum','args'=>[],'priority' => 0.8],
//    'programTranslate' => ['url'=> 'program/translateview/','method'=>'programTranslate','args'=>[12],'priority' => 1],
//    'vrTranslate' => ['url'=> 'vr/translateview/','method'=>'VrTranslate','args'=>[12],'priority' => 1],
//    'weeklyDetail' => ['url'=> 'weekly/detail/','method'=>'WeeklyDetail','args'=>[],'priority' => 1],
//    'planDuyoufang' => ['url'=> 'plan/duyoufangdetail?','method'=>'PlanDuyoufang','args'=>[],'priority' => 1]
//
//    ]

    //详情页url 需要读取db内容
    protected $detail = [
        'v1' => [],
        'v2' => [
            'article' => ['url'=>'article/detail/','method'=>'V2ArticleDetail','args'=>[],'priority' => 1],
            'question' => ['url'=>'question/detail/','method'=>'V2QuestionDetail','args'=>[],'priority' => 0.6],
            'fame' => ['url'=>'fame/detail/','method'=>'V2FameDetail','args'=>[], 'priority' => 0.8],
            'lundao' => ['url'=>'lundao/detail/','method'=>'V2LundaoDetail','args'=>[] , 'priority' => 1],
            'lore' => ['url'=>'lore/detail/','method'=>'V2LoreDetail','args'=>[],'priority' => 1],
            'resource' => ['url'=>'resource/detail/','method'=>'V2ResourceDetail','args'=>[],'priority' => 0.6]
        ]
    ];

    protected  $others =[

    ];

    protected  function createSiteMap($content='', $sitemapIndex='',$version=1, $type='urlset') {
        //version = 1 老系统 ,version = 2 新系统
        $path = public_path().'/sitemap/';
        if(!empty($content)) {
            $header = '<?xml version="1.0" encoding="UTF-8"?>
		<'.$type.'
			xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
			xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
			xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
			   http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
		';
            $content = $header.$content;
            $content .= '</'.$type.'>';
            $path_parts = pathinfo(__FILE__);
            $fp=fopen($path."sitemap{$sitemapIndex}.xml",'w+');
            fwrite($fp,$content);
            fclose($fp);

        }

    }

    protected  function createItem($data){
        $item="<url>\n";
        $item.="<loc>".$data['loc']."</loc>\n";
        $item.="<priority>".$data['priority']."</priority>\n";
        $item.="<lastmod>".$data['lastmod']."</lastmod>\n";
        $item.="<changefreq>".$data['changefreq']."</changefreq>\n";
        $item.="</url>\n";
        return $item;
    }

    protected function createNavItem($data){
        $item="<url>\n";
        $item.="<loc>".$data['loc']."</loc>\n";
        $item.="<lastmod>".$data['lastmod']."</lastmod>\n";
        $item.="</url>\n";
        return $item;
    }

    protected function callMethod($domain,$item,&$index,$version=1)
    {

        $page =0;
        $pageSize = 49000;
        $getMethodCount = 'get'.$item['method'].'Count';
        $getMethodList = 'get'.$item['method'].'List';
        if (method_exists($this,'get'.$item['method'].'Count')) {
            if (count($item['args']) >0) {
                $count = $this->$getMethodCount($item['args'][0]);
            }
            else {
                $count = $this->$getMethodCount();
            }
            while ($page*$pageSize < $count) {
                $content = '';
                if (count($item['args']) >0) {
                    $articles = $this->$getMethodList(1,$page,$pageSize);
                }
                else {
                    $articles = $this->$getMethodList($page,$pageSize);
                }
                foreach($articles as $id){
                    $data = [
                        'loc' => $domain.$item['url'].$id,
                        'lastmod' => date('c'),
                        'changefreq' => 'always',
                        'priority' =>$item['priority']
                    ];
                    $content .= $this->createItem($data);
                }
                $this->createSiteMap($content,$index++,$version);
                $page++;
            }

        }

    }
    protected  function  getV2ArticleDetailCount(){
        return $items = DB::table('gad_archives')
            ->select('id')
            ->where('class_id','=',1)
            ->where('status','=',0)
            ->whereNull('deleted_at')
            ->count();
    }
    protected  function getV2ArticleDetailList($page,$pageSize)
    {
        $items = DB::table('gad_archives')
            ->select('id')
            ->where('class_id','=',1)
            ->where('status','=',0)
            ->whereNull('deleted_at')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->id;
        }
        return $ids;
    }

    protected  function  getV2QuestionDetailCount(){
        return $items = DB::table('gad_archives')
            ->select('id')
            ->where('class_id','=',3)
            ->where('status','=',0)
            ->whereNull('deleted_at')
            ->count();
    }
    protected  function getV2QuestionDetailList($page,$pageSize)
    {
        $items = DB::table('gad_archives')
            ->select('id')
            ->where('class_id','=',1)
            ->where('status','=',0)
            ->whereNull('deleted_at')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->id;
        }
        return $ids;
    }

    protected  function  getV2FameDetailCount(){
        return DB::table("fames")
            ->count();
    }
    protected  function getV2FameDetailList($page,$pageSize)
    {
        $items = DB::table('fames')
            ->select('id')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->id;
        }
        return $ids;
    }

    protected  function  getV2LundaoDetailCount(){
        return DB::table("courses")
            ->where('is_lundao','=',1)
            ->whereNull('deleted_at')
            ->count();
    }
    protected  function getV2LundaoDetailList($page,$pageSize)
    {
        $items = DB::table('courses')
            ->where('is_lundao','=',1)
            ->whereNull('deleted_at')
            ->select('id')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->id;
        }
        return $ids;
    }

    protected  function  getV2LoreDetailCount(){
        return DB::table("lore_sections")
            ->count();
    }
    protected  function getV2LoreDetailList($page,$pageSize)
    {
        $items = DB::table('lore_sections')
            ->select('id')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->id;
        }
        return $ids;
    }

    protected  function  getV2WendaDetailCount(){
        return DB::table("gad_archives")
            ->where('class_id','=',3)
            ->where('status','=',0)
            ->whereNull('deleted_at')
            ->count();
    }
    protected  function getV2WendaDetailList($page,$pageSize)
    {
        $items = DB::table('gad_archives')
            ->select('id')
            ->where('class_id','=',3)
            ->where('status','=',0)
            ->whereNull('deleted_at')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->id;
        }
        return $ids;
    }

    protected  function  getProgramTranslateCount($showType){
        return DB::table('ContentClass')
            ->join('Content','ContentClass.ContentId','=','Content.ContentId')
            ->where('ContentClass.RowStatus','=',0)
            ->where('Content.RowStatus','=',0)
            ->where('Content.ShowType','=',$showType)
            ->where('ContentClass.ClassLV1','=','3')
            ->count();
    }
    protected  function getProgramTranslateList($showType,$page,$pageSize)
    {
        $items = DB::table('ContentClass')
            ->join('Content','ContentClass.ContentId','=','Content.ContentId')
            ->where('ContentClass.RowStatus','=',0)
            ->where('Content.RowStatus','=',0)
            ->where('Content.ShowType','=',$showType)
            ->where('ContentClass.ClassLV1','=','3')
            ->select('ContentClass.Id')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->Id;
        }
        return $ids;
    }

    protected  function  getVrTranslateCount($showType){
        return DB::table('ContentClass')
            ->join('Content','ContentClass.ContentId','=','Content.ContentId')
            ->where('ContentClass.RowStatus','=',0)
            ->where('Content.RowStatus','=',0)
            ->where('Content.ShowType','=',$showType)
            ->where('ContentClass.ClassLV1','=','4')
            ->count();
    }
    protected  function getVrTranslateList($showType,$page,$pageSize)
    {
        $items = DB::table('ContentClass')
            ->join('Content','ContentClass.ContentId','=','Content.ContentId')
            ->where('ContentClass.RowStatus','=',0)
            ->where('Content.RowStatus','=',0)
            ->where('Content.ShowType','=',$showType)
            ->where('ContentClass.ClassLV1','=','4')
            ->select('ContentClass.Id')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->Id;
        }
        return $ids;
    }

    protected  function  getWeeklyDetailCount(){
        return DB::table("tbWeekly")
            ->count();
    }
    protected  function getWeeklyDetailList($page,$pageSize)
    {
        $items = DB::table('tbWeekly')
            ->select('iWeekid')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->iWeekid;
        }
        return $ids;
    }

    protected  function getV2ResourceDetailCount(){
        return DB::table('gad_archives')
            ->select('id')
            ->where('class_id','=',2)
            ->where('status','=',0)
            ->whereNull('deleted_at')
            ->count();
    }
    protected  function getV2ResourceDetailList($page,$pageSize)
    {
        $items = DB::table('gad_archives')
            ->select('id')
            ->where('class_id','=',2)
            ->where('status','=',0)
            ->whereNull('deleted_at')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->id;
        }
        return $ids;
    }


    protected  function getPlanDuyoufangCount(){
        return DB::table('tbIndependGame')
            ->count();
    }
    protected  function getPlanDuyoufangList($page,$pageSize)
    {
        $items = DB::table('tbIndependGame')
            ->select('tbIndependGame.iId as iId' ,'tbIndependGame.iPhaseId as pid' )
            ->where('iPhaseId','>',0)
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = 'ContentId='.$item->iId.'&PhaseId='.$item->pid;
        }
        return $ids;
    }


    //获取content总数
    protected  function getContentCount($showType)
    {
        return DB::table('ContentClass')
            ->join('Content','ContentClass.ContentId','=','Content.ContentId')
            ->where('ContentClass.RowStatus','=',0)
            ->where('Content.RowStatus','=',0)
            ->where('Content.ShowType','=',$showType)
            ->count();

    }

    //获取content列表
    protected  function getContentList($showType,$page,$pageSize=49000)
    {
        $items = DB::table('ContentClass')
            ->join('Content','ContentClass.ContentId','=','Content.ContentId')
            ->where('ContentClass.RowStatus','=',0)
            ->where('Content.RowStatus','=',0)
            ->where('Content.ShowType','=',$showType)
            ->select('ContentClass.Id')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->Id;
        }
        return $ids;

    }

    //获取组件总数
    protected  function  getToolCount()
    {
        return DB::table('Tool')
            ->where('Tool.RowStatus','=',0)
            ->count();
    }

    //获取组件
    protected  function getToolList($page,$pageSize)
    {
        $items = DB::table('Tool')
            ->where('Tool.RowStatus','=',0)
            ->select('ToolId')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->ToolId;
        }
        return $ids;

    }

    //获取活动总数
    protected  function  getActivityCount()
    {
        return DB::table('Subject')
            ->where('Subject.RowStatus','=',0)
            ->count();
    }

    //获取活动列表
    protected  function getActivityList($page,$pageSize)
    {
        $items = DB::table('Subject')
            ->where('Subject.RowStatus','=',0)
            ->select('SubjectId')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->SubjectId;
        }
        return $ids;

    }

    //沙龙总数
    protected  function getSalonCount($type)
    {
        return DB::table('salon')
            ->where('salon.is_product','=',1)
            ->where('salon.type','=',$type)
            ->count();
    }

    protected function getSalonList($type,$page,$pageSize)
    {
        $items=DB::table('salon')
            ->where('salon.is_product','=',1)
            ->where('salon.type','=',$type)
            ->select('salon_id')
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->salon_id;
        }
        return $ids;

    }

    protected function getMegagameCount()
    {
        return DB::table('Megagame')
            ->where('RowStatus','=',0)
            ->count();
    }

    protected function getMegagameList($page,$pageSize)
    {
        $items=DB::table('Megagame')
            ->where('RowStatus','=',0)
            ->select('ActivityId')
            ->skip($page*$pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->ActivityId;
        }
        return $ids;

    }

    protected function getProjectCount()
    {
        return DB::table('Works')
            ->where('RowStatus','=',0)
            ->where('MatchId','=',0)
            ->count();
    }

    protected  function getProjectList($page,$pageSize)
    {
        $items=DB::table('Works')
            ->where('RowStatus','=',0)
            ->where('MatchId','=',0)
            ->select('WorksId')
            ->skip($page*$pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->WorksId;
        }
        return $ids;

    }

    protected function getGameViewCount()
    {
        return DB::table('tbGame')
            ->where('iRowStatus','=',0)
            ->count();
    }

    protected  function getGameViewList($page,$pageSize)
    {
        $items=DB::table('tbGame')
            ->where('iRowStatus','=',0)
            ->select('Id')
            ->skip($page*$pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->Id;
        }
        return $ids;
    }

    protected function getGameForumCount()
    {
        return DB::table('Content')
            ->where('RowStatus','=',0)
            ->where('ShowType','=',9)
            ->count();
    }

    protected  function getGameForumList($page,$pageSize)
    {
        $items=DB::table('Content')
            ->where('RowStatus','=',0)
            ->where('ShowType','=',9)
            ->select('ContentId')
            ->skip($page*$pageSize)
            ->take($pageSize)
            ->get();
        $ids =[];
        foreach($items as $item) {
            $ids[] = $item->ContentId;
        }
        return $ids;
    }

    protected  function createNavSiteMap($domain,$index,$version=1)
    {
        $path = public_path();
        $dir = 'sitemap/';
        $type = 'urlset';
//        if ($version == 2) {
//            $dir = 'sitemap/';
//        }
        $path = $path.'/'.$dir;
        $header = '<?xml version="1.0" encoding="UTF-8"?>
		<'.$type.'
			xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
			xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
			xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
			   http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
		';
        $content = '';
        for ($i=1;$i<$index;$i++) {
            $data = [
                'loc'=>$domain.$dir.'sitemap'.$i.'.xml',
                'lastmod'=>date('c')
            ];
            $content .= $this->createNavItem($data);
        }
        $content = $header.$content;
        $content .= '</'.$type.'>';
        $fp=fopen($path."sitemap.xml",'w+');
        fwrite($fp,$content);
        fclose($fp);
    }

    protected function createDir($dir)
    {
        if (!is_dir($dir)) {
            mkdir($dir);
        }
    }
    /**
     * Execute the console command.
     * @return mixed
     */
    public function handle()
    {
        $this->createDir(public_path().'/sitemap');
        $this->info('Sitemap created start');
        $serverEnv = 'idc';
//        if (config('app.server_environment') == 'idc')
//        {
//            $serverEnv = 'idc';
//        }
        $domain = $this->domain[$serverEnv];
        $index =1;
        //构建老系统固定模块sitemap
        $data = [
            'loc'=> $domain,
            'lastmod'=> date('c'),
            'changefreq' =>'always',
            'priority' =>1
        ];
        $content = $this->createItem($data);
        $moduleV1 = $this->module['v1'];
        foreach ($moduleV1 as $item) {
            $data = [
                'loc' => $domain.$item,
                'lastmod' => date('c'),
                'changefreq' => 'always',
                'priority' =>1
            ];
            $content .= $this->createItem($data);
        }
        $this->createSiteMap($content,$index++);
        $detailV1 = $this->detail['v1'];
        foreach($detailV1 as $item) {
            $this->callMethod($domain,$item,$index);
        }

        $this->createNavSiteMap($domain,$index,1);


        //构建新系统固定模块sitemap
        $index = 1;
        $data = [
            'loc'=> $domain,
            'lastmod'=> date('c'),
            'changefreq' =>'always',
            'priority' =>1
        ];
        $content = $this->createItem($data);
        $moduleV2 = $this->module['v2'];
        foreach ($moduleV2 as $item) {
            $data = [
                'loc' => $domain.$item,
                'lastmod' => date('c'),
                'changefreq' => 'always',
                'priority' => 1
            ];
            $content .= $this->createItem($data);
        }
        $this->createSiteMap($content,$index++,2);
        $detailV2 = $this->detail['v2'];
        foreach($detailV2 as $item) {
            $this->callMethod($domain,$item,$index,2);
        }
        $this->createNavSiteMap($domain,$index,2);


        $this->info('Sitemap created success');
    }

} 