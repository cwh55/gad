<?php

namespace App\Console\Commands;

use App\Models\Feed;
use Gate;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class FeedsLive extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'my:feeds:live:sync';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '同步feeds信息';

    /**
     * @var array
     */
    protected $cache = [];

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // live
        $flag = true;
        $from = 0;
        $size = 100;
        $date = date('Y-m-d H:i:s', strtotime('-70 seconds'));
        $date = date('Y-m-d H:i:s', strtotime('-1 year'));
        while($flag) {
            $lives = DB::table('live_signs as ls')
                ->join('lives as l', 'ls.live_id', '=', 'l.id')
                ->select('l.id','l.name','l.creator','ls.user_id','ls.nickname','ls.avatar','ls.created_at','ls.updated_at')
                ->where('l.rowstatus', '=', 0)
                ->where('ls.type', '=', 3)
                ->where('ls.created_at', '>', $date)
                ->whereNull('l.deleted_at')
                ->offset($from)
                ->limit($size)
                ->get();

            $nums = count($lives);
            if ($nums > 0) {
                foreach($lives as $live) {
                    $data = array(
                        'archive_id' => $live->id,  // live_id
                        'class_id' => 0,
                        'action_id' => 61,
                        'title' => addslashes(stripslashes($live->name)),
                        'description' => '',
                        'cover' => $live->avatar,
                        'tag' => '',
                        'user_id' => $live->creator,
                        'user_name' => addslashes(stripslashes($live->nickname)),
                        'creator' => $live->user_id,
                        'comment_count' => '',
                        'like_count' => '',
                        'favorite_count' => '',
                        'view_count' => '',
                        'is_video' => '',
                        'answer_id' => 0,
                        'total' => '',
                        'extra' => '[]',
                        'sort_time' => strtotime($live->created_at),
                        'created_at' => $live->created_at,
                        'updated_at' => $live->updated_at,
                    );

                    $this->generateFeeds($data);
                    $from += $size;
                }
            }
            if($nums < $size) {
                $flag = false;
            }
        }
    }

    protected function generateFeeds($data)
    {
        if(!empty($data)) {
            $res = $this->checkExsits($data);
            if (!empty($res)) {
                $this->updateFeeds($data, $res->id);
            } else {
                $this->insertFeeds($data);
            }
        }
    }

    protected  function checkExsits($data) {
        return DB::table('gad_feeds')
            ->select('id')
            ->where('archive_id', '=', $data['archive_id'])
            ->where('class_id', '=', $data['class_id'])
            ->where('action_id', '=', $data['action_id'])
            ->where('user_id', '=', $data['user_id'])
            ->where('creator', '=', $data['creator'])
            ->where('answer_id', '=', $data['answer_id'])
            ->first();
    }

    protected function updateFeeds($data, $id) {
        $sql = "UPDATE gad_feeds SET class_id='{$data['class_id']}',action_id='{$data['action_id']}',title='{$data['title']}',description='{$data['description']}',cover='{$data['cover']}',tag='{$data['tag']}',user_id='{$data['user_id']}',user_name='{$data['user_name']}',creator='{$data['creator']}',comment_count='{$data['comment_count']}',like_count='{$data['like_count']}',favorite_count='{$data['favorite_count']}',view_count='{$data['view_count']}',is_video='{$data['is_video']}',answer_id='{$data['answer_id']}',total='{$data['total']}',extra='{$data['extra']}',created_at='{$data['created_at']}',updated_at='{$data['updated_at']}' WHERE id='{$id}'";
        $res = DB::update($sql);
    }

    protected function insertFeeds($data) {
        $sql = "REPLACE INTO gad_feeds SET archive_id='{$data['archive_id']}',class_id='{$data['class_id']}',action_id='{$data['action_id']}',title='{$data['title']}',description='{$data['description']}',cover='{$data['cover']}',tag='{$data['tag']}',user_id='{$data['user_id']}',user_name='{$data['user_name']}',creator='{$data['creator']}',comment_count='{$data['comment_count']}',like_count='{$data['like_count']}',favorite_count='{$data['favorite_count']}',view_count='{$data['view_count']}',is_video='{$data['is_video']}',answer_id='{$data['answer_id']}',total='{$data['total']}',extra='{$data['extra']}',sort_time='{$data['sort_time']}',created_at='{$data['created_at']}',updated_at='{$data['updated_at']}'";
        $res = DB::update($sql);
    }

}