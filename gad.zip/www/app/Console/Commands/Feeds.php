<?php

namespace App\Console\Commands;

use App\Models\Feed;
use Gate;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class Feeds extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'my:feeds:sync';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '同步feeds信息';

    /**
     * @var array
     */
    protected $cache = [];

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $flag = true;
        $from = 0;
        $size = 100;
        $date = date('Y-m-d H:i:s', strtotime('-70 seconds'));        
        //$date = date('Y-m-d H:i:s', strtotime('-6 month'));
        while($flag) {
            $archives = DB::table('gad_archives')
                ->select('id', 'class_id', 'title', 'description', 'cover', 'tag', 'user_id', 'user_name', 'creator', 'comment_count', 'like_count', 'favorite_count', 'view_count', 'is_video', 'total', 'extra', 'status', 'created_at', 'updated_at', 'deleted_at')
                ->where(function($query) use ($date) {
                    $query->where('status', '=', 0);
                    $query->orWhere('status', '=', 2);
                })
                ->where(function($query) use ($date) {
                    $query->where('created_at', '>', $date);
                    $query->orWhere('updated_at', '>', $date);
                })
                ->offset($from)
                ->limit($size)
                ->get();
            //archive_id: 17983

            //return response()->json($archives);
            $nums = count($archives);
            if ($nums > 0) {
                foreach ($archives as $archive) {

                    if ($archive->deleted_at == null) {
                        if (in_array($archive->class_id, array(1, 2))) {    // 文章、作品
                            $data = array(
                                'archive_id' => $archive->id,
                                'class_id' => $archive->class_id,
                                'title' => addslashes(stripslashes($archive->title)),
                                'description' => addslashes(strip_tags($archive->description)),
                                'cover' => $archive->cover,
                                'tag' => $archive->tag,
                                'user_id' => $archive->user_id,
                                'user_name' => addslashes(stripslashes($archive->user_name)),
                                'creator' => $archive->user_id,
                                'comment_count' => $archive->comment_count,
                                'like_count' => $archive->like_count,
                                'favorite_count' => $archive->favorite_count,
                                'view_count' => $archive->view_count,
                                'is_video' => $archive->is_video,
                                'answer_id' => 0,
                                'total' => $archive->total,
                                'extra' => addslashes($archive->extra),
                                'status' => $archive->status,
                                'sort_time' => strtotime($archive->created_at),
                                'created_at' => $archive->created_at,
                                'updated_at' => $archive->updated_at,
                            );
                            if ($archive->class_id == 1) {
                                $data['action_id'] = 41;
                            } else {
                                $data['action_id'] = 42;
                            }
                            $this->generateFeeds($data);

                        } else if (in_array($archive->class_id, array(3, 4))) { // 问答、话题
                            $data = array(
                                'archive_id' => $archive->id,
                                'class_id' => $archive->class_id,
                                'title' => addslashes(stripslashes($archive->title)),
                                'description' => addslashes(strip_tags($archive->description)),
                                'cover' => $archive->cover,
                                'tag' => $archive->tag,
                                'user_id' => $archive->user_id,
                                'user_name' => addslashes(stripslashes($archive->user_name)),
                                'creator' => $archive->creator,
                                'comment_count' => $archive->comment_count,
                                'like_count' => $archive->like_count,
                                'favorite_count' => $archive->favorite_count,
                                'view_count' => $archive->view_count,
                                'is_video' => $archive->is_video,
                                'answer_id' => 0,
                                'total' => $archive->total,
                                'extra' => addslashes($archive->extra),
                                'status' => $archive->status,
                                'sort_time' => strtotime($archive->created_at),
                                'created_at' => $archive->created_at,
                                'updated_at' => $archive->updated_at,
                            );
                            if ($archive->class_id == 3) {
                                $data['action_id'] = 43;    //发表问题
                            } else {
                                $data['action_id'] = 44;    //发表话题
                            }

                            $answer_info = $this->getAnswerInfo($archive->id);
                            if (!empty($answer_info)) {
                                $this->insertFeeds($data);
                                foreach ($answer_info as $key => $answer) {
                                    $answer->answer = strip_tags($answer->answer);
                                    $answer->user_name = addslashes($answer->user_name);
                                    $data['answer_id'] = $answer->id;
                                    $data['extra'] = addslashes(\GuzzleHttp\json_encode($answer));
                                    $data['creator'] = $answer->user_id;
                                    $data['sort_time'] = strtotime($answer->created_at);
                                    if ($archive->class_id == 3) {
                                        $data['action_id'] = 51;    // 新增回答
                                    } else {
                                        $data['action_id'] = 52;    // 新增话题回答
                                    }

                                    $this->generateFeeds($data);
                                    $this->updateCommonInfo($data);
                                }
                            } else {
                                $this->generateFeeds($data);
                            }
                        }
                    } else {
                        $this->deletedFeed($archive);
                    }
                }
                $from += $size;
            }
            if($nums < $size) {
                $flag = false;

            }
        }

        // 发表评论
        $flag = true;
        $from = 0;
        $size = 100;
        while($flag) {
            $comments = DB::table('gad_comments as c')
                ->join('User as u', 'c.user_id', '=', 'u.UserId')
                ->select('c.*','u.UserId','u.NickName as user_name','u.Avatar as avatar')
                //->where('c.model_type', '=', 'App\Entities\Picture')  //调试用
                ->where('c.status', '=', 0)
                ->whereNull('c.deleted_at')
                ->where('c.updated_at', '>', $date)
                ->offset($from)
                ->limit($size)
                ->get();

            $nums = count($comments);
            if ($nums > 0) {
                foreach($comments as $comment) {
                    $model_type = $comment->model_type;
                    //return response()->json($model_type);
                    $arr = explode('\\', $model_type);
                    if(isset($arr[2])) {
                        switch ($arr[2]) {
                            case 'Archive':
                                // 评论文章
                                $data = $this->getArchiveContent($comment, 45);
                                //return response()->json($data);
                                break;
                            case 'Picture':
                                // 评论作品
                                $data = $this->getPictureContent($comment, 46);
                                //return response()->json($data);
                                break;
                            case 'Comment':
                                // 二级评论
                                //$data = $this->getCommentsContent($comment, 47);
                                break;
                        }
                        $this->generateFeeds($data);
                        $this->updateCommonInfo($data);
                    }
                }
                $from += $size;
            }
            if($nums < $size) {
                $flag = false;
            }
        }
    }


    // 获取答案信息
    protected function getAnswerInfo($archive_id) {
        return DB::table('gad_answers as a')
            ->join('User as u', 'a.user_id', '=', 'u.UserId')
            ->select('a.id','a.archive_id','a.answer_id','a.cover','a.answer','a.adopt','a.user_id','a.like_count','a.created_at','a.updated_at','a.updater','a.answer_count','u.NickName as user_name','u.Avatar as avatar')
            ->where('a.archive_id', '=', $archive_id)
            ->where('a.status', '=', 0)
            ->get();
    }

    // 获取文章内容生成feeds内容
    protected function getArchiveContent($object, $action_id)
    {
        $data = array();
        $archive = DB::table('gad_archives')
            ->select('*')
            ->where('id', '=', $object->model_id)
            ->where('status', '=', 0)
            ->whereNull('deleted_at')
            ->first();
        if(!empty($archive)) {

            $data = array(
                'archive_id' => $archive->id,
                'class_id' => $archive->class_id,
                'action_id' => $action_id,
                'title' => addslashes(stripslashes($archive->title)),
                'description' => addslashes(stripslashes($archive->description)),
                'cover' => $archive->cover,
                'tag' => $archive->tag,
                'user_id' => $archive->user_id,
                'user_name' => addslashes(stripslashes($archive->user_name)),
                'creator' => $object->user_id,
                'comment_count' => $archive->comment_count,
                'like_count' => $archive->like_count,
                'favorite_count' => $archive->favorite_count,
                'view_count' => $archive->view_count,
                'is_video' => $archive->is_video,
                'answer_id' => 0,
                'total' => $archive->total,
                'extra' => addslashes($archive->extra),
                'status' => $archive->status,
                'sort_time' => strtotime($object->created_at),
                'created_at' => $object->created_at,
                'updated_at' => $object->updated_at,
            );
        }
        return $data;
    }

    protected function getPictureContent($object, $action_id)
    {
        $data = array();
        $picture = DB::table('gad_pictures')
            ->select('*')
            ->where('id', '=', $object->model_id)
            ->where('status', '=', 0)
            ->whereNull('deleted_at')
            ->first();
        if(!empty($picture)) {
            $extra[] = $picture;
            $data = array(
                'archive_id' => $picture->archive_id,
                'class_id' => 2,
                'action_id' => $action_id,
                'title' => addslashes(stripslashes($picture->content)),
                'description' => '',
                'cover' => $picture->url,
                'tag' => '',
                'user_id' => $picture->user_id,
                'user_name' => addslashes(stripslashes($picture->user_name)),
                'creator' => $object->user_id,
                'comment_count' => $picture->comment_count,
                'like_count' => $picture->like_count,
                'favorite_count' => $picture->favorite_count,
                'view_count' => $picture->view_count,
                'is_video' => 0,
                'answer_id' => 0,
                'total' => 0,
                'extra' => addslashes(\GuzzleHttp\json_encode($extra)),
                'status' => $picture->status,
                'sort_time' => strtotime($object->created_at),
                'created_at' => $object->created_at,
                'updated_at' => $object->updated_at,
            );
        }
        return $data;
    }

    protected function generateFeeds($data)
    {
        if(!empty($data)) {
            $res = $this->checkExsits($data);
            if (!empty($res)) {
                $this->updateFeedsById($data, $res->id);
            } else {
                $this->insertFeeds($data);
            }
        }
    }

    protected  function checkExsits($data) {
        return DB::table('gad_feeds')
            ->select('id')
            ->where('archive_id', '=', $data['archive_id'])
            ->where('class_id', '=', $data['class_id'])
            ->where('action_id', '=', $data['action_id'])
            ->where('user_id', '=', $data['user_id'])
            ->where('creator', '=', $data['creator'])
            ->where('answer_id', '=', $data['answer_id'])
            ->first();
    }

    public function deletedFeed($archive){
        $sql = "UPDATE gad_feeds set deleted_at = '".$archive->deleted_at."' where archive_id = ".$archive->id;
        $res = DB::update($sql);
    }

    protected function updateFeeds($data) {
        $sql = "UPDATE gad_feeds SET title='{$data['title']}',description='{$data['description']}',cover='{$data['cover']}',tag='{$data['tag']}',user_id='{$data['user_id']}',user_name='{$data['user_name']}',creator='{$data['creator']}',comment_count='{$data['comment_count']}',like_count='{$data['like_count']}',favorite_count='{$data['favorite_count']}',view_count='{$data['view_count']}',is_video='{$data['status']}',status='{$data['status']}',updated_at='{$data['updated_at']}' WHERE archive_id='{$data['archive_id']}'";
        $res = DB::update($sql);
    }

    protected function updateFeedsById($data, $id) {
        $sql = "UPDATE gad_feeds SET class_id='{$data['class_id']}',action_id='{$data['action_id']}',title='{$data['title']}',description='{$data['description']}',cover='{$data['cover']}',tag='{$data['tag']}',user_id='{$data['user_id']}',user_name='{$data['user_name']}',creator='{$data['creator']}',comment_count='{$data['comment_count']}',like_count='{$data['like_count']}',favorite_count='{$data['favorite_count']}',view_count='{$data['view_count']}',is_video='{$data['is_video']}',status='{$data['status']}',answer_id='{$data['answer_id']}',total='{$data['total']}',extra='{$data['extra']}',created_at='{$data['created_at']}',updated_at='{$data['updated_at']}' WHERE id='{$id}'";
        $res = DB::update($sql);
    }

    protected function insertFeeds($data) {
        $sql = "REPLACE INTO gad_feeds SET archive_id='{$data['archive_id']}',class_id='{$data['class_id']}',action_id='{$data['action_id']}',title='{$data['title']}',description='{$data['description']}',cover='{$data['cover']}',tag='{$data['tag']}',user_id='{$data['user_id']}',user_name='{$data['user_name']}',creator='{$data['creator']}',comment_count='{$data['comment_count']}',like_count='{$data['like_count']}',favorite_count='{$data['favorite_count']}',view_count='{$data['view_count']}',is_video='{$data['is_video']}',status='{$data['status']}',answer_id='{$data['answer_id']}',total='{$data['total']}',extra='{$data['extra']}',sort_time='{$data['sort_time']}',created_at='{$data['created_at']}',updated_at='{$data['updated_at']}'";
        $res = DB::update($sql);
    }

    protected function updateCommonInfo($data) {
        $sql = "UPDATE gad_feeds SET comment_count='{$data['comment_count']}',like_count='{$data['like_count']}',favorite_count='{$data['favorite_count']}',view_count='{$data['view_count']}' WHERE archive_id='{$data['archive_id']}'";
        $res = DB::update($sql);
    }

}