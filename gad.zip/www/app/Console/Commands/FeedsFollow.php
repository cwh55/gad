<?php

namespace App\Console\Commands;

use App\Models\Feed;
use Gate;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class FeedsFollow extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'my:feeds:follow:sync';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '同步feeds信息';

    /**
     * @var array
     */
    protected $cache = [];

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
         // 关注信息
        $flag = true;
        $from = 0;
        $size = 100;
        $date = date('Y-m-d H:i:s', strtotime('-70 seconds'));
        //$date = date('Y-m-d H:i:s', strtotime('-6 month'));
        while($flag) {
            $follows = DB::table('gad_follows as f')
                ->join('User as u', 'f.follow_user', '=', 'u.UserId')
                ->select('u.UserId','u.NickName as user_name','u.Avatar as avatar', 'u.breif', 'f.user_id','f.follow_user','f.created_at', 'f.updated_at')
                ->where('status', '=', 0)
                ->whereNull('deleted_at')
                ->where('updated_at', '>', $date)
                ->offset($from)
                ->limit($size)
                ->get();

            $nums = count($follows);
            if ($nums > 0) {
                foreach($follows as $follow) {
                    $data = array(
                        'archive_id' => 0,
                        'class_id' => 0,
                        'action_id' => 11,
                        'title' => '',
                        'description' => addslashes(stripslashes($follow->breif)),
                        'cover' => $follow->avatar,
                        'tag' => '',
                        'user_id' => $follow->follow_user,
                        'user_name' => addslashes(stripslashes($follow->user_name)),
                        'creator' => $follow->user_id,
                        'comment_count' => '',
                        'like_count' => '',
                        'favorite_count' => '',
                        'view_count' => '',
                        'is_video' => '',
                        'answer_id' => 0,
                        'total' => '',
                        'extra' => '[]',
                        'sort_time' => strtotime($follow->updated_at),
                        'created_at' => $follow->created_at,
                        'updated_at' => $follow->updated_at,
                    );
                    $this->generateFeeds($data);
                    //return response()->json($data);
                }
                $from += $size;
            }
            if($nums < $size) {
                $flag = false;
            }
        }
    }

    protected function generateFeeds($data)
    {
        if(!empty($data)) {
            $res = $this->checkExsits($data);
            if (!empty($res)) {
                $this->updateFeeds($data, $res->id);
            } else {
                $this->insertFeeds($data);
            }
            $this->updateCommonInfo($data);
        }
    }

    protected  function checkExsits($data) {
        return DB::table('gad_feeds')
            ->select('id')
            ->where('archive_id', '=', $data['archive_id'])
            ->where('class_id', '=', $data['class_id'])
            ->where('action_id', '=', $data['action_id'])
            ->where('user_id', '=', $data['user_id'])
            ->where('creator', '=', $data['creator'])
            ->where('answer_id', '=', $data['answer_id'])
            ->first();
    }

    protected function updateFeeds($data, $id) {
        $sql = "UPDATE gad_feeds SET class_id='{$data['class_id']}',action_id='{$data['action_id']}',title='{$data['title']}',description='{$data['description']}',cover='{$data['cover']}',tag='{$data['tag']}',user_id='{$data['user_id']}',user_name='{$data['user_name']}',creator='{$data['creator']}',comment_count='{$data['comment_count']}',like_count='{$data['like_count']}',favorite_count='{$data['favorite_count']}',view_count='{$data['view_count']}',is_video='{$data['is_video']}',answer_id='{$data['answer_id']}',total='{$data['total']}',extra='{$data['extra']}',created_at='{$data['created_at']}',updated_at='{$data['updated_at']}' WHERE id='{$id}'";
        $res = DB::update($sql);
    }

    protected function insertFeeds($data) {
        $sql = "REPLACE INTO gad_feeds SET archive_id='{$data['archive_id']}',class_id='{$data['class_id']}',action_id='{$data['action_id']}',title='{$data['title']}',description='{$data['description']}',cover='{$data['cover']}',tag='{$data['tag']}',user_id='{$data['user_id']}',user_name='{$data['user_name']}',creator='{$data['creator']}',comment_count='{$data['comment_count']}',like_count='{$data['like_count']}',favorite_count='{$data['favorite_count']}',view_count='{$data['view_count']}',is_video='{$data['is_video']}',answer_id='{$data['answer_id']}',total='{$data['total']}',extra='{$data['extra']}',sort_time='{$data['sort_time']}',created_at='{$data['created_at']}',updated_at='{$data['updated_at']}'";
        $res = DB::update($sql);
    }

    protected function updateCommonInfo($data) {
        $sql = "UPDATE gad_feeds SET comment_count='{$data['comment_count']}',like_count='{$data['like_count']}',favorite_count='{$data['favorite_count']}',view_count='{$data['view_count']}' WHERE archive_id='{$data['archive_id']}'";
        $res = DB::update($sql);
    }

}