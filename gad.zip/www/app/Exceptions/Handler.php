<?php

namespace App\Exceptions;

use Exception;
use Illuminate\Validation\ValidationException;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that should not be reported.
     *
     * @var array
     */
    protected $dontReport = [
        AuthorizationException::class,
        HttpException::class,
        ModelNotFoundException::class,
        ValidationException::class,
    ];

    /**
     * Report or log an exception.
     *
     * This is a great spot to send exceptions to Sentry, Bugsnag, etc.
     *
     * @param  \Exception  $e
     * @return void
     */
    public function report(Exception $e)
    {
        parent::report($e);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Exception  $e
     * @return \Illuminate\Http\Response
     */
    public function render($request, Exception $e)
    {
        if ($e instanceof HttpResponseException) {
            return $e->getResponse();
        } elseif ($e instanceof ModelNotFoundException) {
            $e = new NotFoundHttpException($e->getMessage(), $e);
        } elseif ($e instanceof AuthorizationException) {
            if ($this->isNeedJsonResponse($request)) {
                return response()->json(['code' => 403, 'message' => '没有授权，或你已经被添加黑名单，请联系管理员'], 403);
            }

            $e = new HttpException(403, $e->getMessage());
        } elseif ($e instanceof ValidationException && $e->getResponse()) {
            $message = $e->validator->getMessageBag()->messages();

            return response()->json(['code' => 422, 'message' => $message], 422);
        }

        if ($this->isHttpException($e)) {
            $message = $e instanceof NotFoundHttpException ? '请求的内容不存在' : $e->getMessage();
            if ($this->isNeedJsonResponse($request)) {
                return response()->json(['code' => $e->getStatusCode(), 'message' => $message], $e->getStatusCode());
            } else {
                return $this->toIlluminateResponse($this->renderHttpException($e), $e);
            }
        } else {
            $message = app()->isLocal() ? $e->getMessage() : '系统出现错误';
            if ($this->isNeedJsonResponse($request)) {
                return response()->json(['code' => 500, 'message' => $message], 500);
            }

            if (app()->environment() == 'production') {
                return response()->view('errors.500', [], 500);
            } else {
                return $this->toIlluminateResponse($this->convertExceptionToResponse($e), $e);
            }
        }
    }

    private function isNeedJsonResponse($request)
    {
        return $request->ajax() OR $request->wantsJson();
    }
}
