<?php

namespace App\Exceptions;

use Exception;

class GadException extends Exception
{
    public function __construct($message)
    {
        $arguments = func_get_args();
        if ($arguments) {
            $message = call_user_func_array('sprintf', $arguments);
        }

        parent::__construct($message);
    }
}