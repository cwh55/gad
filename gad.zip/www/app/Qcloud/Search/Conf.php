<?php
namespace App\Qcloud\Search;

class Conf
{
    const SECRET_ID = 'AKID4mfxI7l9It2uXihrCjmZbLliqr02utUC';
    const SECRET_KEY = 'sS2ykV4z8KSNx9BN4sCnpuwrdmyRlWdY';
    const APP_ID = '65040002';
    const TABLE_TYPE = [
        'ARCHIVE' => 1,
        'USER' => 2,
        'TAG' => 3
    ];
}


