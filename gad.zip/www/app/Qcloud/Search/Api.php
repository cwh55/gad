<?php
namespace App\Qcloud\Search;
use QcloudApi;
use App\Repositories\UserRepository;
use App\Repositories\ArchiveRepository;
use App\Repositories\TagRepository;
use App\Repositories\FollowRepository;
use Auth;
class Api
{
    protected $SECRETID = Conf::SECRET_ID;
    protected $SECRETKEY = Conf::SECRET_KEY;
    protected $APP_ID = Conf::APP_ID;
    protected $TABLE_TYPE = Conf::TABLE_TYPE;

    public function __construct(
        UserRepository $user,
        ArchiveRepository $archive,
        TagRepository $tag
    ) {
        $config = array('SecretId' => $this->SECRETID,
            'SecretKey'      => $this->SECRETKEY,
            'RequestMethod'  => 'POST',
            'DefaultRegion'  => 'gz');
        $this->service = QcloudApi::load(QcloudApi::MODULE_YUNSOU, $config);
        $this->user = $user;
        $this->tag = $tag;
        $this->archive = $archive;
    }
    /*
     * @params type : ARCHIVE | USER | TAG
     * @params searchTime : 时间戳
     * @params condition : 腾讯云查询接口参数参见https://cloud.tencent.com/document/product/270/1318
     */
    public function find($str, $type='ARCHIVE', $searchTime=0, $condition=[], $page=0, $pageSize=10)
    {
        $TABLE_TYPE = $this->TABLE_TYPE[$type];

        // 请求参数，请参考wiki文档上对应接口的说明
        $package = array_merge([
            'appId' => $this->APP_ID,
            //$keyword为指定搜索的词
            'search_query' => $str,
            'page_id' => $page,
            'num_per_page' => $pageSize,
            'query_encode' => 0
        ]);
        if($type == 'ARCHIVE') {
            $package = array_merge($package,['FA' => 'hotScore_0']);
        }
        if($searchTime != 0 && $type == 'ARCHIVE') {
            $package = array_merge($package,[
                'num_filter' => '[N:NA:'.$searchTime.':'.time().']'
            ]);
        }
        if (count($condition) > 0) {
            $package = array_merge($package,$condition);
        }
        // 分类域合并 分类域规定在哪个表所属域下查找
        $clFilterOfTable = '[C:tableType:'.$TABLE_TYPE.']';

        if(!empty($package['cl_filter'])){
            $package['cl_filter'] = $clFilterOfTable.'&'.$package['cl_filter'];
        }else{
            $package['cl_filter'] = $clFilterOfTable;
        }
        $res = $this->service->DataSearch($package);
        if($res['codeDesc'] == 'Success'){
            $list = [];
            if($res['data']['result_list']) {
                $ids = $this->getSearchIds($res['data']['result_list'],$TABLE_TYPE);
                if(count($ids) > 0) {
                    switch ($type)
                    {
                        case 'ARCHIVE' :
                            $this->archive->with(['firstPictures']);
                            $list = $this->archive->whereIn('id',$ids)->orderBy('hot_score','desc')->findAll();
                            break;
                        case 'TAG' :
                            $list = $this->tag->whereIn('id',$ids)->findAll();
                            break;
                        case 'USER' :
                            $list = $this->user->whereIn('UserId',$ids)->findAll();
                            // 获取关注关系
                            $Follow = new FollowRepository();
                            $list->each(function($item) use($Follow){
                                // 0 未关注 ， 1 已关注 ， 2 互相关注
                                $visiable = $item->getVisible();
                                $visiable[] = 'followStatus';
                                $item->setVisible($visiable);
                                $item->followStatus = $Follow->getFollowStatus($item->UserId);
                            });
                            break;
                    }
                }

            }
            return [
                'code' => '0',
                'totalCount' => $res['data']['eresult_num'],
                'list' => $list
            ];
        }else {
            $error = $this->service->getError();
            return [
                'code' => $error->getCode(),
                'message' => $error->getMessage(),
                'totalCount' => 0,
                'list' => []
            ];
        }
    }

    /*
     * @params type : ARCHIVE | USER | TAG
     * @params data : 关于各个仓库的查询出的实例，数组
     */
    public function add($type='ARCHIVE', $data)
    {
        if(count($data) == 0){
            return ['status' => -1 , 'code' => -1, 'message' => "添加数据不能为空"];
        }
        $package = [];
        switch ($type){
            case 'ARCHIVE' :
                $package = $this->archiveDataPackage($data);
                break;
            case 'USER' :
                $package = $this->userDataPackage($data);
                break;
            case 'TAG' :
                $package = $this->tagDataPackage($data);
                break;
        }
        $res = $this->service->DataManipulation($package);
        return $this->responseHandle($res);
    }

    /*
     * @params docIds : 在云搜的文档id，可调getPushIds生成
     * @return : code => 0 成功： 1 部分失败 ： -1 全部失败；
     */

    public function del($tableType, $docIds = [])
    {
        if(count($docIds) == 0)
            return;

        $package = [
            'appId' => $this->APP_ID,
            'op_type' => 'del'
        ];
        $ids = [];
        foreach($docIds as $index => $id){
            $ids['contents.'.$index.'.doc_id'] = self::getPushIds($tableType, $id);
        }

        $package = array_merge($package,$ids);
        $res = $this->service->DataManipulation($package);

        if($res && $res['codeDesc'] == 'Success' ){
            $data = $res['data']['result'];
            $successIds = [];
            $failIds = [];
            foreach ($data as $index => $val){
                if($val['result'] != 'succ'){
                    $failIds[] = $val['doc_id'];
                }else{
                    $successIds[] = $val['doc_id'];
                }
            }
            return [
                'code' => count($failIds) > 0 ? 1 : 0,
                'failIds' => $failIds
            ];
        }else {
            return ['code' => -1];
        }
    }

    private function responseHandle($res)
    {
        if ($res === false) {
            // 请求失败，解析错误信息
            $error = $this->service->getError();
            return ['status' => -1 , 'code' => $error->getCode(), 'message' => $error->getMessage()];
        } else {
            // 请求成功
            return ['status' => 0];
        }
    }


    private function getSearchIds($arr,$type)
    {
        $ids = [];
        foreach ($arr as $item){
            $docId = (int) $item['doc_id'];
            $id = $docId - 1000000000 * $type;
            $ids[] = $id;
        }
        return $ids;
    }
    /*
     * @params archives : archiveRepostory 查询出的实例数组
     */
    private function archiveDataPackage($archives)
    {
        $type = $this->TABLE_TYPE['ARCHIVE'];
        foreach ( $archives as  $index => $item) {
            // 修改字段与腾讯云搜字段对应
            $reqData = [
                "TA" => $item->title,
                "TC" => $item->user_name,
                "id" => self::getPushIds($type,$item->id),
                "NA" => $item->sort_time,
                "FA" => $item->hot_score,
                "tableType" => $type,
                "CA" => $item->class_id,
                "CB" => $item->tag,
                "CC" => $item->is_video
            ];
            if($item->class_id == 1 && $item->article) {
                $content = strip_tags($item->article->content);
                if(!empty($content)){
                    $contentMaxLength = self::modifyContentLength($reqData);
                    if( $contentMaxLength > 0){
                        $content = self::fixSubStrCut(substr($content, 0, $contentMaxLength));
                    }
                }else {
                    $content = $item->description ? $item->description : $item->title;
                }
            }else {
                $content = $item->description ? $item->description : $item->title;
            }
            $reqData["TB"] = $content;
            $reqData = self::getPackageData($index, $reqData);
        }
        $package = array_merge(['appId' => $this->APP_ID, 'op.type' => 'add'],$reqData);
        return $package;
    }
    /*
     * @params users : userRepostory 查询出的实例数组
     */
    private function userDataPackage($users)
    {
        $type = $this->TABLE_TYPE['USER'];
        $reqData = [];
        foreach ( $users as  $index => $item) {
            // 修改字段与腾讯云搜字段对应
            $data = [
                "TA" => $item->NickName,
                "TB" => $item->brief ? $item->brief : '暂无',
                "TC" => $item->summary ? $item->summary : '暂无',
                "id" => self::getPushIds($type,$item->UserId),
                "CA" => $item->type,
                "tableType" => $type,
            ];
            $reqData = array_merge($reqData,self::getPackageData($index, $data));
        }
        $package = array_merge(['appId' => $this->APP_ID, 'op_type' => 'add'],$reqData);
        return $package;
    }
    /*
     * @params tags : tagsRepostory 查询出的实例数组
     */
    private function tagDataPackage($tags)
    {
        $type = $this->TABLE_TYPE['TAG'];
        $reqData = [];
        foreach ($tags as  $index => $item) {
            // 修改字段与腾讯云搜字段对应
            $data = [
                "TA" => $item->name,
                "TB" => $item->alias ? $item->alias : $item->name,
                "TC" => $item->description ? $item->description : $item->name,
                "id" => self::getPushIds($type,$item->id),
                "tableType" => $type
            ];
            $reqData = array_merge($reqData,self::getPackageData($index, $data));
        }

        $package = array_merge(['appId' => $this->APP_ID, 'op_type' => 'add'],$reqData);
        return $package;
    }
    private static function modifyContentLength($data)
    {
        // 因为腾讯云API请求体大小限制63K,所以对提交的数据需要进行裁剪
        // 粗略计算
        // 定长参数 160-170之间；
        $fixedRequestLength = 300;
        // 浮动阈值
        $threshold = 50;
        $reqBodyLength = strlen(http_build_query($data)) + $fixedRequestLength + $threshold;
        // 一个中文长度为9，其余都为1
        return 64512 - $reqBodyLength;
    }
    private static function fixSubStrCut($str)
    {
        // 修复多字节裁剪错误的问题
        $lastStr = substr($str,-1,1);
        $charNumberPattern = "/[A-Za-z0-9]/";
        $threeByteCharPattern = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
        if(!preg_match($charNumberPattern,$lastStr)) {
            //如果最后一个不是字母或者数字
            $last3Char = substr($str,-3,3);
            if(!preg_match($threeByteCharPattern, $last3Char)) {
                $secondLastStr = substr($str,-2,1);
                if(!preg_match($charNumberPattern,$secondLastStr)) {
                    //将最后一个字节去掉
                    return substr($str,0,-2);
                }else {
                    return substr($str,0,-1);
                }
            }
        }

        //如果最后一个字符是正常字母的话，截取正确；
        return $str;
    }
    private static function getPushIds($type, $id)
    {
        return (int) sprintf($type.'%09s',$id);
    }
    private static function getPackageData($index = 0,$data)
    {
        $YUNSOU_COLUMNS = [
            'TA' => '暂无',
            'TB' => '暂无',
            'TC' => '暂无',
            'TD' => '暂无',
            'id' => 0,
            'NA' => 0,
            'NB' => 0,
            'NC' => 0,
            'FA' => 0,
            'FB' => 0,
            'FC' => 0,
            'tableType' => 0,
            'CA' => 0,
            'CB' => 0,
            'CC' => 0,
            'CD' => 0
        ];
        $mergeData = array_merge($YUNSOU_COLUMNS,$data);
        $columnData = [];
        foreach ($mergeData as $key => $value){
            $columnData['contents.'.$index.'.'.$key] = $value;
        }
        return $columnData;
    }
}


