<?php

namespace App\Qcloud;

use Exception;
use QcloudApi;

class Qcloud
{
    public static function __callStatic($name, $arguments)
    {
        $config = config('qcloud');
        $module = 'MODULE_'.strtoupper($name);
        list($action, $params) = $arguments;
        $service = QcloudApi::load(constant('QcloudApi::'.$module), $config);
        if ($service === false) {
            throw new Exception('QCloud module:'.$name.'不存在');
        }

        $ret = $service->$action($params);
        if ($ret === false) {
            $error = $service->getError();
            return ['code' => $error->getCode(), 'message' => $error->getMessage()];
        }

        return ['code' => 0, 'data' => $ret];
    }
}