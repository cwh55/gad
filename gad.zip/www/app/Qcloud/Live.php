<?php

namespace App\Qcloud;

use GuzzleHttp\Client;
use RuntimeException;

class Live
{
    const API_URL = 'https://live.api.qcloud.com/v2/index.php';

    public static function describeChannelList($channelStatus = 3)
    {
        $param = self::getCommonParam();
        $param['Action'] = 'DescribeLVBChannelList';
        $param['channelStatus'] = $channelStatus;
        $param['Signature'] = self::sign($param);
        $result = self::httpGet($param);

        return $result;
    }
    
    public static function createChannel($channelName, $sourceName)
    {
        $param = self::getCommonParam();
        $param['Action'] = 'CreateLVBChannel';
        $param['channelName'] = $channelName;
        $param['sourceName'] = $sourceName;
        $param['outputSourceType'] = 3;
        $param['sourceList.1.name'] = $sourceName;
        $param['sourceList.1.type'] = 1;
        $param['Signature'] = self::sign($param);
        $result = self::httpGet($param);

        return $result;
    }

    public static function describeChannel($channelId)
    {
        $param = self::getCommonParam();
        $param['Action'] = 'DescribeLVBChannel';
        $param['channelId'] = $channelId;
        $param['Signature'] = self::sign($param);
        $result = self::httpGet($param);

        return $result;
    }

    public static function startChannel(array $channelIds)
    {
        $param = self::getCommonParam();
        $param['Action'] = 'StartLVBChannel';
        $param['channelId'] = $channelIds;
        $param['Signature'] = self::sign($param);
        $result = self::httpGet($param);

        return $result;
    }

    public static function stopChannel(array $channelIds)
    {
        $param = self::getCommonParam();
        $param['Action'] = 'StopLVBChannel';
        $param['channelIds'] = $channelIds;
        $param['Signature'] = self::sign($param);
        $result = self::httpGet($param);

        return $result;
    }

    public static function deleteChannel(array $channelIds)
    {
        $param = self::getCommonParam();
        $param['Action'] = 'DeleteLVBChannel';
        $param['channelIds'] = $channelIds;
        $param['Signature'] = self::sign($param);
        $result = self::httpGet($param);

        return $result;
    }

    public static function createRecord($channelId, $startTime = null, $endTime = null)
    {
        $param = self::getCommonParam();
        $param['Action'] = 'CreateRecord';
        $param['channelId'] = $channelId;
        if ($startTime) {
            $param['startTime'] = $startTime;
        }

        if ($endTime) {
            $param['endTime'] = $endTime;
        }

        $param['Signature'] = self::sign($param);
        $result = self::httpGet($param);

        return $result;
    }

    public static function stopRecord($channelId, $taskId)
    {
        $param = self::getCommonParam();
        $param['Action'] = 'StopRecord';
        $param['channelId'] = $channelId;
        $param['taskId'] = $taskId;
        $param['Signature'] = self::sign($param);
        $result = self::httpGet($param);

        return $result;
    }

    /**
     * 查询已录制分片列表
     *
     * @param $channelId
     * @param $taskId
     * @return mixed
     */
    public static function describeRecord($channelId, $taskId)
    {
        $param = self::getCommonParam();
        $param['Action'] = 'DescribeRecord';
        $param['channelId'] = $channelId;
        $param['taskId'] = $taskId;
        $param['Signature'] = self::sign($param);
        $result = self::httpGet($param);

        return $result;
    }

    /**
     * 查询录制任务列表
     *
     * @param $channelId
     * @return mixed
     */
    public static function describeRecordList($channelId)
    {
        $param = self::getCommonParam();
        $param['Action'] = 'DescribeRecordList';
        $param['channelId'] = $channelId;
        $param['Signature'] = self::sign($param);
        $result = self::httpGet($param);

        return $result;
    }

    private static function getCommonParam()
    {
        return [
            'Region' => 'gz',
            'Timestamp' => time(),
            'Nonce' => mt_rand(10000, 99999),
            'SecretId' => env('QCLOUD_SECRET_ID'),
        ];
    }

    private static function httpGet($param)
    {
        $client = new Client([
            'timeout' => 10,
            'proxy' => [
                'http' => 'http://10.178.138.25:8080/'
            ]
        ]);
        $response = $client->get(self::API_URL.'?'.http_build_query($param));
        if ($response->getStatusCode() != 200) {
            throw new RuntimeException('腾讯云直播接口请求失败：'.$response->getReasonPhrase());
        }

        $content = json_decode($response->getBody());
        if (!$content) {
            throw new RuntimeException('腾讯云直播接口请求返回异常');
        }

        return $content;
    }

    private static function sign($param)
    {
        ksort($param);
        $paramStr = sprintf('%s%s?', 'GET', str_replace('https://', '', self::API_URL));
        $temp = [];
        foreach ($param as $key => $value) {
            $key = str_replace('-', '.', $key);
            $temp[] = $key.'='.$value;
        }
        $paramStr = $paramStr.implode('&', $temp);
        $secretKey = env('QCLOUD_SECRET_KEY');

        return base64_encode(hash_hmac('sha1', $paramStr, $secretKey, true));
    }
}