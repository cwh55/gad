<?php
namespace App\Qcloud\Cos;

class Conf
{
    const PKG_VERSION = '1.0.0'; 

    const API_IMAGE_END_POINT = 'http://web.image.myqcloud.com/photos/v1/';
    const API_VIDEO_END_POINT = 'http://web.video.myqcloud.com/videos/v1/';
    //正式用
    const API_COSAPI_END_POINT = 'http://web.file.myqcloud.com/files/v1/';
    //请到http://console.qcloud.com/cos去获取你的appid、sid、skey
//    const APPID = '10016574';
//    const SECRET_ID = 'AKIDM6C7Ss8IuUSy9HxASEjagEC3GcKGmT6T';
//    const SECRET_KEY = 'zTQPuDGmyBL1bKIjOlVxN61QKq7ZMwDo';
//    const BUCKET_NAME='gad';

    const APPID = '10045137';
    const SECRET_ID = 'AKIDIqmzlwyPtks17hD1kzKl8QwwfZ7vROdf';
    const SECRET_KEY = 'Pq9i4Nn0p9zCoxg0E0iO8E0fyigPD9YW';
    const BUCKET_NAME='gad';



    public static function getUA() {
        return 'QcloudPHP/'.self::PKG_VERSION.' ('.php_uname().')';
    }
}


//end of script
