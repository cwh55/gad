<?php

namespace App\Http\Middleware;

use Closure;

use Auth;

class CheckPermit
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $permit, $param = '')
    {
		if(Auth::check()){
			$para = array();
			if($param){
				$params = explode(";", $param);
				foreach($params as $param){
					$p = explode("=", $param);
					$para[$p[0]] = $p[1];
				}
			}
			if($request->user()->permit($permit, $para)){
				return $next($request);
			}
		}
		if($request->isMethod('post')){
			return response()->json(['code' => -1111, 'msg' => 'not login']);
		}
		return !Auth::check() ? redirect()->guest('/login') : abort(403);;
    }
}
