<?php

namespace App\Http\Middleware;

use App\Jobs\ActiveQQSession;
use Auth;
use App\Models\User;
use Closure;
use Redis;

class CommunityHref
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
		$hrefKey = 'community::href::indent';
		$namespace = $request->route()->getAction();
		if (!$request->ajax() && Auth::user() != null && isset($namespace['namespace']) && !in_array($namespace['namespace'], ['App\Http\Controllers','App\Http\Controllers\Api','App\Http\Controllers\Operate'])){			if($request->route()->getAction()['namespace'] == 'App\Http\Controllers\Community'){
				Redis::hSet($hrefKey, Auth::user()->UserId, true);
			} else {
				Redis::hSet($hrefKey, Auth::user()->UserId, false);
			}
		}

        return $next($request);
    }
}
