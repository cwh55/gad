<?php

namespace App\Http\Middleware;

use App\Jobs\ActiveQQSession;
use Auth;
use App\Models\User;
use Closure;
use Redis;
use Validator;

class VerifyCaptcha
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $type)
    {
		$required = false;
		if(strpos($type,'archive') === 0 && Auth::user() != null){
			$archiveKey = 'user::community::'.$type.'::save::'.Auth::user()->UserId.'::'.date('Y-m-d');
			$archiveData = Redis::get($archiveKey);
			if($archiveData){
				$archiveData = json_decode($archiveData,true);
				if(isset($archiveData['total']) && $archiveData['total'] >= 10){//10篇
					if($archiveData['time'] >= time() - 60){
						$required = true;
					}
				}
			}
		} else if(strpos($type,'answer') === 0 && Auth::user() != null){
			$answerKey = 'user::community::'.$type.'::save::'.Auth::user()->UserId.'::'.date('Y-m-d');
			$answerData = Redis::get($answerKey);
			if($answerData){
				$answerData = json_decode($answerData,true);
				if($answerData['total'] >= 100){//超过100条
					if($answerData['time'] >= time() - 60){//1分钟内
						$required = true;
					}
				}
			}
		}
		if($required && $request->has('captcha')){
			$rules = ['captcha' => 'required|captcha'];
			$validator = Validator::make($request->all(), $rules);
			if($validator->fails()){
				return response()->json(['code' => 10002, 'message' => '验证码错误']);
			}
		} else if($required){
			return response()->json(['code' => 10001, 'message' => 'need captcha', 'data' => 'captcha']);
		}

        return $next($request);
    }
}
