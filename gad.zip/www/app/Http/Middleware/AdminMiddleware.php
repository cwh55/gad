<?php

namespace App\Http\Middleware;

use Auth;
use Closure;

class AdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        /*if (Auth::guard()->guest() AND !$request->is('admin/auth/*')) {
            if ($request->ajax() || $request->wantsJson()) {
                return response('Unauthorized.', 401);
            } else {
                return redirect('admin/auth/login');
            }

            $user = Auth::user();
            if (!$user->roles->contains(2)) {
                return response('Forbidden.', 403);
            }
        }*/

        return $next($request);
    }
}
