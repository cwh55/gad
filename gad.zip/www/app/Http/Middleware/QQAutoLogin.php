<?php

namespace App\Http\Middleware;

use Auth;
use App\Models\User;
use Closure;
use Request;
use Tencent\Ptlogin\Ptlogin;

class QQAutoLogin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        /*if (Auth::guard()->guest() AND !$request->is('auth/callback')) {
            $uin = intval(str_replace('o', '', $request->cookie('uin')));
            $sKey = $request->cookie('skey');
            if ($uin AND $sKey AND Ptlogin::check($uin, $sKey)) {
                $user = User::where('QQNo', $uin)->first();
                if ($user) {
                    Auth::login($user);
                    Request::setTrustedProxies([Request::server('REMOTE_ADDR')]);
                    $user->ip = Request::ip();
                    $user->save();
                    session(['loginType' => 'qq']);
                }
            }
        }*/

        return $next($request);
    }
}
