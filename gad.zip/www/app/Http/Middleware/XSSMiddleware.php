<?php

namespace App\Http\Middleware;

use Closure;
use SECAPI_AntiXss;
use Illuminate\Foundation\Application;

use Redis;

class XSSMiddleware
{


    /**
     * The application instance.
     *
     * @var \Illuminate\Foundation\Application
     */
    protected $app;

    protected $secapi;

    protected $secConfig;

    /**
     * Create a new middleware instance.
     *
     * @param  \Illuminate\Foundation\Application  $app
     * @return void
     */
    public function __construct(Application $app, SECAPI_AntiXss $secapi)
    {
        $this->app = $app;
        $this->secapi = $secapi;
        
        $cacheKey = 'SECAPICONFIG';
        $config = Redis::get($cacheKey);
        if(empty($config)) {
            $fh = fopen($this->app->configPath().DIRECTORY_SEPARATOR."secapi.conf", "rb");
            $config = fread($fh, 4096*2);
            $ret = Redis::setex($cacheKey, 60*60*24, $config);
            fclose($fh);
        }
        $this->secConfig = $config;
    }


    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        //对post请求进行过滤
        if($request->method() == 'POST') {
            $requestArr = $request->all();
            
            array_walk($requestArr, function(&$p) {
                if(class_exists('SECAPI_AntiXss')) {
                    //$p = $this->secapi->FilterAllActiveContent($this->secConfig, $p);
                }
            });
            $request->replace($requestArr);
        }
        return $next($request);
    }
}
