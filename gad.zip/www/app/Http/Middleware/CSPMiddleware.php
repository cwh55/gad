<?php

namespace App\Http\Middleware;

use Closure;

class CSPMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $response = $next($request);
        $response->headers->set('Content-Security-Policy-Report-Only', config('app.csp'));
        $response->headers->set('X-XSS-Protection', 0);

        return $response;
    }

}
