<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as BaseVerifier;

class VerifyCsrfToken extends BaseVerifier
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [
        'course/wxpay/notify', 'course/wxpay/result', 'course/wxpay/callback',
        'course/lesson/convertVodNotify', 'course/doc2Html','article/editorUploadImage',
        'mgr/*', 'admin/*', 'api/*'
    ];
}
