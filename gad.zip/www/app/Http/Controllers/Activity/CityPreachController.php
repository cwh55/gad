<?php

namespace App\Http\Controllers\Activity;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\CityStationRepositoryEloquent;
use App\Repositories\UserRepositoryEloquent;
use Auth;

class CityPreachController extends Controller
{

	protected $cityStation;
	protected $user;

	public function __construct(CityStationRepositoryEloquent $cityStation, UserRepositoryEloquent $user)
	{
		$this->cityStation = $cityStation;
		$this->user = $user;
	}

	public function getIndex(Request $request, $city_id = 1)
	{
		$city_id = intval($city_id);
		if ($city_id == 7) abort(404);
		$city = ['city_id' => $city_id, 'id'=> '', 'type'=> 1, 'group_type'=> 2, 'name'=> '', 'position'=>'', 'qq'=> '', 'mobile'=> '', 'corp'=> '',
                    'members'=> '', 'game_name'=> '', 'game_os'=> '', 'game_type'=> '', 'description'=> '', 'game_att'=> []];

		if (Auth::user()) {
		  $userId = Auth::user()['UserId'];
			$city['qq'] = Auth::user()['QQNo'] == 0 ? '' : Auth::user()['QQNo'];
			$temp = $this->cityStation->findWhere(['user_id' => $userId, 'city_id' => $city_id])->toArray();
                        $city = empty($temp) ? $city : $temp[0];
			if(isset($city['game_att']) && !is_array($city['game_att'])){
				$city['game_att'] = json_decode($city['game_att'],true);
			}
                        $isAdmin = Auth::user()->roles->contains(2);
		}else{
                    $isAdmin = '';
                }
            
            return view('activity.citypreach'.$city_id, ['city'=>$city, 'isLogin' => Auth::check(), 'isEnd' => $this->cityStation->isEnd($city_id), 'city_id'=>$city_id, 'isAdmin'=>$isAdmin]);
	}

	public function signup(Request $request)
	{
		if(!Auth::user()){
			return response()->json(['code' => -1,'msg' => 'not login','data' => '']);
		}
		$city = $this->cityStation->find($request->input('id',0));
		return view('activity.citysignup', $city);
	}

	public function postStoreInfo(Request $request)
	{
		if(!Auth::user()){
			return response()->json(['code' => -1,'msg' => 'not login','data' => '']);
		}

		$all = $request->all();
		$id = intval($request->input('id'));
		$city_id = intval($request->input('city_id',0));

		if($this->cityStation->isEnd($city_id)){
			return response()->json(['code' => -2,'msg' => '报名已经截止','data' => '']);
		}

		$result = 0;
		$userId = Auth::user()['UserId'];
		$all['user_id'] = $userId;
		$all['status'] = 1;
		$step = intval($request->input('step',1));
		if($step != 1 && $step != 2){
			$step = 1;
		}

		if($step == 1){
			$this->validate($request,[
				'type' => 'required|integer',
				'group_type' => 'required|integer',
				'city_id' => 'required|integer',
				'name' => 'required',
				'qq' => 'required|min:6',
				'mobile' => 'required',
			]);
		}

		if($step == 2){
			$this->validate($request,[
				'game_name' => 'required',
				'game_os' => 'required|integer',
			]);
		}

		if(isset($all['game_att']) && !is_array($all['game_att'])){
			$all['game_att'] = [];
		}

		unset($all['created_at'],$all['updated_at'],$all['deleted_at'],$all['id']);


		if($id){
			if($this->cityStation->findWhere(['user_id'=>$userId, 'id'=>$id])->count()){
				$result = $this->cityStation->update( $all, $id);
			}
		} else {
			if($this->cityStation->findWhere(['user_id'=>$userId, 'city_id'=>$city_id])->count() <= 0){
				$result = $this->cityStation->create( $all );
			}
		}

		if($result){
			return response()->json(['code'=>0, 'data'=>$result->id, 'msg'=>'']);
		} else {
			return response()->json(['code'=>-1, 'data'=>'', 'msg'=>'create update data error']);
		}
	}
}
