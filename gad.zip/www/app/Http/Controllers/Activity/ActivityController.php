<?php

namespace App\Http\Controllers\Activity;
use App\Entities\Activity;
use App\Entities\ActivityComment;
use App\Entities\Service;
use App\Entities\ServiceMember;
use App\Entities\User;
use App\Gad\Lib_Func;
use App\Gad\MessageType;
use App\Gad\TofService;
use App\Models\Article;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Register;
use App\Models\Classify;
use App\Models\Game;
use App\Models\Summercourse;
use App\Models\KeyValue;
use App\Repositories\ActivityCommentRepository;
use App\Repositories\ActivityRepository;
use App\Repositories\ActivitySignupRepository;
use App\Repositories\ServiceMemberRepository;
use App\Repositories\ServiceOrderRepository;
use Illuminate\Http\Request;
use App\Gad\Upload;
use App\Gad\Func;
use Auth;
use Gate;
use Redis;

class ActivityController extends Controller
{
    public function __construct(Request $request)
    {
        $this->middleware("auth", ['only' => ['getEdit', 'postDel', 'postComment', 'postSignup', 'getAdmin', 'getApply']]);
    }

    //项目服务首页
    public function getIndex()
    {
        return view('hatche.service.ip_list', $data);//
    }


    private function hatchValidate($request)
    {
        $data = $request->all();
        $message = ['required' => ':attribute不能为空'];
        $this->validate($request, [
            'service_type' => 'required|integer|max:5|min:1',
            'service.name' => 'required'
        ], $message);
        if ($data['service_type'] == 1) {
            $this->validate($request, [
                'service.ip_type' => 'required',
                'service.logo' => 'required',
                'service.description' => 'required',
                'service.ip_range' => 'required|array',
                'service.showcase' => 'required|array',
                'service.ip_style' => 'required',
                'service.online_time' => 'required'
            ], $message);
        }
        if ($data['service_type'] == 2) {
            $this->validate($request, [
                'SMSCode' => 'required',
                'game.project.name' => 'required',
                'game.project.platform' => 'required|array',
                'game.project.intro' => 'required',
                'game.project.demo' => 'required|array',
                'game.project.videos' => 'required|array',
                'game.hatch_service' => 'required|array',
                'game.project.pictures' => 'array',
                'game.project.other_attachment' => 'array'
            ], $message);
            if (!$this->validUserSmsCode($data['SMSCode'], $data['game']['project']['team_phone'])) {
                throw new \Exception('验证码不正确');
            }
        }
        if ($data['service_type'] == 3) {
            $this->validate($request, [
                'service.showcase' => 'required|array',
                'service.logo' => 'required',
                'service.office_seat' => 'required|integer',
                'service.office_price' => 'required',
                'service.name' => 'required',
                'service.description' => 'required',
                'service.office_address' => 'required'
            ], $message);
        }
    }

    public function postSave(ServiceRepository $serviceRepository, ServiceMemberRepository $memberRes, Request $request)
    {
        $this->hatchValidate($request);
        $data = $request->all();
        $data = array_map('xssFilter', $data);
        $user = Auth::user();
        $member = $memberRes->where('user_id', $user->UserId)->where('status', 0)->where('service_member_type', $data['service_type'])->findAll();
        if (count($member) == 0) {
            return response()->json(['code' => -1, 'message' => '您还没认证，请先认证']);
        }
        $member = $member[0];
        $index = 1;
        if (!empty($data['service']['id'])) {
            $service = $serviceRepository->find($data['service']['id']);
            if (empty($service) || $service->service_member_id != $member->id) {
                throw new \Exception('不存在此服务');
            }
            foreach ($data['service']['derivatives'] as $k => $va) {
                if ($va['status'] == true && $va['name'] != '') {
                    $va['id'] = $index;
                    $index++;
                } else {
                    unset($data['service']['derivatives'][$k]);
                }
            }
            $data['service']['service_member_id'] = $member->id;
            list($status, $service) = $serviceRepository->update($data['service']['id'], $data['service']);
            if (!$status) {
                throw new \Exception('更新数据有误');
            }
        } else {
            $data['service']['service_type'] = $data['service_type'];
            $data['service']['service_member_id'] = $member->id;
            $index = 1;
            foreach ($data['service']['derivatives'] as $k => $va) {
                if ($va['status'] == true && $va['name'] != '') {
                    $va['id'] = $index;
                    $index++;
                } else {
                    unset($data['service']['derivatives'][$k]);
                }
            }
            //$data['game']['project']['is_finish'] = 0;
            //$data['game']['project']['logo'] = 'http://gad.qpic.cn/assets/v2/web/img/hatch/project/default_logo.png';
            list($status, $service) = $serviceRepository->create($data['service']);
            if (!$status) {
                throw new \Exception('新增数据失败' . $status);
            }
        }
        //$data['game']['reg_step']++;
        //$memberEn =  = $member = $serviceMem['game']['project_id'] = $member = ->id;
        //$gameQuery = \App\Models\Game::query();
        //$game = $gameQuery->with(['project'])->where('user_id', $user->UserId)->get()->first();
        ///if (empty($game)) {
        //    $data['game']['status'] = 1;
        //    $data['game']['user_id'] = $user->UserId;
        //    $data['game']['obj_type'] = 1;
        //    if(!$game = Game::create($me['game'])){
        //        throw new \Exception('更新数据失败');
        //    }
        //    $game->project = $project;
        //}else{
        //    unset($data['game']['status'], $data['game']['user_id'], $data['game']['obj_type']);
        //    if(!$game->update($data['game'])){
        //        throw new \Exception('更新数据失败');
        //    }
        //}
        if ($status && false) {
            //$projectRepository->update($project->id, ['is_finish'=>1]);
            //发送站内信
            Func::msgApi(MessageType::PROJECT_APPLY_SUCCESS, $user->UserId, 0, $service->id, url('/hatch/service/ip-detail', $service->id), $service->name);
            //填写完毕后邮件通知
            $title = '[GAD项目扶持]感谢你提交项目资料，请耐心等待审核结果。';
            $mail = view('hatch.mail_create', array('user' => $service->name, 'game' => $service->name, 'title' => $title))->render();
            \Tof::service('message')->sendEmail('gad@tencent.com', $member->email, $title, $mail);
        }
        return response()->json(['code' => 0, 'data' => $service, 'project_id' => '']);
    }

    public function postComment(Request $request, ActivityRepository $activityRes, ActivityCommentRepository $activityCommentRes, $id = 0)
    {
        $detail = $activityRes->find($id);
        if (empty($detail) || $detail->status != 0 || $detail->is_comment == 0) {
            return response()->json(['code' => -1, 'message' => '您没有权限评论']);
        }

        $this->validate($request, ['comment' => 'required']);
        $all = array_map('xssFilter', $request->all());
        $comment = $all['comment'];
        if (Func::hasBadWord($detail->id, $comment, $comment, $comment)) {
            return response()->json(['code' => -1, 'message' => '非法内容']);
        }
        $data = ['comment' => $comment, 'user_id' => Auth::user()->UserId, 'activity_id' => $id, 'activity_type' => $detail->type];
        $res = $activityCommentRes->create($data);

        $count = ActivityComment::where('activity_id', $id)->count(\DB::raw('distinct user_id,activity_id'));
        $activityRes->update($id, ['comment_count' => $count]);

        if ($res[0]) {
            $data = $res[1];
            $data->user = Auth::user();
            return response()->json(['code' => 0, 'data' => $data, 'message' => '修改成功']);
        }

        return response()->json(['code' => -1, 'message' => '新增出错']);
    }

    public function getCommentList(Request $request, ActivityRepository $activity, ActivityCommentRepository $activityComment, $id = 0)
    {
        $detail = $activity->find($id);
        if (empty($detail)) {
            return response()->json(['code' => -1, 'data' => []]);
        }
        $page = $request->input('page', 0);
        $pageSize = $request->input('pageSize', 20);
        $start_date = $request->input('start_date', '');
        $data = $activityComment->getListBy($id, $page, $pageSize, '', $start_date);
        return response()->json(['code' => 0, 'data' => $data, 'comment_count' => $detail->comment_count]);
    }

    public function getDetail(Request $request, ActivityRepository $activityRes, ActivitySignupRepository $activitySignupRes, ActivityCommentRepository $activityCommentRes, $id = 0)
    {
        $detail = $activityRes->find($id);
        $user = Auth::user();
        if (empty($detail) || ($detail->status != 0 && !($user && ($user->roles->contains(2) || $user->UserId == $detail->user_id)))) {
            return abort(404);
        }

        $signup = $activitySignupRes->getListBy($id, 0, 20);
        $comment = $activityCommentRes->getListBy($id, 0, 20);
        $service = $detail->type == 1 ? 'offline' : 'online';

        if ($user == null) {
            $user = new User();
        }
        $type = 'start';
        if (date("Y-m-d", strtotime($detail->start_time)) <= date('Y-m-d H:i:s') && $detail->end_time >= date('Y-m-d H:i:s')) {
            $type = 'ing';
        } else if ($detail->end_time < date('Y-m-d H:i:s')) {
            $type = 'end';
        }
        $time = strtotime($detail->start_time) - time();
        //$latlng = @file_get_contents('http://apis.map.qq.com/ws/geocoder/v1/?address='.$detail->province.$detail->city.$detail->address.'&key=XXHBZ-R5NWS-Z6LOS-6ODEQ-H5DO7-VSF5H');
        $latlng = $detail->location;
        $lat = '';
        $lng = '';
        if ($latlng) {
            $lng = $latlng[1];
            $lat = $latlng[0];
        }
        if ($lng == '' || $lat == '') {
            $lng = 39.91;
            $lat = 104.91;
        }

        if ($request->wantsJson()) {
            $detail->signup = $signup;
            return response()->json(['code' => 0, 'data' => ['detail' => $detail, 'comment' => $comment, 'user' => $user, 'status' => $type]]);
        }
        return view('activity.center.' . $service . '_detail', compact('detail', 'signup', 'comment', 'user', 'type', 'time', 'lng', 'lat'));
    }

    public function getList(Request $request, ActivityRepository $activityRes, $service = '')
    {
        $page = $request->input('page', 1);
        $pageSize = $request->input('pageSize', 10);
        $orderBy = $request->input('orderBy', 'new');
        $city = $request->input('city', '');
        $start_time = $request->input('start_time', '');
        $end_time = $request->input('end_time', '');
        $status = $request->input('state', 0);
        $service = $request->input('type', '');

        if ($pageSize > 100) {
            $pageSize = 20;
        }
        if ($city == '全部') {
            $city = '';
        }

        $data = [];

        $data['data'] = $activityRes->getListByType($service, $city, $page, $pageSize, $status, $start_time, $end_time);
        if ($request->wantsJson()) {
            return response()->json(['code' => 0, 'data' => $data['data']]);
        }

        return view('activity.center.list', $data);
    }

    public function postSignup(Request $request, ActivityRepository $activity, ActivitySignupRepository $activitySignup, $id = 0)
    {
        $detail = $activity->find($id);
        if (empty($detail)) {
            return response()->json(['code' => -1, 'message' => '没有这个活动']);
        }
        $user = Auth::user();
        $type = $request->input('register.type');
        $setting = '';
        foreach($detail->signup_setting as $st){
            $setting = $st['role'] == $type ? $st['setting'] : $setting;
        }
        if(!$setting) {
            return response()->json(['code' => -1, 'message' => '参数出错']);
        }
        $fields = [];
        foreach ($setting as $val) {
            $required = $val['required'] ? 'required|' : '';
            if ($val['key'] == 'email') {
                $fields[] = ['key' => 'register.' . $val['key'], 'name' => $val['text'], 'rule' => $required . 'email'];
            } else if ($val['key'] == 'qq') {
                $fields[] = ['key' => 'register.' . $val['key'], 'name' => $val['text'], 'rule' => $required . 'integer'];
            } else if($val['key'] == 'phone') {
                $fields[] = ['key' => 'register.' . $val['key'], 'name' => $val['text'], 'rule' => $required . 'digits:11'];
            } else if($val['bigType'] == 'input') {
                if($val['smallType'] != 'file') {
                    $fields[] = ['key' => 'register.' . $val['key'], 'name' => $val['text'], 'rule' => $required . 'string'];
                } else {
                    $fields[] = ['key' => 'register.' . $val['key'], 'name' => $val['text'], 'rule' => $required . 'array'];
                }
            } else if($val['bigType'] == 'select' && $val['smallType'] == 'city') {
                $fields[] = ['key' => 'register.province', 'name' => '省份', 'rule' => $required . 'string'];
                $fields[] = ['key' => 'register.city', 'name' => '城市', 'rule' => $required . 'string'];
            } else if($val['bigType'] == 'textarea'){
                $fields[] = ['key' => 'register.' . $val['key'], 'name' => $val['text'], 'rule' => $required . 'string|max:500'];
            } else if($val['smallType'] == 'checkbox') {
                $fields[] = ['key' => 'register.' . $val['key'], 'name' => $val['text'], 'rule' => $required . 'array'];
            } else {
                $fields[] = ['key' => 'register.' . $val['key'], 'name' => $val['text'], 'rule' => $required . 'string'];
            }
        }
        $validator = [
            'messages' => [
                'required' => ':attribute不能为空',
                'register.email.email' => '请填写有效邮箱地址',
                'register.smsCode.digits' => ':attribute错误',
                'register.phone.digits' => '请填写有效:attribute',
                'register.topic.max' => '主题不能超过500字'
            ]
        ];
        foreach ($fields as $field) {
            $validator['rule'][$field['key']] = $field['rule'];
            $validator['attr'][$field['key']] = $field['name'];
        }

        $this->validate($request, $validator['rule'], $validator['messages'], $validator['attr']);
        $all = array_map('xssFilter',$request->all());

        $data = $all['register'];
        $data['user_id'] = $user->UserId;
        $data['activity_id'] = $id;
        $data['activity_type'] = $detail->type;
        $data['type'] = $type;
//        $data['phone'] = $all['register']['phone'];
//        $data['email'] = array_get($all['register'],'email','');
//        $data['qq'] = $all['register']['qq'];
        //$data['address'] = $all['register']['address'];
//        $data['topic'] = array_get($all['register'],'topic','');
//        $data['company'] = array_get($all['register'],'company','');
//        $data['province'] = array_get($all['register'],'province','');
//        $data['city'] = array_get($all['register'],'city','');
//        $data['attachment'] = array_get($all['register'],'attachment');
//        $data['job'] = array_get($all['register'],'job');

        $member = $activitySignup->where('user_id',$user->UserId)->where('activity_id',$id)->findAll();
        if(count($member) > 0) {
            return response()->json(['code' => -1, 'message' => '已经提交']);
        }
        if($detail->signup_limit != 0 && $detail->signup_limit <= $detail->signup_count) {
            return response()->json(['code' => -1, 'message' => '报名已经达到上限']);
        }

        $res = $activitySignup->create($data);
        if($res[0]){
            $detail->increment('signup_count');
            return response()->json(['code' => 0, 'message' => '成功']);
        }
        return response()->json(['code' => -1, 'message' => '提交出错']);
    }

    public function getApply(Request $request, ActivityRepository $activityRes, ActivitySignupRepository $activitySignupRepository, $id = 0)
    {
        $register = $activitySignupRepository->where('user_id', Auth::user()->UserId)
            ->where('activity_id', $id)->findAll();
        $register = count($register) > 0 ? $register[0] : null;
        if (!($detail = $activityRes->find($id))) {
            return abort(404);
        }

        if ($request->wantsJson()) {
            return response()->json(['signup' => $register,'code'=>0]);
        }
        return view('activity.center.apply', [
            'register' => $register, 'detail' => $detail
        ]);
    }

    public function postRegister(Request $request, ServiceMemberRepository $serviceMember)
    {
        $user = Auth::user();
        $member_type = intval($request->input('member_type'));
        if (!$user || !$user->UserId) {
            return response()->json([
                'code' => -1,
                'msg' => '未登录'
            ]);
        }
        $fields = [
            ['key' => 'register.name', 'name' => '团队名称', 'rule' => 'required'],
            ['key' => 'register.logo', 'name' => '团队logo', 'rule' => 'required'],
            ['key' => 'register.province', 'name' => '所在城市', 'rule' => 'required'],
            ['key' => 'register.city', 'name' => '所在城市', 'rule' => 'required'],
            ['key' => 'register.intro', 'name' => '团结简介', 'rule' => 'required|max:500'],
            ['key' => 'register.contacts', 'name' => '接口人', 'rule' => 'required'],
            ['key' => 'register.phone', 'name' => '手机', 'rule' => 'required|digits:11'],
            ['key' => 'SMSCode', 'name' => '验证码', 'rule' => 'required|digits:6'],
        ];
        if ($member_type == 0) {
            $fields[] = ['key' => 'register.team_num', 'name' => '团队人数', 'rule' => 'required'];
            $fields[] = ['key' => 'register.id_card', 'name' => '身份证号', 'rule' => 'required'];
        } else if ($member_type == 1) {
            $fields[] = ['key' => 'register.address', 'name' => '通讯地址', 'rule' => 'required|max:140'];
            $fields[] = ['key' => 'register.type', 'name' => '个人企业', 'rule' => 'required'];
            $fields[] = ['key' => 'register.business_license', 'name' => '公司营业执照', 'rule' => 'required'];
        } else if ($member_type == 2) {
            return abort(404);
        } else if ($member_type == 3) {
            $fields[] = ['key' => 'register.address', 'name' => '通讯地址', 'rule' => 'required|max:140'];
            $fields[] = ['key' => 'register.type', 'name' => '个人企业', 'rule' => 'required'];
            $fields[] = ['key' => 'register.business_license', 'name' => '公司营业执照', 'rule' => 'required'];
        } else if ($member_type == 4) {
            $fields[] = ['key' => 'register.address', 'name' => '通讯地址', 'rule' => 'required|max:140'];
            $fields[] = ['key' => 'register.type', 'name' => '个人企业', 'rule' => 'required'];
            $fields[] = ['key' => 'register.business_license', 'name' => '公司营业执照', 'rule' => 'required'];
            $fields[] = ['key' => 'register.institutional_type', 'name' => '个人/企业', 'rule' => 'required'];
            $fields[] = ['key' => 'register.invest_stage', 'name' => '投资阶段', 'rule' => 'required'];
        } else if ($member_type == 5) {
            $fields[] = ['key' => 'register.address', 'name' => '通讯地址', 'rule' => 'required|max:140'];
            $fields[] = ['key' => 'register.type', 'name' => '个人企业', 'rule' => 'required'];
            $fields[] = ['key' => 'register.business_license', 'name' => '公司营业执照', 'rule' => 'required'];
            $fields[] = ['key' => 'register.business_type', 'name' => '发行类型', 'rule' => 'required|array'];
            $fields[] = ['key' => 'register.business_style', 'name' => '发行方法', 'rule' => 'required|array'];
            $fields[] = ['key' => 'register.business_platform', 'name' => '发行平台', 'rule' => 'required'];
        } else {
            return abort(501);
        }

        $validator = [
            'messages' => [
                'required' => ':attribute不能为空',
                'register.email' => ':attribute 地址不正确',
                'register.smsCode.digits' => ':attribute错误',
                'register.phone.digits' => '请填写有效:attribute',
                'register.intro.max' => '简介不能超过140个字'
            ]
        ];
        foreach ($fields as $field) {
            $validator['rule'][$field['key']] = $field['rule'];
            $validator['attr'][$field['key']] = $field['name'];
        }

        $this->validate($request, $validator['rule'], $validator['messages'], $validator['attr']);
        $all = array_map('xssFilter', $request->all());
        $all = $all['register'];

        $data['service_member_type'] = $member_type > 5 ? 1 : $member_type;
        $data['name'] = $all['name'];
        $data['logo'] = $all['logo'];
        $data['province'] = $all['province'];
        $data['city'] = $all['city'];
        $data['intro'] = $all['intro'];
        $data['contacts'] = $all['contacts'];
        $data['id_card'] = array_get($all, 'id_card');
        $data['phone'] = $all['phone'];
        $data['team_num'] = array_get($all, 'team_num');
        $data['email'] = $all['email'];
        $data['address'] = array_get($all, 'address');
        $data['type'] = $all['type'] ? $all['type'] : 1;
        $data['business_license'] = array_get($all, 'business_license');
        $data['institutional_type'] = array_get($all, 'institutional_type');
        $data['invest_stage'] = array_get($all, 'invest_stage');
        $data['business_type'] = array_get($all, 'business_type');
        $data['business_style'] = array_get($all, 'business_style');
        $data['business_platform'] = array_get($all, 'business_platform');
        $data['user_id'] = Auth::user()->UserId;

        //校验验证码是否正确
        if ($this->validUserSmsCode($request->input('SMSCode'), $all['phone'])) {
            return response()->json(
                [
                    'code' => -1,
                    'message' => '验证码不正确'
                ]
            );
        }

        $member = $serviceMember->where('service_member_type', $member_type)->findWhere(['user_id', Auth::user()->UserId]);
        if (count($member) && $member[0]->status != 0) {
            return response()->json(['code' => -1, 'message' => '你已经提交申请，请等待']);
        }

        $res = [];
        if(count($member)) {
            $res = $serviceMember->update($member[0]->id, $data);
        } else {
            $res = $serviceMember->create($data);
        }

        $code = $res[0] ? 0 : -1;
        return response()->json(['code' => $code, 'message' => $res[0] ? '提交成功' : '系统错误']);
    }

    public function showList(Request $request,$os=0,$type=0,$stage=3)
    {
        //$params = $request->all();
        $data['classes'] = array();
        //12是项目扶持，这里取游戏平台和游戏类型两个二级分类的所有子类
        $pclasses = Classify::where('parent',12)->where('class_name','like','游戏%')->get();
        foreach($pclasses as $class){
            $data['classes'][$class->class_id] = Classify::where('parent',$class->class_id)->get();
            $data['classes'][$class->class_id]['name'] = $class->class_name;
        }
        $projectlist = Game::query()->where('status',0);

        if(!empty($os) && is_numeric($os)){
            $projectlist->where('os',$os);
        }
        if(!empty($type) && is_numeric($type)){
            $projectlist->where('game_type',$type);
        }
        if(is_numeric($stage) && $stage != 3){
            $projectlist->where('flow',$stage);
        }
        $projectlist->orderBy('created_at', 'desc');
        $data['projectlist'] = $projectlist->paginate(20);
        return view('hatch.list',$data);
    }

}
