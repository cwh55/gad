<?php

namespace App\Http\Controllers\Activity;
use App\Gad\Lib_Func;
use App\Gad\MessageType;
use App\Gad\TofService;
use App\Models\Article;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Register;
use App\Models\Classify;
use App\Models\Game;
use App\Models\Summercourse;
use App\Models\KeyValue;
use App\Repositories\TutorRepository;
use Illuminate\Http\Request;
use App\Gad\Upload;
use App\Gad\Func;
use Auth;
use Gate;
use Mockery\CountValidator\Exception;
use Redis;
use View;
use Illuminate\Routing\Route;

class FoolController extends Controller
{
    public function __construct(Request $request){
    }

    //sdfs
    public function getIndex() {
        return view('activity.foolindex', []);//
    }

    public function getDetail(Request $request) {
		$this->validate($request,['name'=>'required|max:16']);
		$name = strip_tags($request->input('name',''));
		$num = $request->input('num') > 0 ? intval($request->input('num')) : rand(1,20);
		$date = date('Y年m月d日 H:i');
		$from = $request->input('fr','');
        return view('activity.fooldetail', compact('name','num','date','from'));
    }

    public function getVipmonth(TutorRepository $tutor, Request $request,$month)
    {
        $month = intval($month);
        if (View::exists('activity.vip.month' . $month)) {
            return view('activity.vip.month' . $month, []);
        }
        $tutors = $tutor->where('year_month', '=', intval($month))->orderBy('rank')->findAll();
        $m = intval($month % 100);
        $year = intval($month / 100);
        if ($year < 2017) {
            abort(404);
        }
        return view('activity.vip.month', ['tutors' => $tutors, 'month' => $m, 'year' => $year]);
    }

    public function getMatch(){
        return view('activity.match');
    }
  }
