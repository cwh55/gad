<?php

namespace App\Http\Controllers\Activity;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\CityStationRepositoryEloquent;
use App\Repositories\LiveRepositoryEloquent;
use App\Repositories\UserRepositoryEloquent;
use Auth;
use Illuminate\Http\Request;

class ExpertController extends Controller
{
    const EXPERT_ID = 11111;
    const EXPERT_TYPE = 11;
    const EXPERT_MOBILE_TYPE = 12;

    public function __construct(CityStationRepositoryEloquent $cityStation, UserRepositoryEloquent $user)
    {
        $this->cityStation = $cityStation;
        $this->user = $user;
        $this->middleware('auth', ['only'=>['postSignup']]);
    }

    public function getIndex(LiveRepositoryEloquent $live)
    {
        $signinfo = null;
        if (Auth::user()) {
            $signinfo = $this->cityStation->findWhere(['user_id'=>Auth::user()->UserId, 'city_id'=>self::EXPERT_ID],['name','qq','position','corp','mobile'])->first();
        }
        //获取特定live的开始结束状态
        $liveinfo = $live->findWhereIn('id',[10014,10015,10016,10017,10018],['id','state']);
        $livestate = array(10014=>0, 10015=>0, 10016=>0, 10017=>0, 10018=>0);//10014=>0, 10015=>0, 10016=>0, 10017=>0, 10018=>0
        foreach ($liveinfo as $live) {
            $livestate[$live['id']] = $live['state'];
        }
        $signstep = count($signinfo) + 1;
        $stage = time() < strtotime('2017-06-22 00:00:00') ? '22' : (time() < strtotime('2017-06-24 9:00:00') ? '22~24' : (time() < strtotime('2017-06-24 14:00:00') ? '24:09' : (time() < strtotime('2017-06-24 19:00:00') ? '24:14' : '24:19')));
        return view('activity.expert', compact('signstep', 'signinfo', 'livestate', 'stage'));
    }

    //
    public function postSignup(Request $request)
    {
        $this->validate($request,[
            'position' => 'required',
            'corp' => 'required',
            'name' => 'required',
            'qq' => 'required|min:6|max:12',
            'mobile' => 'required|min:11|max:11',
        ]);
        $user = Auth::user();
        $data = $request->all();
        $data['city_id'] = self::EXPERT_ID;
        if (!isset($data['type']) || $data['type'] != self::EXPERT_MOBILE_TYPE) {
            $data['type'] = self::EXPERT_TYPE;
        }
        $data['user_id'] = $user->UserId;
        $data['status'] = 1;    //待审核
        $signinfo = $this->cityStation->findWhere(['user_id'=>$user->UserId, 'city_id'=>$data['city_id']])->first();
        if ($signinfo) {
            $result = $this->cityStation->update($data, $signinfo->id);
        }else{
            $result = $this->cityStation->create($data);
        }
        if($result){
            return response()->json(['code'=>0, 'msg'=>'提交成功！']);
        } else {
            return response()->json(['code'=>1, 'msg'=>'提交失败。']);
        }

    }
}
