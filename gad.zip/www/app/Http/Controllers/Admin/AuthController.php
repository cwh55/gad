<?php

namespace App\Http\Controllers\Admin;

use Auth;
use App\Http\Controllers\Controller;
use App\Models\User;
use Cookie;
use Illuminate\Http\Request;
use Tof;

class AuthController extends Controller
{
    public function getLogin(Request $request)
    {
        if (Auth::check()) {
            return redirect('/');
        }

        if ($backUrl = $request->input('url')) {
            $request->session()->put('backUrl', $backUrl);
        }

        return Tof::service('passport')->login(url('admin/auth/callback'));
    }
    
    public function getForbidden()
    {
        return view('admin.forbidden');
    }

    public function getCallback(Request $request)
    {
        $ticket = $request->input('ticket');
        if (!$ticket) {
            abort(500, 'ticket不能为空');
        }

        $userInfo = Tof::service('passport')->checkTicket($ticket);
        $user = User::where('RTXName', $userInfo->LoginName)->first();
        if ($user AND $user->roles->contains(2)) {
            Auth::login($user);
            $authUser = json_encode([
                'id' => $user->UserId,
                'name' => $user->RTXName,
                'avatar' => $user->full_avatar
            ]);
            $cookie = Cookie::make('authUser', $authUser, 720, null, null, false, false);

            return redirect('/manager')->cookie($cookie);
        }

        return redirect('/admin/auth/forbidden');
    }

    public function getLogout(Request $request)
    {
        Auth::logout();

        return Tof::service('passport')
            ->logout(url('admin/auth/callback'))
            ->cookie(Cookie::forget('authUser'));
    }
}
