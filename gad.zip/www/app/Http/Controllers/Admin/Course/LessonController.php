<?php

namespace App\Http\Controllers\Admin\Course;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Lesson;
use App\Models\LessonVod;
use Illuminate\Http\Request;
use Log;
use App\Qcloud\Qcloud;

class LessonController extends Controller
{
    public function index(Request $request, $courseId)
    {
        $result = ['total' => 0, 'lessons' => []];
        $page = $request->get('page', 1);
        $skip = ($page - 1) * 10;
        $lesson = Lesson::query();
        $lesson->where('course_id', $courseId);

        $result['total'] = $lesson->count();
        $result['lessons'] = $lesson->skip($skip)->take(10)->get();

        return response()->json($result);
    }

    public function show($id)
    {
        $lesson = Lesson::findOrFail($id);

        return response()->json($lesson);
    }

    public function store(Request $request)
    {
        $fields = [
            ['key' => 'course_id', 'name' => '分享ID', 'rule' => 'required'],
            ['key' => 'title', 'name' => '分享名称', 'rule' => 'required'],
            ['key' => 'summary', 'name' => '分享简介', 'rule' => 'required'],
            ['key' => 'begin_date', 'name' => '直播开始日期', 'rule' => 'required'],
            ['key' => 'begin_time', 'name' => '直播开始时间', 'rule' => 'required'],
            ['key' => 'end_time', 'name' => '直播结束时间', 'rule' => 'required']
        ];
        $validator  = [
            'rule' => [],
            'messages' => [
                'required' => ':attribute不能为空'
            ],
            'attr' => []
        ];
        foreach ($fields as $field) {
            $validator['rule'][$field['key']] = $field['rule'];
            $validator['attr'][$field['key']] = $field['name'];
        }
        $this->validate($request, $validator['rule'], $validator['messages'], $validator['attr']);

        $course = Course::findOrFail($request->input('course_id'));
        $this->authorize('edit', $course);

        $lessonData = $request->all();
        $lessonData['user_id'] = $request->user()->UserId;
        $lessonData['total_time'] = ceil((strtotime($lessonData['end_time']) - strtotime($lessonData['begin_time'])) / 60);
        $lessonData['vod'] = $course->record ? 1 : 0;
        $lesson = Lesson::create($lessonData);

        return response()->json(Lesson::find($lesson->id));
    }

    public function update(Request $request, $courseId, $id)
    {
        $fields = [
            ['key' => 'course_id', 'name' => '分享ID', 'rule' => 'required'],
            ['key' => 'title', 'name' => '分享名称', 'rule' => 'required'],
            ['key' => 'summary', 'name' => '分享简介', 'rule' => 'required'],
            ['key' => 'begin_date', 'name' => '直播开始日期', 'rule' => 'required'],
            ['key' => 'begin_time', 'name' => '直播开始时间', 'rule' => 'required'],
            ['key' => 'end_time', 'name' => '直播结束时间', 'rule' => 'required']
        ];
        $validator  = [
            'rule' => [],
            'messages' => [
                'required' => ':attribute不能为空'
            ],
            'attr' => []
        ];
        foreach ($fields as $field) {
            $validator['rule'][$field['key']] = $field['rule'];
            $validator['attr'][$field['key']] = $field['name'];
        }
        $this->validate($request, $validator['rule'], $validator['messages'], $validator['attr']);

        $lesson = Lesson::findOrFail($id);
        $this->authorize('update', $lesson);

        $lessonData = $request->all();
        $lessonData['total_time'] = ceil((strtotime($lessonData['end_time']) - strtotime($lessonData['begin_time'])) / 60);
        $lessonData['attachment'] = array_map(function ($item) {
            return array_only($item, ['name', 'url']);
        }, $lessonData['attachment']);
        $lesson->fill($lessonData);
        $lesson->save();

        return response()->json($lesson);
    }

    public function destroy(Request $request, $courseId, $id)
    {
        $lesson = Lesson::findOrFail($id);
        $this->authorize('update', $lesson);
        if ($lesson->state == 'living') {
            return abort(403, '直播中的分享不能删除');
        }

        if ($lesson->delete()) {
            return response()->json(['code' => 0, 'message' => 'ok']);
        } else {
            return abort(500, '未知原因，删除失败！');
        }
    }

    public function postStart(Request $request, $courseId, $id)
    {
        $course = Course::findOrFail($courseId);
        $lesson = Lesson::findOrFail($id);
        $this->authorize('update', $lesson);

        if ($lesson->state !== 'new') {
            return response()->json(['code' => 1, 'message' => '状态异常，直播无法开始']);
        }

        // 从分享老师中选择第一个老师作为直播老师(何为第一个?)
        foreach ($course->teachers as $teacher) {
            if ($teacher->lvb_channel_id) {
                break;
            }
        }

        //$startTime = date('Y-m-d H:i:s', strtotime('2 minutes ago', strtotime($lesson->begin_date.' '.$lesson->begin_time)));
        $result = Qcloud::live('CreateRecord', ['channelId' => $teacher->lvb_channel_id]);
        if ($result['code']) {
            return response()->json(['code' => $result['code'], 'message' => '直播API：'.$result['message']]);
        }
        $lesson->task_id = $result['data']['task_id'];
        $lesson->lvb_channel_id = $teacher->lvb_channel_id;
        $lesson->lvb_source_id = $teacher->lvb_source_id;
        $lesson->state = 'living';
        if ($lesson->save()) {
            $course->state = 'living';
            if ($course->next_lesson != $id) {
                $course->next_lesson = $id; // 把当前直播的分享改为分享的当前分享
            }

            $course->save();
        }

        return response()->json(['code' => 0, 'message' => 'ok', 'data' => $lesson->task_id]);
    }

    public function postStop(Request $request, $courseId, $id)
    {
        $course = Course::findOrFail($courseId);
        $lesson = Lesson::findOrFail($id);
        $this->authorize('update', $lesson);

        if ($lesson->state !== 'living') {
            return response()->json(['code' => 1, 'message' => '直播未开始，无法停止']);
        }

        $result = Qcloud::live('StopRecord', ['channelId' => $lesson->lvb_channel_id, 'taskId' => $lesson->task_id]);
        if ($result['code']) {
            return response()->json(['code' => $result['code'], 'message' => '直播API：'.$result['message']]);
        }

        $lesson->state = 'over';
        if ($course->record) {
            $lesson->type = 'playback';
        }
        $lesson->save();

        $nextLesson = null;
        foreach ($course->lessons as $lesson) {
            if ($lesson->id > $id) {
                $nextLesson = $lesson->id; // 结束直播时指向下一堂课
                break;
            }
        }

        if ($nextLesson) {
            $course->next_lesson = $nextLesson;
        } else {
            $course->state = 'over'; // 没有下一节时分享结束
        }
        $course->save();

        return response()->json(['code' => 0, 'message' => '已成功结束直播！']);
    }

    public function postReset(Request $request, $courseId, $id)
    {
        $lesson = Lesson::findOrFail($id);
        $this->authorize('update', $lesson);
        if ($lesson->state !== 'over' OR $lesson->vod == '3') {
            return response()->json(['code' => 1, 'message' => '直播未结束或已有录播，无法重置']);
        }

        $lesson->lvb_channel_id = '';
        $lesson->lvb_source_id = '';
        $lesson->task_id = '';
        $lesson->state = 'new';
        $lesson->save();

        $course = Course::findOrFail($courseId);
        if ($course->status == 'over') {
            $course->state = 'new'; // 当分享状态为结束时重置为未开始
            $course->save();
        }

        return response()->json(['code' => 0, 'message' => '分享直播状态重置成功！']);
    }

    public function postConvert(Request $request, $courseId, $id)
    {
        $lesson = Lesson::findOrFail($id);
        $this->authorize('update', $lesson);
        if ($lesson->vod === '1') {
            return response()->json(['code' => 1, 'message' => '正在转码中...']);
        }

        if ($lesson->vod === '2') {
            return response()->json(['code' => 1, 'message' => '转码已完成，无须转码！']);
        }

        $ret = Qcloud::live('GetVodRecordFiles', [
            'channelId' => $lesson->lvb_channel_id,
            'startTime' => sprintf('%s %s:00', $lesson->begin_date, $lesson->begin_time)
        ]);

        if ($ret['code']) {
            return response()->json(['code' => 1, 'message' => $ret['message']]);
        }

        $filesInfo = array_get($ret, 'data.filesInfo', []);
        foreach ($filesInfo as $file) {
            LessonVod::create([
                'course_id' => $courseId,
                'lesson_id' => $lesson->id,
                'file_id' => $file['fileId'],
                'sort' => $file['startTime']
            ]);

            Qcloud::vod('ConvertVodFile', ['fileId' => $file['fileId'], 'isScreenshot' => 1]);
            break;
        }

        $lesson->vod = 1;
        $lesson->save();

        return response()->json(['code' => 0, 'message' => '课时转码任务启动成功！']);
    }
}
