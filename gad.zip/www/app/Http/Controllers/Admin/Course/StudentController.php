<?php

namespace App\Http\Controllers\Admin\Course;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Course;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    public function index(Request $request, $courseId)
    {
        $course = Course::findOrFail($courseId);
        $result = [];

        $page = $request->get('page', 1);
        $skip = ($page - 1) * 10;

        $result['total'] = $course->students->count();
        $result['students'] = $course->students()->skip($skip)->take(10)->get();

        return response()->json($result);
    }

    public function destroy(Request $request, $courseId, $id)
    {
        $course = Course::findOrFail($courseId);
        $result = $course->students()->detach($id);

        return response()->json($result);
    }
}
