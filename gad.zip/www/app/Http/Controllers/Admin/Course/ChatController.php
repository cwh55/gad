<?php

namespace App\Http\Controllers\Admin\Course;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Repositories\CourseChatRepositoryEloquent;
use App\Repositories\CourseRepositoryEloquent;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    protected $course;
    protected $chat;

    public function __construct(CourseRepositoryEloquent $course, CourseChatRepositoryEloquent $chat)
    {
        $this->course = $course;
        $this->chat = $chat;
    }

    public function getLoad(Request $request)
    {
        $course = $this->course->find($request->get('course_id'));
        $chats = $this->chat->where(['course_id' => $course->id])->paginate(10);

        return response()->json($chats);
    }

    public function postAddShow(Request $request)
    {
        $ids = $request->get('id');
        $this->chat->addShow($ids);

        return response()->json(['code' => 0, 'message' => 'ok']);
    }

    public function postCancelShow(Request $request)
    {
        $ids = $request->get('id');
        $this->chat->cancelShow($ids);

        return response()->json(['code' => 0, 'message' => 'ok']);
    }

    public function postDelete(Request $request)
    {
        $ids = $request->get('id');
        foreach ($ids as $id) {
            $this->chat->delete($id);
        }

        return response()->json(['code' => 0, 'message' => 'ok']);
    }
}
