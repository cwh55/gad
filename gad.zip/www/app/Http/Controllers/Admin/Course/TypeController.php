<?php

namespace App\Http\Controllers\Admin\Course;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Course;
use Illuminate\Http\Request;

class TypeController extends Controller
{
    public function index(Request $request)
    {
        $course = new Course;
        $types = $course->getTypes();

        return response()->json($types);
    }
}
