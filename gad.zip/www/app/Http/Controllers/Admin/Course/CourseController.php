<?php

namespace App\Http\Controllers\Admin\Course;

use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Course;
use DB;
use Illuminate\Http\Request;
use Log;

class CourseController extends Controller
{
    public function index(Request $request)
    {
        $course = Course::query();
        $result = $course->orderBy('id', 'desc')->paginate($request->get('pageSize',10));
        return response()->json($result);
    }

    public function show($id)
    {
        $course = Course::findOrFail($id);
        $course->append(['type', 'first_type', 'teacher', 'assistant']);

        return response()->json($course);
    }

    public function store(Request $request)
    {
        $course = new Course;
        $fields = [
            ['key' => 'title', 'name' => '分享名称', 'rule' => 'required'],
            ['key' => 'target', 'name' => '适用人群', 'rule' => 'required'],
            ['key' => 'thumbnail', 'name' => '缩略图', 'rule' => 'required'],
            ['key' => 'cost', 'name' => '费用', 'rule' => 'required'],
            ['key' => 'summary', 'name' => '分享简介', 'rule' => 'required'],
            ['key' => 'desc', 'name' => '分享预览', 'rule' => 'required'],
            ['key' => 'teachers.*.id', 'name' => '老师信息', 'rule' => 'required'],
            ['key' => 'assistants.*.id', 'name' => '助教信息', 'rule' => 'required'],
            ['key' => 'cs_uin', 'name' => '客服QQ号', 'rule' => 'required'],
            ['key' => 'cs_name', 'name' => '客服昵称', 'rule' => 'required'],
            ['key' => 'qq_qun', 'name' => 'QQ群号码', 'rule' => 'required'],
            ['key' => 'qq_qun_name', 'name' => 'QQ群名称', 'rule' => 'required'],
            ['key' => 'qq_qun_key', 'name' => 'QQ群KEY', 'rule' => 'required'],
        ];
        $validator  = [
            'rule' => [],
            'messages' => [
                'required' => ':attribute 不能为空',
                'title.max' => '分享名称不能超过20个字'
            ],
            'attr' => []
        ];
        foreach ($fields as $field) {
            $validator['rule'][$field['key']] = $field['rule'];
            $validator['attr'][$field['key']] = $field['name'];
        }
        $this->validate($request, $validator['rule'], $validator['messages'], $validator['attr']);

        $courseData = $request->all();
        $courseData['user_id'] = Auth::user()->UserId;
        $course->fill($courseData);
        $course->save();

        $teacherId = array_unique(array_column($request->teachers, 'id'));
        $assistantId = array_unique(array_column($request->assistants, 'id'));
        $course->teachers()->attach($teacherId);
        $course->assistants()->attach($assistantId);

        return response()->json($course);
    }

    public function update(Request $request, $id)
    {
        $course = Course::findOrFail($id);
        $course->fill($request->all());
        $course->save();

        $teacherId = array_column($request->teachers, 'id');
        $assistantId = array_column($request->assistants, 'id');
        $course->teachers()->sync($teacherId);
        $course->assistants()->sync($assistantId);

        return response()->json($course);
    }

    public function destroy()
    {

    }

    public function postRelease(Request $request, $id)
    {
        $course = Course::findOrFail($id);
        if ($course->release_id) {
            return response()->json(['release_id' => $course->release_id]);
        }

        $teacher = $course->teachers->first();
        $userId = Auth::user()->UserId;
        $desc = sprintf('<p>适用人群：%s %s分享/%s分钟</p><br>', $course->target, $course->total_count, $course->total_time);
        $desc .= $course->desc;
        $contentId = DB::table('Content')->insertGetId([
            'IsTransfer' => 0, 'Title' => $request->get('Title'), 'Author' => $teacher->user_id, 'Summary' => $request->get('Summary'),
            'HtmlDetail' => $desc, 'ShowType' => 3, 'Tag' => '', 'CoverImage' => $course->thumbnail,
            'IsTop' => $request->get('IsTop'), 'IsExcellent' => $request->get('IsExcellent'), 'RowStatus' => 0,
            'Created' => date('Y-m-d H:i:s'), 'Creator' => $userId, 'Modified' => date('Y-m-d H:i:s'),
            'Modifier' => $userId
        ]);

        $index = 0;
        foreach ($course->lessons as $lesson) {
            $vid = $lesson->videos->pluck('file_id');
            if (!$vid->isEmpty()) {
                $moduleId = DB::table('ContentModule')->insertGetId([
                    'ContentId' => $contentId, 'ModuleType' => 'video', 'Title' => $lesson->title, 'Index' => $index,
                    'Attachment' => 'QCloudVod:'.implode('|', $vid->all()), 'Created' => date('Y-m-d H:i:s'),
                    'Creator' => $userId, 'Modified' => date('Y-m-d H:i:s'), 'Modifier' => $userId
                ]);

                $index++;
            }
        }

        $classId = DB::table('ContentClass')->insertGetId([
            'ContentId' => $contentId, 'ClassLV1' => $course->first_type_id, 'ClassLV2' => $course->type_id,
            'RowStatus' => 0, 'Created' => date('Y-m-d H:i:s'), 'Creator' => $userId,
             'Modified' => date('Y-m-d H:i:s'), 'Modifier' => $userId
            ]
        );

        $course->release_id = $classId;
        $course->save();

        return response()->json(['release_id' => $course->release_id]);
    }

    private function createLVBChannel($teacher)
    {
        $result = Qcloud::live('CreateLVBChannel', [
            'channelName' => 'P'.$teacher->uin,
            'outputSourceType' => 3,
            'sourceList.1.name' => $teacher->uin.'直播源',
            'sourceList.1.type' => 1,
            'outputRate.1' => 0,
            'outputRate.2' => 10,
            'outputRate.3' => 20
        ]);

        $channelId = $result['data']['channel_id'];
        if ($result['code']) {
            Log::error('创建老师直播频道失败', ['id' => $teacher->id, 'uin' => $teacher->uin, 'code' => $result['code'], 'message' => $result['message']]);
        } else {
            $result = Qcloud::live('DescribeLVBChannel', ['channelId' => $channelId]);
            if ($result['code']) {
                Log::error('查询老师直播频道信息失败', ['channelId' => $channelId, 'code' => $result['code'], 'message' => $result['message']]);
            } else {
                $channelInfo = $result['data']['channelInfo'][0];
                $source = $channelInfo['upstream_list'][0];
                $teacher->lvb_channel_id = $channelInfo['channel_id'];
                $teacher->lvb_source = $source['sourceAddress'];
                $teacher->save();
            }
        }
    }
}
