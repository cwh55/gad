<?php

namespace App\Http\Controllers\Admin\Course;

use App\Http\Controllers\Controller;
use App\Models\Teacher;
use App\Qcloud\Qcloud;
use Illuminate\Http\Request;
use Log;

class TeacherController extends Controller
{
    public function index(Request $request)
    {
       /* $result = ['total' => 0, 'teachers' => []];
        $page = $request->get('page', 1);
        $skip = ($page - 1) * 10;*/
        $teacher = Teacher::query();
        if ($request->has('type')) {
            $teacher->where('type', $request->input('type'));
        }
        if ($request->has('qq')) {
            $teacher->qq($request->input('qq'));
        }
        if ($request->has('status')) {
            $teacher->where('status', $request->input('status'));
        }

        /*$result['total'] = $teacher->count();
        $result['teachers'] = $teacher->skip($skip)->take(10)->orderBy('id', 'desc')->get(['id', 'uin', 'name',
            'type', 'status', 'created_user', 'created_at']);*/

        $result = $teacher->orderBy('id', 'desc')->paginate($request->get('pageSize',10));
        return response()->json($result);
    }

    public function show($id)
    {
        $teacher = Teacher::findOrFail($id);

        return response()->json($teacher);
    }

    public function store(Request $request)
    {
        $teacher = Teacher::where('uin', $request->input('uin'))->first();
        if ($teacher) {
            throw new \Exception('老师已存在，一个QQ只能注册一个老师或助教');
        }

        $input = $request->all();
        $input['created_user'] = $request->user()->RTXName;
        $teacher = Teacher::create($input);
        if ($teacher->type == Teacher::TYPE_TEACHER OR $teacher->type == Teacher::TYPE_ASSISTANT) {
            if (!$teacher->user->roles->contains(10)) {
                $teacher->user->roles()->attach(10); // 注册老师同时添加白名单
            }
            
            // 创建老师时创建其专属直播频道(测试环境不可用)
            if (config('app.env') == 'production') {
                $this->createLVBChannel($teacher);
            }
        }

        return response()->json($teacher);
    }

    public function update(Request $request, $id)
    {
        $teacher = Teacher::findOrFail($id);
        $teacher->fill($request->all());
        $teacher->save();

        // 正式环境当老师频道为空时自动创建
        if (config('app.env') == 'production' AND $teacher->lvb_channel_id == '') {
            $this->createLVBChannel($teacher);
        }

        return response()->json($teacher);
    }

    public function destroy()
    {

    }

    private function createLVBChannel($teacher)
    {
        $result = Qcloud::live('CreateLVBChannel', [
            'channelName' => 'P'.$teacher->uin,
            'outputSourceType' => 3,
            'sourceList.1.name' => $teacher->uin.'直播源',
            'sourceList.1.type' => 1,
            'outputRate.1' => 0,
            'outputRate.2' => 10,
            'outputRate.3' => 20
        ]);

        $channelId = $result['data']['channel_id'];
        if ($result['code']) {
            Log::error('创建老师直播频道失败', ['id' => $teacher->id, 'uin' => $teacher->uin, 'code' => $result['code'], 'message' => $result['message']]);
        } else {
            $result = Qcloud::live('DescribeLVBChannel', ['channelId' => $channelId]);
            if ($result['code']) {
                Log::error('查询老师直播频道信息失败', ['channelId' => $channelId, 'code' => $result['code'], 'message' => $result['message']]);
            } else {
                $channelInfo = $result['data']['channelInfo'][0];
                $source = $channelInfo['upstream_list'][0];
                $teacher->lvb_channel_id = $channelInfo['channel_id'];
                $teacher->lvb_source = $source['sourceAddress'];
                $teacher->save();
            }
        }
    }
}
