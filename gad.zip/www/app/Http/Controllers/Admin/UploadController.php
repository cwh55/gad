<?php

namespace App\Http\Controllers\Admin;

use App\Gad\Upload;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UploadController extends Controller
{
    public function postImage(Request $request)
    {
        $file = $request->file('file');
        if (!$file OR !$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '上传失败：图片太大或格式不对']);
        }

        $result = Upload::uploadQcloudImage($file);

        return response()->json($result);
    }

    public function postEditorImage(Request $request)
    {
        $file = $request->file('Filedata');
        if (!$file OR !$file->isValid()) {
            return response('<script>alert("图片上传出错");</script>');
        }

        $result = Upload::uploadQcloudImage($file);
        if ($result['code'] == 0) {
            return response($result['data']['downloadUrl']);
        } else {
            return response('<script>alert("图片上传出错：'.$result['message'].'");</script>');
        }
    }

    public function postAttachment(Request $request)
    {
        
    }
}
