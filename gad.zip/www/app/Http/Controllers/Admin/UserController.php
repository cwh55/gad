<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Models\User;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $user = User::query();
        if ($qq = $request->get('qq')) {
            $user->where('QQNo', 'LIKE', $qq.'%');
        }

        $users = $user->take(10)->get(['UserId', 'QQNo', 'Avatar']);

        return response()->json($users);
    }
}
