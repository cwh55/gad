<?php

namespace App\Http\Controllers\SpecialTopic;

use App\Presenters\CommunityPresenter;
use App\Http\Controllers\Community\PictureController;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\SpecialTopicRepository;
use App\Repositories\ArchiveRepository;
use App\Repositories\LikeRepository;
use App\Repositories\FavoriteRepository;
use Auth;

class SpecialTopicController extends Controller
{
    protected $spt;
    protected $archive;
    protected $like;
    protected $fav;

    public function __construct(SpecialTopicRepository $spt, ArchiveRepository $archive, LikeRepository $like, FavoriteRepository $fav)
    {
        $this->spt = $spt;
        $this->archive = $archive;
        $this->like = $like;
        $this->fav = $fav;
    }

    public function getIndex(Request $request, $id)
    {

        $spt = $this->spt->find($id);
        if (!$spt) {
            return abort(404);
        }

        if ($request->has('preview') ){
            $like = $fav = ['id' => 0,'like_count' => $spt->like_count, 'fav_count' => $spt->favorite_count];
        }else{
            if ($spt->status != 0 && !(Auth::check() && Auth::user()->roles->contains(2))) {
                return abort(403);
            }
            $like = $fav = ['id' => 0, 'status' => 0, 'like_count' => $spt->like_count, 'fav_count' => $spt->favorite_count];
        }
        if (Auth::user()) {//点赞收藏
            $likeObj = $this->like->myLike('App\Entities\SpecialTopic', $id, Auth::user()->UserId);
            if ($likeObj) {
                $like['id'] = $likeObj->id;
                $like['status'] = $likeObj->status;
            }
            $favObj = $this->fav->myFavorite('App\Entities\SpecialTopic', $id, Auth::user()->UserId);
            if ($favObj) {
                $fav['id'] = $favObj->id;
            }
        }

        $spt->question = $this->spt->getQuestions($spt->question_topic);
        $spt->more_topic = $this->spt->getMoreTopic($spt->more_topics, $id);
        $spt->list = $this->getList($request, $id, 'first_page');
        return view('specialtopic.index', compact('spt', 'like', 'fav'));
    }

    public function getList(Request $request, $id = 0, $first = '')
    {
        $sp = $this->spt->find($id);
        if ($sp) {
            $page = intval($request->input('page', 1));
            $pageSize = intval($request->input('pageSize', 20));
            $list = collect($sp->content)->forPage($page, $pageSize);
            $title = [];
            $index = 0;
            $data = [];
            $presenter = new CommunityPresenter();
            foreach ($list as $val) {
                $key = $index;
                if (isset($title[$val['title']])) {
                    $key = $title[$val['title']];
                } else {
                    $title[$val['title']] = $index;
                    $index++;
                }
                if ($val['type'] == 'archive') {
                    $archive = $this->archive->find($val['archive_id']);
                    if($archive) {
                        $archive->user_name = $archive->user->NickName;
                        $archive->format_comment_count = $presenter->formatNumber($archive->comment_count);
                        $archive->format_like_count = $presenter->formatNumber($archive->like_count);
                        $archive->format_view_count = $presenter->formatNumber($archive->view_count);
                        $archive->format_favorite_count = $presenter->formatNumber($archive->favorite_count);
                        $archive->avatar = !$archive->user->Avatar ? 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg' : $archive->user->Avatar;
                        if ($archive) {
                            $data[$key]['title'] = $val['title'];
                            $data[$key]['data'][] = $archive;
                        }
                    }
                } else if ($val['type'] == 'ad') {
                    $data[$key]['title'] = $val['title'];
                    $data[$key]['data'][] = ['cover' => $val['imgurl'], 'url' => $val['href'], 'class_id' => -1];
                }
            }
            if($first == 'first_page') {
                return $data;
            }

else {
    return response()->json(['code' => 0, 'data' => $data]);
}
} else {
    return response()->json(['code' => -1, 'data' => [], 'message' => 'not found']);
}
}

}

