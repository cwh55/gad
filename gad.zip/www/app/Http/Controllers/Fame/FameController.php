<?php

namespace App\Http\Controllers\Fame;

use App\Gad\Lib_Func;
use App\Gad\TofService;
use App\Models\Article;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Register;
use App\Models\Classify;
use App\Models\Fame;
use App\Models\Summercourse;
use App\Models\KeyValue;
use Illuminate\Http\Request;
use App\Gad\Upload;
use App\Gad\Func;
use Auth;
use Gate;
use Mockery\CountValidator\Exception;
use Redis;
use Illuminate\Routing\Route;

class FameController extends Controller
{
    public function __construct(Request $request)
    {
        if ($request->is('fame/edit*')) {
            if (isset($request->id) && ($id = $request->id) >= 1) {
                $hatch = Fame::find($id);
                $user_id = $hatch->user_id;
                //$this->middleware("acl:hatch::edit,user_id=".$user_id, ['only' => ['getEdit','postEdit']]);
            }
        }
    }

    public function index(Request $request, $id)
    {
        $this->validator($request, [
            'phase' => 'required|min:1|max:255'
        ]);

        $fame = Fame::findOrFail($id);

        $user = Auth::user();

        $indexBanner = KeyValue::find('new_hatch_index');
        $data['bannerList'] = json_decode($indexBanner['Value'], true);
        $companylist = KeyValue::find('new_hatch_company_list');
        $data['companylist'] = json_decode($companylist['Value']);
        $data['hostNews'] = Article::where('class_id', 1201)->where('status', 0)->orderBy('id', 'desc')->take(3)->get();

        $data['invests'] = Register::where('type', 1)->where('status', 0)->orderBy('id', 'desc')->take(10)->get();

        $data['games'] = Game::where('obj_type', 1)->where('status', 0)->orderBy('id', 'desc')->take(6)->get();

        return view('hatch.index', $data);
    }

    public function getCreate()
    {
        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $user = Auth::user();

        return view('hatch.create', compact('hatch', 'types', 'oss'));
    }

    public function postCreate(Request $request)
    {
        $data = $request->all();
        $hatch = new Game;

        $resp = array(
            'code' => -1,
            'message' => ''
        );

        if (!Auth::check()) {
            $resp['message'] = '未登录';
            return response()->json($resp);
        }

        $user = Auth::user();
        $register = Register::where('user_id', $user->UserId)
            ->first();
        if ($register == null || $register->status == 2) {
            $resp['message'] = '未入驻或入驻被驳回';
            return response()->json($resp);
        }

        if (!$data['name'] OR
            !$data['logo'][0] OR
            !$data['content'] OR
            !$data['platform'] OR
            !$data['ppt']
        ) {
            $resp['code'] = -2;
            $resp['message'] = '数据不完整';
            return response()->json($resp);
        }

        $hatch->user_id = Auth::user()->UserId;
        $hatch->obj_type = 1;
        $hatch->register_id = Register::where('obj_type', 1)
            ->where('user_id', Auth::user()->UserId)->value('id');

        $hatch->name = $data['name'];
        $hatch->logo = json_encode($data['logo']);
        $hatch->game_type = $data['type'];
        $hatch->description = $data['content'];
        $hatch->os = $data['platform'];
        $hatch->videos = json_encode($data['video']);
        $hatch->pictures = json_encode($data['pic']);
        $hatch->ppt = json_encode($data['ppt']);
        $hatch->ppt_pub = intval($data['ppt_pub']);
        $hatch->demo = json_encode($data['demo']);
        $hatch->demo_pub = intval($data['demo_pub']);
        $hatch->cooperation = $data['cooperation'];
        $hatch->status = 1;
        $hatch->save();

        $resp['code'] = $hatch->id;
        return response()->json($resp);
    }

    public function edit(Request $request, $id)
    {
        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $hatch = Game::findOrFail($id);

        $oss = Classify::where('parent', 1202)->get();
        $types = Classify::where('parent', 1203)->get();

        return view('hatch.create', compact('hatch', 'oss', 'types'));
    }

    public function postEdit(Request $request, $id)
    {
        $hatch = Game::findOrFail($id);
        $data = $request->all();

        $resp = array(
            'code' => -1,
            'message' => ''
        );
        if (!Auth::check()) {
            $resp['message'] = '未登录';
            return response()->json($resp);
        }

        if (Auth::user()->UserId != $hatch->user_id and !Auth::user()->roles->contains(2)) {
            $resp['message'] = '无权限';
            return response()->json($resp);
        }

        if (!$data['name'] OR
            !$data['logo'][0] OR
            !$data['content'] OR
            !$data['platform'] OR
            !$data['ppt']
        ) {
            $resp['code'] = -2;
            $resp['message'] = '数据不完整';
            return response()->json($resp);
        }

        $hatch->name = $data['name'];
        $hatch->logo = json_encode($data['logo']);
        $hatch->game_type = $data['type'];
        $hatch->description = $data['content'];
        $hatch->os = $data['platform'];
        $hatch->videos = json_encode($data['video']);
        $hatch->pictures = json_encode($data['pic']);
        $hatch->ppt = json_encode($data['ppt']);
        $hatch->ppt_pub = intval($data['ppt_pub']);
        $hatch->demo = json_encode($data['demo']);
        $hatch->demo_pub = intval($data['demo_pub']);
        $hatch->cooperation = $data['cooperation'];
        $hatch->status = 1;
        $hatch->save();

        $resp['code'] = $hatch->id;
        return response()->json($resp);
    }

    public function detail($id)
    {
        $fame = Fame::findOrFail($id);

        if ($fame->status < 0) {
            return abort(404);
        }

        if ($fame->status == 1) {
            if (Auth::check()) {
                if (!Auth::user()->roles->contains(2)) {
                    return abort(403);
                }
            } else {
                return redirect()->guest('/login');
            }
        }

        $data = [];
        $data['banner'] = $fame->banner;
        $data['detail'] = json_decode($fame->detail, true);
        $data['phase'] = $fame->phase;
        $data['person_description'] = $fame->person_description;
        $data['person_picture'] = $fame->person_picture;
        $data['aye_cnt'] = $fame->aye_cnt;
        $data['fav_cnt'] = $fame->fav_cnt;
        $data['comment_cnt'] = $fame->comment_cnt;
        $data['login'] = Auth::user() ? 'true' : 'false';
        $data['user'] = Auth::user() ? Auth::user() : json_encode('');
        $data['description'] = $fame->desciption;
        $data['detail'] = $this->imgAlt($data['detail'], $fame->desciption, $fame->desciption);
        $data['liked'] = $fame->is_liked;
        $data['favor'] = $fame->is_favor;
        $data['is_comment'] = $fame->is_comment == 1;
        $data['is_read'] = $fame->is_read == 1;
        $data['attach'] = json_decode($fame->attachments, true);
        $data['m_display'] = false;//手机端不展示
        $data['id'] = $fame->id;
        $data['user_id'] = $fame->user_id;
        if (!$data['attach']) {
            $data['attach'] = [];
        }

        //$fame->view_cnt = $fame->view_cnt + 1;
        //$fame->save();

        return view('fame.detail', $data);
    }

    public function imgAlt($detail, $alt, $title)
    {
        if (!$detail) {
            return [];
        }
        foreach ($detail as &$val) {
            $preg = "/<img.*?src=[\"|\'](.*?)[\"|\'](.*?)>/";
            $img = '<img src="$1" alt="' . $alt . '"title="' . $title . '"$2>';
            $val = preg_replace($preg, $img, $val);
        }
        return $detail;
    }

    public function mdetail($id)
    {
        $fame = Fame::findOrFail($id);
        if ($fame->status < 0) {
            abort(404);
        }
        $fame->view_cnt = $fame->view_cnt + 1;
        $fame->save();
        $fame->detail = json_decode($fame->detail, true);
        return view('fame.mdetail', ['fame' => $fame]);
    }

    public function getShare(Request $request, $id)
    {
        $src = $request->input('src', 'm/fame/detail');
        return Func::getShare($src, [$id]);
    }

    public function getDownloadCnt($id)
    {
        if (!Auth::check()) {
            return response()->json(['code' => -2, 'message' => '请登录']);
        }
    }

    public function postUploadAttachment(Request $request)
    {
        $file = $request->file('file');

        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }
        $size = round($file->getSize() / 1024 / 1024, 2) . "M";
        $result = Upload::uploadQcloudCos('hatch', $file);
        if ($result['code'] == 0) {
            $fileExt = strtolower($file->getClientOriginalExtension());
            if (in_array($fileExt, ['ppt', 'pptx', 'pdf'])) {
                $previewUrl = Upload::getPreviewDoc($result);
                $header = get_headers(str_replace("#page#", "1", $previewUrl["url"]), 1);
                $page = intval($header["User-ReturnCode"]);
                if ($page <= 0) {
                    $page = 1;
                }
                $result['data']['access_url'] .= '?newd=' . urlencode($previewUrl["url"] . ";" . $page);
            }
            return response()->json(['code' => 0, 'url' => $result['data']['access_url'], 'size' => $size]);
        } else {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }
    }

    public function getList()
    {
        $famelist = Fame::where('status', 0)->orderBy('phase', 'desc')->paginate(12);
        return view('fame.newlist', compact('famelist'));
    }

    public function getListData(Request $request)
    {
        $params = $request->all();
        if (is_numeric($params['page']) && is_numeric($params['pasize'])) {
            $famelist = Fame::query()
                ->where('status', 0)
                ->skip($params['page'] * $params['pasize'])
                ->take($params['pasize'])
                ->orderBy('phase', 'desc')
                ->get(['id', 'phase', 'name', 'name_description', 'person_description', 'logo', 'desciption']);
            for ($i = 0; $i < count($famelist); $i++) {
                $famelist[$i]['desciption'] = strip_tags($famelist[$i]['desciption']);
            }
            return response()->json(['code' => 0, 'famelist' => $famelist]);
        } else {
            return response()->json(['code' => 1, 'message' => "参数错误！"]);
        }

    }
}
