<?php

namespace App\Http\Controllers\Wenda;

use App\Gad\Func;
use App\Gad\MessageType;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\ArchiveRepository;
use App\Models\Activity;
use App\Models\Answers;
use App\Models\Comment;
use App\Models\Content;
use App\Models\Question;
use App\Models\User;
use App\Repositories\QuestionRepository;
use App\Repositories\WendaActivityRepository;
use Auth;
use Endroid\QrCode\QrCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Response;

class Activity2Controller  extends Controller
{
    protected $activity;
    protected $question;

    public function __construct(WendaActivityRepository $activity, QuestionRepository $question)
    {
        $this->activity = $activity;
        $this->question = $question;
    }

	public function index(Request $request, $activityId= 0, $zero = 0)
    {
        $data = [];
        $activityId = intval($activityId);
		$activity = $this->activity->find($activityId);

		//封装Activity
		$now = time();
		$starttime = strtotime($activity->starttime);
		$endtime = strtotime($activity->endtime);
		$activity->starttime = date('Y-m-d',$starttime);
		$activity->endtime = date('Y-m-d',$endtime);
		$activity->status = true;
		$activity->timestatus = '正在答疑...';
		if($now > $endtime){
			$activity->status = false;
			$activity->timestatus = '答疑结束';
		} else if($now < $starttime){
			$activity->timestatus = '即将开始...';
		}
		$guest = json_decode($activity->info,true);
		$activity->guests = $guest;
		if($activity->guests == null){
			$activity->guests = [];
		}
		$activity->guestnum = count($guest) == 2 ? "lesstwo" : (count($guest) == 3 ? "three" : "");
		$partner = json_decode($activity->partner,true);
		$activity->partner = $partner ? $partner : [];
		$data['activity'] = $activity;$data['ques'] = [];
		$data['count'] = '';

		$data['questions'] = $this->getQuestion($request,$activity,$zero);

		return view('wenda.activity2Index', $data);
	}

	public function getQuestion(Request $request, $activity, $zero, $return = false)
    {
        $query = $this->question->where('obj_type', 'App\Entities\WendaActivity')->where('obj_id', $activity->id)
            ->where('activity_status', 0);
        if ($zero) {
            $query = $query->where('activity_is_answer', 0);
        }
        $questions = $query->orderBy('activity_rank', 'desc')->orderBy('created_at', 'desc')
            ->paginate(20);
        foreach ($questions as &$val) {
            $val->time = $this->getTime($val->created_at);
            $guest = json_decode($activity->info, true);
            $val->guest = [];
            $val->answer = [];
            $guest_id = array_pluck($guest, 'userid');
            foreach ($guest as $g) {
                if (in_array($g['userid'], $val->activity_to_user)) {
                    $val->guest[] = $g;
                }
            }
            if ($val->activity_is_answer) {
                $val->answer = Answer::where('archive_id', $val->archive_id)->whereIn('user_id', $guest_id)
                    ->orderBy('id')->first();
            }
        }
        if ($return == false) {
            return $questions;
        } else {
            return response()->json(['code' => 0, 'question' => $questions]);
        }
    }

	public function getFirstImg($detail)
    {
        $matches = array();
        preg_match("/<[i|I][m|M][g|G].*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>/", $detail, $matches);
		if(isset($matches[1])) {
			return $matches[1];
		}
		return '';
	}

	public function getTime($time)
	{
		$now = time();
		$t = strtotime($time);
		$delay = $now - $t;
		if($delay > 0){
			if($delay < 300){
				return "刚刚";
			} else if($delay < 3600){
				return intval($delay/60)."分钟前";
			} else if($delay < 3600*24){
				return intval($delay/3600)."小时前";
			} else if($delay < 3600*72){
				//return intval($delay/3600/24)."天前";
			}
		}
		return date("Y-m-d H:i:s",$t);
	}

    //问答详情页
    public function wenDetail(ArchiveRepository $archive, $questionId)
    {
        $question = Question::findOrFail($questionId);
        $curUser = Auth::user();
        //$subject = Content::getNewSubject();
        if ($question) {
            $activity = Activity::findOrFail($question->obj_id);
            $relatedContents = Content::getRelatedListByType($archive, $activity->module);
            $question ->userInfo = $question->user;
            $question ->tags = explode(',',$question->label);
            $question ->publishTips = Func::getPublishTimeTips($question->created_at);
            //$question->increment('views');
        }

        return view('wenda.wendetail',compact('activity','question','curUser','relatedContents'));
    }

    //获取回答列表
    public function getAnswerList(Request $request)
    {
        $questionId = (int) $request->input('questionId');
        $page = (int) $request->input('page');
        $pageSize = (int) $request ->input('pageSize');
        $source = (int) $request->input('source');

        $answers = Answers::where('question_id',$questionId)
            ->where('status',0)
            ->where('source',$source)
            ->orderBy('rank','DESC')
            ->orderBy('vip','DESC')
            ->orderBy('adopt','DESC')
            ->orderBy('created_at','DESC')
            ->skip($page*$pageSize)
            ->take($pageSize)
            ->get();

        if ($answers) {
            $question = Question::find($questionId);
            $curUser = Auth::user();
            //获取用户头像信息
            $userIds = array_unique(array_column($answers->toArray(),'user_id'));
            $users = Answers::getUsers($userIds)->keyBy('UserId');
            //获取当前用户和回答的赞关系
            if($curUser) {
                $answerIds = array_unique(array_column($answers->toArray(),'id'));
                $userLikeRelates = Answers::getUserLikeRelates($curUser->UserId,$answerIds)->keyBy('obj_id');
            }
            //格式化数据
            foreach($answers as $item) {
                $creator = array_get($users,$item->user_id,new User());
                $item->publishTips = Func::getPublishTimeTips($item->created_at);
                $item->avatar = $creator->getAvatar();
                $item->commentTips = $item->comment_cnt >0? $item->comment_cnt.'条评论':'添加评论';
                $item->isShowEditBtn = $this->allowUpdate($curUser,$item);
                $item->isUped = false;
                $item->isDowned = false;
                //控制前端是否显示采纳按钮
                if($curUser){
                    $item->isShowAdoptBtn = $item->adopt==1 || $curUser->UserId == $question->user_id;
                    $likeRelate = array_get($userLikeRelates,$item->id);
                    if ($likeRelate) {
                        switch($likeRelate->status) {
                            case 0 :
                                $item->isUped = true;
                                break;
                            case 2 :
                                $item->isDowned = true;
                                break;
                        }
                    }
                }else{
                    $item->isShowAdoptBtn = $item->adopt==1;

                }

            }
        }
        return response()->json([
           'code' => 0,
            'answers' => $answers
        ]);

    }

    //保存回答
    public function saveAnswer(Request $request)
    {
        $questionId = $request->input('questionId');
        $answerContent = $request->input('content');
        $answerId = $request->input('answerId');
				$answerContent = xssFilter($answerContent);
        $ret = [
            'code'=> 0,
            'msg'=> '成功'
        ];
        if (!$questionId || !$answerContent) {
            $ret['code'] = -1;
            $ret['msg'] = '参数错误';
            return response()->json($ret);
        }
        $user = Auth::user();
        if (!$user) {
            $ret['code'] = -1;
            $ret['msg'] = '未登录';
            return response()->json($ret);
        }
        $question = Question::find($questionId);

        if (!$question) {
            $ret['code'] = -1;
            $ret['msg'] = '提问不存在';
            return response()->json($ret);
        }

		if(Func::hasBadWord($questionId,$answerContent,"","")){
			return response()->json(['code'=>-1,'msg'=>'非法内容']);
		}

        $answer = Answers::find($answerId);
        $isNewAnswer = true;
        if ($answer) {
            if (!$this->allowUpdate($user,$answer)) {
                $ret['code'] = -1;
                $ret['msg'] = '无权限';
                return response()->json($ret);
            }
            $isNewAnswer = false;
            $answer->answer = $answerContent;
        }
        else {
            $answer = new Answers();
            $answer->question_id = $questionId;
            $answer->answer = $answerContent;
            $answer->user_id = $user->UserId;
            $answer->name = $user->NickName;
            $answer->update_user = $user->UserId;
            //如果为专家回答则置顶。
            $isExpertAnswer = Activity::isExpert($question->obj_id,$user->UserId);
            if ($isExpertAnswer) {
                $answer->rank = 2;
            }
            $activity = Activity::findOrFail($question->obj_id);
            if(!empty($activity)) {
                $vipUserid = array_column(\GuzzleHttp\json_decode($activity->info, true), 'userid');
                if(in_array($user->UserId, $vipUserid)) {
                    $answer->vip = 1;
                }
            }
        }

        if($answer->save()){
			if($answer->vip == 1){
				Func::msgApi(MessageType::DAKA_GUEST_REPLY,$question->user_id,$user->UserId,$answer->id,'http://gad.qq.com/wenda/detail/'.$question->id,$question->question,$answer->id,'http://gad.qq.com/wenda/detail/'.$question->id,$answer->answer);
			} else {
				Func::msgApi(MessageType::DAKA_QUESTION_REPLY,$question->user_id,$user->UserId,$answer->id,'http://gad.qq.com/wenda/detail/'.$question->id,$question->question,$answer->id,'http://gad.qq.com/wenda/detail/'.$question->id,$answer->answer);
			}
            //以下为前端显示用，不能写在save之前，否则否报错。
            $answer->avatar = $user->getAvatar();
            $answer->publishTips = Func::getPublishTimeTips($answer->created_at);
            $answer->commentTips = $answer->comment_cnt >0? $answer->comment_cnt.'条评论':'添加评论';
            $answer->isShowEditBtn = $this->allowUpdate($user,$answer);
            $ret['answer'] = $answer;
            //更新回答数,新建回答时才更新
            if ($isNewAnswer) {
                $question->increment('answers');
            }
        }
        else {
            $ret['code'] = -1;
            $ret['msg'] = '保存失败';
        }

        return response()->json($ret);
    }

    //删除回答
    public function delAnswer(Request $request)
    {
        if (!Auth::check()) {
             return response()->json([
                 'code' => -1,
                 'msg' => '未登录'
             ]);
         }
        $answerId = $request->input('answerId');
        $answer = Answers::find($answerId);
        if (!$answerId || !$answer) {
            return response()->json([
                'code' => -1,
                'msg' => '回答不存'
            ]);
        }

        if (!$this->allowUpdate(Auth::user(),$answer)){
            return response()->json([
                'code' => -1,
                'msg' => '无权限'
            ]);
        }
        $answer->status = -1;
        if ($answer->save()) {
            $question = Question::find($answer->question_id);
            if ($question) {
                $question ->decrement('answers');
            }
			Func::msgApi(MessageType::DAKA_ANSWER_DELETE,$answer->user_id,0,$question->id,'http://gad.qq.com/wenda/detail/'.$question->id,$question->question,$answerId,'http://gad.qq.com/wenda/detail/'.$question->id,$answer->answer);
            return response()->json([
                'code' => 0,
                'msg' => '删除成功'
            ]);
        }

    }

    //保存问题
    public function saveQuestion(Request $request)
    {
        $activityid = $request->input('activityid');
        $userid = $request->input('user_id');
        $questionId = $request->input('questionid');
        $ret = [
            'code'=> 0,
            'msg'=> '成功'
        ];
        if (!$userid || !$activityid) {
            $ret['code'] = -1;
            $ret['msg'] = '参数错误';
            return response()->json($ret);
        }
        if (strlen($request->input('title'))>90 || strlen($request->input('description'))>3000 ) {
            $ret['code'] = -1;
            $ret['msg'] = '内容超过长度限制';
            return response()->json($ret);
        }
        if (empty($request->input('title'))) {
            $ret['code'] = -1;
            $ret['msg'] = '信息不完整';
            return response()->json($ret);
        }
        $user = Auth::user();
        if (!$user) {
            $ret['code'] = -1;
            $ret['msg'] = '未登录';
            return response()->json($ret);
        }
        $activity = Activity::find($activityid);

        if (!$activity) {
            $ret['code'] = -1;
            $ret['msg'] = '活动不存在';
            return response()->json($ret);
        }
        $question = Question::find($questionId);
        //编辑
        if ($question) {
            if (!$this->allowUpdate($user,$question)) {
                $ret['code'] = -1;
                $ret['msg'] = '无权限';
                return response()->json($ret);
            }
            $question->question = $request->input('title');
            $question->description = xssFilter($request->input('description'));
            $question->label = $request->input('label');
        }
        else {
            $question = new Question();
            $question->question = $request->input('title');
            $question->description = xssFilter($request->input('description'));
            $question->to_user = $request->input('user_id');
            $question->obj_id = $request->input('activityid');
            $question->label = $request->input('label');
            $question->user_id = $user->UserId;
            $question->status = 1; //默认待审核状态
            $question->obj_type = 1;
        }

		if(Func::hasBadWord($question->obj_id,$question->question,$question->description,$question->label)){
			return response()->json(['code'=>-1,'msg'=>'非法内容']);
		}
        $question->save();
        $ret['id'] = $question->id;
		if($ret['id'] > 0){
			Func::msgApi(MessageType::DAKA_INVITE,$question->to_user,$user->UserId,$question->id,'http://gad.qq.com/wenda/detail/'.$question->id,$question->question,'','','');
		}
        return response()->json($ret);
    }

    //采纳答案
    public function  adoptAnswer(Request $request)
    {
       $id = $request->input('answerId');
       $ret = [
           'code'=> 0,
           'msg'=> '成功'
       ];
       $user = Auth::user();
       if (!$user) {
           $ret['code'] = -1;
           $ret['msg'] = '未登录';
           return response()->json($ret);
       }
       $answer = Answers::find($id);
       if (!$answer) {
           $ret['code'] = -1;
           $ret['msg'] = '回答不存在';
           return response()->json($ret);
       }
       $question = Question::find($answer->question_id);
       if (!$question) {
           $ret['code'] = -1;
           $ret['msg'] = '提问不存在';
           return response()->json($ret);
       }
       if ($question->user_id != $user->UserId) {
           $ret['code'] = -1;
           $ret['msg'] = '非提问人无权采纳';
           return response()->json($ret);
       }
       $answer->adopt = 1;
       if($answer->save()){
		   Func::msgApi(MessageType::DAKA_ANSWER_ADOPT,$answer->user_id,$user->UserId,$answer->id,'http://gad.qq.com/wenda/detail/'.$question->id,$answer->answer,'','','');
           return response()->json($ret);
       }
       else {
           return response()->json($ret);
       }
    }

    //获取分享二维码
    public function getShareQrCode($activityId,$questionId)
    {
        $qrCode = new QrCode();
        $response = Response::stream(function () use($qrCode, $activityId,$questionId) {
            $url = url('/wenda/detail',[$questionId]);
            $qrCode->setText($url)->setSize(125)->setPadding(10)->setErrorCorrection('high')->render();
        }, 200, ['Content-Type' => 'image/png']);

        return $response;
    }

    //获取评论
    public function getCommentList(Request $request)
    {
        $answerId = (int) $request->input('answerId');
        $page = (int) $request->input('page');
        $pageSize = (int) $request ->input('pageSize');

        $comments = Comment::where('obj_id',$answerId)
            ->where('obj_type',Comment::ANSWER_TYPE)
            ->where('status',0)
            ->orderBy('created_at','ASC')
            ->skip($page*$pageSize)
            ->take($pageSize)
            ->get();

        if ($comments) {

            $curUser = Auth::user();
            //获取用户头像信息
            $userIds = array_unique(array_column($comments->toArray(),'user_id'));
            $users = Answers::getUsers($userIds)->keyBy('UserId');;
            foreach($comments as $item) {
                $creator = array_get($users,$item->user_id,new User());
                $item->publishTips = Func::getPublishTimeTips($item->created_at);
                $item->avatar = $creator->getAvatar();
                $item->showDelBtn = $this->allowUpdate($curUser,$item);
            }
        }
        return response()->json([
            'code' => 0,
            'comments' => $comments
        ]);
    }

    //保存评论
    public function saveComment(Request $request)
    {
        $answerId= $request->input('answerId');
        $content = $request->input('content');
        $ret = [
            'code'=> 0,
            'msg'=> '成功'
        ];
        if (!Auth::check()) {
            $ret['code'] = -1;
            $ret['msg'] = '未登录';
            return response()->json($ret);
        }
        if (!$answerId || !$content) {
            $ret['code'] = -1;
            $ret['msg'] = '参数错误';
            return response()->json($ret);
        }
        $answer = Answers::find($answerId);

        if (!$answer) {
            $ret['code'] = -1;
            $ret['msg'] = '回答不存在';
            return response()->json($ret);
        }

		if(Func::hasBadWord($answerId,$content,"","")){
			return response()->json(['code'=>-1,'msg'=>'非法内容']);
		}

        $content = xssFilter($content);
        $comment = new Comment();
        $comment->obj_id = $answerId;
        $comment->obj_type = $comment::ANSWER_TYPE;
        $comment->comment = $content;
        $comment->name = Auth::user()->NickName;
        $comment->user_id = Auth::user()->UserId;
        $comment->update_user =  $comment->user_id;

        if($comment->save()){
			$question = Question::find($answer->question_id);
			$user = Auth::user();
			Func::msgApi(MessageType::DAKA_ANSWER_REPLY,$answer->user_id,$user->UserId,$answer->id,'http://gad.qq.com/wenda/detail/'.$question->id,$answer->answer,$comment->id,'',$comment->comment);
            //以下为前端显示用，不能写在save之前，否则否报错。
            $comment->avatar = Auth::user()->getAvatar();
            $comment->publishTips = Func::getPublishTimeTips($comment->created_at);
            $ret['comment'] = $comment;
            //更新回答评论数
            $answer->increment('comment_cnt');
        }
        else {
            $ret['code'] = -1;
            $ret['msg'] = '保存失败';
        }

        return response()->json($ret);

    }

    //删除评论
    public function delComment(Request $request)
    {
        if (!Auth::check()) {
            return response()->json([
                'code' => -1,
                'msg' => '未登录'
            ]);
        }
        $commentId = $request->input('commentId');
        $comment = Comment::find($commentId);
        if (!$commentId || !$comment) {
            return response()->json([
                'code' => -1,
                'msg' => '评论不存'
            ]);
        }

        if (!$this->allowUpdate(Auth::user(),$comment)){
            return response()->json([
                'code' => -1,
                'msg' => '无权限'
            ]);
        }
        $comment->status = -1;
        if ($comment->save()) {
            $answer = Answers::find($comment->obj_id);
            if($answer) {
                $answer->decrement('comment_cnt');
            }
            $question = Question::find($answer->question_id);
            Func::msgApi(MessageType::DAKA_ANSWER_DELETE,$comment->user_id,0,$question->id,'http://gad.qq.com/wenda/detail/'.$question->id,$question->question,$commentId,'http://gad.qq.com/wenda/detail/'.$question->id,$comment->comment);
            return response()->json([
                'code' => 0,
                'msg' => '删除成功'
            ]);
        }
    }

    private function allowUpdate($user,$obj)
    {
        if (!$user) {
            return false;
        }
        if ($user->roles->contains(2)) {
            return true;
        }
        return $user->UserId === $obj->user_id;
    }


}
