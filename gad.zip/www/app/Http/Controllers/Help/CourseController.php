<?php

namespace App\Http\Controllers\Help;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    public function getTeacher(Request $request)
    {
        return view('help.course.teacher');
    }

    public function getStudent(Request $request)
    {
        return view('help.course.student');
    }

    public function getProtocol(Request $request)
    {
        return view('help.course.protocol');
    }
}