<?php

namespace App\Http\Controllers\Live;

use App\Http\Controllers\Controller;
use App\Models\KeyValue;
use App\Repositories\LiveOrderRepositoryEloquent;
use App\Repositories\LiveRepositoryEloquent;
use App\Repositories\LiveSignRepositoryEloquent;
use App\Repositories\UserRepositoryEloquent;
use Auth;
use Endroid\QrCode\QrCode;
use Gate;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Mockery\CountValidator\Exception;
use Tencent\Ptlogin\Ptlogin;


class LiveController extends Controller {

    protected $live;
    protected $messageRepository;
    protected $sign;
    protected $user;
    protected $order;

    public function __construct(LiveRepositoryEloquent $live, LiveSignRepositoryEloquent $sign,
                                UserRepositoryEloquent $user, LiveOrderRepositoryEloquent $order) {
        $this->live = $live;
        $this->sign = $sign;
        $this->user = $user;
        $this->order = $order;

        $this->middleware('auth', ['only' => ['getMy', 'postBuy']]);
    }

    public function getList(Request $request)
    {
        $lives = $this->live->getAllList();
        if ($request->wantsJson()) {
            return response()->json(['code' => 0, 'lives' => $lives]);
        }

        $banners = json_decode(KeyValue::find('live_list_banner')['Value'], true);

        return view('live.list', compact('lives', 'banners'));
    }

    public function getMy(Request $request)
    {
        $lives = $this->live->getByUser($this->sign, $request->user());
        if ($request->wantsJson()) {
            return response()->json(['code' => 0, 'lives' => $lives]);
        }

        $banners = json_decode(KeyValue::find('live_list_banner')['Value'], true);

        return view('live.list', compact('lives', 'banners'));
    }

    public function getDetail(Request $request, $id)
    {
        $live = $this->live->getDetail($id, 8);
        $isLogin = Auth::check();
        $loginType = session('loginType');
        if (!$request->exists('stay') AND Gate::allows('access', $live)) {
            //return redirect('live/chatroom/'.$live->id);
        }

        return view('live.detail', compact('live', 'isLogin', 'loginType'));
    }


    public function postBuy(Request $request, $id)
    {
        $live = $this->live->find($id);
        if (is_null($live)) {
            return abort(404, 'Live不存在');
        }

        $user = $request->user();
        if (is_null($user)) {
            return abort(401, '您尚未登录');
        }

        $status = $this->checkAuthStatus($request);
        if ($status === false) {
            return abort(401, '登录状态已失效，请重新登录');
        }

        $result = $this->live->buy($live, $user, 'pc');
        if ($result['code'] == 1018) {
            return abort(401, '登录状态已失效，请重新登录');
        }

        return response()->json($result);
    }

    private function checkAuthStatus(Request $request)
    {
        $loginType = session('loginType');
        if ($loginType == 'qq') {
            // 判断QQ登录态是否有效
            $uin = intval(str_replace('o', '', $request->cookie('uin')));
            $sKey = $request->cookie('skey');

            return $uin AND $sKey AND Ptlogin::check($uin, $sKey);
        } elseif ($loginType == 'weixin') {
            // 判断微信登录态是否有效
            return session('openId') AND session('accessToken');
        } else {
            return false;
        }
    }

    public function getShip(Request $request)
    {
        $params = $request->all();
        if (!$this->live->checkMidasSig($params)) {
            return response()->json(['ret' => 1, 'msg' => '请求参数错误']);
        }

        $order = $this->order->findByField('token', $params['token'])->first();
        if (!$order) {
            return response()->json(['ret' => 2, 'msg' => 'Live订单不存在']);
        }

        if ($order->state) {
            return response()->json(['ret' => 0, 'msg' => 'OK']);
        }

        if ($order->amt != ($params['amt'] / 10)) {
            // return response()->json(['ret' => 3, 'msg' => '订单总价不一致']);
        }
        //兼容原live处理方式
        if (!$order->obj_type) {
            list($liveId, $_, $_) = explode('*', $params['payitem']);
            if ($order->live->id != $liveId) {
                return response()->json(['ret' => 4, 'msg' => 'Live ID不一致']);
            }
            $this->order->updateByShip($params, $order->id);
            if ($this->sign->contain($order->live, $order->user)->count()) {
                return response()->json(['ret' => 0, 'msg' => 'OK']);
            }

            $sign = $this->sign->addUser($this->live, $order->live, $order->user);
            if ($sign) {
                return response()->json(['ret' => 0, 'msg' => 'OK']);
            }

        } else {
            try {
                //多态关联,当obj_type 关联不到类时会报错
                $orderObj = $order->obj;
                list($objId, $_, $_) = explode('*', $params['payitem']);
                if ($order->obj_id != $objId) {
                    return response()->json(['ret' => 4, 'msg' => '购买货物id不一致']);
                }
                $this->order->updateByShip($params, $order->id);
                //更新购买数
                if(isset($orderObj->pay_cnt)) {
                    $orderObj->increment('pay_cnt');
                }
                return response()->json(['ret' => 0, 'msg' => 'OK']);
            } catch (Exception $e) {
                return response()->json(['ret' => 6, 'msg' => '获取购买货物失败']);
            }
        }

        return response()->json(['ret' => 5, 'msg' => '发货时出错']);
    }

    public function getRcode(Request $request){
        $host = app()->isLocal() ? 'dev.m.gad.qq.com' : 'm.gad.qq.com';
        $id = $request->input('id');
        $src = 'http://'.$host.'/m/live/chatroom/'.intval($id);
        $qrCode = new QrCode();
        $response = Response::stream(function () use($qrCode, $src) {
            $qrCode->setText($src)->setSize(125)->setPadding(0)->setErrorCorrection('high')->render();
        }, 200, ['Content-Type' => 'image/png']);

        return $response;
    }

    //新手引导
    public function getGuide()
    {
        return view("live.guide");
    }
}
