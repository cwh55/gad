<?php

namespace App\Http\Controllers\Mobile\Activity;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Models\Problem;
use App\Http\Controllers\Controller;
use Exception;
use App\Gad\Weixin;
use Auth;
use Cache;

class ProblemController extends Controller
{
	protected $Id = 1;

	protected $user = null;

	public function __construct(){
		  $this->middleware('auth');
			$this->user = Auth::user();
	}

	//是否关注
	public function getFriendship(Request $request, $openId = null)
	{
		$data = ['code' => 0, 'msg' => '', 'data' => []];
		$openId = $this->user['openid'];
		try{
			if($this->Id == null){
				return redirect(Weixin::redirect($request->url()));
			}
			$this->checkOpenId($openId);
		} catch(Exception $e){
			$data['code'] = $e->getCode();
			$data['msg'] = $e->getMessage();
			return response()->json($data);
		}

		$friendship = $this->checkFriendship($openId, true);
		$data['data'] = array('friendship' => $friendship);

		return response()->json($data);
	}

	//答题页
	public function postAnswer(Request $request)
	{
			$p = Problem::findOrFail($this->user['WeixinId']);

			$pp = count(explode(",", $p->problemIds));
			$aa = count(explode(",", trim($p->answers)));
			if($pp <= $aa){
				  $answer = $this->checkAnswer($p);
				  return response()->json(['code' => 1, 'message' => '您已经答完', 'data' => $answer]);
			}

			$pno = intval($request->input('pno'));
			if(!in_array($pno, explode(',', $p->problemIds))){
				  return response()->json(['code' => -1, 'message' => '题号不对']);
			}

			if($p->answers != ""){
					$answerArr = explode(",", $p->answers);
					if(count($answerArr) >= 0){
						  foreach($answerArr as $aval){
								  $avalArr = explode("|", $aval);
									if($avalArr[0] == $pno){
										  return response()->json(['code' => -1, 'message' => '已经回答']);
									}
							}
					}
			}
			$ano = intval($request->input('ano'));
			$p->answers = $p->answers ? $p->answers . ',' . $pno . '|' . $ano : $pno . '|' . $ano;
			$p->save();

			$pp = count(explode(",", $p->problemIds));
			$aa = count(explode(",", trim($p->answers)));
			if($pp <= $aa){
				  $answer = $this->checkAnswer($p);
				  return response()->json(['code' => 1, 'message' => '您已经答完', 'data' => $answer]);
			}

			$nextProblem = $this->problems($p);

			return response()->json(['code' => 0, 'data' => ['index' => count(explode(',',$p->answers)) + 1, 'problem' => $nextProblem['problem']]]);
	}

	//获取题目
	public function getIndex(Request $request)
	{
			$data = ['code' => 0, 'msg' => '', 'data' => []];
			$openId = $this->user['WeixinId'];
			$this->checkOpenId($openId);
			//roblem::checkDate();

			$p = Problem::find($openId);
			if(empty($p) || $p->problemIds == ''){
				  $data['problem'] = ['id' => 1];
					$data['tagName'] = '';
					$data['answers'] = [];
					$data['answerable'] = false;
					$data['answer'] = ['score' => 0, 'answer' => [], 'desc' => ''];
					$data['index'] = 1;
			} else {
				  $data['problem'] = $this->problems($p)['problem'];
					if($data['problem'] == null){
						  $data['problem'] = ['id' => 1];
					}
					$data['tagName'] = $p->num == 1 ? 'program' : ($p->num == 2 ? 'plan' : 'art');
					$data['index'] = $p->answers == '' ? 1 : count(explode(',',$p->answers)) + 1;
					$data['answers'] = explode(',',$p->answers);
					$data['answerable'] = count($data['answers']) >= count(explode(',',$p->problemIds));
					$data['answer'] = $this->checkAnswer($p);
			}

		  return view('mobile.activity.problem_index',$data);
	}

	//分数
	public function postRetest(Request $request, $openId = null)
	{
		$data = ['code' => 0, 'msg' => '', 'data' => []];
		$openId = $this->user['WeixinId'];
		$problem = Problem::findOrFail($openId);
		$problem->problemIds = '';
		$problem->answers = '';
		$problem->save();
		$data['data'] = [];//array('num' => $p->num, 'score' => $p->score, 'qq' => intval($p->qq));

		return response()->json($data);
	}

	//回答
	public function postProblem(Request $request)
	{
			$this->checkOpenId($this->user['WeixinId']);

			$problem = Problem::find($this->user['WeixinId']);//获得题目
			if($problem && $problem->problemIds != ''){
				  return response()->json(['code' => -1, 'message' => '已经答题']);
			}
			if(empty($problem)){
				  $problem = new Problem();
					$problem->openid = $this->user['WeixinId'];
			}
			$num = $request->input('num');
			$problem->num = $num == 'plan' ? 2 : ($num == 'program' ? 1 : 3);
			$problems = $this->problems($problem);
			$problem->problemIds = implode(',', $problems['id']);
			$problem->save();

			return response()->json(['code' => 0, 'data' => ['index' => 1, 'problem' => $problems['problem']]]);
	}

	protected function checkOpenId($openId){
		if(preg_match('/[a-zA-Z0-9_\-]+/', $openId)){
			return true;
		}
		throw new Exception("openId error", -1);
	}

	protected function checkFriendship($ex = true){
		if($this->user['subscribe'] == 1){
			return true;
		}
		if(!$ex){
			return false;
		}
		throw new Exception('not subscribe', -8);
	}

	protected function checkAnswer($p){
		$answers = explode(',', $p->answers);
		$problems = $this->getPConfig();
		$parr = [];
		foreach($problems as $pval){
			  $parr = array_merge($parr, $pval);
		}
		$score = 0;
		$answer = [];
		$index = 1;
		foreach($answers as $aval){
			  $avalArr = explode('|', $aval);
				if(count($avalArr) >= 2 && isset($parr[$avalArr[0]]) && $parr[$avalArr[0]]['answer'] == $avalArr[1]){
					  $answer[] = ['id' => $index, 'name' => $parr[$avalArr[0]]['problem'], 'right' => 1];
					  $score = $score + 10;
				} else {
					  $answer[] = ['id' => $index, 'name' => isset($parr[$avalArr[0]]) ? $parr[$avalArr[0]]['problem'] : '', 'right' => 0];
				}
				$index = $index + 1;
		}

		return ['score' => $score, 'answer' => $answer,'desc'=>$this->getDesc($score)];
	}

	protected function problems($p)
	{
		  if($p == null) {
				  return $this->getPConfig();
			}
			$pconf = $this->getPConfig();
			$acount = $p->answers == '' ? 0 : count(explode(",", $p->answers));
			$problem = array_slice($pconf[$p->num == 1 ? 'program' : ($p->num == 2 ? 'plan' : 'art')], $acount);
			return ['id' => array_pluck($problem, 'id'), 'problem' => array_shift($problem)];
	}

    protected function getPConfig()
    {
        return [
					  'test' => ['test'],
            //游戏美术
            'art' => [
                '1' => [
                    'id' => 1,
                    'no' => '',
                    'problem' => '《剑侠情缘3》的美术风格是哪种？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A.写实偏奇幻'
                        ],
                        ['no' => 2,
                            'value' => ' B.Q版 '
                        ],
                        ['no' => 3,
                            'value' => 'C.卡通'
                        ],
                        ['no' => 4,
                            'value' => 'D.欧美风'
                        ]
                    ],
                    'answer' => 1
                ],
                2 => [
                    'id' => 2,
                    'no' => '',
                    'problem' => '以下哪种不是中国画的表现内容？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A.花鸟画'
                        ],
                        ['no' => 2,
                            'value' => 'B.人物画'
                        ],
                        ['no' => 3,
                            'value' => 'C.山水画'
                        ],
                        ['no' => 4,
                            'value' => 'D.抽象画'
                        ]
                    ],
                    'answer' => 4
                ],
                3 => [
                    'id' => 3,
                    'no' => '',
                    'problem' => '以下哪个不是文艺复兴时期绘画三杰?',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A.达芬奇'
                        ],
                        ['no' => 2,
                            'value' => 'B.拉斐尔'
                        ],
                        ['no' => 3,
                            'value' => 'C.米开朗基罗'
                        ],
                        ['no' => 4,
                            'value' => 'D.梵高'
                        ]
                    ],
                    'answer' => 4
                ],
                4 => [
                    'id' => 4,
                    'no' => '',
                    'problem' => '《清明上河图》画于哪个朝代？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A.唐'
                        ],
                        ['no' => 2,
                            'value' => 'B.宋'
                        ],
                        ['no' => 3,
                            'value' => 'C.明'
                        ],
                        ['no' => 4,
                            'value' => 'D.隋'
                        ]
                    ],
                    'answer' => 2
                ],
                5 => [
                    'id' => 5,
                    'no' => '',
                    'problem' => '以下哪款游戏属于欧美风格？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A.魔兽世界'
                        ],
                        ['no' => 2,
                            'value' => 'B.洛奇英雄传'
                        ],
                        ['no' => 3,
                            'value' => 'C.王者荣耀'
                        ],
                        ['no' => 4,
                            'value' => 'D.龙之谷'
                        ]
                    ],
                    'answer' => 1
                ],
                6 => [
                    'id' => 6,
                    'no' => '',
                    'problem' => '游戏设计部门有哪些美术职业？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A.角色'
                        ],
                        ['no' => 2,
                            'value' => 'B.场景'
                        ],
                        ['no' => 3,
                            'value' => 'C.原画&动作'
                        ],
                        ['no' => 4,
                            'value' => 'D.以上全部'
                        ]
                    ],
                    'answer' => 4
                ],
                7 => [
                    'id' => 7,
                    'no' => '',
                    'problem' => '以下哪一个不是游戏动画制作的三维软件？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A.3ds MAx'
                        ],
                        ['no' => 2,
                            'value' => 'B.Sipne'
                        ],
                        ['no' => 3,
                            'value' => 'C.MAyA'
                        ],
                        ['no' => 4,
                            'value' => 'D.MotionBuilder'
                        ]
                    ],
                    'answer' => 2
                ],
                8 => [
                    'id' => 8,
                    'no' => '',
                    'problem' => '著名卡通形象米老鼠有几根手指？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A.3根'
                        ],
                        ['no' => 2,
                            'value' => 'B.4根'
                        ],
                        ['no' => 3,
                            'value' => 'C.5根'
                        ],
                        ['no' => 4,
                            'value' => 'D.2根'
                        ]
                    ],
                    'answer' => 2
                ],
                9 => [
                    'id' => 9,
                    'no' => '',
                    'problem' => '游戏制作时，以下关联错误的是？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A.策划——PowerPoint'
                        ],
                        ['no' => 2,
                            'value' => 'B.程序——Direct X'
                        ],
                        ['no' => 3,
                            'value' => 'C.图形——CAkewAlk'
                        ],
                        ['no' => 4,
                            'value' => 'D.声效——Sound Forge'
                        ]
                    ],
                    'answer' => 3
                ],
                10 => [
                    'id' => 10,
                    'no' => '',
                    'problem' => ' 以下四组作品与作者的匹配，哪一个是错误的？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A.火影忍者——岸本齐史'
                        ],
                        ['no' => 2,
                            'value' => 'B.小时代——郭敬明'
                        ],
                        ['no' => 3,
                            'value' => 'C.水浒传——吴承恩'
                        ],
                        ['no' => 4,
                            'value' => 'D.冰与火之歌——乔治.R.R.马丁'
                        ]
                    ],
                    'answer' => 3
                ],
            ],
            //游戏策划
            'plan' => [
                11 => [
                    'id' => 11,
                    'no' => '',
                    'problem' => '小b肝癌检测结果为阳性，已知省肝癌发病率4%。，确诊肝癌患者查出率99%，确诊非肝癌患者准确率99.9%，小b患肝癌的概率？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A、99%左右'
                        ],
                        ['no' => 2,
                            'value' => 'B、80%以上'
                        ],
                        ['no' => 3,
                            'value' => 'C、50%以上'
                        ],
                        ['no' => 4,
                            'value' => 'D、小于30%'
                        ]
                    ],
                    'answer' => 4
                ],
                12 => [
                    'id' => 12,
                    'no' => '',
                    'problem' => '小b设计抽奖橙卡概率10%，后新作了如果9次都未抽中橙卡则第10次必然抽中橙卡。问当前抽出橙卡的概率是？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A、10%左右'
                        ],
                        ['no' => 2,
                            'value' => 'B、12%左右'
                        ],
                        ['no' => 3,
                            'value' => 'C、15%左右'
                        ],
                        ['no' => 4,
                            'value' => 'D、20%左右'
                        ]
                    ],
                    'answer' => 3
                ],
                13 => [
                    'id' => 13,
                    'no' => '',
                    'problem' => '在一个战斗类游戏中，两件基础攻击力相同的武器，战锤20%概率触发150%暴击，弯刀拥有112%的攻击速度，哪一把武器的输出更高？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A：战锤'
                        ],
                        ['no' => 2,
                            'value' => 'B：弯刀'
                        ],

                    ],
                    'answer' => 2
                ],
                14 => [
                    'id' => 14,
                    'no' => '',
                    'problem' => '以下哪项不是VR游戏开发的注意事项?',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A：晕动症'
                        ],
                        ['no' => 2,
                            'value' => 'B：Oculus为开发者支付引擎授权金'
                        ],
                        ['no' => 3,
                            'value' => 'C：较少的用户量，较高的设备成本'
                        ],
                        ['no' => 4,
                            'value' => 'D：便携性与移动性'
                        ]
                    ],
                    'answer' => 4
                ],
                15 => [
                    'id' => 15,
                    'no' => '',
                    'problem' => '游戏开发中，以下哪一项是不受著作权保护的?',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A：游戏角色'
                        ],
                        ['no' => 2,
                            'value' => 'B：游戏玩法'
                        ],
                        ['no' => 3,
                            'value' => 'C：美术素材'
                        ],
                        ['no' => 4,
                            'value' => 'D：背景音乐'
                        ]
                    ],
                    'answer' => 2
                ],
                16 => [
                    'id' => 16,
                    'no' => '',
                    'problem' => '某游戏公布了卡牌升级1升2概率80%；2升3为50%；3升4为25%；4升5为10%；失败不掉级，每次消耗1张材料卡。一张卡从1升到5级平均需要多少材料卡？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A:7张左右'
                        ],
                        ['no' => 2,
                            'value' => 'B:12张左右'
                        ],
                        ['no' => 3,
                            'value' => 'C:17张左右'
                        ],
                        ['no' => 4,
                            'value' => 'D:22张左右'
                        ]
                    ],
                    'answer' => 3
                ],
                17 => [
                    'id' => 17,
                    'no' => '',
                    'problem' => '装备强化从1到2级需100金，从2到3级需150金，3到4级要200金；强化消耗的金币数平滑增长。请问装备从1强化到30级共需多少金？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A:24750'
                        ],
                        ['no' => 2,
                            'value' => 'B:23200'
                        ],
                        ['no' => 3,
                            'value' => 'C:24650'
                        ],
                        ['no' => 4,
                            'value' => 'D:26250'
                        ]
                    ],
                    'answer' => 2
                ],
                18 => [
                    'id' => 18,
                    'no' => '',
                    'problem' => '相比于客户端游戏，对手机游戏体验影响最大的是？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A:画面展现'
                        ],
                        ['no' => 2,
                            'value' => 'B:交互方式'
                        ],
                        ['no' => 3,
                            'value' => 'C:硬件性能'
                        ],
                        ['no' => 4,
                            'value' => 'D:收费方式'
                        ]
                    ],
                    'answer' => 2
                ],
                19 => [
                    'id' => 19,
                    'no' => '',
                    'problem' => '以下下4个选项中，哪种因素对于FTG类游戏中的角色打击感体验影响最弱？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A：受击音效'
                        ],
                        ['no' => 2,
                            'value' => 'B：受击动作'
                        ],
                        ['no' => 3,
                            'value' => 'C：攻击速度'
                        ],
                        ['no' => 4,
                            'value' => 'D：攻击特效'
                        ]
                    ],
                    'answer' => 3
                ],
                20 => [
                    'id' => 20,
                    'no' => '',
                    'problem' => '打败某个BOSS可以有5%的概率得到极品装备，打20次能够得到此装备的概率最接近多少？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A:50%'
                        ],
                        ['no' => 2,
                            'value' => 'B:64%'
                        ],
                        ['no' => 3,
                            'value' => 'C:76%'
                        ],
                        ['no' => 4,
                            'value' => 'D:100%'
                        ]
                    ],
                    'answer' => 2
                ],

            ],
            //游戏开发
            'program' => [
                21 => [
                    'id' => 21,
                    'no' => '',
                    'problem' => 'Unity 5.0 标配的GUI组件是？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A、NGUI'
                        ],
                        ['no' => 2,
                            'value' => 'B、UGUI'
                        ],
                        ['no' => 3,
                            'value' => 'C、EZGUI'
                        ],
                        ['no' => 4,
                            'value' => 'D、UniGUI'
                        ]
                    ],
                    'answer' => 2
                ],
                22 => [
                    'id' => 22,
                    'no' => '',
                    'problem' => 'Unity 引擎开发游戏主要使用什么语言？ ',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A、PlayScript'
                        ],
                        ['no' => 2,
                            'value' => 'B、JavaScript'
                        ],
                        ['no' => 3,
                            'value' => 'C、C#'
                        ],
                        ['no' => 4,
                            'value' => 'D、Boo'
                        ]
                    ],
                    'answer' => 3
                ],
                23 => [
                    'id' => 23,
                    'no' => '',
                    'problem' => 'Unity 5.0以上版本的网络组件名是？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A、UNET'
                        ],
                        ['no' => 2,
                            'value' => 'B、Photon'
                        ],
                        ['no' => 3,
                            'value' => 'C、TCPIP'
                        ],
                        ['no' => 4,
                            'value' => 'D、ProtolBuf'
                        ]
                    ],
                    'answer' => 1
                ],
                24 => [
                    'id' => 24,
                    'no' => '',
                    'problem' => 'Unity 实现跨平台主要基于？ ',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A、NET'
                        ],
                        ['no' => 2,
                            'value' => 'B、Mono'
                        ],
                        ['no' => 3,
                            'value' => 'C、IL2CPP'
                        ],
                        ['no' => 4,
                            'value' => 'D、C#'
                        ]
                    ],
                    'answer' => 2
                ],
                25 => [
                    'id' => 25,
                    'no' => '',
                    'problem' => 'Unity 制作游戏一定要掌握编程语言吗？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A、不需要'
                        ],
                        ['no' => 2,
                            'value' => 'B、需要掌握 C# '
                        ],
                        ['no' => 3,
                            'value' => 'C、需要掌握 JavaScript'
                        ],
                        ['no' => 4,
                            'value' => 'D、需要掌握 Boo'
                        ]
                    ],
                    'answer' => 1
                ],
                26 => [
                    'id' => 26,
                    'no' => '',
                    'problem' => '虚幻引擎制作游戏主要使用什么语言？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A、UnrealScript'
                        ],
                        ['no' => 2,
                            'value' => 'B、C++ '
                        ],
                        ['no' => 3,
                            'value' => 'C、C#'
                        ],
                        ['no' => 4,
                            'value' => 'D、C'
                        ]
                    ],
                    'answer' => 2
                ],
                27 => [
                    'id' => 27,
                    'no' => '',
                    'problem' => '虚幻引擎里可视化脚本组件是？',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A、Blueprint'
                        ],
                        ['no' => 2,
                            'value' => 'B、Actor'
                        ],
                        ['no' => 3,
                            'value' => 'C、PlayMaker'
                        ],
                        ['no' => 4,
                            'value' => 'D、UnrealScript'
                        ]
                    ],
                    'answer' => 1
                ],
                28 => [
                    'id' => 28,
                    'no' => '',
                    'problem' => '虚幻引擎使用的物理组件是？ ',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A、Havok'
                        ],
                        ['no' => 2,
                            'value' => 'B、PhysX'
                        ],
                        ['no' => 3,
                            'value' => 'C、Box2D'
                        ],
                        ['no' => 4,
                            'value' => 'D、ODE'
                        ]
                    ],
                    'answer' => 2
                ],
                29 => [
                    'id' => 29,
                    'no' => '',
                    'problem' => '虚幻引擎图形界面组件是？ ',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A、NGUI'
                        ],
                        ['no' => 2,
                            'value' => 'B、UGUI'
                        ],
                        ['no' => 3,
                            'value' => 'C、UMG'
                        ],
                        ['no' => 4,
                            'value' => 'D、Flash'
                        ]
                    ],
                    'answer' => 3
                ],
                30 => [
                    'id' => 30,
                    'no' => '',
                    'problem' => '页游（HTML5）技术主要使用哪种技术？ ',
                    'options' => [
                        ['no' => 1,
                            'value' => 'A、Flash'
                        ],
                        ['no' => 2,
                            'value' => 'B、JavaScript + CSS'
                        ],
                        ['no' => 3,
                            'value' => 'C、WebGL + WebAssembly'
                        ],
                        ['no' => 4,
                            'value' => 'D、JQuery'
                        ]
                    ],
                    'answer' => 3
                ],
            ],

        ];
    }
    //

    protected function getDesc($score){
	    if ($score <= 50){
	        return '如果你有志于从事这方面的工作，建议还要继续努力哦~没事看看GAD网站和微信可以学习很多干货哦！';
        }

        if ( 60<= $score && $score <= 70 ){
            return '可进步的区间还是很大，加油，相信成功入职成为一名游戏人已经不远了！';
        }
        if ( 80<= $score && $score <= 90 ){
            return '这么优秀的你想必是很多游戏公司争抢的人才吧！';
        }
        if ( $score == 100 ){
            return '你就是传说中那个绝无仅有的人才！';
        }
    }

}
