<?php

namespace App\Http\Controllers\Mobile\Activity;
use App\Gad\Lib_Func;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Gad\Func;
use Auth;
use Gate;
use Redis;
use App\Repositories\HatchProjectRepository;

class TeacherController extends Controller
{
    public function __construct(){
        //$this->middleware("auth");
    }

    //活动首页
    public function getIndex(Request $request) {
        echo '活动已经结束';
        return;
        $page = intval($request->input('page',1));
        $teacher = intval($request->input('teacher'));
        return view('mobile.activity.teacher', ['page' => $page, 'teacher' => $teacher]);
    }

    public function getCreate() {
        return view('hatch.create_new', compact('game'));
    }
    
    public function getCreateOld() {
        return view('hatch.create', compact('hatch', 'types', 'oss'));
    }
}
