<?php

namespace App\Http\Controllers\Mobile\Activity;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Cache;
use App\Models\User;
use App\Models\Actgain;
use Auth;
use App\Gad\Func;
use App\Gad\Weixin;
use Redis;

define('REDIS_NEW_YEAR_USER', 'gad:act:ny:hu:%d');
define('REDIS_NEW_YEAR_USER_CNT', 'gad:act:ny:user:cnt');
define('REDIS_NEW_YEAR_PRIZE_STAT', 'gad:act:ny:prize:hstat');
define('REDIS_NEW_YEAR_JOIN_STAT', 'gad:act:ny:join:hstat');
define('REDIS_NEW_YEAR_JOIN_USER', 'gad:act:ny:join:sstat:%d');
define('REDIS_NEW_YEAR_GAIN_PRIZE', 'gad:act:ny:gain:hprize:%d');
define('REDIS_NEW_YEAR_GAIN_USER', 'gad:act:ny:gain:user:s%d');

class NewyearController extends Controller {

    protected $user_info = null;
    private $should_register = false; //是否需要注册用户
    private $user_id = 0;

    private $startDate = '2017-01-19'; // 活动开始日期
    private $newPrizeArr = array(
        1 => array('p1' => 335, 'p2' => 1, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        2 => array('p1' => 235, 'p2' => 0, 'p3' => 0, 'p4' => 1, 'p5' => 0),
        3 => array('p1' => 35, 'p2' => 1, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        4 => array('p1' => 35, 'p2' => 0, 'p3' => 1, 'p4' => 0, 'p5' => 0),
        5 => array('p1' => 35, 'p2' => 1, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        6 => array('p1' => 35, 'p2' => 0, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        7 => array('p1' => 35, 'p2' => 1, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        8 => array('p1' => 35, 'p2' => 0, 'p3' => 1, 'p4' => 0, 'p5' => 0),
        9 => array('p1' => 35, 'p2' => 1, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        10 => array('p1' => 35, 'p2' => 0, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        11 => array('p1' => 35, 'p2' => 1, 'p3' => 1, 'p4' => 0, 'p5' => 0),
        12 => array('p1' => 35, 'p2' => 0, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        13 => array('p1' => 35, 'p2' => 1, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        14 => array('p1' => 35, 'p2' => 0, 'p3' => 0, 'p4' => 1, 'p5' => 0),
        15 => array('p1' => 35, 'p2' => 1, 'p3' => 1, 'p4' => 0, 'p5' => 0),
        16 => array('p1' => 35, 'p2' => 0, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        17 => array('p1' => 35, 'p2' => 1, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        18 => array('p1' => 35, 'p2' => 0, 'p3' => 1, 'p4' => 0, 'p5' => 0),
        19 => array('p1' => 35, 'p2' => 1, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        20 => array('p1' => 35, 'p2' => 0, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        21 => array('p1' => 35, 'p2' => 1, 'p3' => 0, 'p4' => 1, 'p5' => 0),
        22 => array('p1' => 35, 'p2' => 0, 'p3' => 1, 'p4' => 0, 'p5' => 0),
        23 => array('p1' => 35, 'p2' => 1, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        24 => array('p1' => 35, 'p2' => 0, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        25 => array('p1' => 35, 'p2' => 1, 'p3' => 1, 'p4' => 0, 'p5' => 0),
        26 => array('p1' => 35, 'p2' => 0, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        27 => array('p1' => 35, 'p2' => 1, 'p3' => 0, 'p4' => 0, 'p5' => 0),
        28 => array('p1' => 35, 'p2' => 1, 'p3' => 0, 'p4' => 1, 'p5' => 0),
        29 => array('p1' => 20, 'p2' => 1, 'p3' => 1, 'p4' => 0, 'p5' => 1),
    );

    public function __construct(Request $request) {
        $this->redis = Redis::connection('act');
        $this->user_id = session('n_weixin_user_id');
        if ($this->user_id) {
            $this->user_info = $this->_get_user_info($this->user_id);
        }
        if ($code = $request->input("code")) {
            try{
                $user_info = $request->input("state") == 'base' ? (array)Weixin::getUserInfoByCode($code, 'base', true) : (array)Weixin::getUserInfoByCode($code, 'user', true);
            } catch (\Exception $ex) {
                if($this->user_info){
                    return;
                }
            }
            if(empty($user_info)){
                throw new \Exception('登录异常，请联系客服');
            }
            $user = User::where('WeixinId', $user_info['unionid'])->first();
            if (empty($user) && $request->input("state") == 'base') {
                //未注册，且未获取到用户昵称等信息，则进行下一次跳转
                $this->should_register = true;
                return;
            }else{
                if (empty($user)) {
                    //未注册，已获取到用户昵称等信息
                    $user = new User();
                    $user->WeixinId = $user_info['unionid'];
                    $user->NickName = isset($user_info['nickname']) ? $user_info['nickname'] : '';
                    $user->Avatar = isset($user_info['headimgurl']) ? $user_info['headimgurl'] : '';
                    $user->Created = date("Y-m-d H:i:s");
                    $user->Creator = 1111;
                    $user->save();
                }
                Auth::loginUsingId($user->UserId);
                $this->user_id = $user->UserId;
                session(['n_weixin_user_id' => $this->user_id]);
                $this->user_info = $this->_get_user_info($this->user_id);
                if(!$this->user_info){
                    $this->user_info = array('subscribe'=>0, 'share'=>0, 'lottery_times'=>0, 'lottery_result'=>'', 'submit_qq'=>0);
                }
                $this->user_info['subscribe'] = $this->user_info['subscribe'] != 2 ? $user_info['subscribe'] : $this->user_info['subscribe'];
                $this->_ser_user_info($this->user_id, $this->user_info);
            }
        }
    }

    public function activity2017(Request $request) {
        header("Cache-control:no-cache,no-store,must-revalidate");
        header("Pragma:no-cache");
        header("Expires:0");
        if($this->should_register){
            return redirect(Weixin::redirect($request->url(), 'snsapi_userinfo', 'user', true));
        }
        if(empty($this->user_info)){
            return redirect(Weixin::redirect($request->url(), 'snsapi_base', 'base', true));
        }
        //如果用户已经进行第二次抽奖，需要对关注状态进行判定，则每次都去微信中读取最新的关注状态
        if($this->user_info['lottery_times'] == 2 && empty($this->user_info['lottery_result']) && !$request->input("code")){
            return redirect(Weixin::redirect($request->url(), 'snsapi_base', 'base', true));
        }
        $this->user_info['user_id'] = $this->user_id;
        return view('mobile.newyear.activity2017', array('user_info'=>$this->user_info, 'res_host'=>app()->isLocal() ? 'http://ui.gad.oa.com' : 'http://gad.qpic.cn'));
    }
    
    public function test(){
        if(app()->isLocal()){
            $user_id = empty($_GET['uid']) ? $this->user_id : $_GET['uid'];
            if(empty($_GET['get'])){
                $this->_ser_user_info($this->user_id, array('subscribe'=>0, 'share'=>0, 'lottery_times'=>0, 'lottery_result'=>'', 'submit_qq'=>0));
                session(['n_weixin_user_id' => null]);
                echo $this->user_id;
            }else{
                var_dump($this->_get_user_info($user_id));
            }
        }
    }
    
    //抽奖，返回奖品的index(0~5)
    public function do_lottery(){
        try{
            $ret = $this->lottery();
            //$res = array('success'=>true, 'data'=>rand(0, 5));
            $res = array('success'=>true, 'data'=>$ret);
            return response()->json($res);
        } catch (\Exception $ex) {
            return response()->json(array('detail'=>$ex->getMessage(), 'success'=>false));
        }
    }
    
    public function get_user_info(){
        return response()->json($this->user_info);
    }
    
    public function get_lottery_chance(){
        try{
            if($this->user_info['share'] != 0){
                throw new \Exception('你已经分享过，无法再次获得抽奖机会');
            }
            $this->user_info['share'] = 1;
            $user_info = array('share' => 1);
            $this->_ser_user_info($this->user_id, $user_info);
            return response()->json( array('success'=>true));
        } catch (\Exception $ex) {
            return response()->json(array('detail'=>$ex->getMessage(), 'success'=>false));
        }
    }
    
    public function submit_qq(Request $request){
        try{
            $qq = $request->input('qq');
            if(!preg_match("/^[1-9][0-9]{3,11}$/",$qq)) {
                throw new \Exception('QQ号码填写错误');
            }
            //TODO
            $user_info = array('submit_qq' => $qq);
            $this->user_info['submit_qq'] = $qq;
            $this->_ser_user_info($this->user_id, $user_info);
            $this->recordUin($this->user_id, $qq);

            return response()->json( array('success'=>true));
        } catch (\Exception $ex) {
            return response()->json(array('detail'=>$ex->getMessage(), 'success'=>false));
        }
    }

    private function _ser_user_info($user_id, $user_info){
        if(!$user_id || !is_array($user_info)) {
            return false;
        }
        $key = sprintf(REDIS_NEW_YEAR_USER, $user_id);
        return $this->redis->hMset($key, $user_info);
    }

    private function getPrizeDay() {
        $interval = date_diff(date_create($this->startDate), date_create(date('Y-m-d')));
        return $interval->format('%a') + 1;
    }

    private function getRestPrizeStat() {
        $days = $this->getPrizeDay();
        $total = array();

        // 奖品顺延
        /*
        foreach($this->newPrizeArr as $key => $val) {
            if($key <= $days) {
                $total['p1'] = $total['p2'] = $total['p3'] = $total['p4'] = $total['p5'] = 0;
                foreach($val as $k => $v) {
                    $total[$k] += $v;
                }
            } else {
                break;
            }
        }

        return $total;*/

        // 奖品不顺延
        if(isset($this->newPrizeArr[$days])) {
            $total = $this->newPrizeArr[$days];
        }

        // 已消耗的奖品
        $pkey = sprintf(REDIS_NEW_YEAR_GAIN_PRIZE, $days);
        $gainPrize = $this->redis->hGetall($pkey);

        if(!empty($total)) {
            foreach ($total as $k => $v) {
                if ($v > 0 && isset($gainPrize[$k]) && $gainPrize[$k] > 0 && $v - $gainPrize[$k] > 0) {
                    $total[$k] = $v - $gainPrize[$k];
                } else if($v == 0 || (isset($gainPrize[$k]) && $v - $gainPrize[$k] == 0)){
                    unset($total[$k]);
                }
            }
        }

        return $total;
    }

    private function _get_user_info($user_id) {
        if(!$user_id) {
            return false;
        }
        $key = sprintf(REDIS_NEW_YEAR_USER, $user_id);
        $res = $this->redis->hGetAll($key);
        $arr = array('subscribe'=>0, 'share'=>0, 'lottery_times'=>0, 'lottery_result'=>0, 'submit_qq'=>0);

        if(!empty($res)) {
            foreach($arr as $key => $val) {
                if(!isset($res[$key])) {
                    $res[$key] = 0;
                }
            }
        } else {
            $res = $arr;
        }
        return $res;

        /*
         * Weixin::getUserInfoByCode Returns:
        Array
        (
            [subscribe] => 1
            [openid] => oRJAJw8Xk4P-P1NwRnnDweujJiac
            [nickname] => 夏天
            [sex] => 1
            [language] => zh_CN
            [city] => 深圳
            [province] => 广东
            [country] => 中国
            [headimgurl] => http://wx.qlogo.cn/mmopen/lLib7UklNhwDgIw8NeHqhpmFyfia1B1TUyRva0348X4vdcibXqcZclznN2ciakyrA5w9LQovwZdBb3JCLRkWefekZXbFm1d6bfZ1/0
            [subscribe_time] => 1477376816
            [unionid] => oMi-gs7c3YaGy5fNb81PfJLmGRjI
            [remark] =>
            [groupid] => 0
            [tagid_list] => Array()
        )
         *
         */
    }

    public function lottery() {
        $user_id = $this->user_id;
        if(!$user_id) {
            return 0;
        }
        if(date('Y-m-d') < $this->startDate) {
            throw new \Exception('抽奖活动未开始');
        }
        if($this->getPrizeDay() > 29) {
            throw new \Exception('抽奖活动已结束');
        }

        $subscribe = $share = $lottery_times = $lottery_result = 0;
        $userInfo = $this->_get_user_info($user_id);
        if(!empty($userInfo)) {
            $subscribe = $userInfo['subscribe'];
            $share = $userInfo['share'];
            $lottery_times = $userInfo['lottery_times'];
            $lottery_result = $userInfo['lottery_result'];
        }

        // 抽奖逻辑
        // 判断用户是否已经中奖
        if(empty($lottery_result)) {

            if(empty($lottery_times)) {
                // 用户未抽过奖
                return $this->lotteryRules($user_id);
            } else{
                if($share == 1) {
                    $this->user_info['share'] = 2;
                    $this->_ser_user_info($user_id, array('share'=>2));
                    return $this->lotteryRules($user_id);
                }else if($subscribe == 1){
                    $this->user_info['subscribe'] = 2;
                    $this->_ser_user_info($user_id, array('subscribe'=>2));
                    return $this->lotteryRules($user_id);;
                }else{
                    throw new \Exception('你没有获得本次抽奖资格');
                }
            }

        }

        return 0;

    }

    // 抽奖逻辑
    private function lotteryRules($user_id) {

        $userCnt = $this->getUserCnt();
        if(app()->isLocal()){
            $userCnt = 1000;
        }

        $prizeStat = $this->getRestPrizeStat();

        $prizeCnt = array_sum($prizeStat);

        if($prizeCnt > 0) {
            $ukey = sprintf(REDIS_NEW_YEAR_USER, $user_id);
            $this->redis->hIncrby($ukey, 'lottery_times', 1);

            $days = $this->getPrizeDay();
            $prizes = isset($this->newPrizeArr[$days]) ? $this->newPrizeArr[$days] : array();
            $total = array_sum($prizes);

            if($total > 0) {
                $randMaxNum = intval($userCnt / $total);

                $rand = rand(1, $randMaxNum);

                if ($rand == $randMaxNum) {
                    // 中奖
                    $key = array_rand($prizeStat);

                    //记录中奖用户信息
                    if ($this->gainPrizeStat($key, $user_id) && $this->recordPrizeDB($key, $user_id)) {
                        return ltrim($key, 'p');
                    }
                } else {
                    // 记录未抽中的用户数
                    $date = date('Ymd');
                    $this->redis->hIncrby(REDIS_NEW_YEAR_JOIN_STAT, $date, 1);
                    $ukey = sprintf(REDIS_NEW_YEAR_JOIN_USER, $date);
                    $this->redis->sAdd($ukey, $user_id);
                }
            }
        }

        return 0;
    }

    /*
     * 获取用户量
     */
    protected function getUserCnt() {
        return $this->redis->get(REDIS_NEW_YEAR_USER_CNT);
    }

    /*
     * 抽奖统计记录
     */
    protected function gainPrizeStat($type, $user_id) {
        if ($type && $user_id) {
            $day = $this->getPrizeDay();
            $pkey = sprintf(REDIS_NEW_YEAR_GAIN_PRIZE, $day);
            $this->redis->hIncrby($pkey, $type, 1);

            $gkey = sprintf(REDIS_NEW_YEAR_GAIN_USER, $day);
            $this->redis->sAdd($gkey, $user_id);

            $ukey = sprintf(REDIS_NEW_YEAR_USER, $user_id);
            $this->redis->hSet($ukey, 'lottery_result', ltrim($type, 'p'));
            return $this->redis->hIncrby(REDIS_NEW_YEAR_PRIZE_STAT, $type, 1);
        }

        return 0;
    }

    /*
     * 抽奖统计记录
     */
    protected function recordPrizeDB($field, $user_id) {
        // 记录db
        if($field && $user_id) {
            $userInfo = $this->_get_user_info($user_id);

            $actgain = Actgain::query()->where('act_id', 2)->where('user_id', $user_id)->first();

            if (!empty($actgain) &&  $actgain->$field >= 0) {
                $actgain->$field = $actgain->$field + 1;
                $actgain->subscribe = isset($userInfo['subscribe']) ? $userInfo['subscribe'] : 0;
                $actgain->share = isset($userInfo['share']) ? $userInfo['share'] : 0;
                $actgain->times = isset($userInfo['lottery_times']) ? $userInfo['lottery_times'] : 0;
                $actgain->save();
            } else {
                $actgain = new Actgain;
                $data = array(
                    'act_id' => 2,
                    'user_id' => $user_id,
                    $field => 1,
                    'subscribe' => isset($userInfo['subscribe']) ? $userInfo['subscribe'] : 0,
                    'share' => isset($userInfo['share']) ? $userInfo['share'] : 0,
                    'times' => isset($userInfo['lottery_times']) ? $userInfo['lottery_times'] : 0,
                    'result' => ltrim($field, 'p'),
                );

                $actgain->fill($data);
                $actgain->save();
            }
            return true;
        }
    }

    /*
     * 用户提交qq
     */
    protected function recordUin($user_id, $uin) {
        // 记录db
        if($uin && $user_id) {
            $actgain = Actgain::query()->where('act_id', 2)->where('user_id', $user_id)->first();

            if (!empty($actgain) &&  !$actgain->uin) {
                $actgain->uin = $uin;
                $actgain->save();
            }
        }
        return true;
    }

}
