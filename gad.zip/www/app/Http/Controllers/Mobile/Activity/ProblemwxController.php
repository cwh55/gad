<?php

namespace App\Http\Controllers\Mobile\Activity;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Models\Problem;
use App\Http\Controllers\Controller;
use Exception;
use App\Gad\Weixin;
use Cache;

class ProblemwxController extends Controller
{
	protected $Id = 1;

	protected $user = null;

	public function __construct(Request $request){
		$user = session("weixin_user");
		if(!$user){
			if($code = $request->input("code")){
				$user = (array)Weixin::getUserInfo(Weixin::getUserOpenId($code));
				if(array_has($user,"openid")){
					session(['weixin_user' => $user]);
				} else {
					$this->Id = null;
				}
			} else {
				$this->Id = null;
			}
		}

		$this->user = $user;
	}

	public function getdata(Request $request){
		$p = Problem::where('score','>',0)->get();
		$k = 1;
		foreach($p as $v){
			echo $k." ";
			$k++;
			if($v->openId){
				$user = Weixin::getUserInfo($v->openid);
				if($user['subscribe'] == 1){
					$v->num = $v->num * 10;
					$v->save();
				}
			}
		}
	}

	//是否关注
	public function getFriendship(Request $request, $openId = null)
	{
		$data = ['code' => 0, 'msg' => '', 'data' => []];
		$openId = $this->user['openid'];
		try{
			if($this->Id == null){
				return redirect(Weixin::redirect($request->url()));
			}
			$this->checkOpenId($openId);
		} catch(Exception $e){
			$data['code'] = $e->getCode();
			$data['msg'] = $e->getMessage();
			return response()->json($data);
		}

		$friendship = $this->checkFriendship($openId, true);
		$data['data'] = array('friendship' => $friendship);

		return response()->json($data);
	}

	//答题页
	public function answerQuestion(Request $request)
	{
		if($this->Id == null){
			return redirect(Weixin::redirect($request->url()));
		}
		if(!$this->checkFriendship(false)){
			session(['weixin_user' => null]);
			return redirect("/answerwx/answer-wx.html");
		}
		$data = ['code' => 0, 'msg' => '', 'data' => []];
		$data['openid'] = $this->user['openid'];
		$p = Problem::find($this->user['openid']);
		if($p){
			$data['num'] = $p->num;
			$pp = count(explode(",", $p->problemIds));
			$aa = count(explode(",", trim($p->answers)));
			if($p->answers != ""){
				if(10 <= $pp && $p->num == 2){
					$a = explode("|", $p->answers);
					if(count($a) >= 2){
						if($a[1] != ""){
							return redirect('/answerwx/two-times.html');							
						}
					}
				}
				if(5 <= $pp && $p->num == 1){
					return redirect('/answerwx/answer-share.html');
				}
			}
		} else {
			$data['num'] = 1;
		}
		if(Problem::checkDate(true)){
			$data["desc"] = "本次GAD月考已结束<br>继续关注GAD微信公众号第一时间了解下次月考信息";
			return response()->view('activity.answerhint', $data);
		}
		if(!$this->checkNum()){
			$data['desc'] = '很抱歉今日答题名额已满<br>欢迎明日再战！';
			return response()->view('activity.answerhint', $data);
		}

		return response()->view('activity.answer', $data);
	}

	//获取题目
	public function getProblems(Request $request, $openId = null)
	{
		$data = ['code' => 0, 'msg' => '', 'data' => []];
		$openId = $this->user['openid'];
		try{
			if($this->Id == null){
				return redirect(Weixin::redirect($request->url()));
			}
			$this->checkOpenId($openId);
			$this->checkFriendship();
			if(!$this->checkNum()){
				throw new Exception('-9', 'not num');
			}
			Problem::checkDate();
		} catch(Exception $e){
			$data['code'] = $e->getCode();
			$data['msg'] = $e->getMessage();
			return response()->json($data);
		}

		$p = Problem::where("openid",$openId)->first();
		if(empty($p)){
			$p = new Problem();
			$p->openid = $openId;
		}

		$problem = $this->getProblem($openId);
		if(empty($p->problemIds)){
			$ps = [];
			foreach($problem as $vl){
				$ps[] = $vl['id'];
			}
			$p->problemIds = implode(",", $ps);
			$p->num = 1;
			$p->save();
		} else {
			$ps = explode(",", $p->problemIds);
			if(count($ps) < $p->num * 5){
				foreach($problem as $vl){
					$ps[] = $vl["id"];
				}
				$p->problemIds = implode(",", $ps);
				$p->save();
			} else {
				//$as = explode(":", $p->answers);
				//foreach($as as $vl){
				//	$re = explode(",", $vl);
				//	if(in_array($re[0], $ps)){
				//		unset($problem[$re[0]]);
				//	}
				//}
			}
		}
		$ka = [0=>"一",1=>"二",2=>"三",3=>"四",4=>"五",5=>"六",6=>"七"];
		$k=0;
		foreach($problem as &$vl){
			$vl['title'] = '题目'.$ka[$k];
		    $k++;
			if($k > 5){
				break;
			}
		}
		$data['data'] = $problem;
		$data['score'] = $p->score;
		return response()->json($data);
	}

	//分数
	public function getScore(Request $request, $openId = null)
	{
		$data = ['code' => 0, 'msg' => '', 'data' => []];
		$openId = $this->user['openid'];
		try{
			if($this->Id == null){
				return redirect(Weixin::redirect($request->url()));
			}
			$this->checkOpenId($openId);
		} catch(Exception $e){
			$data['code'] = $e->getCode();
			$data['msg'] = $e->getMessage();
			return response()->json($data);
		}

		$p = Problem::find($openId);
		if(empty($p)){
			return response()->json(['code' => -1, 'msg' => 'error', 'data' => []]);
		}
		$data['data'] = array('num' => $p->num, 'score' => $p->score, 'qq' => intval($p->qq));

		return response()->json($data);
	}

	//回答
	public function answerProblem(Request $request, $openId = null){
		$openId = $this->user['openid'];
		try{
			if($this->Id == null){
				return redirect(Weixin::redirect($request->url()));
			}
		    $this->checkOpenId($openId);
		    $this->checkFriendship();
			//$this->checkAnswer($openId);
			$this->checkAnswer($openId);
		} catch(Exception $e){
			$data['code'] = $e->getCode();
			$data['msg'] = $e->getMessage();
			return response()->json($data);
		}

		$problem = Problem::where('openid',$openId)->first();//获得题目

		$pno = intval($request->input("pno"));
		$ans = $request->input("answer");

		//check是否已经答过
		$ps = explode(",", $problem->problemIds);
		$as = explode(",", $problem->answers);
		foreach($as as $vl){
			$re = explode(":", $vl);
			if($re[0] == $pno){
				return response()->json(['code' => -6, 'msg' => 'answer', 'data' => []]);
			}
		}
		if(!in_array($pno, $ps)){
			return response()->json(['code' => -7, 'msg' => 'pno error', 'data' => []]);
		}
		$right = $this->checkRight($pno, $ans);
		Cache::decrement($this->checkNum(true), $right);
		$problem->score = $problem->score+$right;
		if($problem->score > 10){
			$problem->score = 10;
		}
		if($problem->answers){
			$problem->answers = $problem->answers.",".$pno.":".$ans;
		} else {
			$problem->answers = $pno.":".$ans;
		}
		$problem->save();
		return response()->json(['code' => 0, 'msg' => '', 'data' => ['right' => $right, 'score' => $problem->score]]);
	}

	public function summitQQ(Request $request, $openId = null){
		$openId = $this->user['openid'];
		try{
			if($this->Id == null){
				return redirect(Weixin::redirect($request->url()));
			}
			$this->checkOpenId($openId);
			$this->checkFriendship();
		} catch(Exception $e){
			$data['code'] = $e->getCode();
			$data['msg'] = $e->getMessage();
			return response()->json($data);
		}

		$qq = $request->input("qq");
		$problem = Problem::find($openId);
		if(empty($problem)){
			return response()->json(['code' => -1, 'msg' => 'not exists', 'data' => []]);
		}
		$qnum = Problem::where("qq", $qq)->count();
		if($problem->qq || $qnum >= 1){
			$code = -4;
			if($problem->qq){
				$code = -2;
			}
			return response()->json(['code' => $code, 'msg' => 'has qq', 'data' => []]);
		}

		$problem->qq = intval($qq);
		$problem->save();
		return response()->json(['code' => 0, 'msg' => '', 'data' => []]);
	}

	public function addNum(Request $request, $openId = null){
		$openId = $this->user['openid'];
		try{
			if($this->Id == null){
				return redirect(Weixin::redirect($request->url()));
			}
			$this->checkOpenId($openId);
			$this->checkFriendship();
		} catch(EXception $e){
			$data['code'] = $e->getCode();
			$data['message'] = $e->getMessage();
			return response()->json($data);
		}

		$p = Problem::where('openid',$openId)->first();
		if(empty($p)){
			return response()->json(['code' => -1, 'msg' => '', 'data' => []]);
		}

		if($p->num <= 1){
			$p->num = $p->num+1;
		} else {
			return response()->json(['code' => -5, 'msg' => '', 'data' => []]);
		}

		$p->save();
		return response()->json(['code' => 0, 'msg' => '', 'data' => []]);
	}

	protected function checkOpenId($openId){
		if(preg_match('/[a-zA-Z0-9_\-]+/', $openId)){
			return true;
		}
		throw new Exception("openId error", -1);
	}

	protected function checkFriendship($ex = true){
		if($this->user['subscribe'] == 1){
			return true;
		}
		if(!$ex){
			return false;
		}
		throw new Exception('not subscribe', -8);
	}

	protected function checkAnswer($openId){
		$problem = Problem::where('openid',$openId)->first();
		if(empty($problem)){
			throw new Exception("not exists", -2);
		}
		$pcount = count(explode(",", $problem->problemIds));
		$acount = count(explode(",", $problem->answers));
		if($pcount <= $acount){
			throw new Exception("already answer", -3);
		}
		return true;
	}

	protected function checkNum($ke = false){
		$key = "problem_wx_num_".date("d");
		if($ke == true){
			return $key;
		}
		$num = Problem::sum('score');
		$n = (int)((time() - strtotime("2016-09-01")) / 86400 + 1);
		if($num > $n * 9900){
			return false;
		}
		if($num > 50000){
			return false;
		}
		if(!Cache::has($key)){
			Cache::put($key, 9900, 86400*2);
		}
		$num = Cache::get($key);
		if($num > 0){
			return true;
		}
		return false;
	}

	protected function getProblem($openId){
		$p = Problem::where('openid',$openId)->first();
		$ps = $this->getPConfig();
		if(empty($p) || empty($p->problemIds)){
			$k = mt_rand(0, 15);
			return array_slice($ps, $k, 5);
		}
		$pcount = count(explode(",", $p->problemIds));
		$acount = count(explode(",", $p->answers));
		if($pcount < $p->num*5){
			$p->answers = $p->answers . '|';
			$p->save();
			foreach(explode(",", $p->problemIds) as $v){
				unset($ps[$v]);
			}
			$k = mt_rand(0, 10);
			return array_slice($ps, $k, 5);
		}
		$re = [];
		if($p->answers == 0){
			$pId = $p->problemIds;
			foreach(explode(",", $pId) as $k => $v){
				if($ps[$v]){
					$re[] = $ps[$v];
				}
			}
		}
		if(count(explode("|", $p->answers)) >= 2){
			if(explode("|", $p->answers)[1] == 0){
				$pId = $p->problemIds;
				foreach(explode(",", $pId) as $k => $v){
					if($k >= 5){
						$re[] = $ps[$v];
					}
				}
			}
		}
		return $re;
	}

	protected function checkRight($pno, $ans){
		$ps = $this->getPConfig();
		if($ps[$pno]['answer'] == $ans){
			return 1;
		}
		return 0;
	}

	protected function getPConfig(){
		return [
				1 => [
					'id' => 1, 'no' => '', 'problem' => 'LOL中多长时间可以发起投降？', 'options' => [
						'A.20分钟','B.30分钟'
					],'answer' => 1
				],
				2 => [
					'id' => 2, 'no' => '', 'problem' => '游戏设计文档不包含的要素是？', 'options' => [
						'A.背景要素','B.开发者简历'
					],'answer' => 2
				],
				3 => [
					'id' => 3, 'no' => '', 'problem' => '以下属于游戏程序制作过程的是？', 'options' => [
						'A.程序结构设计','B.计算毛利润'
					],'answer' => 1
				],
				4 => [
					'id' => 4, 'no' => '', 'problem' => '以下关于GAD描述正确的是？', 'options' => [
						'A.GAD网站地址是gad.pp.com','B.提供项目孵化渠道'
					],'answer' => 2
				],
				5 => [
					'id' => 5, 'no' => '', 'problem' => '游戏角色定位的主要要素，需要考虑以下哪些？', 'options' => [
						'A.个性特征','B.是否盈利'
					],'answer' => 1
				],
				6 => [
					'id' => 6, 'no' => '', 'problem' => 'LOL里面的最大的野怪，俗称大龙的野怪全名叫什么?', 'options' => [
						'A.纳什男爵 ','B.纳什公爵'
					],'answer' => 1
				],
				7 => [
					'id' => 7, 'no' => '', 'problem' => 'LOL中关于ADC的主要介绍哪一项符合？', 'options' => [
						'A.肉盾，护甲高，血量多，能够承受大量伤害 ','B.需要大量金钱去堆积装备的物理输出  '
					],'answer' => 2
				],
				8 => [
					'id' => 8, 'no' => '', 'problem' => '腾讯公司旗下第一款网络游戏是下列哪一个', 'options' => [
						'A.飞行岛','B.凯旋'
					],'answer' => 2
				],
				9 => [
					'id' => 9, 'no' => '', 'problem' => '风靡全球的电子游戏俄罗斯方块是由下列哪位人物发明的', 'options' => [
						'A.弗拉基米尔·伊里奇','B.阿列克谢·帕基特诺夫'
					],'answer' => 2
				],
				10 => [
					'id' => 10, 'no' => '', 'problem' => '游戏《逆战》和电影《逆战》的关系是', 'options' => [
						'A.先有前者','B.先有后者'
					],'answer' => 1
				],
				11 => [
					'id' => 11, 'no' => '', 'problem' => '网络游戏《天龙八部》是根据哪位作家的著作改编的', 'options' => [
						'A.古龙','B.金庸'
					],'answer' => 2
				],
				12 => [
					'id' => 12, 'no' => '', 'problem' => '网络游戏《斗战神》是什么类型的游戏', 'options' => [
						'A.RPG','B.MMORPG'
					],'answer' => 2
				],
				13 => [
					'id' => 13, 'no' => '', 'problem' => '游戏《DOTA》是', 'options' => [
						'A.一张基于某款游戏的地图','B.一款独立的网络游戏'
					],'answer' => 1
				],
				14 => [
					'id' => 14, 'no' => '', 'problem' => '游戏《DOTA》的全名是', 'options' => [
						'A.Defense of the Ancients','B.Defense of the Ancient'
					],'answer' => 1
				],
				15 => [
					'id' => 15, 'no' => '', 'problem' => '游戏《DOTA2》在中国大陆的发行商是', 'options' => [
						'A.盛大游戏','B.完美世界'
					],'answer' => 2
				],
				16 => [
					'id' => 16, 'no' => '', 'problem' => '游戏《上古世纪》的画面是', 'options' => [
						'A.2.5D','B.3D'
					],'answer' => 2
				],
				17 => [
					'id' => 17, 'no' => '', 'problem' => '天天酷跑中超能少年是用谁作为原形设计的？', 'options' => [
						'A.都敏俊','B.尔康'
					],'answer' => 1
				],
				18 => [
					'id' => 18, 'no' => '', 'problem' => 'LOL中下列哪个英雄被称作菊花哥？', 'options' => [
						'A.德玛','B.赵信'
					],'answer' => 2
				],
				19 => [
					'id' => 19, 'no' => '', 'problem' => '第一家游戏公司是', 'options' => [
						'A.雅达利公司','B.世嘉公司 '
					],'answer' => 1
				],
				20 => [
					'id' => 20, 'no' => '', 'problem' => '《拳皇》是我们很多人玩过的游戏，请问 它是哪个国家开发的的', 'options' => [
						'A.日本','B.美国'
					],'answer' => 2
				],						
			];
	}
    //
}
