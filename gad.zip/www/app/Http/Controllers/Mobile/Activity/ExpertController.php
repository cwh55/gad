<?php

namespace App\Http\Controllers\Mobile\Activity;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\CityStationRepositoryEloquent;
use App\Repositories\LiveRepositoryEloquent;
use App\Repositories\ExpertPlanRepository;
use App\Repositories\UserRepositoryEloquent;
use Auth;
use Illuminate\Http\Request;
use App\Repositories\ExpertCategoryRepository;

class ExpertController extends Controller
{
    const EXPERT_ID = 11111;
    const EXPERT_TYPE = 12; //移动端的报名是12

    public function __construct(CityStationRepositoryEloquent $cityStation)
    {
        $this->cityStation = $cityStation;
        $this->middleware('auth');
    }

    public function getIndex(LiveRepositoryEloquent $live)
    {
        $signinfo = null;
        if (Auth::user()) {
            $signinfo = $this->cityStation->findWhere(['user_id'=>Auth::user()->UserId, 'city_id'=>self::EXPERT_ID, 'type'=>self::EXPERT_TYPE],['name','qq','position','corp','mobile','type'])->first();
        }
        //获取特定live的开始结束状态
        $liveinfo = $live->findWhereIn('id',[10014,10015,10016,10017,10018],['id','state']);
        $livestate = array(10014=>0, 10015=>0, 10016=>0, 10017=>0, 10018=>0);//10014=>0, 10015=>0, 10016=>0, 10017=>0, 10018=>0
        foreach ($liveinfo as $live) {
            $livestate[$live['id']] = $live['state'];
        }
        $stage = time() < strtotime('2017-06-22 00:00:00') ? '22' : (time() < strtotime('2017-06-24 9:00:00') ? '22~24' : (time() < strtotime('2017-06-24 14:00:00') ? '24:09' : (time() < strtotime('2017-06-24 19:00:00') ? '24:14' : '24:19')));
        return view('mobile.activity.expert', compact('signinfo', 'livestate', 'stage'));
    }

    public function getPlan(ExpertPlanRepository $expertPlan){
        $activities = $expertPlan->getExpertPlansActivity(2);
        $list = $expertPlan->getExpertList(4);
        return view('mobile.activity.expert_plan',['activities' => $activities, 'total' => $list->total()]);
    }

    public function getPlanExpert(ExpertPlanRepository $expertPlan){
        $list = $expertPlan->getExpertList(4);
        return view('mobile.activity.expert_planexpert',['experts' => $list, 'total' => $list->total()]);
    }

    public function getList(Request $request, ExpertPlanRepository $expertPlan, ExpertCategoryRepository $expertCategoryRepository){
        $perPage = $request->input('pageSize');
        $categoryList = $expertCategoryRepository->getCategoryList();
        $category = $request->input('category');
        if($category){
            $list = $expertCategoryRepository->getExpertList($category, $perPage);
        }else{
            $list = $expertPlan->getExpertList($perPage);
        }
        if($request->wantsJson()){
            return response()->json(['code' => 0, 'data' => $list]);
        }
        return view('mobile.activity.expert_list',['experts' => $list, 'categoryList'=>$categoryList]);
    }
}
