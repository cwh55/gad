<?php

namespace App\Http\Controllers\Mobile\Activity;

use App\Http\Controllers\Controller;

class OfferController extends Controller
{

    public function getIndex()
    {
        return view('mobile.activity.offer');
    }
}
