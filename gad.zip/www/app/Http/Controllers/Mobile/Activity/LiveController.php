<?php

namespace App\Http\Controllers\Mobile\Activity;

use Illuminate\Http\Request;

use App\Entities\LiveActivityLog;
use App\Gad\Weixin;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Repositories\LiveActivityLogRepositoryEloquent;
use Auth;
use Redis;

define('REDIS_LIVE_H5_GAIN_PRIZE', 'gad:act:live:gain:hprize:%d');

class LiveController extends Controller
{
    protected $log;
    private $userArr = array(
        1 => 3000,
        2 => 3000,
        3 => 700,
        4 => 500,
        5 => 500,
        6 => 100
    );
    private $startDate = '2017-04-25'; // 活动开始日期
    //1：3Qb，2：5Qb，3：10Qb，4：鸡年公仔, 5：live门票
    protected $prizeArr = array(
        1 => array(1 => 0, 2 => 0, 3 => 0, 4 => 0, 5=>0),
        2 => array(1 => 0, 2 => 3, 3 => 0, 4 => 0, 5=>0),
        3 => array(1 => 90, 2 => 75, 3 => 45, 4 => 4, 5=>39),
        4 => array(1 => 35, 2 => 42, 3 => 20, 4 => 4, 5=>23),
        5 => array(1 => 5, 2 => 5, 3 => 0, 4 => 1, 5=>3),
        6 => array(1 => 0, 2 => 5, 3 => 0, 4 => 1, 5=>1)
    );
    public function __construct(LiveActivityLogRepositoryEloquent $log)
    {
        $this->log = $log;
        $this->redis = Redis::connection('act');
        $this->middleware('auth');
    }

    public function getIndex(Request $request)
    {
        /*$login_check = User::checkWxLogin($request->input('code'), $request->input('state'));
        if ($login_check == -1) {
            return redirect(Weixin::redirect($request->url(), 'snsapi_userinfo', 'user', true));
        }
        if (!$login_check) {
            return redirect(Weixin::redirect($request->url(), 'snsapi_base', 'base', true));
        }*/
        $userimg = Auth::user()->Avatar;
        $voteinfo = $this->log->findWhere(['type'=>2, 'userid'=>Auth::user()->UserId]);
        $tid = 0;
        if(count($voteinfo)){
            $tid = $voteinfo[0]['objid'];
        }
        $prizeinfo = $this->log->findWhere(['type'=>1, 'userid'=>Auth::user()->UserId]);
        $pid = 0;
        $qqno = "";
        if(count($prizeinfo)){
            $pid = $prizeinfo[0]['objid'];
            $qqno = $prizeinfo[0]['qqno'];
        }
        return view('mobile.activity.live',compact('tid','pid','qqno','userimg'));
    }

    public function postVote(Request $request)
    {
        if(Auth::user()){
            if (in_array($request->input('tid',0),array(1,2,3,4))) {
                $days = $this->getPrizeDay();
                if($days< 0 || $days > 6){
                    return response()->json([
                        'code' => 3,
                        'msg' => '活动未开始或者已结束'
                    ]);
                }
                $userid = Auth::user()->UserId;
                if(count($this->log->findWhere(['type'=>2, 'userid'=>$userid]))){
                    return response()->json([
                        'code' => 2,
                        'msg' => '已投过票'
                    ]);
                }

                $this->log->create([
                    'type' => 2,
                    'userid' => $userid,
                    'objid' => $request->input('tid',0),
                    'creator' => $userid,
                ]);
            }else{
                return response()->json([
                    'code' => 1,
                    'msg' => '参数错误'
                ]);
            }

        }
        return response()->json([
            'code' => 0,
            'msg' => '成功'
        ]);
    }

    public function postPrize(Request $request)
    {
        if(Auth::user()){
            $userid = Auth::user()->UserId;
            if(count($this->log->findWhere(['type'=>1, 'userid'=>$userid]))){
                return response()->json([
                    'code' => 2,
                    'msg' => '您已抽过奖'
                ]);
            }
            $prize = $this->generatePrize();
            if($prize == -1){
                return response()->json([
                    'code' => 3,
                    'pid' => $prize,
                    'msg' => '活动未开始或者已结束'
                ]);
            }
            $this->log->create([
                'type' => 1,
                'userid' => $userid,
                'objid' => $prize,
                'creator' => $userid
            ]);
        }
        return response()->json([
            'code' => 0,
            'pid' => $prize,
            'msg' => '成功'
        ]);
    }

    public function postFillqq(Request $request)
    {
        if(Auth::user()){
            $qqno = $request->input('qqno', 0);
            if(!preg_match("/^[1-9][0-9]{3,11}$/",$qqno)){
                return response()->json([
                    'code' => 1,
                    'msg' => 'QQ号码格式不正确'
                ]);
            }
            $userid = Auth::user()->UserId;
            $prizeinfo = $this->log->findWhere(['type'=>1, 'userid'=>$userid]);
            if(count($prizeinfo)){
                $id = $prizeinfo[0]['id'];
                $this->log->update(['qqno'=>$qqno, 'updater'=>$userid], $id);
            }else{
                return response()->json([
                    'code' => 2,
                    'msg' => '没有抽奖信息'
                ]);
            }
        }
        return response()->json([
            'code' => 0,
            'msg' => '成功'
        ]);
    }

    public function postShare(Request $request)
    {
        if(Auth::user()){
            $userid = Auth::user()->UserId;
            $shareinfo = $this->log->findWhere(['type'=>3, 'userid'=>$userid]);
            if(count($shareinfo)){
                $id = $shareinfo[0]['id'];
                $this->log->update(['objid'=>$shareinfo[0]['objid'] + 1, 'updater'=>$userid], $id);
            }else{
                $this->log->create([
                    'type' => 3,
                    'userid' => $userid,
                    'objid' => 1,
                    'creator' => $userid,
                ]);
            }
        }
        return response()->json([
            'code' => 0,
            'msg' => '分享成功'
        ]);
    }

    /*public function getRest()
    {
        $pkey = sprintf(REDIS_LIVE_H5_GAIN_PRIZE, $this->getPrizeDay());
        $gainPrize = $this->redis->hGetall($pkey);
        dd($gainPrize);
        return 1;
    }*/
    //抽奖逻辑
    public function generatePrize()
    {
        $day = $this->getPrizeDay();
        $prizeType = 6;
        if (0<$day && $day<7) {
            //全部奖项
            $prizelist = $this->prizeArr[$day];
            $totalPrize = array_sum($prizelist);
            //剩余奖项
            $restPrizeList = $this->getRestPrize();
            $totalRestPrize = array_sum($restPrizeList);
            $usercount = $this->userArr[$day];
            if($totalRestPrize > 0) {
                if($totalPrize > 0) {
                    //$randMaxNum = intval($usercount / $totalPrize) + 1;
                    $result = rand(1,$usercount);
                    //中奖
                    if ($result <= $totalPrize) {
                        $pkey = sprintf(REDIS_LIVE_H5_GAIN_PRIZE, $day);
                        $prizeType = $this->choosePrizeType($restPrizeList);
                        if($prizeType){
                            $this->redis->hIncrby($pkey, $prizeType, 1);
                        } else {
                            $prizeType = 6;
                        }
                    }
                }
            }
        }else{  //活动结束
            return -1;
        }

        return $prizeType;
    }

    private function choosePrizeType($prizelist)
    {
        $totalprize = array_sum($prizelist);
        $randnum = rand(1,$totalprize);
        $count = 0;
        foreach($prizelist as $k => $v){
            $count += $prizelist[$k];
            if($randnum <=$count){
                return $k;
            }
        }
        return 0;
    }
    //获得当前是活动进行第几天
    private function getPrizeDay()
    {
        if($this->startDate > date('Y-m-d')){
            return -1;
        }
        $interval = date_diff(date_create($this->startDate), date_create(date('Y-m-d')));
        return $interval->format('%a') + 1;
    }
    //获取剩余奖项数量
    private function getRestPrize()
    {
        $total = array();
        $days = $this->getPrizeDay();
        //设置总奖品数
        if(isset($this->prizeArr[$days])) {
            $total = $this->prizeArr[$days];
        }
        //消耗奖品数
        $pkey = sprintf(REDIS_LIVE_H5_GAIN_PRIZE, $days);
        $gainPrize = $this->redis->hGetall($pkey);

        if(!empty($total)){
            foreach ($total as $k => $v) {
                if ($v > 0 && isset($gainPrize[$k]) && $gainPrize[$k] > 0 && $v - $gainPrize[$k] > 0) {
                    $total[$k] = $v - $gainPrize[$k];
                } else if($v == 0 || (isset($gainPrize[$k]) && $v - $gainPrize[$k] <= 0)){
                    unset($total[$k]);
                }
            }
        }
        return $total;
    }
}
