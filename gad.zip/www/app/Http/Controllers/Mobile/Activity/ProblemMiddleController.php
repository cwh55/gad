<?php

namespace App\Http\Controllers\Mobile\Activity;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Models\Problem;
use App\Http\Controllers\Controller;
use Exception;
use App\Gad\Weixin;
use Auth;
use Cache;

class ProblemMiddleController extends Controller
{
	protected $Id = 1;

	protected $user = null;

	public function __construct(){
		  //$this->middleware('auth');
          $this->user = new \App\Entities\User();
	}

	//是否关注
	public function getFriendship(Request $request, $openId = null)
	{
		$data = ['code' => 0, 'msg' => '', 'data' => []];
		$openId = $this->user['openid'];
		try{
			if($this->Id == null){
				return redirect(Weixin::redirect($request->url()));
			}
			$this->checkOpenId($openId);
		} catch(Exception $e){
			$data['code'] = $e->getCode();
			$data['msg'] = $e->getMessage();
			return response()->json($data);
		}

		$friendship = $this->checkFriendship($openId, true);
		$data['data'] = array('friendship' => $friendship);

		return response()->json($data);
	}

	//答题页
	public function postAnswer(Request $request)
	{
			//$p = Problem::findOrFail($this->user['UserId'].'-17');

			$a_count = 0;//count(explode(",", trim($p->answers)));
			if($a_count >= 3){
				  return response()->json(['code' => 0, 'message' => '您已经答完', 'data' => ['index' => 4]]);
			}

			$pno = intval($request->input('pno'));
			if(!in_array($pno, array(1,2,3))){
				  return response()->json(['code' => -1, 'message' => '题号不对']);
			}

			//if($p->answers != "") {
            //    $answerArr = explode(",", $p->answers);
            //    foreach ($answerArr as $aval) {
            //        $avalArr = explode("|", $aval);
            //        if ($avalArr[0] == $pno) {
            //            return response()->json(['code' => -2, 'message' => '您已经回答这道题']);
            //        }
            //    }
            //}
			$ano = $request->input('ano');
            $answer = $this->checkAnswer($pno, $ano);
            if(!$answer){
                return response()->json(['code' => -1, 'message' => '选择错误', 'data' => []]);
            }
			//$p->answers = $p->answers ? $p->answers . ',' . $pno . '|' . $ano : $pno . '|' . $ano;
			//$p->save();

			return response()->json(['code' => 0, 'data' => ['index' => $pno + 1]]);
	}

	//获取题目
	public function getIndex(Request $request)
	{
			$data = ['code' => 0, 'msg' => '', 'data' => []];
			//$openId = $this->user['WeixinId'].'-17';
			//$this->checkOpenId($openId);
			//roblem::checkDate();

			//$p = Problem::find($openId);
			//if(empty($p) || $p->problemIds == ''){
			    $data['problem'] = $this->postProblem($request);
                $data['answers'] = [];
                $data['answerable'] = false;
                $data['index'] = 1;
			//} else {
            //    $data['index'] = $p->answers == '' ? 1 : count(explode(',',$p->answers)) + 1;
            //    $data['problem'] = $this->problems();
            //    $data['answers'] = explode(',',$p->answers);
            //    $data['answerable'] = count($data['answers']) >= count(explode(',',$p->problemIds));
			//}

		  return view('mobile.activity.problem_middle_index',$data);
	}

	//分数
	public function postRetest(Request $request, $openId = null)
	{
		$data = ['code' => 0, 'msg' => '', 'data' => []];
		$openId = $this->user['WeixinId'];
		$problem = Problem::findOrFail($openId);
		$problem->problemIds = '';
		$problem->answers = '';
		$problem->save();
		$data['data'] = [];//array('num' => $p->num, 'score' => $p->score, 'qq' => intval($p->qq));

		return response()->json($data);
	}

	//回答
	public function postProblem(Request $request)
	{
			//$this->checkOpenId($this->user['WeixinId']);

			//$problem = Problem::find($this->user['WeixinId'].'-17');//获得题目
			//if($problem && $problem->problemIds != ''){
			//	  return response()->json(['code' => -1, 'message' => '已经答题']);
			//}
			//if(empty($problem)){
			//	  $problem = new Problem();
            //      $problem->openid = $this->user['WeixinId'].'-17';
			//}
			$problems = $this->problems();
			//$problem->problemIds = '1,2,3';
			//$problem->save();

			return $problems;
	}

	protected function checkOpenId($openId){
		if(preg_match('/[a-zA-Z0-9_\-]+/', $openId)){
			return true;
		}
		throw new Exception("openId error", -1);
	}

	protected function checkFriendship($ex = true){
		if($this->user['subscribe'] == 1){
			return true;
		}
		if(!$ex){
			return false;
		}
		throw new Exception('not subscribe', -8);
	}

	protected function checkAnswer($pno, $ano){
		$problems = $this->getPConfig(false);
		return $problems[$pno]['answer'] == $ano;
	}

	protected function problems($filter = true)
    {
        $problem = $this->getPConfig();
        if($filter == true) {
            foreach ($problem as &$p) {
                unset($p['answer']);
            }
        }
        return $problem;
    }

    protected function getPConfig()
    {
        return [
                1 => [
                    'id' => 1,
                    'no' => '',
                    'problem' => ' 给父母打了电话买好月饼，你准备今年提前回家过中秋，你在电脑上发了请假申请，Boss让你进他办公室详谈。你满怀期望地走进了Boss办公室。',
                    'options' => [
                        ['no' => 'A',
                            'value' => '你诚恳地说：“我想提前回家过中秋，希望你能批假。”'
                        ],
                        ['no' => 'B',
                            'value' => '你凶神恶煞地说：“老板，总之不给假就删库……”'
                        ],
                        ['no' => 'C',
                            'value' => '你跪倒在地，抱住老板大腿：“老板你不给假就不起来啊！”'
                        ],
                        ['no' => 'D',
                            'value' => '你露出了手臂上的新纹身问：“老板我回家过中秋，给假不？”'
                        ]
                    ],
                    'answer' => 'A'
                ],
                2 => [
                    'id' => 2,
                    'no' => '',
                    'problem' => '老板终于批假了，你收拾好行李准备买票，但是点开所有抢票软件都显示：票已售完。这时候你会：',
                    'options' => [
                        ['no' => 'A',
                            'value' => '翻开尘封已久的通讯录，找到了黄牛，黄牛表示：加价300%。'
                        ],
                        ['no' => 'B',
                            'value' => '掏出手机扫路边共享单车二维码，准备骑单车1000公里回家'
                        ],
                        ['no' => 'C',
                            'value' => '一咬牙买了全价机票飞回家。'
                        ],
                        ['no' => 'D',
                            'value' => '买了5双草鞋，你想：谁怕谁，今天我步行回家！'
                        ]
                    ],
                    'answer' => 'C'
                ],
                3 => [
                    'id' => 3,
                    'no' => '',
                    'problem' => '回家考验第三关：终极BOSS。经历千辛万苦，你终于买到机票，在登机前，你突然接到同事电话，项目紧急BUG，这时候你会',
                    'options' => [
                        ['no' => 'A',
                            'value' => '公司需要我，老板需要我，赶紧回公司加班。'
                        ],
                        ['no' => 'B',
                            'value' => '搞清楚BUG原理，临时电话指挥同事帮忙处理BUG。'
                        ],
                        ['no' => 'C',
                            'value' => '影帝上身：“手机突然信号不好，喂喂……”，然后关机。'
                        ],
                        ['no' => 'D',
                            'value' => '告诉老板下飞机之后会找个有网络的地方紧急处理BUG。'
                        ]
                    ],
                    'answer' => 'B'
                ],
        ];
    }
    //

    protected function getDesc($score){
	    if ($score <= 50){
	        return '如果你有志于从事这方面的工作，建议还要继续努力哦~没事看看GAD网站和微信可以学习很多干货哦！';
        }

        if ( 60<= $score && $score <= 70 ){
            return '可进步的区间还是很大，加油，相信成功入职成为一名游戏人已经不远了！';
        }
        if ( 80<= $score && $score <= 90 ){
            return '这么优秀的你想必是很多游戏公司争抢的人才吧！';
        }
        if ( $score == 100 ){
            return '你就是传说中那个绝无仅有的人才！';
        }
    }

}
