<?php

namespace App\Http\Controllers\Mobile\Live;

use App\Http\Controllers\Controller;
use App\Repositories\LiveRepositoryEloquent;
use App\Repositories\LiveSignRepositoryEloquent;
use App\Repositories\UserRepositoryEloquent;
use Auth;
use Gate;
use Illuminate\Http\Request;

class Live2Controller extends Controller {

    protected $live;
    protected $messageRepository;
    protected $sign;
    protected $user;

    public function __construct(LiveRepositoryEloquent $live, LiveSignRepositoryEloquent $sign,
                                UserRepositoryEloquent $user) {
        $this->live = $live;
        $this->sign = $sign;
        $this->user = $user;

        $this->middleware('auth');
    }

    public function getList(Request $request)
    {
        $lives = $this->live->getAllList();
        if ($request->wantsJson()) {
            return response()->json(['code' => 0, 'lives' => $lives]);
        }

        return view('mobile.live.list', compact('lives'));
    }

    public function getMy(Request $request)
    {
        $lives = $this->live->getByUser($this->sign, $request->user());
        if ($request->wantsJson()) {
            return response()->json(['code' => 0, 'lives' => $lives]);
        }

        return view('mobile.live.list', compact('lives'));
    }

    public function getDetail(Request $request, $id)
    {
        $live = $this->live->getDetail($id);
        if (Gate::allows('access', $live)) {
            //return redirect('m/live/chatroom/'.$live->id);
        }

        return view('mobile.live.detail', compact('live'));
    }

    public function postBuy(Request $request, $id)
    {
        $live = $this->live->find($id);
        if (is_null($live)) {
            return abort(404, 'Live不存在');
        }

        $user = $request->user();
        if (is_null($user)) {
            return abort(401, '您尚未登录');
        }

        if (session('openId') == null OR session('accessToken') == null) {
            return abort(401, '登录状态已失效，请重新登录');
        }

        $result = $this->live->buy($live, $request->user());
        if ($result['code'] == 1018) {
            return abort(401, '登录状态已失效，请重新登录');
        }

        return response()->json($result);
    }

    public function getLogin(Request $request)
    {
        Auth::logout();
        $request->session()->put('url.intended',  url()->previous());

        return redirect('/login');
    }

    public function getShip(Request $request)
    {
        $params = $request->all();
        if (!$this->live->checkMidasSig($params)) {
            return response()->json(['ret' => 1, 'msg' => '请求参数错误']);
        }

        list($liveId, $_, $_) = explode('*', $params['payitem']);
        list($userId, $_, $_) = explode('*', $params['appmeta']);
        $live = $this->live->find($liveId);
        $user = $this->user->find($userId);
        if ($this->sign->contain($live, $user)) {
            return response()->json(['ret' => 0, 'msg' => 'OK']);
        }

        $sign = $this->sign->addUser($live, $user);
        if ($sign) {
            return response()->json(['ret' => 0, 'msg' => 'OK']);
        }

        return response()->json(['ret' => 2, 'msg' => '发货时出错']);
    }

    //新手引导
    public function getGuide()
    {
        return view("mobile.live.guide");
    }

}
