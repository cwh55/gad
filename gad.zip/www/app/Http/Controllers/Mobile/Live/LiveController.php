<?php

namespace App\Http\Controllers\Mobile\Live;

use App\Gad\Midas;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Auth;
use App\Gad\Weixin;
use Debugbar;
use Redis;
use App\Repositories\LiveRepositoryEloquent;
use App\Repositories\LiveMessageRepositoryEloquent;
use App\Repositories\LiveSignRepositoryEloquent;
use App\Repositories\LiveMessageLikeRepositoryEloquent;
use Illuminate\Support\Facades\DB;
use App\Models\KeyValue;

class LiveController extends Controller {

    protected $repository;
    protected $messageRepository;
    protected $liveSignRepository;
    protected $liveMessageLikeRepository;

    public function __construct(LiveRepositoryEloquent $repository, LiveMessageRepositoryEloquent $messageRepository, LiveSignRepositoryEloquent $liveSignRepository, LiveMessageLikeRepositoryEloquent $liveMessageLikeRepository) {
        $this->repository = $repository;
        $this->messageRepository = $messageRepository;
        $this->liveSignRepository = $liveSignRepository;
        $this->liveMessageLikeRepository = $liveMessageLikeRepository;

        Debugbar::disable();
    }

    private function _getLiveList($isMine) {
        if ($isMine) {
            $lives = Auth::user()->lives()->with('teachers')->orderBy('begin_time', 'desc')->paginate(10)->toArray();
        } else {
            $lives = $this->repository->with('teachers')->orderBy('begin_time', 'desc')->paginate(10)->toArray();
        }
        foreach ($lives['data'] as &$li) {
            if($li['rowstatus'] == 1) {
                $status_code = 1;
                $status_name = '已结束';
            }else{
                $t = strtotime($li['begin_time'])-time();
                if($t<0){
                    $status_code = 0;
                    $status_name = '进行中';
                }else if($t<24*3600){
                    $status_code = 2;
                    $s = floor($t/3600);
                    $status_name = $s ? ($s.'小时后开始') : '1小时内开始';
                }else{
                    $status_code = 2;
                    $status_name = floor($t/24/3600).'天后开始';
                }
            }
            $li['status_code'] = $status_code;
            $li['status_name'] = $status_name;
        }
        return $lives;
    }

    public function getLiveList(Request $request) {
        try {
            $data = $this->_getLiveList(!empty($request->input('is-mine')));
            return response()->json(array('code' => 0, 'data' => $data['data']));
        } catch (\Exception $ex) {
            return response()->json(array('msg' => $ex->getMessage(), 'code' => 1));
        }
    }

    public function getMList(Request $request) {
        $list = $this->_getLiveList(!empty($request->input('is-mine')));
        return view('mobile.live.list', array('list' => $list));
    }

    public function getMDetail(Request $request, $liveId) {
        $liveId = intval($liveId);
        $data = $this->detailData($liveId);
        return view('mobile.live.detail', $data);
    }

    public function getMBuy(Request $request, $id)
    {
        $live = $this->repository->find($id);
        $goods = [
            'payitem' => $live->id.'*'.$live->price.'*1',
            'goodsmeta' => $live->name.'*'.$live->description,
            'goodsurl' => '',
            'amt' => $live->price
        ];

        $result = Midas::mBuyGoods($goods);

        return response()->json($result);
    }

    public function getMChatroom(Request $request, $liveId) {
        $login_check = User::checkWxLogin($request->input('code'), $request->input('state'));
        if ($login_check == -1) {
            return redirect(Weixin::redirect($request->url(), 'snsapi_userinfo', 'user', true));
        }
        if (!$login_check) {
            return redirect(Weixin::redirect($request->url(), 'snsapi_base', 'base', true));
        }
        header('Cache-control:no-cache,no-store,must-revalidate');
        header('Pragma:no-cache');
        header('Expires:0');
        $liveId = intval($liveId);
        $live = $this->getLiveInfo($liveId);
        $user_id = Auth::user()['UserId'];
        if (!$this->canJoinLive($liveId, $user_id)) {
            return redirect("/m/live/detail/{$liveId}");
        }
        $mySign = $this->liveSignRepository->findWhere(array('user_id'=>$user_id, 'live_id'=>$liveId))->toArray()[0];
        $userInfo = array('UserId' => Auth::user()['UserId'], 'NickName' => $mySign['type'] == 1 ? $mySign['nickname'] : Auth::user()['NickName'],
            'Avatar' => ($mySign['type'] == 1 && $mySign['avatar']) ? $mySign['avatar'] : Auth::user()['Avatar'], 'Type' => $mySign['type']);
        return view('mobile.live.chatroom', array('live_host' => app()->isLocal() ? 'demo.gad.qq.com:8080' : 'api.gad.qq.com', '', 'live' => $live, 'userInfo' => $userInfo));
    }

    public function getList(Request $request) {
        $isMine = !empty($request->input('is-mine'));
        if ($isMine && !Auth::check()) {
            return redirect()->guest('/login');
        }
        $list = $this->_getLiveList($isMine);
        $banners = json_decode(KeyValue::find('live_list_banner')['Value'], true);
        return view('live.list', array('list' => $list, 'banners'=>$banners));
    }

    public function getDetail($liveId) {
        $liveId = intval($liveId);
        $data = $this->detailData($liveId);
        return view('live.detail', $data);
    }

    public function getChatroom($liveId) {
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $liveId = intval($liveId);
        $user_id = Auth::user()['UserId'];
        $live = $this->getLiveInfo($liveId);
        if (!$this->canJoinLive($liveId, $user_id)) {
            return redirect("/live/detail/{$liveId}");
        }
        $mySign = $this->liveSignRepository->findWhere(array('user_id'=>$user_id, 'live_id'=>$liveId))->toArray()[0];
        $userInfo = array('UserId' => Auth::user()['UserId'],'UserType' => Auth::user()['type'], 'NickName' => $mySign['type'] == 1 ? $mySign['nickname'] : Auth::user()['NickName'],
                'Avatar' => ($mySign['type'] == 1 && $mySign['avatar']) ? $mySign['avatar'] : Auth::user()['Avatar'], 'Type' => $mySign['type']);
        $students = $this->repository->with('students')->find($liveId)->toArray();
        return view('live.chatroom', array('live_host' => app()->isLocal() ? 'demo.gad.qq.com:8080' : 'api.gad.qq.com', '', 'live' => $live, 'userInfo' => $userInfo, 'students' => $students['students'], 'loginType'=>session('loginType')));
    }

    protected function detailData($liveId) {
        $live = $this->getLiveInfo($liveId);
        $guests = array();
        foreach ($live['teachers'] as $t) {
            $guests[] = array('name' => $t['nickname'], 'attavr' => $t['avatar'], 'intro' => $t['description']);
        }
        if (!Auth::check()) {
            $hasPay = false;
        } else {
            $sign = $this->liveSignRepository->findByField('user_id', $user_id = Auth::user()['UserId'])->toArray();
            $hasPay = !empty($sign) ;
        }
        if($live['rowstatus'] == 1) {
            $status_name = '已结束';
        }else{
            $t = strtotime($live['begin_time'])-time();
            if($t<0){
                $status_name = '进行中';
            }else if($t<24*3600){
                $s = floor($t/3600);
                $status_name = $s ? ($s.'小时后开始') : '1小时内开始';
            }else{
                $status_name = floor($t/24/3600).'天后开始';
            }
        }

        $topic = array('id' => $live['id'], "title" => $live['name'], "time" => $live['begin_time'], "cost" => $live['price'], "intro" => $live['description'], 'hasPay' => $hasPay , 'time_status' => $status_name);
        $rows = $this->repository->with('students')->find($liveId)->toArray();
        $buyers = array();
        foreach ($rows['students'] as $r) {
            $buyers[] = $r['avatar'];
        }
        return compact('guests', 'topic', 'buyers', 'liveId');
    }

    public function postUploadwx(Request $request) {
        try {
            if (!Auth::check()) {
                throw new \Exception('请先登录');
            }
            $accessToken = Weixin::getSubAccessToken();
            $serverId = $request->input('sid');
            $type = $request->input('type');
            $url = \App\Gad\Func::fileApi($accessToken, $serverId, $type);
            if (!$url) {
                throw new \Exception('文件转存失败');
            }
            return response()->json(array('code' => 0, 'data' => $url));
        } catch (\Exception $ex) {
            return response()->json(array('msg' => $ex->getMessage(), 'code' => 1));
        }
    }

    private function getSearchValue($search, $key) {
        preg_match("/{$key}:(\w+)/i", $search, $result);
        return empty($result[1]) ? '' : $result[1];
    }

    private function canJoinLive($live_id, $user_id) {
        //管理员进来房间后，如果发现他没报名，则自动在live添加他为live管理员，便于获取他在live的其他信息
        $user = User::find($user_id);
        $is_admin = $user->roles->contains(2);
        $has_sign = !empty($this->liveSignRepository->findWhere(array('user_id' => $user_id, 'live_id' => $live_id))->toArray());
        if($is_admin && !$has_sign){
            $this->liveSignRepository->addAdmin($live_id, $user);
        }
        return $is_admin || $has_sign;
    }

    private function getLiveInfo($liveId) {
        $live = $this->repository->with('teachers.user')->find($liveId)->toArray();
        return $live;
    }

    public function getMessageList(Request $request) {
        //https://github.com/andersao/l5-repository#create-a-criteria
        //--/live/messageList?search=id:1;live_id:1&searchFields=id:<;live_id&orderBy=id&sortedBy=desc
        try {
            if (!Auth::check()) {
                throw new \Exception('未登录');
            }
            $user_id = Auth::user()['UserId'];
            $live_id = intval($this->getSearchValue($request->input('search'), 'live_id'));
            if(!$this->getLiveInfo($live_id)){
                throw new \Exception('不存在的live');
            }
            //$live_id = intval($request->input('live_id'));
            //$id = intval($request->input('id'));
            if (!$this->canJoinLive($live_id, $user_id)) {
                throw new \Exception('你未报名加入这个Live');
            }
            $messages = $this->messageRepository->paginate(20)->toArray();
            $messageList = $messages['data'];
            //$messageList = DB::select(DB::raw("SELECT * FROM live_messages WHERE live_id = {$live_id} " . ($id ? "AND id < {$id}" : '') . " ORDER BY id DESC LIMIT 20"));
            $msgIds = array();
            foreach ($messageList as $li) {
                $msgIds[] = $li['id'];
            }
            $myLikes = array();
            $likeparams = array(
                'user_id' => $user_id,
                'rowstatus' => 0,
                array('live_message_id', 'IN', $msgIds)
            );
            $temp = $this->liveMessageLikeRepository->findWheresIn($likeparams)->toArray();
            foreach ($temp as $t) {
                $myLikes[$t['live_message_id']] = 1;
            }
            foreach ($messageList as &$li) {
                $li['is_liked'] = isset($myLikes[$li['id']]);
            }
            return response()->json(array('messageList' => $messageList, 'total'=>$messages['total'], 'code' => 0));
        } catch (\Exception $ex) {
            return response()->json(array('msg' => $ex->getMessage(), 'code' => 1));
        }
    }

    public function postLikeMessage(Request $request) {
        try {
            if (!Auth::check()) {
                throw new \Exception('未登录');
            }
            $user_id = Auth::user()['UserId'];
            $message_id = intval($request->input('mid'));
            $rowstatus = intval($request->input('like')) == 0 ? '0' : '-1';
            $msglike = $this->liveMessageLikeRepository->findWhere(array('live_message_id'=>$message_id, 'user_id'=>$user_id));
            if (!count($msglike)) {
                if ($rowstatus == 0) {
                    $this->liveMessageLikeRepository->create(array('user_id' => $user_id, 'live_message_id' => $message_id, 'rowstatus' => $rowstatus));
                }
            } else {
                $this->liveMessageLikeRepository->update(array('rowstatus'=>$rowstatus), $msglike[0]['id']);
            }
            $like_count = $this->liveMessageLikeRepository->findWhere(array('live_message_id'=>$message_id, 'rowstatus'=>0))->count();
            $this->messageRepository->update(array('like_count'=>$like_count*1), $message_id);
            return response()->json(array('code' => 0));
        } catch (\Exception $ex) {
            return response()->json(array('msg' => $ex->getMessage(), 'code' => 1));
        }
    }

    public function getTest(Request $request){
        $user = $request->user();
        $session = $request->session();
        $loginType = $session->get('loginType');
        $op = $request->get('op');
        if ($op == 'expire') {
            $session->forget(['openId', 'accessToken']);
        }

        if ($op == 'error') {
            $session->set('openId', 'openId123');
            $session->set('accessToken', 'accessToken123');
        }

        dump($user->UserId, $loginType, $session->get('openId'), $session->get('accessToken'));
    }
}
