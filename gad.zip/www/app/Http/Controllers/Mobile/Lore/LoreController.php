<?php

namespace App\Http\Controllers\Mobile\Lore;

use App\Http\Controllers\Controller;
use App\Repositories\LiveOrderRepositoryEloquent;
use App\Repositories\LoreLearnRepositoryEloquent;
use App\Repositories\LorePayRepositoryEloquent;
use App\Repositories\LoreRepositoryEloquent;
use App\Repositories\LoreSectionRepositoryEloquent;
use Auth;
use Gate;
use Illuminate\Http\Request;
use Exception;
use Endroid\QrCode\QrCode;
use Response;
use App\Models\User;
use App\Gad\Weixin;
use View;


class LoreController extends Controller {

	protected $lore;
    protected $section;
    protected $order;
    protected $learn;
	public function __construct(
        LoreRepositoryEloquent $lore,
        LoreSectionRepositoryEloquent $section,
        LiveOrderRepositoryEloquent $order,
        LoreLearnRepositoryEloquent $learn
    )
    {
        $this->lore = $lore;
        $this->section = $section;
        $this->order = $order;
        $this->learn = $learn;
        $this->middleware('auth', ['only' => ['postBuy','getDetail']]);
    }

    public function getIndex(Request $request, $id)
    {
        $lore = $this->lore->getDetail($id);
        //未发布需要判断是否有管理员权限
        if ($lore->state == 1) {
            $this->authorize('accessdraft');
        }
        if(View::exists('mobile.lore.index_'.$id)) {
            return view('mobile.lore.index_'.$id,compact('lore'));
        }
        if ($lore->top_banner) {
            $loreAdgs = $lore->advantages();
            return view('mobile.lore.index_tpl',compact('lore','loreAdgs'));
        }
        return view('mobile.lore.index',compact('lore'));
    }

    public function getCatalog(Request $request, $id)
    {
        $lore = $this->lore->getDetail($id);

        //未发布需要判断是否有管理员权限
        if ($lore->state == 1) {
            $this->authorize('accessdraft', $lore);
        }
        $study = $request->session()->get('lore'.$id);
        if (!$study) {
            $lore->increment('study_cnt');
            $request->session()->put('lore'.$id,true);
        }
        if(View::exists('mobile.lore.catalog_'.$id)) {
            return view('mobile.lore.catalog_'.$id,compact('lore'));
        }
        if ($lore->top_banner) {
            return view('mobile.lore.catalog_tpl',compact('lore'));
        }
        return view('mobile.lore.catalog',compact('lore'));
    }

    //小节详情页,登录判断写在构造函数里
    public function getDetail(Request $request, $id)
    {
        /*$login_check = User::checkWxLogin($request->input('code'), $request->input('state'));
        if ($login_check == -1) {
            return redirect(Weixin::redirect($request->url(), 'snsapi_userinfo', 'user', true));
        }
        if (!$login_check) {
            return redirect(Weixin::redirect($request->url(), 'snsapi_base', 'base', true));
        }*/

        $section = $this->section->find($id);

        if ($section) {
            $section->access = $section->allowAccess();
            $isPayed = $section->lore->isPayed();
            if ($section->access) {
                $section->increment('view_cnt');
                $this->learn->record(Auth::user(),$section);
            }
            $loreimg = $section->lore->intro_pic;
            return view('mobile.lore.detail',compact('section', 'isPayed', 'loreimg'));
        } else {
            abort(404);
        }

    }

    //获取分享二维码
    public function getLogin(Request $request,$id)
    {
        $login_check = User::checkWxLogin($request->input('code'), $request->input('state'));
        if ($login_check == -1) {
            return redirect(Weixin::redirect($request->url(), 'snsapi_userinfo', 'user', true));
        }
        if (!$login_check) {
            return redirect(Weixin::redirect($request->url(), 'snsapi_base', 'base', true));
        }

				return redirect('/m/lore/index/'.$id);
    }

    public function postBuy(Request $request, $id)
    {
        $isPayed = $this->lore->isPayed($id);
        if ($isPayed) {
            return ['code' => 1, 'msg' => '已购买请勿重复购买'];
        }
        $lore = $this->lore->find($id);
        if (session('openId') == null OR session('accessToken') == null) {
            return abort(401, '登录状态已失效，请重新登录');
        }
        $user = $request->user();
        $result = $this->lore->buy($lore, $user, 'mobile');
        if ($result['code'] == 1018) {
            return abort(401, '登录状态已失效，请重新登录');
        }
        return response()->json($result);
    }

}
?>
