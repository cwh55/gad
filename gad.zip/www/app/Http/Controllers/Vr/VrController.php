<?php

namespace App\Http\Controllers\Vr;
use App\Gad\Lib_Func;
use App\Models\Article;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\KeyValue;
use App\Models\Config;
use App\Models\Content;
use App\Models\Game;
use App\Models\User;
use Illuminate\Http\Request;
use App\Gad\Upload;
use App\Gad\Html;
use App\Gad\Func;
use Auth;
use Gate;
use Mockery\CountValidator\Exception;
use Redis;
use Illuminate\Routing\Route;

class VrController extends Controller
{
    public function __construct(Request $request){
        if($request->is('hatch/edit*')){
            if(isset($request->id) && ($id = $request->id) >= 1){
                $hatch = Game::find($id);
                $user_id = $hatch->user_id;
                //$this->middleware("acl:hatch::edit,user_id=".$user_id, ['only' => ['getEdit','postEdit']]);
            }
        }
    }

	//根据showtype类型来组装查看页面url
	public function getViewUrl($id, $showType = 1) {
		if($showType == 1) {
			return '/article/detail/'.$id;
		}
		if($showType == 2) {
			return '/content/wendetail/'.$id;
		}
		if($showType == 3) {
			return '/content/coursedetail/'.$id;
		}
		return '/article/detail/'.$id;
	}

    public function index(Request $request)
	{
		$banner = [];
		$key = "vr_new_index_banner";

		$banner = KeyValue::where('Key',$key)->first();
		$bValue = json_decode($banner['Value'],true);
		if($bValue && count($bValue) > 5){
			$bValue = array_slice($bValue,0,5);
		}

		//banner 信息
		$data['bannerValue'] = $bValue;
		$outIds = [];
		foreach($bValue as $v){
			$outIds[] = intval($v['descript']);
		}

		//精选推荐
		$jValue = KeyValue::where('Key','vr_new_v_recommendactivity')->first();
		if($jValue['Value'] && (time() - strtotime($jValue['Modified'])) < 86400 * 3){
			$jingxuan = Content::getNewsListByType(3595,2,1,explode(',',$jValue['Value']),$outIds);
		} else {
			$jingxuan = Content::getNewsListByType(3595,2,1,[],$outIds);
		}
		$data['jingxuan'] = $jingxuan;
		foreach($jingxuan as $v){
			$outIds[] = $v->Id;
			$userId = $v->Creator;
			if($v->Author){
				$userId = $v->Author;
			}
			$v->AuthorName = User::where('UserId',$userId)->first()['NickName'];
		}

		//热门问答
		$wkey = 'vr_new_v_wen';
		$wValue = KeyValue::where('Key',$wkey)->first();
		$wen = [];
		if($wValue['Value'] && (time() - strtotime($wValue['Modified'])) < 86400 * 3){
			$wen = Content::getWenList(['groupid'=>3595,'page'=>0,'size'=>3,'ids' => explode(',',$wValue['Value'])]);
		} else {
			$wen = Content::getWenList(['groupid'=>3595,'page'=>0,'size'=>3]);
		}
		$data['wen'] = $wen;

		//机构
		$jiIds = [];
		$jValue = KeyValue::where('Key','vr_new_jigou')->first();
		if($jValue['Value'] && (time() - strtotime($jValue['Modified'])) < 86400 * 3){
			$jiIds = explode(',',$jValue['Value']);
		} else {
			$jigou = Config::where('identification','vr_org')->get();
			foreach($jigou as $v){
				$jiIds[] = $v['ConfigId'];
			}
		}
		$jiList = Content::getContentByClassType(2,$jiIds,'1,2,3',0,3);
		if(!empty($jiList)){
			foreach($jiList as $key=>$jigou){
				$jiList[$key]->cUrl = $this->getViewUrl($jigou->Id,$jigou->ShowType);
			}
		}
		$data['jigou'] = $jiList;

		//项目
		$pkey = 'vr_new_project';
		$prog = KeyValue::where('Key',$pkey)->first();
		$data['prog'] = [];
		if($prog['Value']){
			$data['prog'] = Game::whereIn('id',explode(',',$prog['Value']))->take(2)->get();
		} else {
			$data['prog'] = Game::where('obj_type', 1)->where('status', 0)->orderBy('id', 'desc')->take(2)->get();
		}

		//翻译 tr配置
		$trankey = 'vr_new_tran';
		$tran = KeyValue::where('Key',$trankey)->first();
		$tranD[] = json_decode($tran['Value'],true)[0];
		$tranK = 'vr_new_tran_key';
		$tr = KeyValue::where('Key',$tranK)->first();
		$trV = explode(',',$tr['Value']);
		$ntran = [];
		$ytran = [];
		if($trV && isset($trV[0])){
			$ntran = Content::getTran(1,3595,'new',1,[$trV[0]]);
		}
		if(!$ntran){
			$ntran = Content::getTran(1,3595,'new',1);
		}
		if($trV && isset($trV[1])){
			$ytran = Content::getTran(0,3595,'new',1,[$trV[1]]);
		}
		if(!$ytran){
			$ytran = Content::getTran(0,3595,'new',1);
		}
		$tranD[] = isset($ntran[0]) ? $ntran[0] : [];
		$tranD[] = isset($ytran[0]) ? $ytran[0] : [];
		$data['tran'] = $tranD;

		//精彩分享
		$ckey = 'vr_new_v_course';
		$cvalue = KeyValue::where('Key',$ckey)->first();
		$data['course'] = [];
		if($cvalue['Value'] && (time() - strtotime($cvalue['Modified'])) < 86400 * 3){
			$data['course'] = Content::getNewsListByType(3595,2,3,explode(',',$cvalue['Value']));
		} else {
			$data['course'] = Content::getNewsListByType(3595,2,3);
		}

		//资讯
		$newsCId = [];
		$data['news'] = [];
		$inIds = [];
		$nValue = KeyValue::where('Key','vr_new_v_news')->first();
		if($nValue['Value'] && (time() - strtotime($nValue['Modified'])) < 86400 * 3){
			$inIds = explode(',',$nValue['Value']);
		}
		$newsConf = Config::where('parentId',3595)->where('shortName','news')->get();
		foreach($newsConf as $v){
			$newsCId[] = $v['ConfigId'];
		}
		$data['news'] = Content::getNews($newsCId,5,'1,2,3',$outIds,$inIds);
		foreach($data['news'] as &$v){
			if(!$v->CoverImage){
				$v->CoverImage = Html::getFirstImage($v->HtmlDetail);
			}
		}
		foreach($data['news'] as &$v){
			if(!$v->CoverImage){
				$v->CoverImage = Html::getFirstImage($v->HtmlDetail);
			}
		}

		//活动
		$activity = KeyValue::where('Key','vr_new_v_activity')->first();
		$data['activity'] = json_decode($activity['Value'],true);

		$func = new Func();
		$ip = $func->getIp();
		$ip_int = ip2long($ip) % 2;

		$data['nav'] = $ip_int;
        $data['domain'] = 'gad.qq.com';

        return view('vr.vrindex', $data);
    }

    public function getCreate() {
        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $user = Auth::user();

        return view('hatch.create', compact('hatch', 'types', 'oss'));
    }

    public function showList(Request $request,$os=0,$type=0,$stage=3)
    {
        //$params = $request->all();
        $data['classes'] = array();
        //12是项目扶持，这里取游戏平台和游戏类型两个二级分类的所有子类
        $pclasses = Classify::where('parent',12)->where('class_name','like','游戏%')->get();
        foreach($pclasses as $class){
            $data['classes'][$class->class_id] = Classify::where('parent',$class->class_id)->get();
            $data['classes'][$class->class_id]['name'] = $class->class_name;
        }
        $projectlist = Game::query()->where('status',0);

        if(!empty($os) && is_numeric($os)){
            $projectlist->where('os',$os);
        }
        if(!empty($type) && is_numeric($type)){
            $projectlist->where('game_type',$type);
        }
        if(is_numeric($stage) && $stage != 3){
            $projectlist->where('flow',$stage);
        }
        $projectlist->orderBy('created_at', 'desc');
        $data['projectlist'] = $projectlist->paginate(20);
        return view('hatch.list',$data);
    }

}


