<?php

namespace App\Http\Controllers\Lore;

use App\Http\Controllers\Controller;
use App\Repositories\LiveOrderRepositoryEloquent;
use App\Repositories\LoreLearnRepositoryEloquent;
use App\Repositories\LorePayRepositoryEloquent;
use App\Repositories\LoreRepositoryEloquent;
use App\Repositories\LoreSectionRepositoryEloquent;
use Auth;
use Gate;
use Illuminate\Http\Request;
use Exception;
use Endroid\QrCode\QrCode;
use Response;
use Tencent\Ptlogin\Ptlogin;
use View;

class LoreController extends Controller {

	protected $lore;
    protected $section;
    protected $order;
    protected $learn;
	public function __construct(
        LoreRepositoryEloquent $lore,
        LoreSectionRepositoryEloquent $section,
        LiveOrderRepositoryEloquent $order,
        LoreLearnRepositoryEloquent $learn
    )
    {
        $this->lore = $lore;
        $this->section = $section;
        $this->order = $order;
        $this->learn = $learn;
        $this->middleware('auth', ['only' => ['postBuy','getDetail']]);
    }

    public function getIndex(Request $request, $id)
    {
        $lore = $this->lore->getDetail($id);
        $loginType = empty(session('loginType')) ? 0 : session('loginType');
        //未发布需要判断是否有管理员权限
        if ($lore->state == 1) {
            $this->authorize('accessdraft');
        }
        if (View::exists('Lore.index_' . $id)) {
            return view('Lore.index_' . $id, compact('lore', 'loginType'));
        }
        if ($lore->top_banner) {
            $loreAdgs = $lore->advantages();
            $lore->daka_comment_list = array_filter(array_sort($lore->daka_comment_list, function ($value) {
                return $value['id'];
            }), function ($var) {
                return $var['status'] == 0;
            });
            return view('Lore.index_tpl', compact('lore', 'loreAdgs', 'loginType'));
        }
        return view('Lore.index', compact('lore', 'loginType'));
    }

    public function getList(Request $request){
	    $lores = $this->lore->orderBy('id','desc')->findWhere(['state' => 0]);
	    return view('Lore.list', compact('lores'));
    }

    public function getCatalog(Request $request, $id)
    {
        $lore = $this->lore->getDetail($id);
        $loginType = session('loginType');
        //未发布需要判断是否有管理员权限
        if ($lore->state == 1) {
            $this->authorize('accessdraft', $lore);
        }
        $study = $request->session()->get('lore' . $id);
        if (!$study) {
            $lore->increment('study_cnt');
            $request->session()->put('lore' . $id, true);
        }
        if (View::exists('Lore.catalog_' . $id)) {
            return view('Lore.catalog_' . $id, compact('lore', 'loginType'));
        }
        if ($lore->top_banner) {
            return view('Lore.catalog_tpl', compact('lore', 'loginType'));
        }
        return view('Lore.catalog', compact('lore', 'loginType'));
    }

    //小节详情页,登录判断写在构造函数里
    public function getDetail(Request $request, $id)
    {

        $section = $this->section->find($id);
        if ($section) {
            $section->access = $section->allowAccess();
            $isPayed = $section->lore->isPayed();
            if ($section->access) {
                $section->increment('view_cnt');
                $this->learn->record(Auth::user(),$section);
            }
            return view('Lore.detail',compact('section','isPayed'));
        } else {
            abort(404);
        }

    }

    //获取分享二维码
    public function getShare($id)
    {
        $qrCode = new QrCode();
        $response = Response::stream(function () use($qrCode, $id) {
            $url = url('/lore/detail',[$id]);
            $qrCode->setText($url)->setSize(125)->setPadding(10)->setErrorCorrection('high')->render();
        }, 200, ['Content-Type' => 'image/png']);

        return $response;
    }

    public function postBuy(Request $request, $id)
    {
        $isPayed = $this->lore->isPayed($id);
        if ($isPayed) {
            return ['code' => 1, 'msg' => '已购买请勿重复购买'];
        }
        $status = $this->checkAuthStatus($request);
        if ($status === false) {
            return abort(401, '登录状态已失效，请重新登录');
        }
        $lore = $this->lore->find($id);
        $user = $request->user();
        $result = $this->lore->buy($lore, $user, 'pc');
        if ($result['code'] == 1018) {
            return abort(401, '登录状态已失效，请重新登录');
        }
        return response()->json($result);
    }

    private function checkAuthStatus(Request $request)
    {
        $loginType = session('loginType');
        if ($loginType == 'qq') {
            // 判断QQ登录态是否有效
            $uin = intval(str_replace('o', '', $request->cookie('uin')));
            $sKey = $request->cookie('skey');

            return $uin AND $sKey AND Ptlogin::check($uin, $sKey);
        }elseif ($loginType == 'weixin') {
            // 判断微信登录态是否有效
            return session('openId') AND session('accessToken');
        } else {
            return false;
        }
    }

}
?>
