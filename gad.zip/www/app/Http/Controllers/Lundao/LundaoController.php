<?php
namespace App\Http\Controllers\Lundao;

use App\Entities\CourseChat;
use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Repositories\CourseChatRepositoryEloquent;
use App\Repositories\CourseRepositoryEloquent;
use App\Repositories\LessonRepositoryEloquent;
use Illuminate\Http\Request;
use App\Models\KeyValue;
use Auth;
class LundaoController extends Controller
{

    protected $course;
    protected $lesson;
    protected $chat;

    public function __construct(
        CourseRepositoryEloquent $course,
        LessonRepositoryEloquent $lesson,
        CourseChatRepositoryEloquent $chat
    )
    {
        $this->middleware('auth', ['only' => ['postRegister','postDelComment','postAddChat']]);
        $this->course = $course;
        $this->lesson = $lesson;
        $this->chat = $chat;
    }

    //论道列表页
    public function getList(Request $request)
    {
        $courses = Course::with('lesson')->where('is_lundao',1)
            ->where('status',1);
        //分页获取
        $courses = $courses->orderBy('id','desc')->paginate(12);
        for ($i = 0; $i < count($courses); $i++) {
            if ($courses[$i]['state'] == 'new') {
                if ($courses[$i]->lesson['begin_date'] == date('Y-m-d')) {
                    $times = explode(':', $courses[$i]->lesson['begin_time']);
                    $minites = $times[0] * 60 + $times[1];
                    $nowminites = date('H') * 60 + date('i');
                    if ($minites - $nowminites > 60 && $minites - $nowminites < 360) {
                        $courses[$i]['livestate'] = intval(($minites - $nowminites)/60).'小时后开始直播';
                    } elseif ($nowminites < $minites && $minites - $nowminites <=60) {
                        $courses[$i]['livestate'] = ($minites - $nowminites).'分钟后开始直播';
                    } else {
                        $courses[$i]['livestate'] = '报名中';
                    }
                } else {
                    $courses[$i]['livestate'] = '报名中';
                }

            } elseif ($courses[$i]['state'] == 'living') {
                $courses[$i]['livestate'] = '直播中';
            } else {
                $courses[$i]['livestate'] = '回放';
            }
        }
        return view('lundao.newlist',compact('type','courses'));
    }

    public function getDetail(Request $request, $id)
    {
        $course = $this->course->find($id);
        if (!$course->is_lundao) {
            return redirect(url('course', $id));
        }

        $relates = $this->course->getRelatedLundao($course);
        $lesson = $this->lesson->with('videos')->find($course->next_lesson);
        $user = $request->user();
        $isAdmin = 0;
        if ($user) {
            if ($user->cannot('learn', $course) AND $course->state != 'new') {
                $this->course->signup($course, $user);
            }
            if ($user->roles->contains(2)) {
                $isAdmin = 1;
            }

            $this->course->access($lesson, $user);
        }

        return view('lundao.detail', compact('course', 'relates', 'lesson','isAdmin'));
    }

    public function postSignup(Request $request, $id)
    {
        $course = $this->course->find($id);
        $result = $this->course->signup($course, $request->user());

        return response()->json($result);
    }

    public function postAddChat(Request $request)
    {
        $content = $request->input('content');
        $lessonId= $request->input('lessonid');
        $lesson = $this->lesson->find($lessonId);

        if ($lesson and $content != '') {
            $user = Auth::user();
            $chat = $this->chat->create([
                'course_id' => $lesson->course_id,
                'lesson_id' => $lessonId,
                'user_id' => $user->UserId,
                'nickname' => $user->NickName,
                'content' => $content,
                'source' => 'discuss',
                'is_show' => 1
            ]);
            if ($chat) {
                $chat->user = Auth::user();
                return response()->json([
                    'code'=> 0,
                    'chat'=>$chat
                ]);
            } else {
                return response()->json([
                    'code'=> -1,
                    'msg' => '服务器异常'
                ]);
            }
        } else {
            return response()->json([
                'code'=> -1,
                'msg' => '评论对象不存在'
            ]);
        }

    }

    public function postDelChat($id)
    {
        $user = Auth::user();
        //管理员有权限删除
        if ($user->roles->contains(2)) {
            if ($this->chat->delete($id)) {
                return response()->json([
                    'code' => 0,
                    'msg' => '成功'
                ]);
            } else {
                return response()->json([
                    'code' => -1,
                    'msg' => '服务异常'
                ]);
            }
        } else {
            return response()->json([
                'code' => -1,
                'msg' => '无权限'
            ]);
        }
    }


    public function getChats(Request $request, $id)
    {
        $page = $request->input('page',0);
        $pageSize = $request->input('pageSize',10);
        $chatList = CourseChat::with('user')
            ->where('lesson_id',$id)
            ->where('is_show',1)
            ->orderby('created_at','DESC')
            ->paginate($pageSize,['*'],'page')
            ->all();
        return response()->json([
            'code' => 0,
            'chats' => $chatList
        ]);
    }





} 