<?php

namespace App\Http\Controllers\Feature;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Fame;
use App\Entities\GamePai;
use Auth;

class FeatureController extends Controller
{
    //首页
    public function getIndex()
    {
        $courses = Course::with('lesson')->where('is_lundao',1)->where('status',1)->orderBy('updated_at','desc')->take(8)->get();
        for ($i = 0; $i < count($courses); $i++) {
            if ($courses[$i]['state'] == 'new') {
                if ($courses[$i]->lesson['begin_date'] == date('Y-m-d')) {
                    $times = explode(':', $courses[$i]->lesson['begin_time']);
                    $minites = $times[0] * 60 + $times[1];
                    $nowminites = date('H') * 60 + date('i');
                    if ($minites - $nowminites > 60 && $minites - $nowminites < 360) {
                        $courses[$i]['livestate'] = intval(($minites - $nowminites)/60).'小时后开始直播';
                    } elseif ($nowminites < $minites && $minites - $nowminites <=60) {
                        $courses[$i]['livestate'] = ($minites - $nowminites).'分钟后开始直播';
                    } else {
                        $courses[$i]['livestate'] = '报名中';
                    }
                } else {
                    $courses[$i]['livestate'] = '报名中';
                }

            } elseif ($courses[$i]['state'] == 'living') {
                $courses[$i]['livestate'] = '直播中';
            } else {
                $courses[$i]['livestate'] = '回放';
            }
        }
        $famelist = Fame::where('status', 0)->orderBy('phase', 'desc')->take(8)->get();

        $gamepies = GamePai::where('status', 0)->orderBy('id', 'desc')->take(8)->get();
        return view('feature.index',compact('courses', 'famelist', 'gamepies'));
    }
}
