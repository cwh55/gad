<?php

namespace App\Http\Controllers\Hatch;

use App\Http\Controllers\Controller;
use App\Repositories\ExpertPlanRepository;
use Illuminate\Http\Request;
use App\Repositories\HatchProjectRepository;
use App\Repositories\ExpertCommentRepository;
use Auth;
use Redis;
use App\Repositories\CommentRepository;
use Cache;
use DB;

class ProjectController extends Controller
{
    public function __construct(){
        $this->middleware('auth', ['only'=>['getMyList', 'postSave', 'postDelete']]);
    }

    public function getIndex(ExpertPlanRepository $expertPlanEloquen) {
        
    }

    public function getMyList(HatchProjectRepository $projectRepository, Request $request)
    {
        if ($request->ajax()) {
            $pageSize = 20;
            $page = $request->input('page') * 1;
            $projects = $projectRepository->getMyList([['user_id', '=', Auth::User()->UserId]], $page, $pageSize, true);
            return response()->json(['code' => 0, 'data' => $projects]);
        } else {
            return view('hatch.project.my_list');
        }
    }
    
    public function getBlogs(HatchProjectRepository $projectRepository, Request $request){
        $id = $request->input('id') * 1;
        $project = $projectRepository->find($id);
        if(!empty($project)){
            $list = $projectRepository->getBlogs($project, $request->input('type'), $request->input('page') * 1, 20);
            return response()->json($list);
        }else{
            return response()->json([]);
        }
    }
    
    public function getBlogCount(HatchProjectRepository $projectRepository, Request $request, $id){
        $project = $projectRepository->find($id);
        if(!empty($project)){
            $list = $projectRepository->getBlogCount($project);
            return response()->json($list);
        }else{
            return response()->json([]);
        }
    }
    
    public function getNews(HatchProjectRepository $projectRepository, Request $request){
        $project = $projectRepository->find($request->input('id'));
        if(!empty($project)){
            $list = $projectRepository->getNews($project, $request->input('type'));
            return response()->json($list);
        }else{
            return response()->json([]);
        }
    }
    
    public function getNewsCount(HatchProjectRepository $projectRepository, Request $request, $id){
        $project = $projectRepository->find($id);
        if(!empty($project)){
            $list = $projectRepository->getNewsCount($project);
            return response()->json($list);
        }else{
            return response()->json([]);
        }
    }
    
    public function getDetail(HatchProjectRepository $projectRepository, CommentRepository $commentRepository, ExpertPlanRepository $expertPlan, ExpertCommentRepository $expertComment, $id = 0, $exper = '')
    {
        $project = $projectRepository->find($id);

        if (empty($project)) {
            return abort(404);
        }

        $project->public = 1;
        if ($project->is_public == 0 && (!Auth::check() || (Auth::check() && Auth::user()->UserId != $project->user_id && !Auth::user()->roles->contains(2)))) {
            $project->public = 0;
        }

        $other = $projectRepository->where('user_id', $project->user_id)
            ->whereNotIn('name', [$project->name])
            ->where('is_public', 1)
            ->orderBy('id', 'desc')->limit(10)->findAll()->unique('name');

        $project->demo = empty($project->demo) ? ['name' => '', 'url' => ''] : $project->demo[0];
        $pictures = [];
        if ($project['pictures']) {
            foreach ($project['pictures'] as $val) {
                $pictures[] = ['type' => 'img', 'img_url' => $val['url'], 'url' => ''];
            }
        }
        if ($project['videos']) {
            foreach ($project['videos'] as $val) {
                $pictures[] = ['type' => 'video', 'url' => $val['url'],
                    'img_url' => isset($val['uuid']) ? 'http://p.qpic.cn/wecam_pic/0/' . $val['uuid'] . '_1/0' : 'http://p.qpic.cn/wecam_pic/0/0'];
            }
        }
        $user = Auth::user();
        $expert = $exper == 'expert' ? $user : null;
        if ($user && $user->UserId != $project->user_id) {//当前专家
            $expertAll = $expertPlan->findWhere(['user_id', '=', $user->UserId]);
            if (count($expertAll) >= 1) {
                $expert = $expertAll[0];
                $project->public = 1;
            }
        }

        if($project->is_public_demo == 0) {
            if ($expert || (Auth::user() && Auth::user()->roles->contains(2))) {
                $project->is_public_demo = 1;
            }
        }

        $userComment = null;
        $expertComments = [];
        if ($expert) {//专家
            $userComment = $expertComment->where('project_id', $id)->where('user_id', $expert->UserId)->where('status', 0)->findAll()->first();
            if ($userComment) {
                $expertComments = $expertComment->with(['user'])->where('project_id', $id)->where('user_id', '<>', $expert->UserId)
                    ->where('status', 0)->orderBy('id','desc')->paginate(10);
            } else {
                $expertComments = $expertComment->with(['user'])->where('project_id', $id)->where('status', 0)
                    ->orderBy('rank','desc')->paginate(10);
            }
        } else {
            $expertComments = $expertComment->with(['user'])->where('project_id', $id)->where('status', 0)
                ->orderBy('rank','desc')->paginate(10);
        }

        $comments = $commentRepository->getList(['orderBy' => 'create', 'objId' => $project->id, 'objType' => 'App\\Entities\\Project', 'page' => 0, 'pageSize' => 20], ['status' => 1])['comments'];
        $project = array_except($project, ["team_type","team_business_license","team_name","team_logo","team_province","team_city","team_intro","team_contacts","team_id_card","team_phone","team_email","team_weixin"]);
        return view('hatch.project.detail_intro', compact('project', 'other', 'pictures', 'comments', 'expertComments', 'userComment', 'expert'));
    }

    public function getDetailExpert(HatchProjectRepository $projectRepository, ExpertPlanRepository $expertPlan, ExpertCommentRepository $expertComment, $id)
    {
        $project = $projectRepository->find($id);

        if (empty($project)) {
            return response()->json(['code' => -1, 'data' => '', 'message' => 'Not Fount']);
        }

        $project->public = 1;
        if ($project->push_email_status != 1 && (!Auth::check() || (Auth::check() && Auth::user()->UserId != $project->user_id))) {
            //return abort(404);
        }

        //其他项目
        //$other = $projectRepository->where('user_id', $project->user->UserId)->whereNotIn('id', [$id])->where('is_public', 1)->orderBy('id', 'desc')->limit(10)->findAll();

        $user = Auth::user();
        $expert = null;
        //if ($user && $user->UserId != $project->user_id) {//当前专家
            //$expertAll = $expertPlan->findWhere(['user_id', '=', $user->UserId]);
            //if (count($expertAll) > 1) {
            //    $expert = $user;
            //}
        //}

        $comments = $expertComment->with(['user'])->where('project_id', $id)->where('status', 0)
            ->orderBy('id','desc')->paginate(1);

        return response()->json(['code'=>0,'data' => $comments]);
    }

    public function postApplyExpertComment(HatchProjectRepository $projectRepository, $id)
    {
        $project = $projectRepository->find($id);

        if (empty($project)) {
            return abort(404);
        }

        $project->user = \App\Entities\User::find($project->user_id);

        if ($project->push_email_status != 1 && (!Auth::check() || (Auth::check() && Auth::user()->UserId != $project->user_id))) {
            return abort(404);
        }

        $data = ['push_email_status' => 2];
        $res = $projectRepository->update($project->id, $data);
        if ($res[0]) {
            return response()->json(['code' => 0, 'data' => $res[1]]);
        }

        return response()->json(['code' => -1, 'message' => '']);
    }

    public function getExpertCommentList(Request $request, ExpertPlanRepository $expertPlan, ExpertCommentRepository $expertComment, $id)
    {
        $user = Auth::user();
        $expert = $user;
        if ($user) {//当前专家
            $expertAll = $expertPlan->findWhere(['user_id', '=', $user->UserId]);
            if (count($expertAll) >= 1) {
                $expert = $expertAll[0];
            }
        }

        $userComment = null;
        $comments = [];
        if ($expert) {//专家
            $userComment = $expertComment->where('project_id', $id)->where('user_id', $expert->UserId)->where('status', 0)->findAll()->first();
            if ($userComment) {
                $comments = $expertComment->with(['user'])->where('project_id', $id)->where('user_id', '<>', $expert->UserId)
                    ->where('status', 0)->orderBy('id', 'desc')->paginate(10);
            } else {
                $comments = $expertComment->with(['user'])->where('project_id', $id)->where('status', 0)
                    ->orderBy('rank', 'desc')->paginate(10);
            }
        } else {
            $comments = $expertComment->with(['user'])->where('project_id', $id)->where('status', 0)
                ->orderBy('rank', 'desc')->paginate(10);
        }
        return response()->json(['code' => 0, 'data' => $comments]);
    }

    public function getExpertProjectList(Request $request, ExpertPlanRepository $expertPlan, $week = 0, $expert_count = 1)
    {
        $user = Auth::user();
        $expert = $user;
        if ($user) {//当前专家
            $expertAll = $expertPlan->findWhere(['user_id', '=', $user->UserId]);
            if (count($expertAll) >= 1) {
                $expert = $expertAll[0];
            }
        }
        $tab = 1;
        $projects = null;
        $hasPermit = 1;
        if ($expert) {//专家
            $query = DB::table('gad_projects')
                ->whereNull('gad_projects.deleted_at')
                ->whereIn('gad_projects.push_email_status', [0,2]);
            if ($week) {
                $tab = 2;
                $query = $query->where('gad_projects.created_at', '>=', date('Y-m-d', strtotime('last week')));
            }

            if ($expert_count == 0) {
                $tab = 3;
                $query = $query->where('expert_comment_count', '=', 0);
            }

            if($request->has('key')){
                $key = XSSFilter(addslashes($request->input('key')));
                if($key){
                    $query->where('name', 'like', '%' . $key . '%');
                }
            }

            $projects = $query->select('gad_projects.*')
                ->orderBy('gad_projects.rank', 'desc')
                ->paginate(10);
        } else {
            $projects = null;
            $hasPermit = 0;
        }

        return view('hatch.project.expert_project_list', ['projects' => $projects, 'hasPermit' => $hasPermit, 'tab' => $tab]);
    }

    public function getHatchProjectList($hatch = 0)
    {
        $hatchen = $hatching = [];
        $query = \App\Entities\HatchProject::with('oldgame');

        if ($hatch == 0) {
            $hatchen = $query->where('gad_projects.hatch_status', '=', 2)
                ->orderBy('gad_projects.rank', 'desc')
                ->paginate(3);
            $hatching = \App\Entities\HatchProject::with('oldgame')->where('gad_projects.hatch_status', '=', 1)
                ->orderBy('gad_projects.rank', 'desc')
                ->paginate(6);
        }

        if($hatch == 2)
            $hatchen = $query->where('gad_projects.hatch_status', '=', 2)
                ->orderBy('gad_projects.rank', 'desc')
                ->paginate(12);

        if($hatch == 1)
            $hatching = $query->where('gad_projects.hatch_status', '=', 1)
                ->orderBy('gad_projects.rank', 'desc')
                ->paginate(12);

        return view('hatch.project.project_list',['hatch' => $hatch, 'hatchen' => $hatchen, 'hatching' => $hatching]);
    }

    public function postSaveExpertComment(Request $request, HatchProjectRepository $projectRepository, ExpertPlanRepository $expertPlan, ExpertCommentRepository $expertComment, $id)
    {

        $project = $projectRepository->find($id);//项目不存在
        if (empty($project)) {
            return response()->json(['code' => -1, 'message' => '非法请求']);
        }

        $all = $request->all();
        $all = array_map('xssFilter', $all);

        $this->validate($request, ['comment' => 'required', 'score' => 'required|integer|max:50']);

        $user = Auth::user();
        $expert = $user;
        if ($user && $user->UserId != $project->user_id) {//当前专家
            $expertAll = $expertPlan->findWhere(['user_id', '=', $user->UserId]);
            if (count($expertAll) >= 1) {
                $expert = $user;
            }
        }

        if (!$expert) {
            return response()->json(['code' => -1, 'message' => '你不是专家']);
        }

        $comment = $expertComment->where('project_id', $id)->where('user_id', $expert->UserId)->findAll();
        if (count($comment) > 0) {
            $comment = $comment[0];
        } else {
            $comment = null;
        }

        if ($comment == null) {
            $data = ['user_id' => $user->UserId, 'project_id' => $id, 'comment' => $all['comment'], 'status' => 0, 'score' => $all['score'],'rank' => time()];
            $res = $expertComment->create($data);
            if ($res[0]) {
                $project->increment('expert_comment_count');
                return response()->json(['code' => 0, 'message' => '', 'data' => $res[1]]);
            }
        } else {
            $data = ['comment' => $all['comment'], 'status' => 0, 'created_at' => date('Y-m-d H:i:s'), 'score' => $all['score']];
            $res = $expertComment->update($comment->id, $data);
            if ($res[0]) {
                if($comment->status == -1){
                    $project->increment('expert_comment_count');
                }
                return response()->json(['code' => 0, 'message' => '', 'data' => $res[1]]);
            }
        }

        return response()->json(['code' => -1, 'data' => '', 'message' => '更新出错']);
    }

    public function getDowdown(ExpertPlanRepository $expertPlanRepository)
    {
        return;
        $handle = file_get_contents(dirname(__FILE__) . '/../../../../public/expe.csv');
        $array = explode("\r\n", $handle);
        foreach ($array as $val) {
            var_dump($val);
            $valArr = explode(',',$val);
            $id = $valArr[0];
            var_dump($id);
            $expert = $expertPlanRepository->find($id);
            if ($expert) {
                $res = $expertPlanRepository->update($id, ['email' => $valArr[10], 'user_id' => $valArr[11]]);
                if ($res[0]) {
                    var_dump($id . ' update ' . ' email ' . $valArr[10]);
                }
                var_dump($id . 'enter');
            }
            var_dump($id);
        }
    }

    public function postDelExpertComment(Request $request, HatchProjectRepository $projectRepository, ExpertPlanRepository $expertPlan, ExpertCommentRepository $expertComment, $id)
    {

        $project = $projectRepository->find($id);//项目不存在
        if (empty($project)) {
            return response()->json(['code' => -1, 'message' => '非法请求']);
        }

        $user = Auth::user();
        $expert = $user;
        if ($user && $user->UserId != $project->user_id) {//当前专家
            $expertAll = $expertPlan->findWhere(['user_id', '=', $user->UserId]);
            if (count($expertAll) >= 1) {
                $expert = $user;
            }
        }

        if (!$expert) {
            return response()->json(['code' => -1, 'message' => '你不是专家']);
        }

        $comment = $expertComment->where('project_id', $id)->where('user_id', $expert->UserId)->findAll();
        if (count($comment) > 0) {
            $comment = $comment[0];
        } else {
            $comment = null;
        }

        if ($comment) {
            $data = ['status' => -1];
            $res = $expertComment->update($comment->id, $data);
            if ($res[0]) {
                if($project->expert_comment_count > 0) {
                    $project->decrement('expert_comment_count');
                }
                return response()->json(['code' => 0, 'message' => '', 'data' => $res[1]]);
            }
        }

        return response()->json(['code' => -1, 'data' => '', 'message' => '更新出错']);
    }

    public function postSave(HatchProjectRepository $projectRepository, Request $request){
        $this->validate($request,[
            'name' => 'required',
            'created_from' => 'required',
            'is_public' => 'required',
            'logo' => 'required',
            'type' => 'required',
            'team_num' => 'required',
            'pictures' => 'required',
            'intro' => 'required',
            'platform' => 'required'
        ]);
        $inputAll = $request->all();
        $inputAll = array_map('xssFilter', $inputAll);
        $id = isset($inputAll['id']) ? $inputAll['id'] : 0;
        $SMSCode = isset($inputAll['SMSCode']) ? $inputAll['SMSCode'] : '';
        $allowKeys = ["created_from","is_public","name","logo","type","progress","team_num","pictures","intro","platform","demo","videos","ppt","team_type","team_business_license","team_name","team_logo","team_province","team_city","team_intro","team_contacts","team_id_card","team_phone","team_email","team_weixin","is_public_demo"];
        $arrayKeys = ['type', 'pictures', 'platform', 'demo', 'videos', 'ppt'];
        $input = array();
        foreach($inputAll as $k=>$v){
            if(!in_array($k, $allowKeys)){
                continue;
            }
            $input[$k] = in_array($k, $arrayKeys) && !is_array($v) ? [] : $v;
        }
        if($id > 0){
            $project = $projectRepository->find($id);
            if(!\App\Models\User::judgeEditRight(Auth::user(), $project['user_id'])){
                throw new \Exception('你没有权限修改这个项目');
            }
            if(isset($input['team_phone']) && $input['team_phone'] != $project->team_phone && !$this->validUserSmsCode($SMSCode, $input['team_phone'])){
                throw new \Exception('验证码错误');
            }
            list($status, $temp) = $projectRepository->update($id, $input);
            if(!$status){
                throw new \Exception('更新数据失败');
            }
        }else{
            if(isset($input['team_phone']) && !$this->validUserSmsCode($SMSCode, $input['team_phone'])){
                $this->validUserSmsCode($SMSCode, $input['team_phone']);
            }
            $input['user_id'] = Auth::User()->UserId;
            $input['rank'] = time();
            list($status, $insertInfo) = $projectRepository->create($input);
            if(!$status){
                throw new \Exception('更新数据失败');
            }
            $id = $insertInfo->id;;
        }
        return response()->json(array('code' => 0, 'data' => $id));
    }
    
    public function postDelete(HatchProjectRepository $projectRepository, Request $request){
        $id = $request->input('id');
        if($id > 0){
            $project = $projectRepository->find($id);
            if(!\App\Models\User::judgeEditRight(Auth::user(), $project['user_id'])){
                throw new \Exception('你没有权限修改这个项目');
            }
            $projectRepository->deleteProject($id);
            return response()->json(array('code' => 0));
        }else{
            return response()->json(array('code' => 1, 'msg'=>'数据不存在'));
        }
    }
    
    // 验证短信验证码
    private function validUserSmsCode($code,$phone){
        $isValid = false;
        $user = Auth::user();
        if ($user) {
            $userKey = 'Register_User_SmsCode_'.$user->UserId.'_'.$phone;
            $userCode = Redis::get($userKey);
            if ($code == $userCode) {
                $isValid = true;
            }
        }
        return $isValid;
    }
    
    private function syncTeam($projectRepository, $teamProjects){
        //同步组队数据
        $teamProjectReposotory = app(\App\Repositories\ProjectRepository::class);
        $teams = $teamProjectReposotory->findAll();
        $teamInsertCount = $teamUpdateCount = 0;
        foreach($teams as $g){
            $data = ['created_from'=>4, 'created_from_id'=>$g->id, 'team_type'=>'个人', 'logo'=>!empty($g->cover) && is_array($g->cover) ? $g->cover[0]['url']: '',
                'name'=>$g->game_name, 'type'=>[$g->game_type], 'progress'=>$g->game_state, 'team_num'=>$g->member_count,
                'pictures'=>is_array($g->cover) ? $g->cover : [],
                'intro'=>$g->intro, 'videos'=>is_array($g->videos) ? $g->videos : [], "demo"=>is_array($g->demo) ? $g->demo : [],
                'music'=>is_array($g->music) ? $g->music : [], 'user_id'=>$g->user_id];
            try{
                if(isset($teamProjects[$g->id])){
                    $teamUpdateCount++;
                    list($status, $project) = $projectRepository->update($teamProjects[$g->id]->id, $data);
                }else{
                    $teamInsertCount++;
                    list($status, $project) = $projectRepository->create($data);
                }
                $g->update(array('project_id'=>$project->id));
            } catch (\Exception $ex) {
                echo "TEAM PROJECT ID: {$g->id}导入失败：".$ex->getMessage()."<br>";
            }
        }
        echo "组队：新增{$teamInsertCount}条数据，更新{$teamUpdateCount}条数据<br>";
    }
    
    private function syncGame($projectRepository, $gameProjects){
        $gameKeys = [
            "user_id"=>['register', 'user_id'],
            "name"=>'name',"team_num"=>['register', 'member_count'],
            "team_business_license"=>['register','business_license'],"team_name"=>['register','company'],
            "team_logo"=>['register','business_license'],"team_province"=>['register','province'],"team_city"=>['register','city'],"team_intro"=>['register','info'],
            "team_id_card"=>['register','id_card'],"team_phone"=>['register','mobile'],"team_email"=>['register','email'],"team_weixin"=>['register','weixin']];
        $game = \App\Models\Game::query();
        $games = $game->with(['register','gameType'])->where('id', '>', 0)->where('status', 0)->get();
        $gameInsertCount = $gameUpdateCount = 0;
        foreach($games as $g){
            if(!is_object($g->register)){
                continue;
            }
            $data = ['created_from'=>1, 'created_from_id'=>$g->id,  'team_type'=>$g->register->type == 0 ? '个人' : '公司', 'logo'=>is_array($g->logo) ? $g->logo[0]['url']: '',
                'pictures'=>is_array($g->pictures) ? $g->pictures : [], 'platform'=>is_array($g->game_oses) ? $g->game_oses : [],
                "demo"=>is_array($g->demo) ? $g->demo : [],"videos"=>is_array($g->videos) ? $g->videos : [],"ppt"=>is_array($g->ppt) ? $g->ppt : [],
                'type'=>$g->gameType && $g->gameType->class_name ? [$g->gameType->class_name] : [],
                "team_contacts"=>$g->register->user_name ? $g->register->user_name : '', "intro"=>$g->description ? $g->description : ''];
            foreach($gameKeys as $k=>$v){
                $data[$k] = is_array($v) ? $g->$v[0]->$v[1] : $g->$v;
            }
            $data['team_phone'] = $data['team_phone'] ? $data['team_phone'] : '';
            $data['team_email'] = $data['team_email'] ? $data['team_email'] : '';
            $data['team_weixin'] = $data['team_weixin'] ? $data['team_weixin'] : '';
            try{
                if(isset($gameProjects[$g->id])){
                    $gameUpdateCount++;
                    list($status, $project) = $projectRepository->update($gameProjects[$g->id]->id, $data);
                }else{
                    $gameInsertCount++;
                    list($status, $project) = $projectRepository->create($data);
                }
                $g->update(array('project_id'=>$project->id));
            } catch (\Exception $ex) {
                echo "GAME ID: {$g->id}导入失败：".$ex->getMessage()."<br>";
            }
        }
        echo "项目扶持：新增{$gameInsertCount}条数据，更新{$gameUpdateCount}条数据<br>";
    }
    
    private function syncCompetetion($projectRepository, $comptProjects){
        $comps = \DB::table('Works')->select(DB::raw('`Title`,`ConverImg`,`PPT`,`Video`,`Demo`,`Game`,`Intro`,GameType,WorksId'))->whereIn('WorksId', array_keys($comptProjects))->get();
        $compInsertCount = $tcompUpdateCount = 0;
        foreach($comps as $g){
            $g->Video = json_decode($g->Video, true);
            $g->Demo = json_decode($g->Demo, true);
            $g->Game = json_decode($g->Game, true);
            $g->PPT = json_decode($g->PPT, true);
            $data = ['created_from'=>5, 'created_from_id'=>$g->WorksId, 'team_type'=>'个人', 'logo'=>$g->ConverImg ? $g->ConverImg: '',
                'name'=>$g->Title, 'type'=>$g->GameType ? [$g->GameType] : [], 'ppt'=>is_array($g->PPT) ? $g->PPT : [],
                'intro'=>$g->Intro ? strip_tags($g->Intro) : '', 'videos'=>is_array($g->Video) ? $g->Video : [], "demo"=>is_array($g->Demo) ? $g->Demo : (is_array($g->Game) ? $g->Game : [])];
            foreach($data['videos'] as &$v){
                preg_match('/uuid=(\w+)/', $v['url'], $match);
                if(!preg_match('/^http/i', $v['url']) && $match && $match[1]){
                    $v['url'] = 'http://file.gad.qq.com/attachment/video?video_id='.$match[1];
                }
            }
            foreach($data['demo'] as &$v){
                if(!preg_match('/^http/i', $v['url'])){
                    $v['url'] = 'http://gad.qq.com/'.$v['url'];
                }
            }
            try{
                if(isset($comptProjects[$g->WorksId])){
                    $compInsertCount++;
                    list($status, $project) = $projectRepository->update($comptProjects[$g->WorksId]->id, $data);
                }
            } catch (\Exception $ex) {
                echo "Works PROJECT ID: {$g->WorksId}导入失败：".$ex->getMessage()."<br>";
            }
        }
        echo "大赛：更新{$compInsertCount}条数据<br>";
    }
    
    public function getSyncData(HatchProjectRepository $projectRepository){
        if($_SERVER['SERVER_ADDR'] == '10.222.144.25' || app()->isLocal()){
            $projects = $projectRepository->whereIn('created_from', [1,2,3,4,5])->where('created_from_id', '>', 0)->findAll();
            $gameProjects = $teamProjects = $comptProjects = array();
            foreach($projects as $p){
                if($p->created_from == 1){
                    $gameProjects[$p->created_from_id] = $p;
                }else if($p->created_from == 4){
                    $teamProjects[$p->created_from_id] = $p;
                }else if($p->created_from == 5){
                    $comptProjects[$p->created_from_id] = $p;
                }
            }
            $this->syncGame($projectRepository, $gameProjects);
            $this->syncTeam($projectRepository, $teamProjects);
            $this->syncCompetetion($projectRepository, $comptProjects);
        }
    }
}
