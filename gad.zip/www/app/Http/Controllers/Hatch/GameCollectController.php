<?php

namespace App\Http\Controllers\Hatch;
use App\Gad\Lib_Func;
use App\Gad\MessageType;
use App\Gad\TofService;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\HatchProjectRepository;
use App\Repositories\HatchGameRepository;
use App\Models\Register;
use App\Models\Classify;
use App\Models\Game;
use App\Models\KeyValue;
use Illuminate\Http\Request;
use App\Gad\Upload;
use App\Gad\Func;
use Auth;
use Gate;
use Mockery\CountValidator\Exception;
use Redis;

class GameCollectController extends Controller
{
    protected $project;
    protected $game;

    public function __construct(HatchProjectRepository $project,HatchGameRepository $game){
        $this->project = $project;
        $this->game = $game;
        $this->middleware("auth", ['only' => ['getCreate','getEdit','postSave', 'postVote']]);
    }

    //首页
    public function getIndex($id = 2) {
        $user = Auth::user();

        $data['user'] = $user;//是否登录
        $data['proj'] = $this->game->with(['project'])->where('game_id',$id)->where('status',0)->orderBy('id','desc')
            ->findAll();
        $data['project'] = null;
        if($user){//判断是否参与
            $game = $this->game->with(['project'])->where('user_id',$user->UserId)->where('game_id',$id)
                ->findAll()->first();
            if($game && $game->step >= 4) {//判断是否提交完成
                $data['project'] = $game->project;
            }
        }
        $data['id'] = $id;
        $data['end'] = date('Y-m-d') > '2018-02-28';

        return view('hatch.game_collect.index',$data);
    }

    public function getEdit($id = 2) {
        $user = Auth::user();
        $project = $this->game->with(['project'])->where('user_id',$user->UserId)->where('game_id',$id)
            ->findAll()->first();
        if(!$project) {
            $project = ['project' => '','step' => 1];
        } else {
            $project->project->step = $project->step;
            $project->project->status = $project->status;
        }
        return view('hatch.game.create', compact('project','id'));
    }
    
    public function getTest(Request $request){
        $this->validate($request,[
            'game.reg_step' => 'required|integer|max:3|min:1',
        ]);
    }

    
    private function hatchValidate($request){
        $data = $request->all();
        $message = ['required' => ':attribute不能为空'];
        $this->validate($request,[
            'game.reg_step' => 'required|integer|max:5|min:1'
        ], $message);
        if($data['game']['reg_step'] == 1) {
            $this->validate($request, [
                'game.title' => 'required',
                'game.name' => 'required',
                'game.type' => 'required',
                'game.progress' => 'required',
                'game.pictures' => 'required|array',
                'game.logo' => 'required',
                'game.intro' => 'required'
            ], $message);
        }
        if($data['game']['reg_step'] == 2){
            $this->validate($request,[
                'game.mobile' => 'required|integer',
                'SMSCode' => 'required',
                'game.email' => 'required|email',
                //'game.demo' => 'required|array',
                //'game.videos' => 'required|array',
                //'game.hatch_service' => 'required|array',
                //'game.pictures' => 'array',
                //'game.other_attachment' => 'array'
            ], $message);
            if (!$this->validUserSmsCode($data['SMSCode'], $data['game']['mobile'])) {
                throw new \Exception('验证码不正确');
            }
        }
        if($data['game']['reg_step'] == 3){
            $this->validate($request,[
                'game.videos' => 'required|array',
                'game.demo' => 'required|array',
                //'register.email' => 'required',
                //'register.weixin' => 'required'
            ], $message);
        }
    }
    
    public function postSave(Request $request, $id = 0) {
        $this->hatchValidate($request);
        if($id < 1) {
            throw new \Exception('大赛Id错误');
        }
        $data = array_map('XssFilter', $request->all());
        $step = $data['game']['reg_step'];
        $user = Auth::user();
        $game = $this->game->with(['project'])->where('user_id',$user->UserId)
            ->where('game_id',$id)->findAll()->first();
        $project = $game ? $game->project : [];
        if(empty($project)) {
            if($step == 1 && $id > 0) {
                $project_data['title'] = $data['game']['title'];
                $project_data['team_name'] = $data['game']['title'];
                $project_data['name'] = $data['game']['name'];
                $project_data['type'] = is_array($data['game']['type']) ? $data['game']['type'] : [$data['game']['type']];
                $project_data['pictures'] = $data['game']['pictures'];
                $project_data['intro'] = $data['game']['intro'];
                $project_data['logo'] = $data['game']['logo'];
                $project_data['user_id'] = $user->UserId;
                $project_data['progress'] = $data['game']['progress'];
                $project_data['created_from'] = 3;
                $project_data['is_public'] = 1;
                $project_data['rank'] = time();
                list($res, $project) = $this->project->create($project_data);
                if ($res) {
                    $register_data['user_id'] = $user->UserId;
                    $register_data['project_id'] = $project->id;
                    $register_data['status'] = 1;
                    $register_data['game_id'] = $id;
                    $register_data['step'] = 1;
                    $this->game->create($register_data);
                }
            } else {
                throw new \Exception('Step 参数错误');
            }
        } else {
            if ($game->step >= 4) {
                return response()->json(['code' => 1, 'message' => '不能修改']);
            }
            $res = [false];
            if ($step == 1) {
                $project_data['title'] = $data['game']['title'];
                $project_data['team_name'] = $data['game']['title'];
                $project_data['name'] = $data['game']['name'];
                $project_data['type'] = is_array($data['game']['type']) ? $data['game']['type'] : [$data['game']['type']];
                $project_data['pictures'] = $data['game']['pictures'];
                $project_data['intro'] = $data['game']['intro'];
                $project_data['logo'] = $data['game']['logo'];
                $project_data['progress'] = $data['game']['progress'];
                $res = $this->project->update($project->id, $project_data);
            } else if ($step == 2) {
                $register_data['team_phone'] = $data['game']['mobile'];
                $register_data['team_email'] = $data['game']['email'];
                $res = $this->project->update($project->id, $register_data);
            } else if ($step == 3) {
                $project_data['demo'] = $data['game']['demo'];
                $project_data['videos'] = $data['game']['videos'];
                $res = $this->project->update($project->id, $project_data);
            }
            if ($res[0] == false) {
                return response()->json(['code' => -1, 'message' => '更新数据出错']);
            }
            $register_data['step'] = $step + 1;
            $this->game->update($game->id, $register_data);
        }

        if($step == 3){
            //发送站内信
            $this->dispatch(new \App\Jobs\SendMessage(MessageType::PROJECT_APPLY_SUCCESS, $user->UserId, 0,
                $project->id,
                url('/game_project/detail', $project->id), $project->name));
            //填写完毕后邮件通知
            $user = $user->NickName;
            $game = $project->name;
            $title = '[GAD游戏创新大赛]感谢你报名参加第三届腾讯GAD游戏创新大赛！';
            $mail = view('hatch.project.mail_create', compact('user', 'game', 'title'))->render();
            \Tof::service('message')->sendEmail('gad@tencent.com', $project->team_email, $title, $mail);
        }
        return response()->json(array('code' => 0, 'data' => []));
    }

    public function getDetail($id)
    {
        $project = $this->project->find($id);

        if(empty($project)) {
            return abort(404);
        }

        $user = \App\Entities\User::find($project->user_id);

        $project->public = 1;
        if($project->is_public == 0 && (!Auth::check() || (Auth::check() && Auth::user()->UserId != $project->user_id && !Auth::user()->roles->contains(2) ))) {
            $project->public = 0;
        }

        $other = $this->project->where('user_id',$user->UserId)->whereNotIn('id',[$id])->where('is_public',1)->orderBy('id','desc')->limit(10)->findAll();

        $demotemp = $project->demo;
        $demo = empty($demotemp) ? (object)array() : (object)$demotemp[0];
        $demo->name = isset($demo->name) ? $demo->name : '';
        $demo->state = isset($demo->state) ? $demo->state : '';
        $demo->progress = isset($demo->progress) ? $demo->name : 0;
        $demo->url = isset($demo->url) ? $demo->url : 0;
        $demo->size = isset($demo->size) ? $demo->size : 0;
        $project->demo = $demo;
        $pictures = [];
        if($project['pictures']) {
            foreach ($project['pictures'] as $val) {
                $pictures[] = ['type' => 'img', 'img_url' => $val['url'],'url' => ''];
            }
        }
        if($project['videos']) {
            foreach ($project['videos'] as $val) {
                $pictures[] = ['type' => 'video', 'url' => $val['url'],
                    'img_url' => isset($val['uuid']) ? 'http://p.qpic.cn/wecam_pic/0/' . $val['uuid'] . '_1/0' : 'http://p.qpic.cn/wecam_pic/0/0'];
            }
        }

        $project['ppts'] = $project['ppt'];

        return view('hatch.project.detail_intro', compact('project', 'user', 'other', 'pictures'));
    }

    public function getCaptchaUrl(){
        return response()->json(['code' => 0, 'data' => \Captcha::src()]);
    }

    public function postUploadAttachment(Request $request)
    {
        $file = $request->file('file');

        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }
        $size = round($file->getSize()/1024/1024,2)."M";
        $result = Upload::uploadQcloudCos('hatch', $file);
        if ($result['code'] == 0) {
            $fileExt = strtolower($file->getClientOriginalExtension());
            if (in_array($fileExt,['ppt','pptx','pdf'])) {
                $previewUrl = Upload::getPreviewDoc($result);
                $header = get_headers(str_replace("#page#","1",$previewUrl["url"]), 1);
                $page = intval($header["User-ReturnCode"]);
                if($page <=0){
                    $page = 1;
                }
                $result['data']['access_url'] .= '?newd='.urlencode($previewUrl["url"].";".$page);
            }
            return response()->json(['code' => 0, 'url' => $result['data']['access_url'],'size' =>$size]);
        } else {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }
    }

    //上传视频
    public function postUploadVideo(Request $request)
    {
        $file = $request->file('file');
        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }

        $ret = Upload::file($file);
        if(isset($ret["url"])){
            $url = parse_url($ret['url']);
            if(isset($url['query'])){
                parse_str($url['query']);
            }
            $ret['uuid'] = $uuid;
            $url = parse_url($ret['url']);
            $ret["url"] = "/hatch/showVideo/?fileurl=".Upload::hideFileServer($ret["url"])."%26videotype=30|||".$file->getClientOriginalName();
        }
        return response()->json(['code' => 0, 'uuid' => $ret['uuid'], 'url' => $ret['url']]);
    }

    //查看视频
    public function getShowVideo(Request $request)
    {
        $fileurl = $request->input("fileurl");
        if(empty($fileurl)){
            return response()->json(["code" => -1, "msg" => "地址错误"]);
        }
        $tmp = explode("|||", Upload::showFileServer($fileurl));
        if(null != $request->input('HTTP_IF_MODIFIED_SINCE')){
            header('HTTP/1.0 304 Not Modified');
            return true;
        }
        header("Expires:" . gmdate("D, d M Y H:i:s", strtotime("+1 year")) . " GMT");
        header("Pragma: Pragma");
        header("Cache-Control: max-age=31536000");
        header("Last-Modified:" . gmdate("D, d M Y H:i:s", strtotime("-1 day")) . " GMT");
        if (strpos($tmp[0], "http://file.tig.oa.com/") === 0
            || strpos($tmp[0], "http://file.ieg.local/") === 0
            || strpos($tmp[0], "http://tig.oa.com/") === 0
        ) {
            $ft= substr($tmp[0], strrpos($tmp[0], '.')+1);
            if (!strpos($tmp[0],"mod/VideoAo.php?")&&!in_array(strtolower($ft),self:: $allowTypes)) {
                exit('Invalid file type.');
            }
            Upload::getFile($tmp[0], $tmp[1]);
        }
    }

    public function getList(Request $request, $id = 2) {
        $order = 'id';
        if($request->input('order','new') == 'hot') {
            $order = 'vote_count';
        }
        $project = $this->game->with(['project'])->where('game_id',$id)->where('status',0)->orderBy($order,'desc')
            ->findAll();
        foreach ($project as $p) {
//                $p->voted = \App\Entities\Vote::where('project_id', $p->project_id)->where('user_id', Auth::user()->UserId)
//                    ->where('date', date('Y-m-d'))->count();
            unset($p->project->id,$p->project->created_from,$p->project->created_from_id,
                $p->project->demo,$p->project->team_business_license,$p->project->team_email,
                $p->project->team_id_card,$p->project->team_phone,$p->project->updater,
                $p->project->updated_at,$p->project->user_id,$p->project->videos,
                $p->project->team_type,$p->project->team_weixin,$p->project->team_contacts,
                $p->project->team_city,$p->project->team_intro,$p->project->team_logo,
                $p->project->team_name,$p->project->team_num,$p->project->team_province);
        }
        return response()->json(['code' => 0, 'data' => $project]);
    }

    public function postSmsCode(Request $request) {
        $user = Auth::user();
        if (!$user || !$user->UserId) {
            return response()->json([
                'code' => -1,
                'msg' =>'未登录'
            ]);
        }
        $validators = [
            'messages'=>[
                'required' => ':attribute 不能为空',
                'phone.digits' => ':attribute 不合法 '
            ],
            'rule' => [
                'phone' =>'required|digits:11'
            ],
            'attr' => [
                'phone' =>'手机号'
            ]
        ];
        $this->validate($request,$validators['rule'],$validators['messages'],$validators['attr']);
        $phone = $request->input('phone');

        $userKey = 'Register_User_SmsCode_'.$user->UserId.'_'.$phone;
        $phoneKey = 'Register_SmsCode_'.$phone;
        $code = Redis::get($phoneKey);
        if ($code != false) {
            return response()->json([
                'code' => -1,
                'msg' =>'验证码已发送60s不能重复获取'
            ]);
        }

        for ($i =0 ;$i < 6; $i++) {
            $code .= rand(0,9);
        }

        $msg = sprintf("您正在参加腾讯GAD第三届游戏创新大赛，验证码为%s，该验证码5分钟内有效。如非本人操作，请勿泄漏。",$code);
        try {
            $ret = TofService::sendSms($phone,$msg);
            if ($ret['code'] == 0) {
                Redis::setex($phoneKey,60,$code);
                Redis::setex($userKey,300,$code);
            }
            return response()->json([
                'code' => 0,
                'msg' =>'验证码已发送'
            ]);

        }
        catch(Exception $e) {
            return response()->json([
                'code' => -1,
                'msg' =>'验证码已发送'
            ]);

        }



    }

    // 验证短信验证码
    private function validUserSmsCode($code,$phone)
    {
        $isValid = false;
        $user = Auth::user();
        if ($user) {
            $userKey = 'Register_User_SmsCode_'.$user->UserId.'_'.$phone;
            $userCode = Redis::get($userKey);
            if ($code == $userCode) {
                $isValid = true;
            }
        }

        return $isValid;
    }

    public function showList(Request $request,$os=0,$type=0,$stage=3)
    {
        //$params = $request->all();
        $data['classes'] = array();
        //12是项目扶持，这里取游戏平台和游戏类型两个二级分类的所有子类
        $pclasses = Classify::where('parent',12)->where('class_name','like','游戏%')->get();
        foreach($pclasses as $class){
            $data['classes'][$class->class_id] = Classify::where('parent',$class->class_id)->get();
            $data['classes'][$class->class_id]['name'] = $class->class_name;
        }
        $projectlist = Game::query()->where('status',0);

        if(!empty($os) && is_numeric($os)){
            $projectlist->where('os',$os);
        }
        if(!empty($type) && is_numeric($type)){
            $projectlist->where('game_type',$type);
        }
        if(is_numeric($stage) && $stage != 3){
            $projectlist->where('flow',$stage);
        }
        $projectlist->orderBy('created_at', 'desc');
        $data['projectlist'] = $projectlist->paginate(20);
        return view('hatch.list',$data);
    }

}
