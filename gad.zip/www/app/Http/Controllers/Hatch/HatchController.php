<?php

namespace App\Http\Controllers\Hatch;
use App\Gad\Lib_Func;
use App\Gad\MessageType;
use App\Gad\TofService;
use App\Models\Article;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Register;
use App\Models\Classify;
use App\Models\Game;
use App\Models\Summercourse;
use App\Models\KeyValue;
use Illuminate\Http\Request;
use App\Gad\Upload;
use App\Gad\Func;
use Auth;
use Gate;
use Mockery\CountValidator\Exception;
use Redis;
use Illuminate\Routing\Route;
use App\Repositories\HatchProjectRepository;

class HatchController extends Controller
{
    public function __construct(Request $request){
        if($request->is('hatch/edit*')){
            if(isset($request->id) && ($id = $request->id) >= 1){
                $hatch = Game::find($id);
                $user_id = $hatch->user_id;
                //$this->middleware("acl:hatch::edit,user_id=".$user_id, ['only' => ['getEdit','postEdit']]);
            }
        }
    }

    //sdfs
    public function getIndex() {
        $user = Auth::user();

        if ($user && $user->UserId) {
            $data['user_id'] = $user->UserId;
            //$data['registInfo'] = Register::where('user_id', $user->UserId)->where('obj_type', 1)->where('status', 0)->get();
            $userInfo = Register::where('user_id', $user->UserId)->where('obj_type', 1)->first();
            //$course = Register::findOrFail($request->input('id'));
            $data['userInfo'] = $userInfo;

            $stat = array();
            $stat['s0'] = $stat['s1'] = $stat['s2'] = $stat['total'] = 0;
            $stat['f0'] = $stat['f1'] = $stat['f2'] = 0;
            $stat['reason'] = '';

            if(!empty($userInfo)) {
                $gamesInfo = $userInfo->games;

                if($userInfo->status == 0) {
                    if(!empty($gamesInfo)) {
                        foreach($gamesInfo as $key => $game) {
                            if($game->status == -1) continue;
                            if($game->flow == 0) {
                                if($game->status == 0) {
                                    $stat['f0']++;
                                }
                            } elseif($game->flow == 1) {
                                $stat['f1']++;
                            } elseif($game->flow == 2) {
                                $stat['f2']++;
                            }
                            if($game->status == 0) {
                                $stat['s0']++;
                            } elseif($game->status == 1) {
                                $stat['s1']++;
                            } elseif($game->status == 2) {
                                $stat['s2']++;
                                $stat['reason'] .= "由于{$game->reason}原因，你的项目《{$game->name}》未能通过审核； ";
                            }
                            $stat['total']++;
                        }
                    }
                }
            }
            $data['stat'] = $stat;
        } else {
            $data['user_id'] = '';
            $data['userInfo'] = '';
        }

        $indexBanner = KeyValue::find('new_hatch_index');
        $data['bannerList'] = json_decode($indexBanner['Value'], true);
        $companylist = KeyValue::find('new_hatch_company_list');
        $data['companylist'] = json_decode($companylist['Value']);
        $data['hostNews'] = Article::where('class_id', 1201)->where('status', 0)->orderBy('id', 'desc')->take(3)->get();

        $data['invests'] = Register::where('type', 1)->where('status', 0)->orderBy('id', 'desc')->take(10)->get();

        $data['games'] = Game::where('obj_type', 1)->where('status', 0)->orderBy('id', 'desc')->take(6)->get();

        return view('hatch.index_new', $data);//
    }

    public function getCreate() {
        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $user = Auth::user();
        $gameQuery = \App\Models\Game::query();
        $game = $gameQuery->with(['project'])->where('user_id', $user->UserId)->get()->first();
        if(!empty($game->project)){
            $game->project->setVisible([]);
        }
        return view('hatch.create_new', compact('game'));
    }
    
    public function getCreateOld() {
        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $user = Auth::user();
        $register = Register::where('user_id',$user->UserId)->first();
        if ($register == null || $register->status == 2) {
            return redirect()->guest('/hatch/register');
        }
    	$hatch = new Game();
        $oss = Classify::where('parent',1202)->get();
        $types = Classify::where('parent',1203)->get();
        return view('hatch.create', compact('hatch', 'types', 'oss'));
    }
    
    public function getTest(Request $request){
        $this->validate($request,[
            'game.reg_step' => 'required|integer|max:5|min:1',
        ]);
    }
    
    
    private function hatchValidate($request){
        $data = $request->all();
        $message = ['required' => ':attribute不能为空'];
        $this->validate($request,[
            'game.reg_step' => 'required|integer|max:5|min:1',
            'game.project' => 'required|array'
        ], $message);
        if($data['game']['reg_step'] >= 2){
            $this->validate($request,[
                'game.project.team_name' => 'required',
                //'register.member_count' => 'required|integer|min:1',
                //'register.province' => 'required',
                //'register.city' => 'required',
                'game.project.team_intro' => 'required',
                'game.project.team_contacts' => 'required',
                'game.project.team_id_card' => 'required'
            ], $message);
        }
        if($data['game']['reg_step'] >= 3){
            $this->validate($request,[
                'game.project.name' => 'required',
                'game.project.platform' => 'required|array',
                'game.project.intro' => 'required',
                'game.project.demo' => 'required|array',
                'game.project.videos' => 'required|array',
                'game.hatch_service' => 'required|array',
                'game.project.pictures' => 'array',
                'game.project.other_attachment' => 'array'
            ], $message);
        }
        if($data['game']['reg_step'] >= 4){
            $this->validate($request,[
                'SMSCode' => 'required',
                'game.project.team_phone' => 'required',
                'game.project.team_email' => 'required',
                'game.project.team_weixin' => 'required'
            ], $message);
            if (!$this->validUserSmsCode($data['SMSCode'], $data['game']['project']['team_phone'])) {
                throw new \Exception('验证码不正确');
            }
        }
        $project = [];
        $allowKeys = ['id', 'name', 'intro', 'team_type', 'team_business_license', 'team_name', 'team_logo', 'team_contacts', 'team_id_card',
            'team_province', 'team_city', 'team_intro', 'platform', 'demo', 'videos', 'pictures', 'other_attachment',
            'team_phone', 'team_email', 'team_weixin', 'is_public_demo'];
        foreach($allowKeys as $key){
            if(isset($data['game']['project'][$key])){
                $project[$key] = $data['game']['project'][$key];
            }
        }
        $game = ['id'=>isset($data['game']['id']) ? $data['game']['id'] : 0, 'project'=>$project];
        foreach(['reg_step', 'project_id', 'hatch_service'] as $key){
            if(isset($data['game'][$key])){
                $game[$key] = $data['game'][$key];
            }
        }
        return ['game'=>$game];
    }
    
    public function postSave(HatchProjectRepository $projectRepository, Request $request) {
        if (!Auth::check()) {
            throw new \Exception('未登录');
        }
        $data = $this->hatchValidate($request);
        $data = array_map('xssFilter', $data);
        $user= Auth::user();
        if(!isset($data['game']['project']) || !is_array($data['game']['project'])){
            $data['game']['project'] = [];
        }
        if(!empty($data['game']['project_id'])){
            $project = $projectRepository->find($data['game']['project_id']);
            if(empty($project) || $project->user_id != $user->UserId){
                throw new \Exception('不存在所选项目');
            }
            list($status, $project) = $projectRepository->update($project->id, $data['game']['project']);
            if(!$status){
                throw new \Exception('更新数据失败');
            }
        }else{
            $data['game']['project']['user_id'] = $user->UserId;
            $data['game']['project']['created_from'] = 1;
            $data['game']['project']['is_finish'] = 0;
            $data['game']['project']['logo'] = 'http://gad.qpic.cn/assets/v2/web/img/hatch/project/default_logo.png';
            list($status, $project) = $projectRepository->create($data['game']['project']);
            if(!$status){
                throw new \Exception('更新数据失败');
            }
        }
        $data['game']['reg_step']++;
        $data['game']['project_id'] = $project->id;
        $gameQuery = \App\Models\Game::query();
        $game = $gameQuery->with(['project'])->where('user_id', $user->UserId)->get()->first();
        if (empty($game)) {
            $data['game']['status'] = 1;
            $data['game']['user_id'] = $user->UserId;
            $data['game']['obj_type'] = 1;
            if(!$game = Game::create($data['game'])){
                throw new \Exception('更新数据失败');
            }
            $game->project = $project;
        }else{
            unset($data['game']['status'], $data['game']['user_id'], $data['game']['obj_type']);
            if(!$game->update($data['game'])){
                throw new \Exception('更新数据失败');
            }
        }
        if($data['game']['reg_step']==5){
            $projectRepository->update($project->id, ['is_finish'=>1]);
            //发送站内信
            Func::msgApi(MessageType::PROJECT_APPLY_SUCCESS, $user->UserId, 0, $game->id, url('/hatch/detail', $game->id), $game->project->name);
            //填写完毕后邮件通知
            $title = '[GAD项目扶持]感谢你提交项目资料，请耐心等待审核结果。';
            $mail = view('hatch.mail_create', array('user'=>$game->project->team_name, 'game'=>$game->project->name, 'title'=>$title))->render();
            \Tof::service('message')->sendEmail('gad@tencent.com', $game->project->team_email, $title, $mail);
        }
        return response()->json(array('code' => 0, 'data' => $game->id, 'project_id'=>$project->id));
    }

    public function postCreate(Request $request)
    {
        $data = $request->all();
		$data = array_map('xssFilter', $data);
        $hatch = new Game;

        $resp = array(
            'code' => -1,
            'message' => ''
        );

        if (!Auth::check()) {
            $resp['message'] = '未登录';
            return response()->json($resp);
        }

        $user = Auth::user();
        $register = Register::where('user_id',$user->UserId)
            ->first();
        if ($register == null || $register->status == 2) {
            $resp['message'] = '未入驻或入驻被驳回';
            return response()->json($resp);
        }

        if (!$data['name'] OR
            !$data['logo'][0] OR
            !$data['content'] OR
            !$data['platform'] OR
            !$data['ppt']
        ) {
            $resp['code'] = -2;
            $resp['message'] = '数据不完整';
            return response()->json($resp);
        }

        $hatch->user_id = Auth::user()->UserId;
        $hatch->obj_type = 1;
        $hatch->register_id = Register::where('obj_type', 1)
            ->where('user_id', Auth::user()->UserId)->value('id');

        $hatch->name = $data['name'];
        $hatch->logo = json_encode($data['logo']);
        $hatch->game_type = $data['type'];
        $hatch->description = $data['content'];
        $hatch->os = $data['platform'];
        $hatch->videos = $data['video'];
        $hatch->pictures = json_encode($data['pic']);
        $hatch->ppt = json_encode($data['ppt']);
        $hatch->ppt_pub = intval($data['ppt_pub']);
        $hatch->demo = $data['demo'];
        $hatch->demo_pub = intval($data['demo_pub']);
        $hatch->cooperation = $data['cooperation'];
        $hatch->status = 1;
        $hatch->save();

        $resp['code'] = $hatch->id;
        //发送站内信
        Func::msgApi(
            MessageType::PROJECT_APPLY_SUCCESS,
            Auth::user()->UserId,
            0,
            $hatch->id,
            url('/hatch/detail',$hatch->id),
            $hatch->name
        );
        return response()->json($resp);
    }

    public function getEdit(Request $request, $id)
    {
        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $hatch = Game::findOrFail($id);
        $hatch['videos'] = json_encode($hatch['videos']);
        $hatch['demo'] = json_encode($hatch['demo']);
        
        $oss = Classify::where('parent',1202)->get();
        $types = Classify::where('parent',1203)->get();

        return view('hatch.create', compact('hatch', 'oss', 'types'));
    }

    public function postEdit(Request $request, $id)
    {
        $hatch = Game::findOrFail($id);
        $data = $request->all();
        $data = array_map('xssFilter', $data);

        $resp = array(
            'code' => -1,
            'message' => ''
        );
        if (!Auth::check()) {
            $resp['message'] = '未登录';
            return response()->json($resp);
        }

        if (Auth::user()->UserId != $hatch->user_id and !Auth::user()->roles->contains(2)) {
            $resp['message'] = '无权限';
            return response()->json($resp);
        }

        if (!$data['name'] OR
            !$data['logo'][0] OR
            !$data['content'] OR
            !$data['platform'] OR
            !$data['ppt']
        ) {
            $resp['code'] = -2;
            $resp['message'] = '数据不完整';
            return response()->json($resp);
        }

        $hatch->name = $data['name'];
        $hatch->logo = json_encode($data['logo']);
        $hatch->game_type = $data['type'];
        $hatch->description = $data['content'];
        $hatch->os = $data['platform'];
        $hatch->videos = $data['video'];
        $hatch->pictures = json_encode($data['pic']);
        $hatch->ppt = json_encode($data['ppt']);
        $hatch->ppt_pub = intval($data['ppt_pub']);
        $hatch->demo = $data['demo'];
        $hatch->demo_pub = intval($data['demo_pub']);
        $hatch->cooperation = $data['cooperation'];
        $hatch->status = 1;
        $hatch->save();

        $resp['code'] = $hatch->id;
        //仅自己修改才提醒
        if (Auth::user()->UserId == $hatch->user_id )
        {
            Func::msgApi(
                MessageType::PROJECT_APPLY_SUCCESS,
                Auth::user()->UserId,
                0,
                $hatch->id,
                url('/hatch/detail',$hatch->id),
                $hatch->name
            );
        }
        return response()->json($resp);
    }

    public function getDetail($id)
    {
        $gameQuery = \App\Models\Game::query();
        $game = $gameQuery->with(['project'])->find($id);

        if(empty($game) || empty($game->project) || ($game->status != 0 && !(Auth::user() && Auth::user()->roles->contains(2)))){
            return abort(404);
        }
        
        $hatch = $game->project;
        
        $demotemp = $hatch->demo;
        $demo = empty($demotemp) ? (object)array() : (object)$demotemp[0];
        $demo->name = isset($demo->name) ? $demo->name : '';
        $demo->state = isset($demo->state) ? $demo->state : '';
        $demo->progress = isset($demo->progress) ? $demo->name : 0;
        $demo->url = isset($demo->url) ? $demo->url : 0;
        $demo->size = isset($demo->size) ? $demo->size : 0;
        $hatch->ppt_pub = $game->ppt_pub;
        
        $ppts = $hatch->ppt ? Func::getPreviewDocs($hatch->ppt) : [];

        $recommend = KeyValue::find('new_hatch_detail');
        $project = json_decode($recommend['Value'], true);

        return view('hatch.detail', compact('hatch', 'demo', 'ppts', 'project'));
    }

    public function getDownloadCnt($id)
    {
        if (!Auth::check()) {
            return response()->json(['code' => -2, 'message' => '请登录']);
        }

        $cnt = Game::where('id', intval($id));
        $cnt->increment('dl_cnt');
        $new_cnt = $cnt->value('dl_cnt');

        return response()->json(['code' => 1, 'message' => $new_cnt]);
    }

    public function postUploadAttachment(Request $request)
    {
        $file = $request->file('file');

        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }
        $size = round($file->getSize()/1024/1024,2)."M";
        $result = Upload::uploadQcloudCos('hatch', $file);
        if ($result['code'] == 0) {
            $fileExt = strtolower($file->getClientOriginalExtension());
            if (in_array($fileExt,['ppt','pptx','pdf'])) {
                $previewUrl = Upload::getPreviewDoc($result);
                $header = get_headers(str_replace("#page#","1",$previewUrl["url"]), 1);
                $page = intval($header["User-ReturnCode"]);
                if($page <=0){
                    $page = 1;
                }
                $result['data']['access_url'] .= '?newd='.urlencode($previewUrl["url"].";".$page);
            }
            return response()->json(['code' => 0, 'url' => $result['data']['access_url'],'size' =>$size]);
        } else {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }
    }

    //上传视频
    public function postUploadVideo(Request $request)
    {
        $file = $request->file('file');
        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }

        $ret = Upload::file($file);
        if(isset($ret["url"])){
            $url = parse_url($ret['url']);
            if(isset($url['query'])){
                parse_str($url['query']);
            }
            $ret['uuid'] = $uuid;
            $url = parse_url($ret['url']);
            $ret["url"] = "/hatch/showVideo/?fileurl=".Upload::hideFileServer($ret["url"])."%26videotype=30|||".$file->getClientOriginalName();
        }
        return response()->json(['code' => 0, 'uuid' => $ret['uuid'], 'url' => $ret['url']]);
    }

    //查看视频
    public function getShowVideo(Request $request)
    {
        $fileurl = $request->input("fileurl");
        if(empty($fileurl)){
            return response()->json(["code" => -1, "msg" => "地址错误"]);
        }
        $tmp = explode("|||", Upload::showFileServer($fileurl));
        if(null != $request->input('HTTP_IF_MODIFIED_SINCE')){
            header('HTTP/1.0 304 Not Modified');
            return true;
        }
        header("Expires:" . gmdate("D, d M Y H:i:s", strtotime("+1 year")) . " GMT");
        header("Pragma: Pragma");
        header("Cache-Control: max-age=31536000");
        header("Last-Modified:" . gmdate("D, d M Y H:i:s", strtotime("-1 day")) . " GMT");
        if (strpos($tmp[0], "http://file.tig.oa.com/") === 0
            || strpos($tmp[0], "http://file.ieg.local/") === 0
            || strpos($tmp[0], "http://tig.oa.com/") === 0
        ) {
            $ft= substr($tmp[0], strrpos($tmp[0], '.')+1);
            if (!strpos($tmp[0],"mod/VideoAo.php?")&&!in_array(strtolower($ft),self:: $allowTypes)) {
                exit('Invalid file type.');
            }
            Upload::getFile($tmp[0], $tmp[1]);
        }
    }

    public function getRegister() {

        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }

        return view('hatch.register');
    }

    public function postRegister(Request $request) {
        $user = Auth::user();
        $registerType = $request->input('registerType');
        if (!$user || !$user->UserId) {
            return response()->json([
                'code' => -1,
                'msg' =>'未登录'
            ]);
        }
        $fields = [
            ['key' => 'user_name', 'name' => '姓名', 'rule' => 'required'],
            ['key' => 'mobile', 'name' => '手机号', 'rule' => 'required|digits:11'],
            ['key' => 'email', 'name' => '邮箱', 'rule' => 'required|email'],
            ['key' => 'smsCode', 'name' => '验证码', 'rule' => 'required|digits:6'],
            ['key' => 'id_card', 'name' => '身份证号', 'rule' => 'required'],
            ['key' => 'company', 'name' => '公司/团队名称', 'rule' => 'required'],
            ['key' => 'logo', 'name' => 'logo', 'rule' => 'required'],
            ['key' => 'info', 'name' => '简介', 'rule' => 'max:140']

        ];
        if($registerType == 0) {
            $fields[] = ['key' => 'memberList', 'name' => '团队成员', 'rule' => 'required'];
        }
        else if($registerType == 1) {
            $fields[] = ['key' => 'members', 'name' => '公司规模', 'rule' => 'required'];
            $fields[] = ['key' => 'city', 'name' => '所在城市', 'rule' => 'required'];
            $fields[] = ['key' => 'province', 'name' => '所在省份', 'rule' => 'required'];
            $fields[] = ['key' => 'phone', 'name' => '联系电话', 'rule' => 'required'];
            $fields[] =  ['key' => 'company_type', 'name' => '公司类型', 'rule' => 'required'];
        }

        $validator  = [
            'messages' => [
                'required' => ':attribute不能为空',
                'email' => ':attribute 地址不正确',
                'smsCode.digits' => ':attribute错误',
                'mobile.digits' => '请填写有效:attribute',
                'info.max' => '简介不能超过140个字'
            ]
        ];
        foreach ($fields as $field) {
            $validator['rule'][$field['key']] = $field['rule'];
            $validator['attr'][$field['key']] = $field['name'];
        }

        $this->validate($request, $validator['rule'], $validator['messages'], $validator['attr']);
        $objType = $request->input('objType',1);
        $userName = $request->input('user_name');
        $mobile = $request->input('mobile');
        $smsCode = $request->input('smsCode');
        $email = $request->input('email');
        $qq = $request->input('qq',0);
        $idCard = $request->input('id_card');
        $company = $request->input('company');
        $info = $request->input('info');
        $position = $request->input('position');
        $companyType = $request->input('company_type');
        $province = $request->input('province');
        $city = $request->input('city');
        $phone = $request->input('phone');
        $logo = $request->input('logo');

        //校验验证码是否正确
        if (!$this->validUserSmsCode($smsCode,$mobile)) {
            return response()->json(
                [
                    'code' => -1,
                    'message' => '验证码不正确'
                ]
            );
        }
        //开发团队
        if ($registerType === 0) {
            $members = \GuzzleHttp\json_encode($request->input('memberList'));
        }
        else {
            //机构
            $members = $request->input('members');
        }

        $register = Register::where('user_id',$user->UserId)
            ->where('type',$registerType)
            ->first();

        if (!$register) {
            $register = new Register();
        }
        $register->obj_type = $objType;
        $register->type = $registerType;
        $register->user_id = $user->UserId;
        $register->user_name = $userName;
        $register->mobile = $mobile;
        $register->email = $email;
        $register->qq = $qq;
        $register->id_card = $idCard;
        $register->position = $position;
        $register->company = $company;
        $register->company_type = $companyType;
        $register->members = $members;
        $register->phone = $phone;
        $register->province = $province;
        $register->city = $city;
        $register->info = $info;
        $register->logo = $logo;
        //每次修改都变为待审核
        $register->status = 1;

        $ret = $register->save();

        if ($ret) {
            return response()->json([
                'code' => 0,
                'msg' =>'保存成功'
            ]);
        }
        else {
            return response()->json([
                'code' => -1,
                'msg' =>'保存失败'
            ]);
        }


    }

    public function getRegisterInfo(Request $request) {
        $user = Auth::user();
        if (!$user || !$user->UserId) {
            return response()->json([
                'code' => -1,
                'msg' =>'未登录'
            ]);
        }

        $register = Register::where('user_id',$user->UserId)
                    ->first();
        if ($register) {
            if ($register->qq === 0) {
                $register->qq = null;
            }

            if ($register->members && $register->type == 0) {
                $register->memberList = \GuzzleHttp\json_decode($register->members);
            }
        }


        return response()->json([
            'code' =>0,
            'register' => $register
        ]);

    }

    public function getSmsCode(Request $request) {
        $user = Auth::user();
        if (!$user || !$user->UserId) {
            return response()->json([
                'code' => -1,
                'msg' =>'未登录'
            ]);
        }
        $validators = [
            'messages'=>[
                'required' => ':attribute 不能为空',
                'phone.digits' => ':attribute 不合法 '
            ],
            'rule' => [
                'phone' =>'required|digits:11'
            ],
            'attr' => [
                'phone' =>'手机号'
            ]
        ];
        $this->validate($request,$validators['rule'],$validators['messages'],$validators['attr']);
        $phone = $request->input('phone');

        $userKey = 'Register_User_SmsCode_'.$user->UserId.'_'.$phone;
        $phoneKey = 'Register_SmsCode_'.$phone;
        $code = Redis::get($phoneKey);
        if ($code != false) {
            return response()->json([
                'code' => -1,
                'msg' =>'验证码已发送60s不能重复获取'
            ]);
        }

        for ($i =0 ;$i < 6; $i++) {
            $code .= rand(0,9);
        }

        $msg = sprintf("[腾讯GAD]您好，您正在申请入驻GAD游戏开发者平台，验证码为%s，该验证码5分钟内有效。如非本人操作，请勿泄漏。",$code);
        try {
            $ret = TofService::sendSms($phone,$msg);
            if ($ret['code'] == 0) {
                Redis::setex($phoneKey,60,$code);
                Redis::setex($userKey,300,$code);
            }
            return response()->json([
                'code' => 0,
                'msg' =>'验证码已发送'
            ]);

        }
        catch(Exception $e) {
            return response()->json([
                'code' => -1,
                'msg' =>'验证码已发送'
            ]);

        }



    }

    // 验证短信验证码
    private function validUserSmsCode($code,$phone)
    {
        $isValid = false;
        $user = Auth::user();
        if ($user) {
            $userKey = 'Register_User_SmsCode_'.$user->UserId.'_'.$phone;
            $userCode = Redis::get($userKey);
            if ($code == $userCode) {
                $isValid = true;
            }
        }

        return $isValid;
    }

    public function showList(Request $request,$os=0,$type=0,$stage=3)
    {
        //$params = $request->all();
        $data['classes'] = array();
        //12是项目扶持，这里取游戏平台和游戏类型两个二级分类的所有子类
        $pclasses = Classify::where('parent',12)->where('class_name','like','游戏%')->get();
        foreach($pclasses as $class){
            $data['classes'][$class->class_id] = Classify::where('parent',$class->class_id)->get();
            $data['classes'][$class->class_id]['name'] = $class->class_name;
        }
        $projectlist = Game::query()->where('status',0);

        if(!empty($os) && is_numeric($os)){
            $projectlist->where('os',$os);
        }
        if(!empty($type) && is_numeric($type)){
            $projectlist->where('game_type',$type);
        }
        if(is_numeric($stage) && $stage != 3){
            $projectlist->where('flow',$stage);
        }
        $projectlist->orderBy('created_at', 'desc');
        $data['projectlist'] = $projectlist->paginate(20);
        return view('hatch.list',$data);
    }

    public function getSkill () {
        return view('hatch.skill');
    }
}
