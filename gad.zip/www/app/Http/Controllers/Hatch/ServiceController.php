<?php

namespace App\Http\Controllers\Hatch;
use App\Entities\Service;
use App\Entities\ServiceMember;
use App\Gad\Lib_Func;
use App\Gad\MessageType;
use App\Gad\TofService;
use App\Models\Article;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Register;
use App\Models\Classify;
use App\Models\Game;
use App\Models\Summercourse;
use App\Models\KeyValue;
use App\Repositories\ServiceMemberRepository;
use App\Repositories\ServiceOrderRepository;
use Illuminate\Http\Request;
use App\Gad\Upload;
use App\Gad\Func;
use Auth;
use Gate;
use Mockery\CountValidator\Exception;
use Redis;
use Illuminate\Routing\Route;
use App\Repositories\ServiceRepository;
use App\Repositories\HatchProjectRepository;

class ServiceController extends Controller
{
    public function __construct(Request $request){
        $this->middleware("auth", ['only' => ['getEdit','postDel','postApply','getAdmin']]);
    }

    //项目服务首页
    public function getIndex() {
        //$data['ip_type'] = $serviceRepository->getIpType();
        $data['ip_style'] = [];

        if ($user && $user->UserId) {
            $data['user_id'] = $user->UserId;
            //$data['registInfo'] = Register::where('user_id', $user->UserId)->where('obj_type', 1)->where('status', 0)->get();
            $userInfo = Register::where('user_id', $user->UserId)->where('obj_type', 1)->first();
            //$course = Register::findOrFail($request->input('id'));
            $data['userInfo'] = $userInfo;

            $stat = array();
            $stat['s0'] = $stat['s1'] = $stat['s2'] = $stat['total'] = 0;
            $stat['f0'] = $stat['f1'] = $stat['f2'] = 0;
            $stat['reason'] = '';

            if(!empty($userInfo)) {
                $gamesInfo = $userInfo->games;

                if($userInfo->status == 0) {
                    if(!empty($gamesInfo)) {
                        foreach($gamesInfo as $key => $game) {
                            if($game->status == -1) continue;
                            if($game->flow == 0) {
                                if($game->status == 0) {
                                    $stat['f0']++;
                                }
                            } elseif($game->flow == 1) {
                                $stat['f1']++;
                            } elseif($game->flow == 2) {
                                $stat['f2']++;
                            }
                            if($game->status == 0) {
                                $stat['s0']++;
                            } elseif($game->status == 1) {
                                $stat['s1']++;
                            } elseif($game->status == 2) {
                                $stat['s2']++;
                                $stat['reason'] .= "由于{$game->reason}原因，你的项目《{$game->name}》未能通过审核； ";
                            }
                            $stat['total']++;
                        }
                    }
                }
            }
            $data['stat'] = $stat;
        } else {
            $data['user_id'] = '';
            $data['userInfo'] = '';
        }

        $indexBanner = KeyValue::find('new_hatch_index');
        $data['bannerList'] = json_decode($indexBanner['Value'], true);
        $companylist = KeyValue::find('new_hatch_company_list');
        $data['companylist'] = json_decode($companylist['Value']);
        $data['hostNews'] = Article::where('class_id', 1201)->where('status', 0)->orderBy('id', 'desc')->take(3)->get();

        $data['invests'] = Register::where('type', 1)->where('status', 0)->orderBy('id', 'desc')->take(10)->get();

        $data['games'] = Game::where('obj_type', 1)->where('status', 0)->orderBy('id', 'desc')->take(6)->get();

        return view('hatche.service.ip_list', $data);//
    }

    public function getCreate() {
        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $user = Auth::user();
        $gameQuery = \App\Models\Game::query();
        $game = $gameQuery->with(['project'])->where('user_id', $user->UserId)->get()->first();
        if(!empty($game->project)){
            $game->project->setVisible([]);
        }
        return view('hatch.create_new', compact('game'));
    }

    public function getCreateOld() {
        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $user = Auth::user();
        $register = Register::where('user_id',$user->UserId)->first();
        if ($register == null || $register->status == 2) {
            return redirect()->guest('/hatch/register');
        }
    	$hatch = new Game();
        $oss = Classify::where('parent',1202)->get();
        $types = Classify::where('parent',1203)->get();
        return view('hatch.create', compact('hatch', 'types', 'oss'));
    }

    public function getTest(Request $request){
        $this->validate($request,[
            'game.reg_step' => 'required|integer|max:5|min:1',
        ]);
    }

    
    private function hatchValidate($request){
        $data = $request->all();
        $message = ['required' => ':attribute不能为空'];
        $this->validate($request,[
            'service_type' => 'required|integer|max:5|min:1',
            'service.name' => 'required'
        ], $message);
        if($data['service_type'] == 1){
            $this->validate($request,[
                'service.ip_type' => 'required',
                'service.logo' => 'required',
                'service.description' => 'required',
                'service.ip_range' => 'required|array',
                'service.showcase' => 'required|array',
                'service.ip_style' => 'required',
                'service.online_time' => 'required'
            ], $message);
        }
        if($data['service_type'] == 2){
            $this->validate($request,[
                'SMSCode' => 'required',
                'game.project.name' => 'required',
                'game.project.platform' => 'required|array',
                'game.project.intro' => 'required',
                'game.project.demo' => 'required|array',
                'game.project.videos' => 'required|array',
                'game.hatch_service' => 'required|array',
                'game.project.pictures' => 'array',
                'game.project.other_attachment' => 'array'
            ], $message);
            if (!$this->validUserSmsCode($data['SMSCode'], $data['game']['project']['team_phone'])) {
                throw new \Exception('验证码不正确');
            }
        }
        if($data['service_type'] == 3){
            $this->validate($request,[
                'service.showcase' => 'required|array',
                'service.logo' => 'required',
                'service.office_seat' => 'required|integer',
                'service.office_price' => 'required',
                'service.name' => 'required',
                'service.description' => 'required',
                'service.office_address' => 'required'
            ], $message);
        }
    }
    
    public function postSave(ServiceRepository $serviceRepository, ServiceMemberRepository $memberRes, Request $request) {
        $this->hatchValidate($request);
        $data = $request->all();
        $data = array_map('xssFilter', $data);
        $user= Auth::user();
        $member = $memberRes->where('user_id',$user->UserId)->where('status',0)->where('service_member_type',$data['service_type'])->findAll();
        if(count($member) == 0) {
            return response()->json(['code' => -1, 'message' => '您还没认证，请先认证']);
        }
        $member = $member[0];
        $index = 1;
        if(!empty($data['service']['id'])){
            $service = $serviceRepository->find($data['service']['id']);
            if(empty($service) || $service->service_member_id != $member->id) {
                throw new \Exception('不存在此服务');
            }
            foreach($data['service']['derivatives'] as $k => $va) {
                if ($va['status'] == true && $va['name'] != '') {
                    $va['id'] = $index;
                    $index++;
                } else {
                    unset($data['service']['derivatives'][$k]);
                }
            }
            $data['service']['service_member_id'] = $member->id;
            list($status, $service) = $serviceRepository->update($data['service']['id'], $data['service']);
            if(!$status) {
                throw new \Exception('更新数据有误');
            }
        }else{
            $data['service']['service_type'] = $data['service_type'];
            $data['service']['service_member_id'] = $member->id;
            $index = 1;
            foreach($data['service']['derivatives'] as $k => $va) {
                if ($va['status'] == true && $va['name'] != '') {
                    $va['id'] = $index;
                    $index++;
                } else {
                    unset($data['service']['derivatives'][$k]);
                }
            }
            //$data['game']['project']['is_finish'] = 0;
            //$data['game']['project']['logo'] = 'http://gad.qpic.cn/assets/v2/web/img/hatch/project/default_logo.png';
            list($status, $service) = $serviceRepository->create($data['service']);
            if(!$status) {
                throw new \Exception('新增数据失败'.$status);
            }
        }
        //$data['game']['reg_step']++;
        //$memberEn =  = $member = $serviceMem['game']['project_id'] = $member = ->id;
        //$gameQuery = \App\Models\Game::query();
        //$game = $gameQuery->with(['project'])->where('user_id', $user->UserId)->get()->first();
        ///if (empty($game)) {
        //    $data['game']['status'] = 1;
        //    $data['game']['user_id'] = $user->UserId;
        //    $data['game']['obj_type'] = 1;
        //    if(!$game = Game::create($me['game'])){
        //        throw new \Exception('更新数据失败');
        //    }
        //    $game->project = $project;
        //}else{
        //    unset($data['game']['status'], $data['game']['user_id'], $data['game']['obj_type']);
        //    if(!$game->update($data['game'])){
        //        throw new \Exception('更新数据失败');
        //    }
        //}
        if($status && false){
            //$projectRepository->update($project->id, ['is_finish'=>1]);
            //发送站内信
            Func::msgApi(MessageType::PROJECT_APPLY_SUCCESS, $user->UserId, 0, $service->id, url('/hatch/service/ip-detail', $service->id), $service->name);
            //填写完毕后邮件通知
            $title = '[GAD项目扶持]感谢你提交项目资料，请耐心等待审核结果。';
            $mail = view('hatch.mail_create', array('user'=>$service->name, 'game'=>$service->name, 'title'=>$title))->render();
            \Tof::service('message')->sendEmail('gad@tencent.com', $member->email, $title, $mail);
        }
        return response()->json(['code' => 0, 'data' => $service, 'project_id' => '']);
    }

    public function postCreate(Request $request)
    {
        $data = $request->all();
		$data = array_map('xssFilter', $data);
        $hatch = new Game;

        $resp = array(
            'code' => -1,
            'message' => ''
        );

        if (!Auth::check()) {
            $resp['message'] = '未登录';
            return response()->json($resp);
        }

        $user = Auth::user();
        $register = Register::where('user_id',$user->UserId)
            ->first();
        if ($register == null || $register->status == 2) {
            $resp['message'] = '未入驻或入驻被驳回';
            return response()->json($resp);
        }

        if (!$data['name'] OR
            !$data['logo'][0] OR
            !$data['content'] OR
            !$data['platform'] OR
            !$data['ppt']
        ) {
            $resp['code'] = -2;
            $resp['message'] = '数据不完整';
            return response()->json($resp);
        }

        $hatch->user_id = Auth::user()->UserId;
        $hatch->obj_type = 1;
        $hatch->register_id = Register::where('obj_type', 1)
            ->where('user_id', Auth::user()->UserId)->value('id');

        $hatch->name = $data['name'];
        $hatch->logo = json_encode($data['logo']);
        $hatch->game_type = $data['type'];
        $hatch->description = $data['content'];
        $hatch->os = $data['platform'];
        $hatch->videos = $data['video'];
        $hatch->pictures = json_encode($data['pic']);
        $hatch->ppt = json_encode($data['ppt']);
        $hatch->ppt_pub = intval($data['ppt_pub']);
        $hatch->demo = $data['demo'];
        $hatch->demo_pub = intval($data['demo_pub']);
        $hatch->cooperation = $data['cooperation'];
        $hatch->status = 1;
        $hatch->save();

        $resp['code'] = $hatch->id;
        //发送站内信
        Func::msgApi(
            MessageType::PROJECT_APPLY_SUCCESS,
            Auth::user()->UserId,
            0,
            $hatch->id,
            url('/hatch/detail',$hatch->id),
            $hatch->name
        );
        return response()->json($resp);
    }

    public function getEdit(Request $request, $id)
    {
        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $hatch = Game::findOrFail($id);
        $hatch['videos'] = json_encode($hatch['videos']);
        $hatch['demo'] = json_encode($hatch['demo']);
        
        $oss = Classify::where('parent',1202)->get();
        $types = Classify::where('parent',1203)->get();

        return view('hatch.create', compact('hatch', 'oss', 'types'));
    }

    public function postDel(Request $request, ServiceRepository $serviceRes, $id = 0)
    {
        $service = $serviceRes->find($id);
        if(empty($service) || $service->member->user_id != Auth::user()->UserId) {
            return response()->json(['code' => -1, 'message' => '您没有权限修改']);
        }

        $res = $serviceRes->update($service->id,['status' => -1]);

        if($res[0]) {
            return response()->json(['code' => 0, 'message' => '修改成功']);
        }

        return response()->json(['code' => -1, 'message' => '数据出错']);
    }

    public function getDetail(Request $request, ServiceRepository $serviceRepository, $id = 0)
    {
        $detail = $serviceRepository->getIpDetail($id);
        if(empty($detail) || empty($detail->member) || ($detail->status != 0 && !(Auth::user() && (Auth::user()->roles->contains(2) || Auth::user()->UserId == $detail->user_id)))){
            return abort(404);
        }

        $ip_type = $serviceRepository->getIpType()[$detail->ip_type];
        $ip_style = $serviceRepository->getIpStyle()[$detail->ip_style];
        $range = $detail->ip_range;
        if(Auth::user()) {
            $member = \App\Entities\ServiceMember::where('user_id', Auth::user()->UserId)->where('status', 0)->where('service_member_type', 1)->get()->first();
        }
        $ip_range = '';
        foreach($range as $k => $val) {
            $ip_range = $ip_range . $serviceRepository->getIpRange()[$val];
            if ($k + 1 != count($range)) {
                $ip_range = $ip_range . '|';
            }
        }
        $service = $detail->service_type == 1 ? 'ip' : 'office';

        return view('hatch.service.'.$service.'_detail', compact('detail', 'ip_type', 'ip_style', 'ip_range','member'));
    }

    public function getList(Request $request, ServiceRepository $serviceRepository, $service = 'ip', $ip_type = 0, $ip_style = 0, $ip_range = 0, $city = '0')
    {
        $page = $request->input('page', 1);
        $pageSize = $request->input('pageSize', 10);
        $orderBy = $request->input('orderBy','new');

        if ($pageSize > 100) {
            $pageSize = 20;
        }

        $data = [];

        $data['ip_type'] = $serviceRepository->getIpType();
        $data['ip_style'] = $serviceRepository->getIpStyle();
        $data['ip_range'] = $serviceRepository->getIpRange();

        $data['ip_type_select'] = $ip_type;
        $data['ip_style_select'] = $ip_style;
        $data['ip_range_select'] = $ip_range;
        $data['orderBy'] = $orderBy;
        $data['city'] = $city;

        $data['services'] = $serviceRepository->getListByType($service == 'ip' ? 1 : ($service == 'office' ? 3 : ($service == 'version' ? 2 : ($service == 'finance' ? 4 : 5))),$ip_type, $ip_style, $ip_range, $orderBy, $city, $page, $pageSize);
        if ($service == 'finance') {
            $memberRespository = new ServiceMemberRepository();
            $data['jigous'] = $memberRespository->where('status', '=', 0)->where('service_member_type', '=', 4)->findAll();
        }

        if ($request->wantsJson()) {
            return response()->json(['code' => 0, 'data' => $data['services']]);
        }

        return view('hatch.service.'.$service.'_index', $data);
    }

    public function postUploadAttachment(Request $request)
    {
        $file = $request->file('file');

        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }
        $size = round($file->getSize()/1024/1024,2)."M";
        $result = Upload::uploadQcloudCos('hatch', $file);
        if ($result['code'] == 0) {
            $fileExt = strtolower($file->getClientOriginalExtension());
            if (in_array($fileExt,['ppt','pptx','pdf'])) {
                $previewUrl = Upload::getPreviewDoc($result);
                $header = get_headers(str_replace("#page#","1",$previewUrl["url"]), 1);
                $page = intval($header["User-ReturnCode"]);
                if($page <=0){
                    $page = 1;
                }
                $result['data']['access_url'] .= '?newd='.urlencode($previewUrl["url"].";".$page);
            }
            return response()->json(['code' => 0, 'url' => $result['data']['access_url'],'size' =>$size]);
        } else {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }
    }

    //上传视频
    public function postApply(Request $request, ServiceRepository $serviceRepository, ServiceOrderRepository $orderRepository, $serviceType = 'ip')
    {
        $service_arr = ['ip' => 1, 'version' => 2, 'office' => 3, 'finance' => 4, 'publish' => 5];
        $detail = $serviceRepository->createModel();
        if($serviceType == 'ip' || $serviceType == 'office'){
            $this->validate($request, [
                'id' => 'required',
                'userComment' => 'required|max:500'
            ],['userComment.max' => '合作意向不能超500字']);
            $id = $request->input('id');
            if (!($detail = $serviceRepository->getIpDetail($id))) {
                return response()->json(['code' => -1, 'message' => '提交的服务不存在']);
            }
        } else if($serviceType == 'finance' || $serviceType == 'version' || $serviceType == 'publish') {
            $this->validate($request, [
                'userComment' => 'required|max:500'
            ],['userComment.max' => '合作意向不能超过500字']);
            $id = $request->input('id');
            $detail = $serviceRepository->where('status', 0)->findWhere(['service_type', $service_arr[$serviceType]]);
            if (count($detail)) {
                $ids = array_pluck($detail->toArray(), 'id');
            } else {
                $detail = $serviceRepository->createModel();
                $id = 0;
            }
        } else if($serviceType == 'version') {
            $this->validate($request, [
                'id' => 'required',
                'userComment' => 'required|max:500'
            ]);
        } else if($serviceType == 'publish') {
            $this->validate($request, [
                'userComment' => 'required|max:501'
            ]);
        } else {
            return abort(404);
        }

        $userComment = $request->input('userComment');
        $extra = $request->input('extra','[]');
        $code = 0;
        $message = '';
        if(empty($userComment)) {
            $code = -1;
            $message = '合作意向不能为空';
        } else {
            $member = \App\Entities\ServiceMember::where('user_id',Auth::user()->UserId)->where('status',0)->where('service_member_type',0)->get();
            if(count($member) == 0) {
                return response()->json(['code' => -2, 'message' => '你没有认证开发者']);
            } else {
                if(!isset($ids)) {
                    $detail = [$detail];
                }
                $code = -1;
                $message = '你已经提交';
                foreach($detail as $val) {
                    $data = ['service_id' => intval($val->id), 'apply_member_id' => $member[0]->id, 'service_type' => $service_arr[$serviceType]];
                    $ord = $orderRepository->where('service_id', $val->id)->where('apply_member_id', $member[0]->id)
                        ->findWhere(['service_type', '=', $service_arr[$serviceType]]);
                    if (count($ord)) {
                        if (in_array($service_arr[$serviceType], [2, 4, 5]) && $ord[0]->status==11) { //更新状态
                            $orderRepository->update($ord[0]->id, ['cooperation_intention'=>$userComment, 'status'=>1]);
                            $code = 0;
                        }
                    } else {
                        $code = 0;
                        $data['provide_member_id'] = intval($val->service_member_id);
                        $data['cooperation_intention'] = $userComment;
                        $data['extra'] = $extra;
                        $orderRepository->create($data);
                    }
                }
            }
        }
        return response()->json(['code' => $code, 'message' => $message]);
    }

    //查看视频
    public function getShowVideo(Request $request)
    {
        $fileurl = $request->input("fileurl");
        if(empty($fileurl)){
            return response()->json(["code" => -1, "msg" => "地址错误"]);
        }
        $tmp = explode("|||", Upload::showFileServer($fileurl));
        if(null != $request->input('HTTP_IF_MODIFIED_SINCE')){
            header('HTTP/1.0 304 Not Modified');
            return true;
        }
        header("Expires:" . gmdate("D, d M Y H:i:s", strtotime("+1 year")) . " GMT");
        header("Pragma: Pragma");
        header("Cache-Control: max-age=31536000");
        header("Last-Modified:" . gmdate("D, d M Y H:i:s", strtotime("-1 day")) . " GMT");
        if (strpos($tmp[0], "http://file.tig.oa.com/") === 0
            || strpos($tmp[0], "http://file.ieg.local/") === 0
            || strpos($tmp[0], "http://tig.oa.com/") === 0
        ) {
            $ft= substr($tmp[0], strrpos($tmp[0], '.')+1);
            if (!strpos($tmp[0],"mod/VideoAo.php?")&&!in_array(strtolower($ft),self:: $allowTypes)) {
                exit('Invalid file type.');
            }
            Upload::getFile($tmp[0], $tmp[1]);
        }
    }

    public function getRegister(ServiceMemberRepository $serviceMember, $member_type = 0)
    {

        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $register = $serviceMember->where('service_member_type', $member_type)->where('user_id', Auth::user()->UserId)->findAll();
        $register = count($register) > 0 ? $register[0] : null;
        $team_name = '团队信息';
        $v_name = $member_type == 0 ? '开发者认证' :
            ($member_type == 1 ? 'IP提供商认证' :
                ($member_type == 2 ? '版号认证' :
                    ($member_type == 3 ? '办公场地提供方认证' :
                        ($member_type == 4 ? '投资方认证' :
                            ($member_type == 5 ? '发行商认证' : '')
                        )
                    )
                )
            );
        $name = '接口人信息';
        if($v_name == '' || $v_name == '版号认证') {
            return abort(404);
        }

        return view('hatch.service.register', [
            'member_type' => $member_type,
            'register' => $register,
            'v_name' => $v_name,
            'team_name' => $team_name,
            'in_name' => $name
        ]);
    }

    public function postRegister(Request $request, ServiceMemberRepository $serviceMember)
    {
        $user = Auth::user();
        $member_type = intval($request->input('member_type'));
        if (!$user || !$user->UserId) {
            return response()->json([
                'code' => -1,
                'msg' => '未登录'
            ]);
        }
        $fields = [
            ['key' => 'register.name', 'name' => '团队名称', 'rule' => 'required'],
            ['key' => 'register.logo', 'name' => '团队logo', 'rule' => 'required'],
            ['key' => 'register.province', 'name' => '所在城市', 'rule' => 'required'],
            //['key' => 'register.city', 'name' => '所在城市', 'rule' => 'required'],
            ['key' => 'register.intro', 'name' => '团结简介', 'rule' => 'required|max:500'],
            ['key' => 'register.contacts', 'name' => '接口人', 'rule' => 'required'],
            ['key' => 'register.phone', 'name' => '手机', 'rule' => 'required|digits:11'],
            ['key' => 'SMSCode', 'name' => '验证码', 'rule' => 'required|digits:6'],
        ];
        if ($member_type == 0) {
            $fields[] = ['key' => 'register.team_num', 'name' => '团队人数', 'rule' => 'required'];
            $fields[] = ['key' => 'register.id_card', 'name' => '身份证号', 'rule' => 'required'];
        } else if ($member_type == 1) {
            $fields[] = ['key' => 'register.address', 'name' => '通讯地址', 'rule' => 'required|max:140'];
            $fields[] = ['key' => 'register.type', 'name' => '个人企业', 'rule' => 'required'];
            $fields[] = ['key' => 'register.business_license', 'name' => '公司营业执照', 'rule' => 'required'];
        } else if ($member_type == 2) {
            return abort(404);
        } else if ($member_type == 3) {
            $fields[] = ['key' => 'register.address', 'name' => '通讯地址', 'rule' => 'required|max:140'];
            $fields[] = ['key' => 'register.type', 'name' => '个人企业', 'rule' => 'required'];
            $fields[] = ['key' => 'register.business_license', 'name' => '公司营业执照', 'rule' => 'required'];
        } else if ($member_type == 4) {
            $fields[] = ['key' => 'register.address', 'name' => '通讯地址', 'rule' => 'required|max:140'];
            $fields[] = ['key' => 'register.type', 'name' => '个人企业', 'rule' => 'required'];
            $fields[] = ['key' => 'register.business_license', 'name' => '公司营业执照', 'rule' => 'required'];
            $fields[] = ['key' => 'register.institutional_type', 'name' => '个人/企业', 'rule' => 'required'];
            $fields[] = ['key' => 'register.invest_stage', 'name' => '投资阶段', 'rule' => 'required'];
        } else if ($member_type == 5) {
            $fields[] = ['key' => 'register.address', 'name' => '通讯地址', 'rule' => 'required|max:140'];
            $fields[] = ['key' => 'register.type', 'name' => '个人企业', 'rule' => 'required'];
            $fields[] = ['key' => 'register.business_license', 'name' => '公司营业执照', 'rule' => 'required'];
            $fields[] = ['key' => 'register.business_type', 'name' => '发行类型', 'rule' => 'required|array'];
            $fields[] = ['key' => 'register.business_style', 'name' => '发行方法', 'rule' => 'required|array'];
            $fields[] = ['key' => 'register.business_platform', 'name' => '发行平台', 'rule' => 'required'];
        } else {
            return abort(501);
        }

        $validator = [
            'messages' => [
                'required' => ':attribute不能为空',
                'register.email' => ':attribute 地址不正确',
                'register.smsCode.digits' => ':attribute错误',
                'register.phone.digits' => '请填写有效:attribute',
                'register.intro.max' => '简介不能超过140个字'
            ]
        ];
        foreach ($fields as $field) {
            $validator['rule'][$field['key']] = $field['rule'];
            $validator['attr'][$field['key']] = $field['name'];
        }

        $this->validate($request, $validator['rule'], $validator['messages'], $validator['attr']);
        $all = array_map('xssFilter', $request->all());
        $all = $all['register'];

        $data['service_member_type'] = $member_type > 5 ? 1 : $member_type;
        $data['name'] = $all['name'];
        $data['logo'] = $all['logo'];
        $data['province'] = $all['province'];
        $data['city'] = $all['city'];
        $data['intro'] = $all['intro'];
        $data['contacts'] = $all['contacts'];
        $data['id_card'] = array_get($all, 'id_card');
        $data['phone'] = $all['phone'];
        $data['team_num'] = array_get($all, 'team_num');
        $data['email'] = $all['email'];
        $data['address'] = array_get($all, 'address');
        $data['type'] = $all['type'] ? $all['type'] : 1;
        $data['business_license'] = array_get($all, 'business_license');
        $data['institutional_type'] = array_get($all, 'institutional_type');
        $data['invest_stage'] = array_get($all, 'invest_stage');
        $data['business_type'] = array_get($all, 'business_type');
        $data['business_style'] = array_get($all, 'business_style');
        $data['business_platform'] = array_get($all, 'business_platform');
        $data['user_id'] = Auth::user()->UserId;

        //校验验证码是否正确
        if (!$this->validUserSmsCode($request->input('SMSCode'), $all['phone'])) {
            return response()->json(
                [
                    'code' => -1,
                    'message' => '验证码不正确'
                ]
            );
        }

        $member = $serviceMember->where('service_member_type', $member_type)->findWhere(['user_id', Auth::user()->UserId]);
        if (count($member) && $member[0]->status != 0) {
            return response()->json(['code' => -1, 'message' => '你已经提交申请，请等待']);
        }

        $res = [];
        if(count($member)) {
            $res = $serviceMember->update($member[0]->id, $data);
        } else {
            $res = $serviceMember->create($data);
        }

        $code = $res[0] ? 0 : -1;
        return response()->json(['code' => $code, 'message' => $res[0] ? '提交成功' : '系统错误']);
    }

    public function getAdmin(Request $request, ServiceRepository $serviceRepository, ServiceMemberRepository $member, ServiceOrderRepository $order, $auth = 'user', $service_type = 1)
    {
        $user = Auth::user();
        $service_type = intval($service_type);
        $members = $member->where('user_id', $user->UserId)->findAll();
        $services = ['data' => [], 'enable' => -1];
        $isChange = $request->input('change', 0);
        $member = count($members) > 0 ? $members->where('service_member_type',$auth == 'apply' ? 0 : $service_type)->first() : null;
        if($auth == 'apply' && $member == null && $members->whereIn('service_member_type',[1,2,3,4,5])->first() && $isChange==0) {
            $auth = 'provide';
            $member = $members->whereIn('service_member_type', [1, 2, 3, 4, 5])->first();
            $service_type = $member->service_member_type;
        }
        if (count($members) > 0) {
            $service_member_type = array_pluck($members->toArray(), 'service_member_type');
            if (in_array('0', $service_member_type) && $auth == 'apply') {
                $services['type'] = 'user';
                $services['data']['online'] = $order->with(['service'])->where('service_type', $service_type)
                    ->where('status','<',10)->where('apply_member_id', $member->id)
                    ->orderBy('id', 'desc')->paginate(100);
                $services['data']['online'] = $serviceRepository->format($services['data']['online']);
                $services['data']['offline'] = $order->with(['service'])->where('service_type', $service_type)
                    ->where('status', 10)->where('apply_member_id', $member->id)
                    ->orderBy('id', 'desc')->paginate(100);
                $services['data']['offline'] = $serviceRepository->format($services['data']['offline']);
                $services['data']['cancel'] = $order->with(['service'])->where('service_type', $service_type)
                    ->where('status',11)->where('apply_member_id', $member->id)
                    ->orderBy('id', 'desc')->paginate(100);
                $services['data']['cancel'] = $serviceRepository->format($services['data']['cancel']);
                $services['enable'] = $member->status;
            } else if ($auth == 'provide') {
                if (in_array($service_type, array_pluck($members->toArray(), 'service_member_type'))) {
                    $services['data'] = $order->with(['service'])->where('service_type', $service_type)
                        ->where('status','>',0)->where('provide_member_id', $member->id)
                        ->orderBy('id', 'desc')->paginate(100);
                    $services['data'] = $serviceRepository->format($services['data']);
                    $services['list'] = $serviceRepository->where('service_type',$service_type)->where('service_member_id',$member->id)
                        ->where('status','>=',0)
                        ->orderBy('id','desc')->paginate(100);
                    $services['list'] = $serviceRepository->format($services['list'],$auth);
                    $services['enable'] = $member->status;
                }
            }
        }
        if (!\View::exists('hatch.service.admin_' . $auth)) {
            return abort(501);
        }
        return view('hatch.service.admin_' . $auth, ['service_type' => $service_type, 'services' => $services, 'member' => $member]);
    }

    public function getSmsCode(Request $request) {
        $user = Auth::user();
        if (!$user || !$user->UserId) {
            return response()->json([
                'code' => -1,
                'msg' =>'未登录'
            ]);
        }
        $validators = [
            'messages'=>[
                'required' => ':attribute 不能为空',
                'phone.digits' => ':attribute 不合法 '
            ],
            'rule' => [
                'phone' =>'required|digits:11'
            ],
            'attr' => [
                'phone' =>'手机号'
            ]
        ];
        $this->validate($request,$validators['rule'],$validators['messages'],$validators['attr']);
        $phone = $request->input('phone');

        $userKey = 'Register_User_SmsCode_'.$user->UserId.'_'.$phone;
        $phoneKey = 'Register_SmsCode_'.$phone;
        $code = Redis::get($phoneKey);
        if ($code != false) {
            return response()->json([
                'code' => -1,
                'msg' =>'验证码已发送60s不能重复获取'
            ]);
        }

        for ($i =0 ;$i < 6; $i++) {
            $code .= rand(0,9);
        }

        $msg = sprintf("[腾讯GAD]您好，您正在申请入驻GAD游戏开发者平台，验证码为%s，该验证码5分钟内有效。如非本人操作，请勿泄漏。",$code);
        try {
            $ret = TofService::sendSms($phone,$msg);
            if ($ret['code'] == 0) {
                Redis::setex($phoneKey,60,$code);
                Redis::setex($userKey,300,$code);
            }
            return response()->json([
                'code' => 0,
                'msg' =>'验证码已发送'
            ]);

        }
        catch(Exception $e) {
            return response()->json([
                'code' => -1,
                'msg' =>'验证码已发送'
            ]);

        }



    }

    // 验证短信验证码
    private function validUserSmsCode($code,$phone)
    {
        $isValid = false;
        $user = Auth::user();
        if ($user) {
            $userKey = 'Register_User_SmsCode_'.$user->UserId.'_'.$phone;
            $userCode = Redis::get($userKey);
            if ($code == $userCode) {
                $isValid = true;
            }
        }

        return $isValid;
    }

    public function showList(Request $request,$os=0,$type=0,$stage=3)
    {
        //$params = $request->all();
        $data['classes'] = array();
        //12是项目扶持，这里取游戏平台和游戏类型两个二级分类的所有子类
        $pclasses = Classify::where('parent',12)->where('class_name','like','游戏%')->get();
        foreach($pclasses as $class){
            $data['classes'][$class->class_id] = Classify::where('parent',$class->class_id)->get();
            $data['classes'][$class->class_id]['name'] = $class->class_name;
        }
        $projectlist = Game::query()->where('status',0);

        if(!empty($os) && is_numeric($os)){
            $projectlist->where('os',$os);
        }
        if(!empty($type) && is_numeric($type)){
            $projectlist->where('game_type',$type);
        }
        if(is_numeric($stage) && $stage != 3){
            $projectlist->where('flow',$stage);
        }
        $projectlist->orderBy('created_at', 'desc');
        $data['projectlist'] = $projectlist->paginate(20);
        return view('hatch.list',$data);
    }

}
