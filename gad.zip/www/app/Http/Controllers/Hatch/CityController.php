<?php

namespace App\Http\Controllers\Hatch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\CityRepository;
use App\Repositories\CityActivityRepository;
use App\Repositories\CityBannerRepository;
use App\Repositories\CityNewsRepository;
use App\Repositories\CityPartnerRepository;
use App\Repositories\CityPlaceRepository;
use App\Repositories\CityProjectRepository;
use App\Repositories\CommentRepository;
use Auth;

class CityController extends Controller
{
    public function __construct(){
        $this->middleware('auth', ['only'=>['getSignup']]);
    }

    public function getDetail(CityRepository $cityRepository, CityBannerRepository $cityBannerRepository, CityNewsRepository $cityNewsRepository, CityActivityRepository $cityActivityRepository, 
            CityPlaceRepository $cityPlaceRepository, CityProjectRepository $cityProjectRepository, CityPartnerRepository $cityPartnerRepository, CommentRepository $commentRepository, $city_id = 0) {
        $city = $cityRepository->find($city_id);
        if(empty($city)){
            return abort(404);
        }
        $cities = $cityRepository->findAll();
        $banners = $cityBannerRepository->where('city_id', $city_id)->orderBy('order_no','desc')->findAll();
        $news = $cityNewsRepository->where('city_id', $city_id)->orderBy('order_no','desc')->limit(3)->findAll();
        $activities = $cityActivityRepository->where('city_id', $city_id)->orderBy('order_no','desc')->limit(3)->findAll();
        $places = $cityPlaceRepository->where('city_id', $city_id)->orderBy('order_no','desc')->findAll();
        $projects = $cityProjectRepository->where('city_id', $city_id)->orderBy('order_no','desc')->limit(3)->findAll();
        $partners = $cityPartnerRepository->where('city_id', $city_id)->orderBy('order_no','desc')->findAll();
        $comments = $commentRepository->getList(['orderBy'=>'create', 'objId'=>$city_id, 'objType'=>'App\\Entities\\City', 'page'=>0, 'pageSize'=>10], ['status'=>1])['comments'];
        return view('hatch.city.index', compact('city', 'city_id', 'cities', 'banners', 'news', 'activities', 'places', 'projects', 'partners', 'comments'));
    }
    
    public function getNewsList(CityRepository $cityRepository, CityNewsRepository $cityNewsRepository, Request $request, $city_id){
        $pageSize = 20;
        $page = $request->input('page')*1;
        $keys = ['id','logo','title','description','created_at'];
        $news = $cityNewsRepository->where('city_id', $city_id)->orderBy('order_no')->offset($page * $pageSize)->limit($pageSize)->findAll($keys);
        if ($request->ajax()) {
            return response()->json(['code' => 0, 'data' => $news]);
        }else{
            $city = $cityRepository->find($city_id);
            return view('hatch.city.news_list', compact('news', 'city'));
        }
    }
    
    public function getNewsDetail(CityRepository $cityRepository, CityNewsRepository $cityNewsRepository, $id){
        $news = $cityNewsRepository->find($id);
        $city = $cityRepository->find($news->city_id);
        $news->update(['view_count'=>$news->view_count+1]);
        return view('hatch.city.news_detail', compact('news', 'city'));
    }
    
    public function getProjectList(CityProjectRepository $cityProjectRepository, CityRepository $cityRepository, Request $request, $city_id){
        $pageSize = 20;
        $page = $request->input('page')*1;
        $projects = $cityProjectRepository->where('city_id', $city_id)->orderBy('order_no')->offset($page * $pageSize)->limit($pageSize)->findAll();
        if ($request->ajax()) {
            return response()->json(['code' => 0, 'data' => $projects]);
        }else{
            $city = $cityRepository->find($city_id);
            return view('hatch.city.project_list', compact('city', 'projects'));
        }
    }
    
    public function getActivityList(CityRepository $cityRepository, CityActivityRepository $cityActivityRepository, Request $request, $city_id){
        $pageSize = 20;
        $page = $request->input('page')*1;
        $activities = $cityActivityRepository->where('city_id', $city_id)->orderBy('order_no')->offset($page * $pageSize)->limit($pageSize)->findAll();
        if ($request->ajax()) {
            return response()->json(['code' => 0, 'data' => $activities]);
        }else{
            $city = $cityRepository->find($city_id);
            return view('hatch.city.activity_list', compact('activities', 'city'));
        }
    }
    
    public function getSignup(CityRepository $cityRepository, \App\Repositories\CityStationRepositoryEloquent $cityStationRepositoryEloquent, $city_id){
        $city = $cityRepository->find($city_id);
        $singupInfo = $cityStationRepositoryEloquent->findWhere(['user_id' => Auth::User()->UserId, 'city_id' => $city_id])->first();
        if(empty($singupInfo)){
            $singupInfo = ['city_id' => $city_id, 'id'=> '', 'type'=> 1, 'group_type'=> 2, 'name'=> '', 'position'=>'', 'qq'=> '', 'mobile'=> '', 'corp'=> '',
                    'members'=> '', 'game_name'=> '', 'game_os'=> '', 'game_type'=> '', 'description'=> '', 'game_att'=> []];
        }
        return view('hatch.city.signup', compact('city', 'singupInfo'));
    }
}
