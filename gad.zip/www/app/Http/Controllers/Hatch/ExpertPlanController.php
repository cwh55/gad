<?php

namespace App\Http\Controllers\Hatch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\ExpertPlanRepository;
use App\Repositories\ExpertCategoryRepository;
use Auth;
use Redis;

class ExpertPlanController extends Controller
{
    public function __construct(){
        $this->middleware('auth', ['only'=>['getSignup']]);
    }

    public function getIndex(ExpertPlanRepository $expertPlanEloquen) {
        $activitys = $expertPlanEloquen->getExpertPlansActivity();
        $experts = $expertPlanEloquen->getExpertList(8,'recommend');
        return view('hatch.expert_plan.index_dev', compact('activitys', 'experts'));
    }

    public function getExpert(ExpertPlanRepository $expertPlanEloquent) {
        $experts = $expertPlanEloquent->getExpertList(8);
        return view('hatch.expert_plan.index_exp', compact('experts'));
    }

    public function getExpertAll(ExpertPlanRepository $expertPlanEloquent, ExpertCategoryRepository $expertCategoryRepository) {
        $categoryList = $expertCategoryRepository->getCategoryList();
        $experts = $expertPlanEloquent->getExpertList(12);
        return view('hatch.expert_plan.expert_all', compact('experts', 'categoryList'));
    }

    public function getSignup(ExpertPlanRepository $expertPlanEloquent) {
        $expert = $expertPlanEloquent->findBy('user_id', Auth::user()->UserId);
        return view('hatch.expert_plan.signup', compact('expert'));
    }

    public function getExpertList(Request $request, ExpertPlanRepository $expertPlanEloquent, ExpertCategoryRepository $expertCategoryRepository)
    {
        $page = $request->input('page');
        $perPage = $request->input('pageSize');
        $category = $request->input('category');
        if($category){
            $expertList = $expertCategoryRepository->getExpertList($category, $perPage);
        }else{
            $expertList = $expertPlanEloquent->getExpertList($perPage);
        }
        $data = [];
        foreach($expertList as $li){
            $data[] = ['title'=>$li->title, 'avatar'=>$li->avatar, 'name'=>$li->name, 'company'=>$li->company, 'profession'=>$li->profession, 'good_at'=>$li->good_at];
        }
        return response()->json(['code' => 0, 'data' => ['data'=>$data]]);
    }

    // 验证短信验证码
    private function validUserSmsCode($code,$phone){
        $isValid = false;
        $user = Auth::user();
        if ($user) {
            $userKey = 'Register_User_SmsCode_'.$user->UserId.'_'.$phone;
            $userCode = Redis::get($userKey);
            if ($code == $userCode) {
                $isValid = true;
            }
        }
        return $isValid;
    }

    private function hatchValidate($request){
        $data = $request->all();
        $message = ['required' => ':attribute不能为空'];
        $this->validate($request,[
            'step' => 'required|integer|max:5|min:1'
        ], $message);
        if($data['step'] == 1){
            $this->validate($request,[
                'name' => 'required',
                'avatar' => 'required',
                'job' => 'required',
                'company' => 'max:50',
                'profession' => 'max:50',
                'account' => 'array',
                'meeting' => 'array',
                'wish' => 'required'
            ], $message);
        } else if($data['step'] == 2){
            $this->validate($request,[
                'email' => 'required|email',
                'phone' => 'required'
            ], $message);
            if (!$this->validUserSmsCode($data['SMSCode'], $data['phone'])) {
                throw new \Exception('验证码不正确');
            }
        } else {
          throw new \Exception('非法');
        }
    }

    public function postSave(Request $request, ExpertPlanRepository $expertPlanEloquent)
    {
        $this->hatchValidate($request);
        $data = $request->all();
        $data['wish'] = empty($data['wish']) || !is_array($data['wish']) ? [] : $data['wish'];
        $data['meeting'] = empty($data['meeting']) || !is_array($data['meeting']) ? [] : $data['meeting'];
        $data['account'] = empty($data['account']) || !is_array($data['account']) ? [] : $data['account'];
        //$data = array_map('xssFilter', $data);
        $userId = Auth::user()->UserId;
        $expertPlan = $expertPlanEloquent->findBy('user_id', $userId);
        if (empty($expertPlan)) {
            $data['user_id'] = $userId;
            $data['status'] = 1;
            $data['step'] = 2;
            if(!$expertPlan = $expertPlanEloquent->create($data)){
                throw new \Exception('更新数据失败');
            }
            $expertPlan = $expertPlan[1];
        }else{
            if($expertPlan->step >= 3){
                return response()->json(['code' => -1, 'message' => '不能修改']);
            }
            if($data['step'] == 2){
                $data['step'] = 3;
            }
            unset($data['user_id'], $data['status']);
            if(!$expertPlanEloquent->update($expertPlan->id,$data)){
                throw new \Exception('更新数据失败');
            }
        }
        if(!empty($expertPlan) && $data['step']==3){
            $title = '[GAD专家团]感谢你申请加入专家团，请耐心等待审核结果';
            $mail = view('hatch.expert_plan.mail_signup', array('user'=>$expertPlan->name,'title'=>$title))->render();
            \Tof::service('message')->sendEmail('gad@tencent.com', $data['email'], $title, $mail);
        }
        return response()->json(array('code' => 0, 'data' => ''));
    }
}
