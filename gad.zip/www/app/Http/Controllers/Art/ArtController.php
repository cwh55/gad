<?php

namespace App\Http\Controllers\Art;

use Illuminate\Http\Request;
use App\Gad\Upload;
use App\Gad\QcloudApi;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\ArtWork;
use Auth;
use App\Models\Summercourse;
use App\Models\Worktype;
use Cache;

class ArtController extends Controller
{

    //构造函数
    public function __construct(Request $request) {
        //系统管理员和作者有权限修改
        if($request->is('art/edit/*')) {
            $id = $request->id;
            if(is_numeric($id) && ($id>0)) {
                $artwork = ArtWork::findOrFail($id);
                $userId = $artwork->user_id;
                $this->middleware("acl:art::edit,user_id=".$userId, ['only'=>['getEdit', 'postEdit']]);
            }
        }
    }

    //创建美术作品
    public function getCreate(Request $request) {
    	if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $artwork = new ArtWork;

        //判断白名单
        $artworkData = $request->all();
        if(empty($artworkData['classid'])) {
            return view('errors.msg', ['message'=>'classid参数缺少']);
        }
        $sc = new Summercourse();
        $artworkData['channel_id'] = floor($artworkData['classid']/100);
        if(!$sc->getWhitelist($artworkData['channel_id'])) {
            return view('errors.msg', ['message'=>'非白名单用户']);
        }

    	return view('art.edit', compact('artwork'));
    }

    public function postUploadImage(Request $request)
    {
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }

        $file = $request->file('file');
        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '上传失败：图片太大或格式不对']);
        }

        $result = Upload::uploadQcloudImage($file);
        
        return response()->json($result);
    }

    //编辑美术作品
    public function getEdit(Request $request, $id) {
		if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        if(empty($id) || !is_numeric($id)) {
            return view('errors.msg', ['message'=>'ID参数错误']);
		}

		$artwork = ArtWork::findOrFail($id);
		if(!empty($artwork['content'])) {
			$artwork['content'] = json_decode($artwork['content'], true);
		}
    	return view('art.edit', compact('artwork'));
    }

    //新建保存作品
    public function postCreate(Request $request) {
    	if (!Auth::check()) {
            return redirect()->guest('/login');
        }
    	$artwork = new ArtWork;

    	$rule = [
    		'title' => 'required',
    		'description' => 'required',
    		'content' => 'required',
    		'label' => 'required',
            'class_id' => 'required'
    		];
    	$message = ['required' => ':attribute 不能为空'];
    	//校验类型
    	$this->validate($request, $rule, $message);
        $sc = new Summercourse();
    	$artworkData = $request->all();
        $artworkData['channel_id'] = floor($artworkData['class_id']/100);
        if(!$sc->getWhitelist($artworkData['channel_id'])) {
            return response()->json(['code'=>423, 'msg'=>'非白名单用户'], 423);
        }
        $artworkData['user_id'] = Auth::user()->UserId;
        $artworkData['cover'] = !empty($artworkData['content'][0]) ? $artworkData['content'][0] : '';
        $artworkData['content'] = json_encode(xssFilter($artworkData['content']));
        $artwork->fill($artworkData);
        $artwork->save();
        
        return response()->json($artwork);
    }

    //编辑保存作品
    public function postEdit(Request $request, $id) {
    	if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $artwork = ArtWork::findOrFail($id);
        
        $artworkData = $request->all();
        $artworkData['cover'] = !empty($artworkData['content'][0]) ? $artworkData['content'][0] : '';
        $artworkData['content'] = json_encode(xssFilter($artworkData['content']));
        $artworkData['user_id'] = Auth::user()->UserId;
        $artwork->fill($artworkData);
        $artwork->save();

        return response()->json($artwork);
    }

    //作业列表展示页
    public function showList(Request $request) {
        //拉取分类下的所有兄弟分类
        $params = $request->all();
        if(empty($params['classid'])) {
            return response()->json(['code'=>-1, 'msg'=>'classid参数为空']);
        }
        if(!is_numeric($params['classid']) || ($params['classid']<0)) {
            return response()->json(['code'=>-1, 'msg'=>'classid参数错误']);
        }
        $classid = $params['classid'];
        $channel = floor($classid/100);
        
        $key = 'classifiy_'.$channel;
        $list = Cache::remember($key, 10, function() use ($channel)  {
            return Worktype::with('classify')->where('class_id', '>=', $channel*100+1)
                            ->where('class_id', '<=', $channel*100+99)
                            ->orderBy('created_at', 'desc')
                            ->take(8)
                            ->get();                   
        }); 
        
        return view('art.list', ['classes'=>$list, 'class_id'=>$classid]);
    }

    //作业列表瀑布,传入参数 classid
    public function getList(Request $request) 
    {
        $artwork = new ArtWork;
        $params = $request->all();
        $classId = $params['id'];

        $pageSize = 12;
        $key = 'artwork_list_'.$params['id'].'_'.$params['page'].'_'.$pageSize;

        if ($params['order'] == 'new') {
            $order = 'created_at';
        } else {
            $order = 'view_cnt';
        }

        $list = Cache::remember($key, 10, function() use ($artwork, $order, $pageSize, $classId)  {
            return $artwork->with('user')->where('class_id', '=', $classId)->orderBy($order, 'desc')->paginate($pageSize);                     
        }); 
        
        return response()->json($list);
    }

    //作品详情页
    public function getDetail($id){

        $artwork = ArtWork::findOrFail($id);
        $author = $artwork->user;
        $artwork->Liked = $artwork->is_liked;
        $artwork->Favored = $artwork->is_favored;
        $artwork->labels = explode(',',$artwork->label);
        $classify = $artwork->classify ;
        $artwork->className = $classify !=null ? $classify->class_name :'';
        //更新浏览数
        $artwork->increment('view_cnt',1);
        $pictures = \GuzzleHttp\json_decode($artwork->content,true);


        return view('art.detail',compact('artwork','pictures','author'));

    }

}


