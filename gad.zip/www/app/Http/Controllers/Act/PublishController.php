<?php

namespace App\Http\Controllers\Act;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;



class PublishController extends Controller
{
    public function getOrgteam ()
    {
        $isValid = Auth::check() ? Auth::user()['is_valid'] : 0;
        return view('act.orgteam', array('isValid'=>$isValid));
    }
}