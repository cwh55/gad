<?php

namespace App\Http\Controllers\Act;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Actconfig;
use App\Models\Actgain;
use App\Models\User;
use Redis;
use Auth;

define('DAKA_REDIS_KEY', 'gad:act:jnh:tutors');
define('QUESTION_REDIS_KEY', 'gad:act:jnh:questions');
define('DATE_DAKAID_REDIS_KEY', 'gad:act:jnh:date:tutor');

define('REDIS_USER_QQ_WHITELIST', 'gad:act:user:jnh:qqwhitelist');
define('REDIS_JNH_USER_CNT', 'gad:act:jnh:user:cnt');
define('REDIS_JNH_WL_USER_CNT', 'gad:act:jnh:wluser:cnt');
define('REDIS_USER_QA_RECORD_LIST', 'gad:act:jnh:qalist:%d');
define('REDIS_USER_QA_DAILY_RECORD', 'gad:act:jnh:qadaily:%d');
define('REDIS_USER_JNH_SIGN_SUCC', 'gad:act:jnh:sign:succ:%d');
define('REDIS_USER_SIGN_SUCC_STAT', 'gad:act:jnh:sign:succ:stat');
define('REDIS_USER_GAIN_PRIZE_STAT', 'gad:act:jnh:prize:stat');
define('REDIS_USER_DRAW_PRIZE', 'gad:act:jnh:zige:%d');
define('REDIS_JNH_GAIN_USER_STAT', 'gad:act:jnh:gain:user:%s');
define('REDIS_JNH_USER_PRIZE', 'gad:act:jnh:user:prize:%d');
define('REDIS_USER_GAIN_LIST', 'gad:act:jnh:gain:list');
define('REDIS_USER_IPHONE_LIST', 'gad:act:jnh:iphone:list');
define('REDIS_USER_PRIZE_ZIGE', 'gad:act:jnh:prize:zige:%d');


class ActController extends Controller
{
    private $prizeArr = array(
        '2' => array('num' =>  6000, 'per' => 1, 'type' => 'p1'),
        '5' => array('num' =>  1500, 'per' => 2, 'type' => 'p2'),
        '9' => array('num' =>  1200, 'per' => 3, 'type' => 'p3'),
        '14' => array('num' =>  1000, 'per' => 5, 'type' => 'p4'),
        '21' => array('num' =>  800, 'per' => 8, 'type' => 'p5'),
        '30' => array('num' =>  400, 'per' => 10, 'type' => 'p6'),
        '40' => array('num' =>  150, 'per' => 20, 'type' => 'p7'),
    );

    private $prizeType = array(
        'p1' => array('name' => 'Q币', 'per' => 1),
        'p2' => array('name' => 'Q币', 'per' => 2),
        'p3' => array('name' => 'Q币', 'per' => 3),
        'p4' => array('name' => 'Q币', 'per' => 5),
        'p5' => array('name' => 'Q币', 'per' => 8),
        'p6' => array('name' => 'Q币', 'per' => 10),
        'p7' => array('name' => 'Q币', 'per' => 20),
        'p8' => array('name' => '20Q币', 'per' => 1),
        'p9' => array('name' => '猴年公仔', 'per' => 1),
        'p10' => array('name' => 'GAD背包', 'per' => 1),
        'p11' => array('name' => '移动电源', 'per' => 1),
        'p12' => array('name' => '文化衫', 'per' => 1),
        'p13' => array('name' => 'iPhone6', 'per' => 1),
        'p14' => array('name' => 'iPhone7plus', 'per' => 1),
    );


    private $user = array();
    private $todayQa = '';
    private $redis = null;

    public function __construct() {
        $this->redis = Redis::connection('act');
    }
    
    public function index(Request $request,$flag=0)
    {
        $data = [];
        if($flag){
            $data['isRule'] = 1;
        }else{
            $data['isRule'] = 0;
        }

        $data['dakalist'] = [];
        $user = Auth::user();
        $data['user'] = $user;
        $data['errnum'] = 0;
        $prizejson = $this->getGainPrizeList();
        $data['prizelist'] = [];
        if(!empty($prizejson)){
            foreach($prizejson as $prize){
                $oneprize = json_decode($prize);
                if(in_array($oneprize->type,array('p1','p2','p3','p4','p5','p6','p7'))){
                    $strEnd = $oneprize->num.$this->prizeType[$oneprize->type]['name'];
                }else{
                    $strEnd = $this->prizeType[$oneprize->type]['name'].$oneprize->num.'个';
                }
                $qqstr1 = substr_replace($oneprize->qq,'****',(int)(strlen($oneprize->qq)/2-2),4);//strlen($oneprize->qq)/2;
                $prizestr = $qqstr1."获得".$strEnd;
                array_push($data['prizelist'],$prizestr);
            }
        }

        if(!empty($user)){
            $heartlist = $this->getSendHeartsList($user['QQNo']);
            $data['heartCount'] = $this->getSendHearts($user['QQNo']);
            $data['errnum'] = $this->getQARights($user['QQNo']);
            $data['qbnum'] = $this->getUserPrizeCnt($user['QQNo']);
        }else{
            $data['heartCount'] = 0;
            $data['errnum'] = 0;
            $data['qbnum'] = 0;
        }

        $dakalist = $this->redis->hgetall(DAKA_REDIS_KEY);
        if(empty($dakalist)){

        }else{
            foreach($dakalist as $daka){
                $item = json_decode($daka);
                $time = strtotime($item->date);
                $item->month = date('m',$time);
                $item->day = date('d',$time);
                if(date('Y-m-d',strtotime($item->date))==date('Y-m-d',time())){
                    $item->isToday = 1;
                }else{
                    $item->isToday = 0;
                }
                if(!empty($user)){
                    if(in_array(date('Ymd',strtotime($item->date)),$heartlist)) //判断这个嘉宾有没有被送过心
                        $item->status = 1;
                    else
                        $item->status = 0;
                }else{
                    $item->status = 0;
                }

                array_push($data['dakalist'],$item);
            }
            //按照日期进行排序
            usort($data['dakalist'],function($a,$b){
                if($a->date > $b->date){
                    return 1;
                }else{
                    return 0;
                }
            });
        }
        if(!empty($user)) {
            $data['prizetimes'] = $this->getDrawPrizeZige($user['QQNo']);
        }else{
            $data['prizetimes'] = 0;
        }

        return view('act.jianianhua.index', $data);
    }



    public function rule(Request $request)
    {
        return $this->index($request,1);
    }
    //更新redis
    public function updateConfig(Request $request)
    {
        $type = $request->input('type');
        if($type){ //大咖信息
            $rediskey = "gad:act:jnh:tutors";
        }else{  //问题信息
            $rediskey = "gad:act:jnh:questions";
        }
        $itemlist = Actconfig::query()
            ->where('status', 0)
            ->where('act_id', 1)
            ->where('type',$type)
            ->orderBy('date','asc')
            ->get(['id','title','content','answer','img','date']);

        foreach($itemlist as $item){
            $this->redis->hSet($rediskey,$item['id'],json_encode($item));
            if($type){
                $this->redis->hSet(DATE_DAKAID_REDIS_KEY,date('Ymd',strtotime($item['date'])),$item['id']);
            }
        }
        return response()->json([
            'code' => 0,
            'msg' =>'信息发布成功'
        ]);
    }

    public function givePrize(Request $request){
        $user = $this->checkLogin();
        if(!(is_numeric($request->input('qid')) && is_numeric($request->input('aid')))){
            $ret['code'] = -1;
            $ret['msg'] = "参数非法";
        }else{
            $ret = $this->checkAnswer($request->input('qid'),$request->input('aid'),$user['QQNo']);
            $ret['question'] = '';
            if($ret['code']=="111" && ($ret['msg']==1 || $ret['msg']==2)){      //如果是打错题且还有答题机会的，直接拉取下一道题目。
                $ret['question'] = $this->answer(true);
            }
        }

        return response()->json($ret);
    }

    public function checkLogin() {
        $user = Auth::user();
        if (!$user) {
            $ret['code'] = -1;
            $ret['msg'] = '未登录';
            return response()->json($ret);
        }
        return $user;
    }


    /*
     * 获取用户是否参与活动
     */
    public function getUseActStatus() {
        $ret = -1;
        $data = 0;
        $user = $this->checkLogin();
        if(isset($user->UserId) && $user->QQNo) {
            $date = date('Ymd');
            $dailyKey = sprintf(REDIS_USER_QA_DAILY_RECORD, $user->QQNo);
            $status = $this->redis->hGet($dailyKey, $date);
            if($status > 0) {
                $ret = 0;
            }
        }

        return response()->json(array('code' => $ret));
    }

    /*
     *  获取每日答题题目
     */
    public function answer($returntype = false) {
        $user = $this->checkLogin();
        $uin = isset($user->QQNo) ? $user->QQNo : null;

        $ret = -1;
        $data = array();

        if(!empty($uin) && $uin > 10001 && $this->checkQARights($uin)===0) {
            $qk = "gad:act:jnh:questions";
            $allQids = $this->redis->hKeys(QUESTION_REDIS_KEY);

            if(!empty($allQids)) {
                $ak = "gad:act:jnh:qalist:{$uin}";
                $ak = sprintf(REDIS_USER_QA_RECORD_LIST, $uin);
                $userQids = $this->redis->sMembers($ak);

                if (empty($userQids)) {
                    $questions = $allQids;
                } else {
                    $questions = array_diff($allQids, $userQids);
                }

                // 每次随机抽取1道题
                $randKey = array_rand($questions);

                $temp = $question = array();
                if(isset($questions[$randKey])) {
                    $temp = $this->redis->hGet($qk, $questions[$randKey]);

                    $question = \GuzzleHttp\json_decode($temp);
                    unset($question->answer);

                    $data = \GuzzleHttp\json_encode($question);
                    $ret = 0;
                } else {
                    $ret = -1;
                }
            }
        }
        if($returntype)
            return json_encode(array('code' => $ret, 'data' => $data));
        else
            return response()->json(array('code' => $ret, 'data' => $data));
    }

    /*
     * 获取最近中奖用户列表
     * @return array
     */
    public function getGainPrizeList() {

        $count = $this->redis->lLen(REDIS_USER_GAIN_LIST);
        $icount = $this->redis->lLen(REDIS_USER_IPHONE_LIST);

        $list = $res = array();
        $ret = -1;
        if($count > 0 && $count <=49) {
            $list = $this->redis->lRange(REDIS_USER_GAIN_LIST, 0, $count);
            $ret = 0;
        } else {
            $list = $this->redis->lRange(REDIS_USER_GAIN_LIST, 0, 49);
            $ret = 0;
        }

        if($icount > 0) {
            $ilist = $this->redis->lRange(REDIS_USER_IPHONE_LIST, 0, $icount);
            $list = array_merge($ilist, $list);
        }

        return $list;//response()->json(array('code' => $ret, 'data' => $list));

    }

    /*
     * 判断是否可答题
     * @return int (0可答题/101已成功签到送心/110答题次数已达到上限/-1参数错误)
     */
    protected function checkQARights($uin) {
        if(!empty($uin)) {
            $dailyKey = sprintf(REDIS_USER_QA_DAILY_RECORD, $uin);
            $date = date('Ymd');
            $qa = $this->redis->hGet($dailyKey, $date);
            $this->todayQa = empty($qa) ? 0 : $qa;
            if($this->todayQa % 10 == 1) {
                return 101;
            }
            if($this->todayQa < 1000) {
                return 0;
            } else {
                return 110;
            }
        }
        return -1;
    }

    /*
     * 判断答题情况
     * @return int (0/1/2/3答错次数，9成功，-1其他错误)
     */
    protected function getQARights($uin) {
        if(!empty($uin)) {
            $dailyKey = sprintf(REDIS_USER_QA_DAILY_RECORD, $uin);
            $date = date('Ymd');
            $this->todayQa = $this->redis->hGet($dailyKey, $date);

            if($this->todayQa % 10 == 1) {
                return 9;
            }
            if($this->todayQa <= 1000) {
                $cnt = strlen($this->todayQa);
                return $cnt == 0 ? 0 : $cnt - 1;
            }
        }
        return -1;
    }

    /*
     * 校验答案
     */
    protected function checkAnswer($qid, $aid, $uin) {
        $ret = -1;
        $type = $msg = $cnt = '';
        $ret = $this->checkQARights($uin);

        // 判断是否有答题资格
        if($ret === 0) {
            $aKey = "gad:act:jnh:qalist:{$uin}";
            $alKey = sprintf(REDIS_USER_QA_RECORD_LIST, $uin);

            $temp = $temp1 = $data = array();
            $temp = $this->redis->sIsmember($alKey, $qid);
            // 是否是重复提交
            if(empty($temp)) {
                $qKey = "gad:act:jnh:questions";
                $temp1 = $this->redis->hGet(QUESTION_REDIS_KEY, $qid);
                // 问题id是否题库中的id
                if(!empty($temp1)) {

                    // 保存用户所有答题记录
                    $this->redis->sAdd($alKey, $qid);

                    $data = \GuzzleHttp\json_decode($temp1);

                    // 判断当天次数限制及是否答对
                    if ($aid == $data->answer) {
                        // 答对签到成功
                        $this->setSendHearts($uin);

                        // 每日答题记录
                        $qavalue = empty($this->todayQa) ? 1 : $this->todayQa.'1';
                        $this->setDailyQA($uin, $qavalue);

                        // 答对进入对应的送qb逻辑/获得抽奖资格
                        $heartCnt = $this->getSendHearts($uin);
                        $award = $this->awardRules($heartCnt, $uin);
                        if($award && is_array($award)) {
                            // 获取qb奖励或抽奖资格
                            list($type, $cnt) = $award;
                        }

                        // 默认答对ret为0

                    } else {
                        $ret = 111;     //答题错误
                        $qavalue = empty($this->todayQa) ? 10 : $this->todayQa.'0';

                        // 每日答题记录
                        $this->setDailyQA($uin, $qavalue);
                    }

                } else {
                    $ret = -1;  //非正常问题id
                }
            } else {
                $ret = 112; //重复答题
            }
        }

        // 返回答题状态及今日答题次数
        return array('code' => $ret, 'msg' => strlen($this->todayQa), 'type' => $type, 'cnt' => $cnt);
    }

    /*
     * 每日答题记录
     */
    protected function setDailyQA($uin, $value) {
        if($uin > 10000 && $value) {
            $date = date('Ymd');
            $dailyKey = sprintf(REDIS_USER_QA_DAILY_RECORD, $uin);
            return $this->redis->hSet($dailyKey, $date, $value);
        }
        return false;
    }

    /*
     * 签到送心成功
     */
    protected function setSendHearts($uin) {
        if($uin > 10000) {
            $date = date('Ymd');
            $succKey = sprintf(REDIS_USER_JNH_SIGN_SUCC, $uin);
            return $this->redis->sAdd($succKey, $date);
        }
        return false;
    }

    /*
     * 获取送心个数
     */
    protected function getSendHearts($uin) {
        if($uin > 10000) {
            $succKey = sprintf(REDIS_USER_JNH_SIGN_SUCC, $uin);
            return $this->redis->sCard($succKey);
        }
        return 0;
    }

    /*
     * 获取用户送心列表
     */
    protected function getSendHeartsList($uin) {
        if($uin > 10000) {
            $succKey = sprintf(REDIS_USER_JNH_SIGN_SUCC, $uin);
            return $this->redis->sMembers($succKey);
        }
        return array();
    }

    /*
     * 送心奖励及签到规则
     * @return array (102获得QB，103获得抽奖资格)
     */
    protected function awardRules($cnt, $uin) {
        if($cnt >=1 && $cnt <=45 && $uin > 10000) {
            // 记录达到条件用户数
            $this->setSendHeartStat($cnt);
        }
        if(!in_array($cnt, array(2, 5, 9, 14, 15, 21, 30, 40)) || $uin <= 10000) {
            return false;
        }

        switch($cnt) {
            case 15:    // 加入抽奖逻辑
            case 30:
            case 45:    
                // 累计签到15天获取1次抽奖资格
                $ret = $this->setDrawPrizeZige($uin);
                $this->setGainPrizeUser($cnt, $uin);
                return array('cj', 1);
                break;
            default:
                if(!$this->getUserStatus($uin)) {
                    return false;
                }
                $sentCnt = $this->getPrizeStat($cnt);
                $total = $this->prizeArr[$cnt]['num'];
                // 判断是否达到奖励上限
                if($sentCnt < $total) {
                    // 进入送qb逻辑
                    $ret = $this->qbAward($cnt, $uin);
                    // 成功中奖QB（状态码102，cnt QB数量）
                    if($ret) {
                        return array('qb', $this->prizeArr[$cnt]['per']);
                    }
                }
                return false;
        }

    }

    /*
     * 记录获取抽奖资格的用户
     */
    protected function setGainPrizeUser($cnt, $uin) {
        $key = sprintf(REDIS_USER_SIGN_SUCC_STAT, $cnt);

        return $this->redis->sAdd($key, $uin);
    }

    /*
     * 记录达到条件用户数
     */
    protected function setSendHeartStat($cnt) {
        if($cnt) {
            $field = 'd'.$cnt;
        } else {
            $field = 'd0';
        }

        return $this->redis->hIncrby(REDIS_USER_SIGN_SUCC_STAT, $field, 1);
    }

    /*
     * 获取已送出奖品份数
     */
    protected function getPrizeStat($type) {
        if($type) {
            if (in_array($type, array('p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10', 'p11', 'p12', 'p13', 'p14', 'p15'))) {
                $field = $type;
            } else {
                $field = $this->prizeArr[$type]['type'];
            }
            if ($field) {
                return $this->redis->hGet(REDIS_USER_GAIN_PRIZE_STAT, $field);
            }
        }

        return 0;
    }

    /*
     * 送QB/抽奖统计记录
     */
    protected function gainPrizeStat($type, $uin) {
        if($type && $uin > 10000) {
            if (in_array($type, array('p8', 'p9', 'p10', 'p11', 'p12', 'p13', 'p14', 'p15'))) {
                $field = $type;
            } else {
                $field = $this->prizeArr[$type]['type'];
            }
            if ($field) {
                $upKey = sprintf(REDIS_JNH_USER_PRIZE, $uin);
                $this->redis->hIncrby($upKey, $field, 1);
                $ret = $this->redis->hIncrby(REDIS_USER_GAIN_PRIZE_STAT, $field, 1);

                if($field != 'p15') {
                    $this->setUserPrize($field, $uin);
                    // 记录db
                    $this->recordPrizeDB($field, $uin);
                }
                return $ret;
            }
        }
        return 0;
    }

    /*
     * 送QB/抽奖统计记录
     */
    protected function recordPrizeDB($field, $uin) {
        if($field && $uin > 10000) {
            // 记录db
            $user = Auth::user();
            if(isset($user->UserId)) {
                $actgain = Actgain::query()->where('act_id', 1)->where('user_id', $user->UserId)->first();

                if (!empty($actgain) &&  $actgain->$field >= 0) {
                    $actgain->$field = $actgain->$field + 1;
                    $actgain->save();
                } else {
                    $actgain = new Actgain;
                    $data = array(
                        'act_id' => 1,
                        'user_id' => isset($user->UserId) ? $user->UserId : 0,
                        'uin' => $user->QQNo,
                        $field => 1,
                    );

                    $actgain->fill($data);
                    $actgain->save();
                }
            }
        }
    }

    /*
     * AMS抽奖中奖回调
     */
    public function amsPrizeStat(Request $request) {
        $data = $request->all();
        $user = $this->checkLogin();
        $uin = $user['QQNo'];
        $prizeType = $data['type'];
        $ret = -1;
        if($uin > 10000 && in_array($prizeType, array('p8','p9','p10','p11','p12','p13','p14','p15'))) {
            $times = $this->getDrawPrizeZige($uin);
            if($times == 1 || $times == 2) {
                $this->gainPrizeStat($prizeType, $uin);
                $this->setDrawPrizeZige($uin, -1);
                $ret = 0;
            }
        }

        return array('code' => $ret);
    }

    /*
     * 抽奖资格记录
     */
    protected function setDrawPrizeZige($uin, $by=1) {
        if($uin > 10000) {
            $kPf = $uin % 10;
            $zgKey = sprintf(REDIS_USER_DRAW_PRIZE, $kPf);
            $ret = $this->redis->hIncrby($zgKey, $uin, $by);
            return ($ret < 0 || $ret > 2) ? 0 : $ret;
        }
        return 0;
    }

    /*
     * 获取抽奖资格
     */
    protected function getDrawPrizeZige($uin) {
        if($uin > 10000) {
            $kPf = $uin % 10;
            $zgKey = sprintf(REDIS_USER_DRAW_PRIZE, $kPf);
            $ret = $this->redis->hGet($zgKey, $uin);
            return ($ret > 0 && $ret <= 2) ? $ret : 0;
        }
        return 0;
    }

    /*
     * 获取用户量
     */
    protected function getUserCnt() {
        return $this->redis->get(REDIS_JNH_USER_CNT);
    }

    /*
     * 送QB策略
     */
    protected function qbAward($cnt, $uin) {
        $stat = $this->getWhiteUserStatus($uin);
        if ($cnt == 2 && $stat) {
            // 符合用户群1的直接奖励qb
            return $this->gainPrizeStat($cnt, $uin);

        } else {// 其它用户进入随机送QB逻辑
            $userCnt = $this->getUserCnt();
            if($cnt == 2) {
                $prizeCnt = $this->prizeArr[$cnt]['num']/6;
            } else {
                $prizeCnt = $this->prizeArr[$cnt]['num'];
            }
            $randMaxNum = intval($userCnt / $prizeCnt);
            //$randMaxNum = 2;
            $rand = rand(1, $randMaxNum);

            if ($rand == $randMaxNum) {
                return $this->gainPrizeStat($cnt, $uin);
            }
        }

        return false;
    }

    /*
     * 获取白名单用户
     */
    protected function getWhiteUserStatus($uin) {
        $userType = $this->getUserType($uin);
        // 符合用户群1的判断是否满额
        $total = $this->redis->get(REDIS_JNH_WL_USER_CNT);
        if ($userType == 1 && $total < 5000) {
            $this->redis->incr(REDIS_JNH_WL_USER_CNT);
            return true;
        } else {
            return false;
        }
    }
        /*
         * 记录中奖用户及记录流水
         */
    protected function setUserPrize($cnt, $uin) {
        if (in_array($cnt, array('p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10', 'p11', 'p12', 'p13', 'p14', 'p15'))) {
            $type = $cnt;
        } else {
            $type = $this->prizeArr[$cnt]['type'];
        }
        if(isset($type)) {
            $key = sprintf(REDIS_JNH_GAIN_USER_STAT, $type);

            $this->redis->sAdd($key, $uin);

            $list = array(
                'qq' => $uin,
                'type' => $type,
                'num' => $this->prizeType[$type]['per'],
                'date' => date('Y-m-d H:i:s'),
            );

            if(in_array($cnt, array('p13', 'p14'))) {
                $this->redis->lPush(REDIS_USER_IPHONE_LIST, json_encode($list));
            } else {
                $this->redis->lPush(REDIS_USER_GAIN_LIST, json_encode($list));
            }
        }
    }

    /*
     * 获取用户得到的每项奖励数
     */
    protected function getUserPrizeCnt($uin, $type='qb') {
        if($type && $uin > 10000) {
            $qbArr = array('p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7');
            $cjArr = array('p8', 'p9', 'p10', 'p11', 'p12', 'p13', 'p14', 'p15');

            $upKey = sprintf(REDIS_JNH_USER_PRIZE, $uin);

            if($type == 'qb' || in_array($type, $qbArr)) {

                $res = $this->redis->hMget($upKey, $qbArr);
                $ret = array_combine($qbArr, $res);
                if(!empty($ret)) {
                    $sum = 0;
                    foreach($ret as $key => $val) {
                        if(!empty($val) && isset($this->prizeType[$key]['per'])) {
                            $sum += $val * $this->prizeType[$key]['per'];
                        }
                    }
                    return $sum;
                }
            } else if (in_array($type, $cjArr)) {

                return $this->redis->hGet($upKey, $cjArr);
            }
        }

        return 0;
    }

    protected function getUserType($uin) {
        if($uin > 10000) {
            return $this->redis->sIsmember(REDIS_USER_QQ_WHITELIST, $uin);
        }
        return 0;
    }

    protected function getUserStatus($uin) {
        $user = $this->checkLogin();
        if(isset($user->QQNo) && $user->Created<'2016-11-17 00:00:00') {
            return true;
        }
        return false;
    }

    public function testApi() {
        $cnt = 3;
        $uin = 11000;
        //$data = $this->awardRules($cnt, $uin);

        //return response()->json($data);
    }
}