<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-7-8
 * Time: 下午4:26
 */

namespace App\Http\Controllers\Operate;

use App\Http\Controllers\Controller;
use App\Http\Requests;
use App\Models\Favorite;
use Auth;
use Illuminate\Http\Request;

class FavoriteController extends  Controller
{
    /**
     * 收藏和取消收藏操作
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function postOperate(Request $request)
    {
        $ret = [
            'code' => 0,
            'msg' => '成功'
        ];
        $objId = $request->input('objid');
        $objType = $request->input('objtype');
        $action = $request->input('action');
        //参数检查
        if (!$objId || !is_numeric($objType) || !in_array($action,['favor','unfavor'])) {
            $ret['code'] = -1;
            $ret['msg'] = '参数不正确';
            return response()->json($ret);
        }
        $user = Auth::user();
        //判断用户是否登录
        if (!$user || !$user->UserId) {
            $ret['code'] = -1;
            $ret['msg'] = '未登录';
            return response()->json($ret);
        }

        //获取操作记录
        $favorite = Favorite::where('obj_id',$objId)
            ->where('obj_type',$objType)
            ->where('user_id',$user->UserId)
            ->first();
        $status = $action == 'favor'? 0:1;
        //操作记录存在
        if ($favorite) {
            $favorite->update(['status'=>$status]);
        }
        else if ($status == 0) {
            $favorite = Favorite::create([
                'obj_id' => $objId,
                'obj_type' => $objType,
                'user_id' => $user->UserId
            ]);
        }
        else {
            $ret['code'] = -1;
            $ret['msg'] = '操作异常';
            return response()->json($ret);
        }

        //更新收藏数
        if ($favorite) {
            $operateObj = $favorite->getOperateObj();
            if ($operateObj && isset($operateObj->fav_cnt)){
                if ($status == 0){
                    $operateObj->increment('fav_cnt',1);
                }
                else {
                    $operateObj->decrement('fav_cnt',1);
                }
            }
            return response()->json($ret);
        }

    }

} 