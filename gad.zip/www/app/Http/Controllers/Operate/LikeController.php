<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-7-8
 * Time: 上午10:41
 */

namespace App\Http\Controllers\Operate;

use App\Gad\Func;
use App\Gad\MessageType;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use App\Models\Like;
use Auth;
use Illuminate\Http\Request;

class LikeController extends Controller
{
    //0赞,1取消,2 踩
    public function postOperate(Request $request)
    {
        $ret = [
            'code' => 0,
            'msg' => '成功'
        ];
        $objId = $request->input('objid');
        $objType = $request->input('objtype');
        $action = $request->input('action');
        $actValues = [
            'like'=> 0,
            'unlike'=>1,
            'step'=>2
        ];
        //参数检查
        if (!$objId || !is_numeric($objType) || !in_array($action,['like','unlike','step'])) {
            $ret['code'] = -1;
            $ret['msg'] = '参数不正确';
            return response()->json($ret);
        }

        //判断用户是否登录
        $user = Auth::user();
        if (!Auth::check()) {
           $ret['code'] = -1;
           $ret['msg'] = '未登录';
           return response()->json($ret);
        }

        //获取操作记录
        $oldLike = Like::where('obj_id',$objId)
            ->where('obj_type',$objType)
            ->where('user_id',$user->UserId)
            ->first();

        //操作记录存在
        if ($oldLike) {
            //重复操作返回
            if ($oldLike->status == $actValues[$action]) {
                $ret['code'] = -1;
                $ret['msg'] = '参数不正确';
                return response()->json($ret);
            }
            //已赞现在为踩或取消操作，原赞数要减一
            if (
                in_array($actValues[$action],[1,2])
                && $oldLike->status == $actValues['like']
            ) {
                $operateObj = $oldLike->getOperateObj();
                if ($operateObj && isset($operateObj->aye_cnt)){
                    $operateObj->decrement('aye_cnt',1);
                    $ret['aye_cnt'] = $operateObj->aye_cnt;
                }
            }
            else if ($actValues[$action] == 0) {
                $operateObj = $oldLike->getOperateObj();
                if ($operateObj && isset($operateObj->aye_cnt)){
                    $operateObj->increment('aye_cnt',1);
                    $ret['aye_cnt'] = $operateObj->aye_cnt;
                }
            }
            $oldLike->update(['status'=>$actValues[$action]]);

            return response()->json($ret);
        }
        else  {
            $like = Like::create([
                'obj_id' => $objId,
                'obj_type' => $objType,
                'user_id' => $user->UserId,
                'status'=>$actValues[$action]
            ]);
            //更新点赞数
            if ($like) {
                $operateObj = $like->getOperateObj();
                if ($operateObj && isset($operateObj->aye_cnt)){
                    if ( $actValues[$action] == 0){
                        $operateObj->increment('aye_cnt',1);
                    }
                    $ret['aye_cnt'] = $operateObj->aye_cnt;
                }
				if($objType == 4 && $operateObj){//消息提醒
					Func::msgApi(MessageType::DAKA_ANSWER_LIKE,$operateObj->user_id,$user->UserId,$operateObj->id,'http://gad.qq.com/wenda/detail/'.$operateObj->question_id,$operateObj->answer,'','','');
				}
                return response()->json($ret);
            }
        }
    }

    public function getLikeRelate(Request $request)
    {
        $ret = [
            'code' => 0,
            'msg' => '成功'
        ];
        $objId = $request->input('objid');
        $objType = $request->input('objtype');
        $user = Auth::user();
        if (!$user) {
            $ret['code'] = -1;
            $ret['msg'] = '未登录';
            return response()->json($ret);
        }
        $like = Like::where('obj_id',$objId)
            ->where('obj_type',$objType)
            ->first();
        $ret['like'] = $like;
        return response()->json($ret);
    }
} 