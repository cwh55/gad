<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 2017/9/4
 * Time: 20:14
 */

namespace App\Http\Controllers\Operate;


use App\Http\Controllers\Controller;
use App\Http\Requests;

class FileController extends  Controller
{
    public function getFileInfo($name)
    {
        $path = "office/".$name;
        if (file_exists($path)) {
            $file = fopen($path,"r");
            $size = filesize($path);
            $content = fread($file,$size);
            $sha256 = base64_encode(hash('sha256',$content,true));
            return response()->json([
                'BaseFileName' => $name,
                'OwnerId' => 'admin',
                'Size' => $size,
                'SHA256' => $sha256,
                'version' => '1.0'
            ]);
        } else {
            return response()->json([
                'code' => -1,
                'msg' => 'file no found'
            ]);
        }
    }

    public function getFileContent($name)
    {
        $path = "office/".$name;
        if (file_exists($path)) {
            $file = fopen($path,"r");
            $size = filesize($path);
            $content = fread($file,$size);
            header("Content-type: application/octet-stream");
            echo $content;
        }
    }
}