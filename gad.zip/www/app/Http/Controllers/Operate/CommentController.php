<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-7-11
 * Time: 上午9:37
 */

namespace App\Http\Controllers\Operate;

use App\Http\Controllers\Controller;
use App\Http\Requests;
use App\Models\Like;
use App\Models\User;
use Auth;
use Illuminate\Http\Request;
use App\Models\Comment;
use App\Gad\Upload;

class CommentController extends Controller
{

    public function comment()
    {
        return view('operate.comment',['title'=>'文章评论','commentCount' => 10,'objId'=>1,'objType' => 0]);
    }

    public function index(Request $request)
    {
        return view('operate.index');
    }
    //获取评论数
    public function getCount(Request $request)
    {
        $objId = (int)$request->input('objid');
        $objType = (int)$request->input('objtype');

        $count = Comment::where('obj_id',$objId)
            ->where('obj_type',$objType)
            ->where('status',0)
            ->count();
        return response()->json([
            'code' =>0,
            'count'=>$count
        ]);

    }

    //获取评论列表
    public function getList(Request $request)
    {
        $objId = (int)$request->input('objid');
        $objType = (int)$request->input('objtype');
        $orderBy = $request->input('orderby','create');
        $page = (int)$request->input('page',0);
        $pageSize = (int)$request->input('pagesize',10);

        //排序字典
        $orderDict = [
            'create' => ['created_at','DESC']
        ];
        //排序方式
        if (!array_key_exists($orderBy,$orderDict)) {
            $orderBy = 'create';
        }
        $count = Comment::where('obj_id',$objId)
            ->where('obj_type',$objType)
            ->where('status',0)
            ->count();
        $comments = Comment::where('obj_id',$objId)
            ->where('obj_type',$objType)
            ->where('status',0)
            ->orderBy($orderDict[$orderBy][0],$orderDict[$orderBy][1])
            ->skip($page*$pageSize)
            ->take($pageSize)
            ->get();
        //获取回复
        $commentIds = array_column($comments->toArray(),'id');
        $replyList = Comment::getReply($commentIds);
        //获取用户信息
        $userIds = array_column($comments->toArray(),'user_id');
        $userIds = array_merge($userIds,array_column($replyList->toArray(),'user_id'));
        $userIds = array_unique($userIds);
        $users = Comment::getUsers($userIds);
        //获取赞关系
        $likeList = Comment::getLikeList($commentIds);
        $likeList = $likeList->keyBy('obj_id')->toArray();
        //组合数据
        $users = $users->keyBy('UserId');
        $replyList = $replyList->groupBy('obj_id');

        //组装用户头像、回复数据
        foreach($comments as $comment){
            $creator = array_get($users,$comment->user_id,new User());
            $comment->avatar =  $creator->getAvatar();
            $comment->liked = array_key_exists($comment->id,$likeList) ? true:false;
            $comment->reply = array_get($replyList,$comment->id,[]);
            $comment->isAllowUpdate = $this->allowUpdate(Auth::user(),$comment);
            foreach($comment->reply as $reply) {
                $creator = array_get($users,$reply->user_id,new User());
                $reply->avatar = $creator->getAvatar();
                $reply->isAllowUpdate = $this->allowUpdate(Auth::user(),$reply);
            }
        }

        return response()->json([
            'code'=>0,
            'comments'=>$comments,
            'comment_cnt'=>$count
        ]);


    }

    //添加评论
    public function postAdd(Request $request)
    {
        $user = Auth::user();
        if (!$user || !$user->UserId){
            return response()->json([
                'code' => -1,
                'msg' => '未登录'
            ]);
        }

        $objId = (int)$request->input('objid');
        $objType = (int)$request->input('objtype');
        $comment = xssFilter($request->input('comment'));

        if (!$objId || !in_array($objType,Comment::$objTypes) || !$comment) {
            return response()->json([
                'code' =>-1,
                'msg' => '参数不正确'
            ]);

        }

        $item = Comment::create([
            'obj_id' => $objId,
            'obj_type' => $objType,
            'comment' => $comment,
            'user_id' => $user->UserId,
            'update_user' => $user->UserId,
            'name' => $user->NickName
        ]);

        if ($item) {
            $item->avatar = $item->user->getAvatar();
            $operateObj = $item->getOperateObj();
            if ($operateObj && isset($operateObj->comment_cnt)) {
                $operateObj->increment('comment_cnt',1);
            }
            $item->aye_cnt =0;
            $item->comment_cnt=0;
            return response()->json([
                'code' => 0,
                'msg' => '成功',
                'comment' => $item
            ]);
        }
        else {
            return response()->json([
                'code' => -1,
                'msg' => '保存失败'
            ]);
        }



    }

    //编辑评论
    public function postEdit(Request $request)
    {
        $user = Auth::user();
        if (!$user || !$user->UserId) {
            return response()->json([
                'code' => -1,
                'msg' => '未登录'
            ]);
        }
        $id = (int)$request->input('id');
        $comment = xssFilter($request->input('comment'));

        if (!$id || !$comment) {
            return response()->json([
                'code' =>-1,
                'msg' => '参数不正确'
            ]);
        }
        $item = Comment::find($id);
        if (!$item) {
            return response()->json([
                'code' => -1,
                'msg' => '对象不存在'
            ]);
        }

        if($item->user_id != $user->UserId && !Auth::user()->roles->contains(2)) {
            return response()->json([
                'code' => -1,
                'msg' => '无权限'
            ]);
        }

        $item->comment = $comment;
        $item->update_user = $user->UserId;
        $ret = $item->save();

        if ($ret) {
            return response()->json([
                'code' => 0,
                'msg' => '保存成功'
            ]);
        }
        else {
            return response()->json([
                'code' => -1,
                'msg' => '保存失败'
            ]);
        }


    }

    //删除评论
    public function postDel($id)
    {
        $user = Auth::user();
        if (!$user || !$user->UserId) {
            return response()->json([
                'code' => -1,
                'msg' => '未登录'
            ]);
        }
        $id = (int)$id;
        $comment = Comment::find($id);
        if (!$comment) {
            return response()->json([
                'code' => -1,
                'msg' => '对象不存在'
            ]);
        }

        //只有管理员和创建人能删除
        if (!$this->allowUpdate($user,$comment)){
            return response()->json([
                'code' => -1,
                'msg' => '无权限'
            ]);
        }

        $ret = $comment->update([
            'status' => -1
        ]);
        if ($ret) {
            $operateObj = $comment->getOperateObj();
            if ($operateObj && isset($operateObj->comment_cnt)) {
                $operateObj->decrement('comment_cnt',1);
            }
            return response()->json([
                'code' => 0,
                'msg' => '删除成功'
            ]);
        }
        else {
            return response()->json([
                'code' => -1,
                'msg' => '删除失败'
            ]);
        }

    }

    public function postEditorUploadImage(Request $request)
    {

        if (!Auth::check()) {
            return response('<script>alert("未登录");</script>');
        }
        $file = $request->file('Filedata');
        if (!$file->isValid()) {
            return response('<script>alert("图片上传出错");</script>');
        }
        if($file->getSize() > 10*1024*1024) {
            return response('<script>alert("图片上传出错：最大上传大小10M");</script>');
        }
        $result = Upload::uploadQcloudImage($file);
        if ($result['code'] == 0) {
            return response($result['data']['downloadUrl']);
        } else {
            return response('<script>alert("图片上传出错：'.$result['message'].'");</script>');
        }
    }

    //是否有权限更新
    private function allowUpdate($user,$obj)
    {
        if (!$user) {
            return false;
        }
        if ($user->roles->contains(2)) {
            return true;
        }
        return $user->UserId === $obj->user_id;
    }

} 