<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-12-13
 * Time: 下午4:24
 */

namespace App\Http\Controllers\Operate;

use App\Gad\UrlMap;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Gad\Tlog;
use Cookie;


class PvController extends Controller
{

    //采集页面访问信息
    public function main(Request $request)
    {
        $tlog = UrlMap::getInstance()->mapTlog($request->input('url'),$request->input('refer'));
        $tlog['szUrlSrc'] = $request->input('refer');
        $tlog['szUrlDst'] = $request->input('url');
        $tlog['ivisitMode'] = $request->input('visitmode');
        //生成用户suid cookie
        $suid = $request->cookie("gaduid",uniqid());
        $cookie =  Cookie::make('gaduid',$suid,time()+(10*365*24*3600),'/','.qq.com');
        //生成会话id
        $ssid = $request->cookie('gadsid',uniqid());
        $ssidCookie = Cookie::make('gadsid',$ssid,null,'/','.qq.com');
        $tlog['sUid'] =$suid;
        $tlog['sSessionId'] =$ssid;
        $ret = Tlog::getInstance()->writeTbDataStat($tlog);
        return response()->json([
            'ret'=>$ret,
            'msg'=>'success'
        ])->withCookie($cookie)->withCookie($ssidCookie);
    }

    //记录点击事件
    public function click(Request $request)
    {
        $tlog = UrlMap::getInstance()->mapTlog($request->input('url'),$request->input('refer'));
        $tlog['iEventId'] = $request->input('eventId');
        $tlog['sExt'] = $request->input('hotTagName');
        $tlog['szUrlSrc'] = $request->input('refer');
        $tlog['szUrlDst'] = $request->input('url');
        $tlog['iVisitMode'] = $request->input('visitmode',0);
        //生成用户suid cookie
        $suid = $request->cookie("gaduid",uniqid());
        $cookie = cookie('gaduid',$suid,time()+(10*365*24*3600),'/','.qq.com');
        //生成回话id
        $ssid = $request->cookie('gadsid',uniqid());
        $ssidCookie = Cookie::make('gadsid',$ssid,null,'/','.qq.com');
        $tlog['sUid'] =$suid;
        $tlog['sSessionId'] =$ssid;
        $ret = Tlog::getInstance()->writeTbGadStat($tlog);
        return response()->json([
            'ret'=>$ret,
            'msg'=>'success'
        ])->withCookie($cookie)->withCookie($ssidCookie);
    }

} 