<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App;

class BonController extends Controller
{
	public function __construct(Request $request){
		$this->middleware('acl:permit', ['only' => ['permitNoParam']]);
		$this->middleware("acl:permit", ["except" => ["testBadword"]]);
	}
    //
	public function testBadword(){
		$bon = App::make("BonHelper");
		$data = array("title" => "123", "content" => "123123", "desc" => "123123", "contentId" => 1);
		//var_dump($bon->hasBadWord($data));
	}
	public function index(){
		$this->middleware("acl:permit");
		var_dump('test');
	}
}
