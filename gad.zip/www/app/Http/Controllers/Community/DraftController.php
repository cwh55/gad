<?php

namespace App\Http\Controllers\Community;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use App\Repositories\ArchiveRepository;

class DraftController extends Controller {

    public function __construct() {
        $this->middleware('auth');
    }

    public function getIndex(ArchiveRepository $archive) {
        $draftCount = $archive->getDraftCount(Auth::User()->UserId);
        $archive->setRejectNotice(Auth::user()->UserId, null);
        return view('community.draft', compact('draftCount'));
    }
    
    public function getList(Request $request, ArchiveRepository $archiveRepository){
        $page = $request->input('page') * 1;
        $classId = $request->input('classId') * 1;
        $status = $request->input('status') * 1;
        $pageSize = 20;
        $list = $archiveRepository->with(['firstPictures'])->where('user_id', Auth::User()->UserId);
        if($status == -1){
            $list = $list->whereIn('status', [2, 3]);
        }else{
            $list = $list->where('status', $status);
        }
        if($classId){
            $list = $list->where('class_id', $classId);
        }
        $list = $list->orderBy('updated_at', 'desc')->offset($page * $pageSize)->limit($pageSize)->findAll();
        return response()->json($list);
    }
}
