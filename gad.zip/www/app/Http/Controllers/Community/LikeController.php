<?php

namespace App\Http\Controllers\Community;
use App\Repositories\LikeRepository;
use App\Repositories\ArchiveRepository;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Register;
use Illuminate\Http\Request;
use Auth;
use App\Entities\Like;
use Debugbar;

class LikeController extends Controller
{
    protected $like;
    protected $archive;

    protected $prefix = 'App\\Entities\\';

    public function __construct(LikeRepository $like, ArchiveRepository $archive)
    {
        $this->like = $like;
        $this->archive = $archive;
        $this->middleware('auth');
    }

    public function getIndex()
    {
        return view('like.template',[]);
    }

    //
    public function getLike(Request $request)
    {
        $user_id = Auth::user()->UserId;
        $model_type = $this->prefix . $request->input('model_type');
        $model_id = $request->input('model_id');

        $like = $this->like->where('model_type', $model_type)->where('model_id', $model_id)->limit(1)->findAll();

        return response()->json(['code' => 0, 'data' => $like, 'message' => '']);
    }

    public function postCreate(Request $request)
    {
        $this->validate($request, [
            'model_type' => 'required',
            'model_id' => 'required',
            'status' => 'required|integer'
        ]);

        $model_type = $this->prefix . $request->input('model_type');
        $model_id = $request->input('model_id');
        $status = $request->input('status');
        $user_id = Auth::user()->UserId;

        $like = $this->like->myLike($model_type, $model_id, $user_id);

        if ($like) {
            return $this->postEdit($request, $like->id);
        }

        $data['status'] = $status;
        $data['model_type'] = $model_type;
        $data['model_id'] = $model_id;
        $data['user_id'] = $user_id;

        list($statu, $like) = $this->like->create($data);
        if ($statu) {
            $this->updateModel($like->likeModel, $status);
            $messageType = [
                'Question' => \App\Gad\MessageType::QUESTION_LIKE,
                'Answer' => \App\Gad\MessageType::ANSWER_LIKE,
                'Comment' => \App\Gad\MessageType::COMMENT_LIKE,
                'Picture' => \App\Gad\MessageType::ART_LIKE,
                'Topic' => \App\Gad\MessageType::TOPIC_LIKE,
                'Lesson' => \App\Gad\MessageType::LESSION_LIKE,
                'Article' => \App\Gad\MessageType::ARTICLE_LIKE,
                'Archive' => \App\Gad\MessageType::ARTICLE_LIKE
            ];
            $model_type = $request->input('model_type');
            $model = $like->likeModel;
            if ($model && isset($messageType[$model_type])) {
                $url = '';
                $name = '';
                if ($model_type == 'Question') {
                    $url = url('/question/detail', $model->id);
                    $name = $model->title;
                } else if ($model_type == 'Comment') {
                    $comment = $model->commentable;
                    $archive = $comment;
                    if ($comment instanceof \App\Entities\Comment) {
                        $archive = $comment->commentable;
                    }
                    if ($archive instanceof \App\Entities\Picture) {
                        $comment = $archive;
                        $archive = $comment->archive;
                    }
                    if ($archive instanceof \App\Entities\Archive) {
                        if ($archive->class_id == 1) {
                            $url = url('/article/detail', $archive->id);
                        } else if ($archive->class_id == 2) {
                            $url = url('/gallery/detail', [$archive->id, $comment->id]);
                        }
                        $name = str_limit(strip_tags($model->comment), 50, '...');
                    }
                } else if ($model_type == 'Answer') {
                    $question = null;
                    if ($model->archive_id > 0) {
                        $question = $model->question;
                    } else if ($model->answer_id > 0) {
                        $question = $model->panswer->question;
                    }
                    if ($question) {
                        $url = url($model->is_topic == 1 ? '/topic/detail' : '/question/detail', $question->id);
                        $name = str_limit(strip_tags($model->answer), 50, '...');
                        $model_type = $model->is_topic == 1 ? 'Topic' : $model_type;
                    }
                } else if ($model_type == 'Picture') {
                    $archive = $model->archive;
                    $url = url('/gallery/detail', [$archive->id, $model->id]);
                    $name = $archive->title;
                } else if ($model_type == 'Article') {
                    $archive = $model->archive;
                    $url = url('/article/detail', $archive->id);
                    $name = $archive->title;
                } else if ($model_type == 'Archive') {
                    $archive = $model;
                    $url = url('/article/detail', $archive->id);
                    $name = $archive->title;
                }
                if ($url && $model->user_id != $user_id) {
                    //$name = $model->answer ? str_limit(strip_tags($model->answer), 50, '...') : $model->title;
                    //发送站内信
                    $this->dispatch(new \App\Jobs\SendMessage(
                        $messageType[$model_type],
                        $model->user_id,
                        $user_id,
                        $model_id,
                        $url,
                        $name
                    ));
                }
            }
            return response()->json(['code' => 0, 'data' => $like, 'message' => '']);
        }

        return response()->json(['code' => -1, 'data' => $like, 'message' => '更新失败']);

    }

    public function postEdit(Request $request, $id)
    {
        $like = Like::findOrFail($id);

        $this->validate($request, [
            'status' => 'required|integer',
        ]);

        $status = $request->input('status');
        $user_id = Auth::user()->UserId;

        if ($user_id != $like->user_id && !Auth::user()->roles->contains(2)) {
            return response()->json(['code' => -1, 'message' => '没有权限']);
        }

        if ($status == $like->status) {
            return response()->json(['code' => -2, 'message' => '重复操作']);
        }

        $likestatus = $like->status;

        $this->like->update($id, ['status' => $status]);
        $this->updateModel($like->likeModel, $status, $likestatus);
        //仅自己修改才提醒
        //Func::msgApi(
        //MessageType::PROJECT_APPLY_SUCCESS,
        //Auth::user()->UserId,
        //0,
        //$hatch->id,
        //url('/hatch/detail',$hatch->id),
        //$hatch->name
        //);

        return response()->json(['code' => 0, 'data' => '', 'message' => '']);
    }

    protected function updateModel($model, $status, $likestatus = 1, $level = 1)
    {
        if ($level > 2) {
            return;
        }
        if ($status == 1 && $model) {
            $model->increment('like_count', 1);
        } else if ($status == 2 && $model) {
            if ($model->like_count > 0 && $likestatus == 1) {
                $model->decrement('like_count', 1);
            }
            if (isset($model->unlike_count)) {
                $model->increment('unlike_count', 1);
            }
        } else if ($status == 0 && $model) {
            if ($model->like_count > 0 && $likestatus == 1) {
                $model->decrement('like_count', 1);
            }
            if (isset($model->unlike_count) && $model->unlike_count > 0) {
                $model->decrement('unlike_count', 1);
            }
        }
        if ($model->archive) {
            $this->updateModel($model->archive, $status, $likestatus, $level + 1);
        }
        if ($model->question && ($model->question->class_id == 3 || $model->question->class_id == 4)) {
            $ar = $model->question;
            if ($ar->is_hot == 1 && isset($ar->extra['id']) && $ar->extra['id'] == $model->id) {
                $extra = collect($ar->extra)->toArray();
                $extra['like_count'] = $model->like_count;
                $this->archive->update($ar->id, ['extra' => $extra]);
            } else if ($ar->is_hot != 1 || $ar->hot_aid == 0) {
                $this->archive->updateExtra($ar);
            }
        }
    }

}
