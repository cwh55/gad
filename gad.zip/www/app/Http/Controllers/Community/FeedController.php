<?php

namespace App\Http\Controllers\Community;

use Illuminate\Http\Request;
use App\Presenters\CommunityPresenter;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\FeedRepository;
use Auth;
use DB;

class FeedController extends Controller
{
    public function __construct() {
        $this->middleware('auth', ['only'=>['getIndex', 'postFeedList']]);
    }
    
    public function getIndex(Request $request, FeedRepository $feedRepository, \App\Repositories\TagRepository $tagRepository, $orderType = 'new'){
        $page = $request->input('p',1);
        $pageSize = $request->input('ps',20);
        $pageSize = ($pageSize > 20) ? 20 : $pageSize;
        $tagName= 'my';
        $hasMore = 0;
        if (Auth::check()) {
            $archives = $feedRepository->getMyFeeds(Auth::user()->UserId);
        }
        if (!empty($archives)) {
            $presenter = new CommunityPresenter();
            foreach ($archives as $archive) {
                $archive->avatar = !$archive->Avatar ? 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg' : $archive->Avatar;
                if ($archive->extra) {
                    $archive->extra = json_decode($archive->extra, true);
                }
                $archive->tags = explode(',', $archive->tag);
                $archive->format_comment_count = $presenter->formatNumber($archive->comment_count);
                $archive->format_like_count = $presenter->formatNumber($archive->like_count);
                $archive->format_view_count = $presenter->formatNumber($archive->view_count);
                $archive->format_favorite_count = $presenter->formatNumber($archive->favorite_count);
                $archive->user_name = $archive->NickName;
                $archive->user_type = $archive->user_type;
            }
            $archives = collect($archives);
            $hasMore = $archives->count() == $pageSize ? true : false;
        }
        $archives['hasMorePage'] = $hasMore;
        $tag = 'my';
        $orderBy = $orderType;
        $hotTags = $tagRepository->getHotTags($tag);
        return view('community.feeds', compact('archives', 'page', 'tag', 'pageSize', 'tagName', 'orderBy', 'hotTags'));
    }
    
    public function postFeedList(Request $request,  FeedRepository $feedRepository){
        try {
            $page = intval($request->input('page'));
            $pageSize = intval($request->input('pageSize'));
            $orderType = $request->input('orderType');
            $tagName = $request->input('tagName');
            $tagValue = isset(\App\Repositories\TagRepository::$tagMap[$tagName]) ? \App\Repositories\TagRepository::$tagMap[$tagName] : '';
            if (!$tagValue){
                $list = $archive->getList(1, $channel_id, $page, $pageSize, $orderType);
            } else {
                $list = $archive->getListByTagName($tagValue, 1, null, 20, $orderType) ;
            }
            return response()->json(array('code' => 0, 'data' => $list));
        } catch (\Exception $ex) {
            return response()->json(array('msg' => $ex->getMessage(), 'code' => 1));
        }
    }

    public function getTags(\App\Repositories\TagRepository $tag){
        $list = $tag->findAll(['id', 'name']);
        return response()->json($list);
    }
    
    public function getTest()
    {
    }
}
