<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 17-5-6
 * Time: 上午11:38
 * 使用
 */

namespace App\Http\Controllers\Community;

use App\Entities\User;
use App\Gad\Func;
use App\Gad\MessageType;
use App\Http\Controllers\Controller;
use App\Repositories\FollowRepository;
use Illuminate\Http\Request;
use App\Repositories\OperationRepositoryEloquent;
use App\Repositories\ArchiveRepository;
use Auth;
use Gate;

class FollowController extends Controller
{
    protected $follow;
    protected $operation;

    public function __construct(FollowRepository $follow,OperationRepositoryEloquent $operation,\App\Repositories\FollowUserRepository $followUserRepository)
    {
        $this->follow = $follow;
        $this->operation = $operation;
        $this->followUserRep = $followUserRepository;
    }

    //需要登录在构造函数里加了判断
    public function postIndex(Request $request)
    {
        $followUser = $request->input('followuser');
        $act = $request->input('act');
        $actMap = ['follow' => 0, 'followed' => 0, 'cancel' => 1];
        if (!Auth::check()) {
            return response()->json(['code' => -2, 'msg' => '未登录']);
        }

        if (!in_array($act,['follow', 'cancel'])) {

            return response()->json(['code' => -1, 'msg' => '参数错误']);
        }
        $user = Auth::user();

        if ($followUser == $user->UserId) {
            return response()->json(['code' => -1, 'msg' => '不能关注自己']);
        }

        //查看关系是否存在
        $followItem = $this->follow->where('user_id',$user->UserId)
                                   ->where('follow_user',$followUser)
                                   ->findAll()
                                   ->first();
        if ($followItem) {
            // 判断是否相互关注
            if($act == 'follow') {
                $following = $this->follow->where('user_id', $followUser)
                    ->where('follow_user', $user->UserId)
                    ->findAll()
                    ->first();
                if (!empty($following) && $following->status == 0) {
                    $actMap['followed'] = 2;
                } else {
                    $actMap['followed'] = 1;
                }
            }

            if ($followItem->status != $actMap[$act]) {

                $followItem->status = $actMap[$act];
                $followItem->save();
                if ($act == 'follow') {
                    Func::msgApi(MessageType::FOLLOW,$followUser,$user->UserId);
                }
                return response()->json(['code' => 0, 'status' => $actMap['followed'], 'msg' => '成功']);
            } else {
                return response()->json(['code' => -1, 'msg' => '重复操作']);
            }
        } elseif ($act == 'follow') {

            $this->follow->create([
                'user_id' => $user->UserId,
                'follow_user' => $followUser,
                'status' => $actMap['follow'],
            ]);
            Func::msgApi(MessageType::FOLLOW,$followUser,$user->UserId);

            // 判断是否相互关注
            if($act == 'follow') {
                $following = $this->follow->where('user_id', $followUser)
                    ->where('follow_user', $user->UserId)
                    ->findAll()
                    ->first();
                if (!empty($following) && $following->status == 0) {
                    $actMap['followed'] = 2;
                } else {
                    $actMap['followed'] = 1;
                }
            }

            return response()->json(['code' => 0, 'status' => $actMap['followed'], 'msg' => '成功']);

        } else {

            return response()->json(['code' => -1, 'msg' => '未关注']);
        }

    }

    //推荐关注
    public function getRecommend(Request $request)
    {
        $ruleOut = $request->input('rules');
        $page = intval($request->input('p'));
        $pageSize = intval($request->input('ps',9));
        $pageSize = ($pageSize > 10) ? 9 : $pageSize;
        $followUsers = collect([]);
        $user = Auth::user();
        if(Auth::user()) {
            $followUsers = $this->follow->where('user_id', $user->UserId)->where('status', 0)->limit(100)->findAll();
        }
        $userIds = [];
        if($followUsers->toArray()) {
            $userIds = array_merge(array_column($followUsers->toArray(), 'follow_user'),[$user->UserId]);
        }
        $users = $this->operation->where('type',1)
            ->where('status',0)
            ->with(['user'])
            ->whereNotIn('model_id',$userIds)
            ->orderBy(\DB::raw('rand()'))
            ->simplePaginate($pageSize,['*']);
        $res = $users->map(function($item) use($userIds,$followUsers){
            $tmp = [];
            $tmp['nickName'] = $item->user->NickName;
            $tmp['userId'] = $item->user->UserId;
            $tmp['avatar'] = $item->user->Avatar;
            $tmp['type'] = $item->user->type;
            $tmp['title'] = $item->title;
            $tmp['isFollowed'] = 0;
            return $tmp;
        });

        $data = [
            'code' =>0,
            'users' => $res,
            'hasMore' => $users->hasMorePages()
        ];
        return response()->json($data);

    }

    //空状态推荐关注
    public function getFeeds(Request $request, ArchiveRepository $archive)
    {
        $ruleOut = $request->input('rules');
        $users = $this->follow->getRecommendUser();
        $userIds = [];
        if (Auth::check()) {
            $userIds = array_column($users->toArray()['data'],'user_id');
        }
        $res = $users->map(function($item) use($userIds, $archive){
            $tmp = [];
            $tmp['nickName'] = $item->NickName;
            $tmp['type'] = $item->type;
            $tmp['userId'] = $item->user_id;
            $tmp['avatar'] = $item->Avatar;
            $tmp['title'] = $item->introduction;
            $temp = $archive->where('user_id', '=', $item->user_id)->orderBy('class_id', 'asc')->orderBy('created_at', 'desc')->findAll(['id','class_id','title'])->take(3);
            if(!empty($temp)) {
                $urlMap = array(
                    1 => 'article',
                    2 => 'gallery',
                    3 => 'question',
                    4 => 'topic',
                );
                foreach($temp as $val) {
                    if(!isset($urlMap[$val->class_id])) {
                        $val->class_id = 1;
                    }
                    $tmp['archives'][] = array(
                        'title' => $val->title,
                        'url' => sprintf('/%s/detail/%d', $urlMap[$val->class_id], $val->id),
                    );
                }
            }

            $tmp['isFollowed'] = 0;

            return $tmp;
        });

        $data = [
            'code' =>0,
            'users' => $res,
            'hasMore' => $users->hasMorePages()
        ];
        return response()->json($data);
    }

    public function getMyRecommendInfo(\App\Repositories\FollowUserRepository $followUserRepository, \App\Repositories\FollowRepository $follow){
        if(Auth::check()){
            $recommendOperation = \Redis::connection()->hGetAll('gad:community:recommendOperation:'.Auth::user()->UserId);
            $tagList = Auth::user()->tags;
            $followList = $followUserRepository->with(['user'])->findAll();
            $myFollowList = $follow->where('user_id', Auth::user()->UserId)->where('status', 0)->whereIn('follow_user', array_column($followList->toArray(), 'user_id'))->findAll(['follow_user']);
            return response()->json(['code' => 0, 'data' => ['tagList'=>$tagList, 'myFollowList'=>$myFollowList, 'recommendOperation'=>$recommendOperation]]);
        }
    }
} 