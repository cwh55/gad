<?php

namespace App\Http\Controllers\Community;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\LiveRepositoryEloquent;
use App\Repositories\ArchiveRepository;
use App\Repositories\AnswerRepository;
use App\Repositories\LikeRepository;
use App\Repositories\QuestionRepository;
use App\Repositories\FavoriteRepository;
use App\Repositories\FollowRepository;
use App\Repositories\TagRepository;
use App\Entities\Archive;
use App\Entities\Answer;
use App\Entities\Question;

use App\Gad\Func;

use Auth;
use Gate;

use Illuminate\Http\Request;
use Illuminate\Routing\Route;


class QuestionController extends Controller
{
    protected $live;
    protected $archive;
    protected $answer;
    protected $question;
    protected $fav;
    protected $archive_type = Archive::TYPE_QUESTION;
    protected $is_topic = 0;//0问答1话题
    protected $view = 'community.question';
    protected $controller = 'question';

    public function __construct(
        Request $request,
        ArchiveRepository $archive,
        LiveRepositoryEloquent $live,
        AnswerRepository $answer,
        QuestionRepository $question,
        FavoriteRepository $fav)
    {
        $this->live = $live;
        $this->archive = $archive;
        $this->answer = $answer;
        $this->question = $question;
        $this->fav = $fav;
        $this->middleware("auth", ['only' => ['postQuestion', 'postAnswer']]);
        $this->middleware('captcha:answer'.$this->archive_type, ['only' => ['postAnswer']]);
        $this->middleware('captcha:archive'.$this->archive_type, ['only' => ['postQuestion']]);
    }
    //
    public function getIndex(Request $request, TagRepository $tagRes, $tagName = '', $orderType = 'new')
    {
        $liveList = $this->live->getAllList($this->archive_type);
        if (!isset(TagRepository::$tagMap[$tagName])) {
            $list = $this->archive->getList($this->archive_type, null, 0, 20, $orderType, $this->controller == 'topic' ? '' : 'hot');
        } else {
            $list = $this->archive->getListByTagName(TagRepository::$tagMap[$tagName], $this->archive_type, 0, 20, $orderType);
        }
        $questionCount = $this->archive->where('class_id', '=', $this->archive_type)->where('status', '=', 0)->paginate();
        $answerCount = $this->answer->where('archive_id', '<>', 0)->where('is_topic', '=', $this->is_topic)->paginate();
        $hotTags = $tagRes->getHotTags($tagName);
        $hotUsers = $this->getHotUsers();
        $draftCount = Auth::User() ? $this->archive->getDraftCount(Auth::User()->UserId) : 0;
        $data = [
            'liveList' => $liveList,
            'list' => $list,
            'orderType' => $orderType,
            'hotTags' => $hotTags,
            'tagName' => $tagName,
            'questionCount' => $questionCount->total(),
            'answerCount' => $answerCount->total(),
            'hotUsers' => $hotUsers,
            'draftCount'=>$draftCount
        ];
        return view($this->view, $data);
    }

    public function getHotUsers(){

    }

    public function getList(Request $request, $tagName = '') {
        $orderType = $request->input('orderType','new');
        $channel_id = intval($request->input('channel_id'));
        $page = intval($request->input('page'));
        $pageSize = intval($request->input('pageSize'));
        if (!isset(TagRepository::$tagMap[$tagName])) {
            $list = $this->archive->getList($this->archive_type, $channel_id, $page, $pageSize,$orderType,$this->controller == 'topic' ? '' : 'hot');
        } else {
            $list = $this->archive->getListByTagName(TagRepository::$tagMap[$tagName], $this->archive_type, $page, $pageSize, $orderType);
        }
        return response()->json(['code' => 0, 'data' => $list, 'message' => '']);
    }

    public function postQuestion(Request $request, TagRepository $tagRes, FollowRepository $follow, $id = 0)
    {
        $all = $request->all();
        $all = array_map('xssFilter', $all);

        $data = ['code' => -1, 'message' => '', 'data' => []];
        $user = Auth::user();

        $this->validate($request, [
            'title' => 'required|max:50'
        ]);

        if ($id > 0) {
            $archive = $this->archive->find($id);
            if (!$archive) {
                $data['message'] = '问题不存在';
                return response()->json($data);
            }
            if (!$archive->question) {
                $data['message'] = '非法问题';
                return response()->json($data);
            }
            //权限
            $this->authorize('edit', $archive);
            //删除
            if (isset($all['type']) && $all['type'] == 'del') {
                $this->archive->removeTags($archive);
                $this->archive->delete($id);
                $data['code'] = 0;
            } else {//修改

                if (Func::hasBadWord($id, $all['content'], $all['title'], '')) {
                    return response()->json(['code' => -1, 'message' => '非法内容']);
                }
                $tagArr = $all['tag'] == '' ? '' : explode(',', $all['tag']);
                $tagInput = $this->tagInput($tagRes, $tagArr, $all['title'], $all['content']);

                $archiveData = [
                    'title' => $all['title'], 'description' => str_limit(strip_tags($all['content']), 150),
                    'updater' => $user->UserId, 'tag' => $tagInput[1],
                    'project_id' => intval($all['projectId'])
                ];
                $archiveData['channel_id'] = getChannelId($tagInput[0]);
                list($res, $archive) = $this->archive->update($id, $archiveData);
                if ($res) {
                    //$all['content'] = Func::imgAltTitle($all['content'],$all['title'],$all['title']);
                    $questionData = ['content' => $all['content'], 'updater' => $user->UserId];
                    $this->question->update($archive->question->id, $questionData);

                    $data['data']['archive'] = $archive;
                    $data['code'] = 0;
                }
                $this->archive->addTags($archive, $tagInput[0]);
            }
        } else {//新增
            $this->authorize('create', $this->archive->createModel());
            if (Func::hasBadWord($id, $all['content'], $all['title'], '')) {
                return response()->json(['code' => -1, 'message' => '非法内容']);
            }
            $tagArr = $all['tag'] == '' ? '' : explode(',', $all['tag']);
            $tagInput = $this->tagInput($tagRes, $tagArr, $all['title'], $all['content']);
            $archiveData = [
                'title' => $all['title'], 'description' => str_limit(strip_tags($all['content']), 150),
                'user_id' => $user->UserId, 'user_name' => $user->NickName,
                'creator' => $user->UserId, 'tag' => $tagInput[1],
                'class_id' => $this->archive_type, 'extra' => [],
                'sort_time' => time(),'project_id' => intval($all['projectId'])
            ];
            $archiveData['channel_id'] = getChannelId($tagInput[0]);
            list($res, $archive) = $this->archive->create($archiveData);
            if ($res) {
                $this->archive->captchaCache($this->archive_type, 'archive');//验证码统计
                //$all['content'] = Func::imgAltTitle($all['content'],$all['title'],$all['title']);
                $questionData = [
                    'content' => $all['content'], 'updater' => $user->UserId,
                    'archive_id' => $archive->id, 'is_topic' => $this->is_topic
                ];
                $question = $this->question->create($questionData);

                $data['data']['archive'] = $archive;
                $data['code'] = 0;

                $this->archive->addTags($archive, $tagInput[0]);

                if ($archive) {
                    $followers = $follow->getFans($user->UserId)->pluck('user_id')->toArray();
                    //发送站内信
                    $this->dispatch(new \App\Jobs\SendMessage(
                        $this->controller == 'question' ? \App\Gad\MessageType::QUESTION_NEW : \App\Gad\MessageType::TOPIC_NEW,
                        $followers,
                        $user->UserId,
                        $archive->id,
                        url('/' . $this->controller . '/detail', $archive->id),
                        $archive->title
                    ));
                }
            }
        }

        return response()->json($data);
    }

    public function getAnswerList(Request $request, $id)
    {
        //$question = $this->question->findOrFail($id);
        //$answerCount = $question->answer_count;

        $user = Auth::user();
        $isLogin = Auth::check();
        $pageSize = $request->input('pageSize', 20);
        if ($pageSize > 100) {
            $pageSize = 20;
        }
        $orderBy = $request->input('orderBy');
        $answerList = $this->answer->getListByQuestion($id, $user ? $user->UserId : 0, $pageSize, $orderBy);
        return response()->json(['code' => 0, 'data' => compact('user', 'isLogin', 'answerList')]);
    }

    public function postAnswer(Request $request, $id = 0)
    {
        $all = $request->all();
        $all = array_map('xssFilter', $all);

        $data = ['code' => -1, 'message' => ''];

        $user = Auth::user();

        if ($id > 0) {
            $answer = $this->answer->find($id);
            if ($answer == null) {
                $data['message'] = '非法内容';
                return response()->json($data);
            }
            $this->authorize('edit', $answer);

            $this->validate($request, [
                'type' => 'required'
            ]);

            if ($all['type'] == 'del') {
                if ($answer->status != -1) {
                    $this->answer->update($id, ['status' => -1]);
                    $this->updateCount($answer, 'down');
                }
            } else if ($all['type'] == 'update') {
                if (Func::hasBadWord($id, $all['answer'], '', '')) {
                    return response()->json(['code' => -1, 'message' => '非法内容']);
                }
                $res = $this->answer->update($id, ['answer' => $all['answer']]);
                if($res[0]) {
                    $res[1]->user;
                    $this->updateCount($res[1]);
                }
                $answer = $all['answer'];
            }
            $data = ['code' => 0, 'message' => '', 'data' => $answer];
        } else {
            $this->authorize('create', $this->answer->createModel());
            $this->validate($request, ['type' => 'required', 'answer' => 'required']);
            if (Func::hasBadWord($id, $all['answer'], '', '')) {
                return response()->json(['code' => -1, 'message' => '非法内容']);
            }
            $answer = ['answer' => $all['answer'], 'user_id' => $user->UserId, 'user_name' => $user->NickName];
            $answer['is_topic'] = $this->is_topic;
            if ($all['type'] == 'question') {
                $answer['cover'] = '';
                preg_match_all("/<[i|I][m|M][g|G].*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>/", $all['answer'], $matches);
                if (isset($matches[1])) {
                    foreach ($matches[1] as $url) {
                        if (!strpos($url, 'js/editor/css')) {
                            $answer['cover'] = $url;
                        }
                    }
                }
                $answer['project_id'] = intval($all['projectId']);
                $answer['archive_id'] = $all['id'];
            } else if ($all['type'] == 'answer') {
                $answer['answer_id'] = $all['id'];
                $answer['at_user'] = $all['at_user_id'];
                $answer['at_name'] = $all['at_user_name'];
            }
            list($status, $res) = $this->answer->create($answer);
            if ($status) {
                $this->archive->captchaCache($this->archive_type, 'answer');
                $this->updateCount($res, 'up');
                $res->replyList = ['data' => [], 'pushState' => false, 'first' => false, 'current_page' => 0, 'per_page' => 20];
                $res->textShow = false;
                $res->loading = false;
                $res->like_count = 0;
                $res->answer_count = 0;
                $res->likefav = ['id' => 0, 'status' => 0];
                $res->avatar = $user->getAvatar();
                $res->user = $user;
                $data = ['code' => 0, 'message' => '', 'data' => $res];

                //提醒
                $messageType = $all['type'] == 'question' ? ($this->controller == 'question' ? \App\Gad\MessageType::QUESTION_REPLY : \App\Gad\MessageType::TOPIC_REPLY)
                    : ($this->controller == 'question' ? \App\Gad\MessageType::QUESTION_ANSWER_REPLY : \App\Gad\MessageType::TOPIC_ANSWER_REPLY);
                $archive = $all['type'] == 'question' ? $res->question : $res->panswer;
                $archiveId = $all['type'] == 'question' ? $archive->id : $archive->archive_id;
                if($archive && $archive->user_id != $user->UserId){
                    $this->dispatch(new \App\Jobs\SendMessage(
                        $messageType,
                        $archive->user_id,
                        $user->UserId,
                        $archiveId,
                        url('/'.$this->controller.'/detail',$archiveId),
                        $archive->answer ? str_limit(strip_tags($archive->answer),50,'...') : $archive->title,
                        $archiveId,
                        url('/'.$this->controller.'/detail',$archiveId),
                        str_limit(strip_tags($answer['answer']),50,'...')
                    ));
                }
            } else {
                $data['message'] = '更新失败';
                return response()->json($data);
            }
        }

        return response()->json($data);
    }

    public function getDetail(Request $request, TagRepository $tagRes, $id, $order = 'hot')
    {
        $detail = $this->archive->with(['question', 'user'])->find($id);
        if (empty($detail)) {
            return abort(404);
        }

        $like = $fav = null;
        $user = null;
        $hasPermit = false;
        if (Auth::check()) {
            $user = Auth::user();
            $user_id = $user->UserId;
            $fav = $this->fav->myFavorite('App\\Entities\\Archive', $id, $user_id);
            $hasPermit = Gate::allows('edit',$detail);
        }

        $favId = $fav == [] ? 0 : $fav->id;
        $relatedArchive = $this->archive->getRelatedArchivesByClassId($detail, $this->archive_type, 'hot_score', 5);
        $relatedHot = $this->archive->getRelatedArchives($detail, 1, 'hot_score', 10);
        //回答
        $answerList = $this->answer->getListByQuestion($id, $user ? $user->UserId : 0, 20, $order);
        //$this->archive->addVisitCount($id);
        $controller = $this->controller;
        //异步加载时返回json
        if ($request->ajax()) {
            $detail->favId = $favId;
            return response()->json([
                'code' => 0,
                'detail' => $detail
            ]);
        }
        return view('community.question_detail', compact('detail', 'favId', 'user', 'order', 'relatedArchive', 'relatedHot', 'project', 'answerList', 'hasPermit', 'controller'));
    }

    //二级回复列表
    public function getReplyList(Request $request, $id)
    {
        $pageSize = $request->input('pageSize', 10);
        if ($pageSize > 100) {
            $pageSize = 20;
        }
        $page = $request->input('page',1);
        $orderBy = $request->input('orderBy');
        $user_id = Auth::user() ? Auth::user()->UserId : 0;
        $data = $this->answer->getListByAnswer($id, $user_id, $pageSize, $orderBy, $page);
        return response()->json(['code' => 0, 'data' => $data, 'message' => '']);
    }

    //更新评论数量
    protected function updateCount($answer, $type = 'u')
    {
        if ($type == 'up') {//加
            if ($answer->archive_id > 0) {
                $answer->question->increment('comment_count', 1);
                $this->archive->updateExtra($answer->question);
            } else {
                $answer->panswer->increment('answer_count', 1);
            }
        } else if($type == 'down') {//减
            if ($answer->archive_id > 0) {
                if ($answer->question->comment_count > 0) {
                    $answer->question->decrement('comment_count', 1);
                    if (isset($answer->question->extra['id']) && $answer->question->extra['id'] == $answer->id) {
                        $data = [
                            'extra' => [],
                            'is_aid' => 0
                        ];
                        //更新extra
                        $this->archive->update($answer->question->id, $data);
                    }
                }
            } else {
                if ($answer->panswer->answer_count > 0) {
                    $answer->panswer->decrement('answer_count', 1);
                }
            }
        } else {
            $data = [
                'extra' => $answer->toArray()
            ];
            $data['extra']['answer'] = strip_tags($data['extra']['answer']);
            //$data['extra']['answer'] = strip_tags($data['extra']['answer']);
            $this->archive->update($answer->question->id, $data);
        }
    }

    //标签匹配 没有匹配默认策划
    protected function tagInput($tagRes, $tagArr, $title, $content)
    {
        if (empty($tagArr)) {
            $tags = $tagRes->findFromTitleContent($title, $content);
            if (count($tags) == 0) {
                $tags = $tagRes->where('name', '=', '游戏策划')->findAll();
            }
            $tagStr = implode(',', array_column($tags->slice(0, 6)->toArray(), 'name'));
            return [$tags, $tagStr];
        } else {
            $tags = $tagRes->whereIn('name', $tagArr)->findAll();
            $tagStr = implode(',', $tagArr);
            return [$tags, $tagStr];
        }
    }

}
