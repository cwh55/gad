<?php

namespace App\Http\Controllers\Community;

use App\Entities\CityStation;
use App\Entities\GamePai;
use App\Entities\HatchProject;
use Illuminate\Http\Request;
use App\Entities\Archive;
use App\Entities\Comment;
use App\Entities\Picture;
use App\Gad\MessageType;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Jobs\SendMessage;
use App\Repositories\CommentRepository;
use App\Repositories\ArchiveRepository;
use Auth;
use Gate;

class CommentController extends Controller
{
    private $cmttypes = array(
        1 => 'App\Entities\Archive',
        2 => 'App\Entities\Comment',
        3 => 'App\Entities\Picture',
        4 => 'App\Entities\CityStation',
        5 => 'App\Entities\GamePai',
        6 => 'App\Entities\City',
        7 => 'App\\Entities\\Project'
    );

    public function __construct(CommentRepository $comment)
    {
        $this->comment = $comment;
        $this->middleware('captcha:answer' . Archive::TYPE_COMMENT, ['only' => ['postAdd']]);
    }

    //获取评论列表
    public function getList(Request $request)
    {
        $params = array(
            'objId' => (int)$request->input('objid', 1),
            'objType' => $request->input('objtype', $this->cmttypes[2]),
            'orderBy' => $request->input('orderby', 'create'),
            'page' => (int)$request->input('page', 0),
            'pageSize' => (int)$request->input('pagesize', 10)
        );
        $result = $this->comment->getList($params);
        $result['code'] = 0;
        return response()->json($result);
    }

    //添加评论
    public function postAdd(Request $request, ArchiveRepository $archive)
    {
        $user = Auth::user();
        if (!$user || !$user->UserId) {
            return response()->json([
                'code' => -1,
                'msg' => '未登录'
            ]);
        }

        if (Gate::denies('create', $this->comment->createModel())) {
            return response()->json([
                'code' => -1,
                'msg' => '您已被禁言，无法发表！'
            ]);
        }

        $objId = (int)$request->input('objid');
        $objType = $request->input('objtype');
        $comment = xssFilter($request->input('comment'));
        $image = xssFilter($request->input('image'));
        $atUser = $request->input('atuser',0);
        $atName = $request->input('atname','');

        if (!$this->checkImageValid($image)) {
            return response()->json([
                'code' => -1,
                'msg' => '图片不合法'
            ]);
        }

        if (!$objId || !in_array($objType,$this->cmttypes,true) || !$comment) {
            return response()->json([
                'code' => -1,
                'msg' => '参数不正确'
            ]);
        }

        if (!$this->checkIsPublished($objType, $objId)) {
            return response()->json([
                'code' => -1,
                'msg' => '请求不合法'
            ]);
        }
        $data = [
            'model_id' => $objId,
            'model_type' => $objType,
            'comment' => $comment,
            'image' => $image,
            'user_id' => $user->UserId,
            'user_name' =>$user->NickName,
            'at_user' => $atUser,
            'at_name' => $atName,
            'updater' => $user->UserId
        ];
        if ($objType == 'App\Entities\ActivityTeacher') {
            $data['status'] = 0;
        }
        $result = $this->comment->create($data);

        if ($result[0]) {
            $archive->captchaCache(Archive::TYPE_COMMENT, 'answer');//验证码统计
            $item = $result[1];
            $item->avatar = $item->user->getAvatar();
            //获取评论对象
            $operateObj = $item->commentable;
            if ($operateObj && isset($operateObj->comment_count)) {
                $operateObj->increment('comment_count',1);
                if ($objType === 'App\Entities\Picture') {
                    $archiveobj = $operateObj->archive;
                    if ($archiveobj && isset($archiveobj->comment_count)) {
                        $archiveobj->increment('comment_count',1);
                    }
                }
            }
            //发送消息
            $messageType = [
                'App\Entities\Archive' => \App\Gad\MessageType::ARTICLE_REPLY,
                'App\Entities\Comment' => \App\Gad\MessageType::COMMENT_REPLY,
                'App\Entities\Picture' => \App\Gad\MessageType::ART_REPLY
            ];
            if ($operateObj && isset($messageType[$objType]) && isset($operateObj['user_id'])) {
                $url = '';
                $name = str_limit(strip_tags($comment),50,'...');
                if ($objType == 'App\Entities\Comment') {
                    $realObj = $operateObj->commentable;
                    if($realObj instanceof Picture) {
                        $realType = 'App\Entities\Picture';
                    } else if ($realObj instanceof Archive) {
                        $realType = 'App\Entities\Archive';
                    } else {
                        $realType = '';
                    }
                } else {
                    $realType = $objType;
                }
                switch ($realType) {
                    case 'App\Entities\Archive':
                        $archive = isset($realObj) ? $realObj : $operateObj;
                        $url = url('/article/detail', $archive->id);
                        break;
                    case 'App\Entities\Picture':
                        $realObj = isset($realObj) ? $realObj : $operateObj;
                        $archive = $realObj->archive;
                        $url = url('/gallery/detail', [$archive->id, $realObj->id]);
                        break;
                }
                if ($url) {
                    //发送站内信
                    if($objType == 'App\Entities\Comment'){
                        $archive = $this->comment->find($objId);
                        $archive->title = strip_tags($archive->comment);
                        $url = $url.'#'.$archive->id.'/'.$item->id;
                    }else{
                        $url = $url.'#'.$item->id;
                    }
                    if ($operateObj['user_id'] != $user->UserId) {
                        $this->dispatch(new SendMessage(
                            $messageType[$objType],
                            $operateObj['user_id'],
                            $user->UserId,
                            $objId, $url, $archive->title,
                            $item->id, $url.'#'.$item->id, strip_tags($name)
                        ));
                    }
                }
            }
            $item->like_count =0;
            $item->comment_count=0;
            $item = array_except($item, ['commentable']);
            return response()->json([
                'code' => 0,
                'msg' => '成功',
                'comment' => $item
            ]);
        } else {
            return response()->json([
                'code' => -1,
                'msg' => '保存失败'
            ]);
        }
    }

    private function checkIsPublished($type, $id)
    {
        switch ($type) {
            case 'App\Entities\Archive':
                $archive = Archive::find($id);
                return !empty($archive) && $archive['status'] == 0;
            case 'App\Entities\Picture':
                $picture = Picture::find($id);
                $archive = $picture->archive;
                return !empty($archive) && $archive['status'] == 0 && $archive['status'] == 0;
            case 'App\Entities\CityStation':
                $station = CityStation::find($id);
                return !empty($station) && $station['status'] == 0;
            case 'App\Entities\GamePai':
                $game = GamePai::find($id);
                return !empty($game) && $game['status'] == 0;
            case 'App\Entities\Project':
                $project = HatchProject::find($id);
                return !empty($project) && $project['is_public'] == 1;
        }
        return true;
    }

    public function checkImageValid($url)
    {
        $domain = parse_url($url, PHP_URL_HOST);

        return empty($url) || ($domain == 'gadimg-10045137.image.myqcloud.com');
    }

    //编辑评论
    public function postEdit(Request $request)
    {
        $user = Auth::user();
        if (!$user || !$user->UserId) {
            return response()->json([
                'code' => -1,
                'msg' => '未登录'
            ]);
        }
        $id = (int)$request->input('id');
        $comment = xssFilter($request->input('comment'));
        $image = xssFilter($request->input('image'));
        if (empty($image)) {
            $image = '';
        }
        if (!$id || !$comment) {
            return response()->json([
                'code' =>-1,
                'msg' => '参数不正确'
            ]);
        }
        $item = $this->comment->find($id);
        if (!$item) {
            return response()->json([
                'code' => -1,
                'msg' => '对象不存在'
            ]);
        }

        if (Gate::denies('edit', $item)) {
            return response()->json([
                'code' => -1,
                'msg' => '无权限'
            ]);
        }

        $ret = $this->comment->update($id, ['comment'=>$comment, 'updater'=>$user->UserId, 'image'=>$image]);
        if ($ret[0]) {
            return response()->json([
                'code' => 0,
                'msg' => '保存成功'
            ]);
        } else {
            return response()->json([
                'code' => -1,
                'msg' => '保存失败'
            ]);
        }
    }

    //删除评论
    public function postDel($id)
    {
        $user = Auth::user();
        if (!$user || !$user->UserId) {
            return response()->json([
                'code' => -1,
                'msg' => '未登录'
            ]);
        }
        $id = (int)$id;
        $comment = $this->comment->find($id);
        if (!$comment) {
            return response()->json([
                'code' => -1,
                'msg' => '对象不存在'
            ]);
        }

        //只有管理员和创建人能删除
        if (Gate::denies('delete', $comment)) {
            return response()->json([
                'code' => -1,
                'msg' => '无权限'
            ]);
        }

        $ret = $this->comment->delete($id);
        if ($ret) {
            $operateObj = $comment->commentable;
            if ($operateObj && isset($operateObj->comment_count)) {
                $operateObj->decrement('comment_count',1);
                if ($operateObj->getTable() === 'gad_pictures') {
                    $archiveobj = $operateObj->archive;
                    if ($archiveobj && isset($archiveobj->comment_count)) {
                        $archiveobj->decrement('comment_count',1);
                    }
                }
            }
            return response()->json([
                'code' => 0,
                'msg' => '删除成功'
            ]);
        } else {
            return response()->json([
                'code' => -1,
                'msg' => '删除失败'
            ]);
        }

    }
}
