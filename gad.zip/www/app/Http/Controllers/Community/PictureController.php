<?php

namespace App\Http\Controllers\Community;

use App\Entities\Archive;
use App\Entities\Follow;
use App\Gad\MessageType;
use App\Jobs\SendMessage;
use App\Repositories\ArchiveRepository;
use App\Repositories\CommentRepository;
use App\Repositories\FavoriteRepository;
use App\Repositories\FollowRepository;
use App\Repositories\LikeRepository;
use App\Repositories\OperationRepositoryEloquent;
use App\Repositories\PictureRepository;
use App\Repositories\TagRepository;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Gate;
use Auth;
use Illuminate\Http\Request;

class PictureController extends Controller
{
    protected $picture;

    public function __construct(PictureRepository $picture)
    {
        $this->picture = $picture;
        $this->middleware('auth', ['only' => ['getEdit', 'getDetailList', 'postSaveAtlas']]);
        $this->middleware('captcha:archive2', ['only' => ['postSaveAtlas']]);
    }

    //首页
    public function getIndex(TagRepository $tagRepository, $tag = 'hot', $type = 2, $subtag = 0, $order = 'hot')
    {
        return redirect('/resource/list');
        if ($type != 1) {
            $type = 2;
        }
        if ($order != 'new') {
            $order = 'hot';
        }
        if ($tag != 'art') {
            $tag = 'hot';
        }
        $subTagList = array(
            0 => '全部类型', 10498 => '美术新手', 10476 => '原画', 10506 => '3D',
            10559 => 'UI', 10548 => '特效', 10552 => '技术美术', 10530 => '动画'
        );
        if (intval($subtag)) {
            $tagitem = $tagRepository->findBy('id', $subtag);
        }
        $commentre = new CommentRepository();
        if (!empty($tagitem)) { //仅当有二级标签时，按照标签拉取数据。
            $workslist = $this->picture->findByTag($tagRepository, $tagitem, 0, $order, 24, $tag, $type);
            if ($type == 2) {    //点评时需要寻找导师回答
                foreach ($workslist as $works) {
                    $comments = $commentre->with(['user'])
                        ->where('model_id', '=', $works->id)
                        ->where('model_type', '=', 'App\Entities\Picture')
                        ->orderBy('created_at', 'desc')
                        ->findAll();
                    foreach ($comments as $comment) {
                        if ($comment->user->TutorStatus == 2) {
                            $comment->comment = strip_tags($comment->comment);
                            $works->tutoranswer = $comment;
                            break;
                        }
                    }
                    $works->avatar = $works->user->getAvatar();
                }
            }
        } else {
            $workslist = $this->picture->getList($type, 0, $order, 0, 24, $tag);
        }
        $tagName = $tag;
        return view('community.workslist', compact('workslist', 'subTagList', 'tagName', 'type', 'order', 'subtag'));
    }

    //异步拉取接口
    public function getList(Request $request, TagRepository $tagRepository)
    {
        $page = intval($request->input('page'));
        $pageSize = intval($request->input('pagesize'));
        $order = $request->input('order') == 'new' ? 'new' : 'hot';
        $tag = $request->input('tag') == 'art' ? 'art' : 'hot';
        //热门需要添加is_hot判断

        $type = $request->input('type') == 1 ? 1 : 2;
        $subtag = intval($request->input('subtag'));
        if ($subtag) {
            $tagitem = $tagRepository->findBy('id', $subtag);
        }

        if (!empty($tagitem)) { //仅当有二级标签时，按照标签拉取数据。
            $list = $this->picture->findByTag($tagRepository, $tagitem, $page, $order, $pageSize, $tag, $type)->items();
            $commentre = new CommentRepository();
            if ($type == 2) {    //点评时需要寻找导师回答
                foreach ($list as $works) {
                    $comments = $commentre->with(['user'])
                        ->where('model_id', '=', $works->id)
                        ->where('model_type', '=', 'App\Entities\Picture')
                        ->orderBy('created_at', 'desc')
                        ->findAll();
                    foreach ($comments as $comment) {
                        if ($comment->user->TutorStatus == 2) {
                            $comment->comment = strip_tags($comment->comment);
                            $works->tutoranswer = $comment;
                            break;
                        }
                    }
                    $works->avatar = $works->user->getAvatar();
                }
            }
        } else {
            $list = $this->picture->getList($type, 0, $order, $page, $pageSize, $tag);
        }
        return response()->json(array('code' => 0, 'data' => $list));
    }

    public function getEdit(ArchiveRepository $archive, $id = 0)
    {
        return redirect('/resource/list');
        if ($id) {
            $atlas = $archive->with(['pictures', 'atlas'])->find($id);
            if ($atlas->atlas && $atlas->atlas->type == 1) {
                if (count($atlas->pictures) && ($atlas->pictures[0]['source_type'] == 'model')) {
                    $assetid = $atlas->pictures[0]['mofang_id'];
                    $murl = app()->isLocal() ? 'ci.asset.qq.com' : 'mofang.qq.com';
                    $gurl = app()->isLocal() ? 'dev.gad.qq.com' : 'gad.qq.com';
                    $url = sprintf('https://%s/index/model/draft?modelID=%d&back_url=http://%s/resource/fill-model/%d',
                        $murl, $assetid, $gurl, $assetid);
                    return redirect($url);
                } else {
                    return redirect('/resource/edit/'.$atlas->id);
                }
            }
            if (Gate::denies('edit', $atlas)) {
                abort(403);
            }
            return view('community.worksedit', compact('atlas'));
        } else {
            if (Gate::denies('create', $archive->createModel())) {
                abort(403);
            }
            $atlas = null;
            return view('community.worksedit', compact('atlas'));
        }
    }


    public function getDetailList(Request $request)
    {
        $id = intval($request->input('id'));
        if ($id) {
            $list = $this->picture->where('archive_id', '=', $id)->orderBy('sort', 'asc')->findAll();
        } else {
            $list = null;
        }
        return response()->json(array('code' => 0, 'data' => $list));
    }

    //保存
    public function postSaveAtlas(Request $request, ArchiveRepository $archive, TagRepository $tagRepository)
    {
        return false;
        $data = $request->all();
        $data = array_map('xssFilter', $data);
        $id = intval($data['id']);
        $title = $data['title'];
        $tags = !empty($data['tags']) ? explode(',', $data['tags']) : [];
        $content = '';
        if (!empty($data['piclist'])) {
            foreach ($data['piclist'] as $picture) {
                $content = $content . $picture['content'];
            }
        }
        if (\App\Gad\Func::hasBadWord($id, $content, '', $title)) {
            return response()->json(['code' => -1, 'message' => '非法内容']);
        }
        if (empty($tags)) { //优先采用用户标签，若用户没有输入标签，则根据内容计算
            $tags = $tagRepository->findFromTitleContent($title, $content);
            $tagsinput = implode(',', array_column($tags->slice(0, 6)->toArray(), 'name'));
        } else {
            $tags = $tagRepository->whereIn('name', $tags)->findAll();
            $tagsinput = $data['tags'];
        }
        $status = intval($data['status']) == 2 ? 2 : 1;
        $projectid = intval($data['projectid']);
        if ($status == 2) {
            $msg = '发表成功';
        } else {
            $msg = '保存成功';
        }
        if (!in_array($status, array(1, 2))) {
            $status = 2;
        }
        if ($id) {  //更新图集
            $atlas = $archive->with(['pictures'])->find($id);
            if ($atlas) {
                if (Gate::denies('edit', $atlas)) {
                    return response()->json(array('code' => 2, 'message' => '没有权限修改'));
                }
                if ($status == 2) { //白名单判断
                    $status = Gate::allows('verify', $archive->createModel()) ? 0 : 2;
                }
                $ids = array_column($atlas->pictures->toArray(), 'id');
                $pictures = $this->picture->savePictures($data, $ids, $status);
                $params = [
                    'title' => $title,
                    'tag' => $tagsinput,
                    'total' => count($pictures),
                    'status' => $status,
                    'extra' => array_slice($pictures, 0, 3),
                    //'sort_time' => time(),
                    'project_id' => $projectid
                ];
                //首次发表
                if ($atlas->status == 1 && $status != 1 && $atlas->publish_time == '0000-00-00 00:00:00') {
                    $params['publish_time'] = date("Y-m-d H:i:s");
                }
                if (!empty($pictures)) {
                    //更新主表的信息

                    $result = $archive->update($id, $params);
                    if ($result[0]) {
                        $archive->addTags($atlas, $tags);
                        return response()->json(array('code' => 0, 'message' => $msg, 'id' => $result[1]['id']));
                    } else {
                        return response()->json(array('code' => 1, 'message' => '图集信息保存失败'));
                    }
                } else {
                    return response()->json(array('code' => 1, 'message' => '图片保存失败'));
                }
            } else {
                return response()->json(array('code' => 1, 'message' => '图集不存在'));
            }
        } else {    //添加
            if (Gate::denies('create', $archive->createModel())) {
                return response()->json(array('code' => 1, 'message' => '您没有权限创建'));
            }
            if ($status == 2) { //白名单判断
                $status = Gate::allows('verify', $archive->createModel()) ? 0 : 2;
            }
            $params = [
                'title' => $title,
                'status' => $status,
                'channel_id' => 2,
                'class_id' => Archive::TYPE_WORKS,
                'user_id' => Auth::user()['UserId'],
                'user_name' => Auth::user()['NickName'],
                'creator' => Auth::user()['UserId'],
                'tag' => $tagsinput,
                'sort_time' => time(),
                'project_id' => $projectid
            ];
            if ($status != 1) {
                $params['publish_time'] = date("Y-m-d H:i:s");
            }
            $result = $archive->create($params);
            if ($result[0]) {
                $data['id'] = $result[1]['id'];
                $pictures = $this->picture->savePictures($data, [], $status);
                if (!empty($pictures)) {
                    $archive->update($data['id'], ['total' => count($pictures), 'extra' => array_slice($pictures, 0, 3)]);
                    $follow = new FollowRepository();
                    $followers = $follow->getFans(Auth::user()->UserId)->pluck('user_id')->toArray();
                    if ($status == 0) {
                        $this->dispatch(new SendMessage(
                            MessageType::WORK_NEW,
                            $followers,
                            Auth::user()->UserId,
                            $data['id'],
                            url('/gallery/detail', $data['id']),
                            $title
                        ));
                        $archive->captchaCache(2, 'archive');//验证码统计
                    }
                    return response()->json(array('code' => 0, 'message' => $msg, 'id' => $result[1]['id']));
                } else {
                    return response()->json(array('code' => 1, 'message' => '图片保存失败'));
                }
            } else {
                return response()->json(array('code' => 1, 'message' => '图集信息保存失败'));
            }
        }
    }

    //判断是否有编辑权限
    public function judgeEditRight($user, $userid)
    {
        if (!$user) {
            return false;
        }
        return $user->UserId === $userid || $user->roles->contains(2);
    }

    public function getDetail(
        Request $request,
        ArchiveRepository $archive,
        $id,
        LikeRepository $like,
        FavoriteRepository $fav,
        OperationRepositoryEloquent $operation,
        TagRepository $tag,
        $pid = 0
    )
    {
        $atlas = $archive->with(['tags', 'user', 'pictures', 'atlas'])->find($id);
        if (empty($atlas) || !count($atlas->pictures)) {
            abort(404);
        }

        if ($atlas->status && Gate::denies('edit', $atlas)) {
            abort(403);
        }
        $picture = null;
        foreach ($atlas->pictures as $item) {
            if ($pid) {
                if ($item->id == $pid) {
                    $picture = $item;
                    break;
                }
            } else {
                if ($item->sort == 0) {
                    $picture = $item;
                    break;
                }
            }
        }
        if (!$picture) {
            $picture = $atlas->pictures[0];
        }
        if (Auth::check()) {
            $myLike = $like->myLike('App\Entities\Picture', $pid, Auth::user()['UserId']);
            $myFavorite = $fav->myFavorite('App\Entities\Picture', $pid, Auth::user()['UserId']);
            $myFollow = count(Follow::where('user_id', Auth::user()['UserId'])
                ->where('follow_user', $atlas->user_id)->where('status', 0)->first());
        } else {
            $myLike = $myFavorite = $myFollow = null;
        }
        $relatedHot = $archive->getRelatedArchives($atlas, 1, 'hot_score', 10);
        $QQGroup = $operation->getQQGroup($tag, '游戏美术');

        //$archive->addVisitCount($id, $pid, $this->picture);
        if ($request->ajax() || $request->wantsJson()) {
            for ($i = 0; $i < count($atlas->pictures); $i++) {
                $plike = $like->myLike('App\Entities\Picture', $atlas->pictures[$i]->id, Auth::user()['UserId']);
                $atlas->pictures[$i]->pfav = $fav->myFavorite('App\Entities\Picture', $atlas->pictures[$i]->id, Auth::user()['UserId']);
                $atlas->pictures[$i]->liked = ($plike && $plike->status == 1) ? true : false;
            }
            header("Cache-Control: no-store");  //防止缓存造成的返回问题。
            $data = array(
                'atlas' => $atlas,
                'picture' => $picture,
                'myLike' => $myLike,
                'myFavorite' => $myFavorite,
                'myFollow' => $myFollow,
                'relatedHot' => $relatedHot,
                'editright' => Gate::allows('edit', $atlas),
                'QQGroup' => $QQGroup
            );
            return response()->json(array('code' => 0, 'data' => $data));
        } else {
            if($atlas->atlas && $atlas->atlas->type == 1) {
                return redirect('/resource/detail/' . $id);
            }
            return view('community.worksdetail', compact('atlas', 'picture', 'myLike', 'myFavorite', 'myFollow', 'relatedHot', 'QQGroup'));
        }
    }

    public function postDeleteAtlas(Request $request, ArchiveRepository $archive)
    {
        $id = intval($request->input('id'));
        $atlas = null;
        if ($id) {
            $atlas = $archive->with(['tags', 'user', 'pictures'])->find($id);
        }
        if (!empty($atlas) && Gate::allows('edit', $atlas)) {
            foreach ($atlas->pictures as $onepicture) {
                $this->picture->delete($onepicture['id']);
            }
            $archive->removeTags($atlas);
            $archive->delete($id);
            return response()->json(array('code' => 0, 'msg' => '删除成功'));
        } else {
            return response()->json(array('code' => -1, 'msg' => '删除失败'));
        }
    }
}
