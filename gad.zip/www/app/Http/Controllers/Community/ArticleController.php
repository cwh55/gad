<?php

namespace App\Http\Controllers\Community;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\LiveRepositoryEloquent;
use App\Repositories\ArchiveRepository;
use Auth;
use Gate;
use App\Gad\Func;
use App\Repositories\TagRepository;

class ArticleController extends Controller {

    public function __construct() {
        $this->middleware('auth', ['only' => ['getEdit', 'postSaveDraft', 'postSave']]);
        $this->middleware('captcha:archive'.\App\Entities\Archive::TYPE_ARTICLE, ['only' => ['postSave']]);
    }

    public function getIndex(Request $request, ArchiveRepository $archive, LiveRepositoryEloquent $live, TagRepository $tag, $tagName = '', $orderType = 'new') {
        $liveList = $live->getAllList(3);
        $hotTags = $tag->getHotTags($tagName);
        $tagValue = isset(TagRepository::$tagMap[$tagName]) ? TagRepository::$tagMap[$tagName] : '';
        if (!$tagValue) {
            $list = $archive->getList(1, null, 0, 20, $orderType);
        } else {
            $list = $archive->getListByTagName($tagValue, 1, null, 20, $orderType, true, $tagName);
        }
        $draftCount = Auth::User() ? $archive->getDraftCount(Auth::User()->UserId) : 0;
        return view('community.article', compact('list', 'liveList', 'orderType', 'hotTags', 'tagName', 'draftCount'));
    }

    public function postFeedList(Request $request, ArchiveRepository $archive) {
        try {
            $channel_id = intval($request->input('channel_id'));
            $page = intval($request->input('page'));
            $pageSize = intval($request->input('pageSize'));
            $orderType = $request->input('orderType');
            $tagName = $request->input('tagName');
            $tagValue = isset(TagRepository::$tagMap[$tagName]) ? TagRepository::$tagMap[$tagName] : '';
            if (!$tagValue) {
                $list = $archive->getList(1, $channel_id, $page, $pageSize, $orderType);
            } else {
                $list = $archive->getListByTagName($tagValue, 1, $page, 20, $orderType,true, $tagName);
            }
            return response()->json(array('code' => 0, 'data' => $list));
        } catch (\Exception $ex) {
            return response()->json(array('msg' => $ex->getMessage(), 'code' => 1));
        }
    }

    public function getRelatedArchives(Request $request, ArchiveRepository $archive) {
        $id = intval($request->input('id'));
        $page = intval($request->input('page'));
        $orderBy = $request->input('orderBy');
        $pageSize = intval($request->input('pageSize'));
        $tagName = $request->input('tagName');
        $tagValue = isset(TagRepository::$tagMap[$tagName]) ? TagRepository::$tagMap[$tagName] : '';
        if ($tagValue) {
            $list = $archive->getListByTagName($tagValue, 0, $page - 1, $pageSize, $orderBy);
        } else {
            $detail = $archive->find($id);
            if (empty($detail)) {
                abort('404');
            }
            $list = $archive->getRelatedArchives($detail, $page, $orderBy, $pageSize);
        }
        return response()->json(array('code' => 0, 'data' => $list));
    }

    public function getDetail(Request $request, ArchiveRepository $archive, \App\Repositories\LikeRepository $like, \App\Repositories\FavoriteRepository $fav, \App\Repositories\OperationRepositoryEloquent $operation, TagRepository $tag, $id) {
        $id = intval($id);
        $detail = $archive->with(['article', 'user'])->find($id);
        if (is_null($detail)) {
            // 旧版文章通过ccid查找，并跳转到新文章id
            $detail = $archive->findBy('ccid', $id);
            if ($detail) {
                return redirect('/article/detail/' . $detail->id, 301);
            }
        }

        if (empty($detail) || empty($detail->article) || ($detail->status != 0 && empty($detail->article->content))) {
            //文章不存在或者未曾经审核过的
            abort('404');
        }
        $QQGroup = $operation->getQQGroup($tag, $detail->tag);
        if (Auth::check()) {
            $myLike = $like->myLike('App\\Entities\\Archive', $id, Auth::user()['UserId']);
            $myFavorite = $fav->myFavorite('App\\Entities\\Archive', $id, Auth::user()['UserId']);
            $myFollow = count(\App\Entities\Follow::where('user_id', Auth::user()['UserId'])->where('follow_user', $detail->user_id)->where('status', 0)->first());
            $canEdit = \App\Models\User::judgeEditRight(Auth::user(), $detail->user_id);
        } else {
            $myLike = $myFavorite = $myFollow = null;
            $canEdit = false;
        }
        $userRecent = $archive->getRecentByUser($detail->user_id, $id);
        //$archive->addVisitCount($id);
        $relatedArchives = $archive->getRelatedArchives($detail);
        //异步加载时返回json
        if ($request->ajax()) {
            return response()->json([
                'code' => 0,
                'detail' => $detail,
                'myLike' => $myLike,
                'myFavorite' => $myFavorite
            ]);
        }
        return view('community.article_detail', compact('detail', 'userRecent', 'myLike', 'myFavorite', 'myFollow', 'QQGroup', 'relatedArchives', 'canEdit'));
    }

    public function getPreview(ArchiveRepository $archive, $id) {
        $detail = $archive->with(['article', 'user'])->find($id);
        if (empty($detail) || $detail['status'] != 0 && !\App\Models\User::judgeEditRight(Auth::user(), $detail->user_id)) {
            abort('404');
        }
        $detail->article->content = $detail->article->draft_content;
        return view('community.article_preview', compact('detail'));
    }

    public function getEdit(ArchiveRepository $archive, $id = 0) {
        $id = intval($id);
        if ($id) {
            $detail = $archive->with(['article', 'user'])->find($id);
            if (!\App\Models\User::judgeEditRight(Auth::user(), $detail['user_id'])) {
                throw new \Exception('你没有权限修改这篇文章');
            }
            $detail->showTags = $detail->tag ? explode(',', $detail->tag) : [];
            if($detail->status != 0){
                //如果未审核通过的内容，则加载出草稿
                if($detail->article->draft_content){
                    $detail->article->content = $detail->article->draft_content;
                }
                if($detail->article->draft_content_md){
                    $detail->article->content_md = $detail->article->draft_content_md;
                }
            }
        } else {
            $detail = null;
        }
        return view('community.article_edit', compact('detail'));
    }

    public function getTags(TagRepository $tag, $class_id = 1, $tagName = '') {
        if ($tagName) {
            $list = $tag->where('alias', 'like', "%{$tagName}%")->findAll(['id', 'name', 'alias']);
        } else if ($class_id) {
            //日志下方推荐标签：策划、程序、美术、VR/AR
            //问答下方推荐标签：策划、程序、VR/AR
            //话题下方推荐标签：策划、程序、VR/AR
            //作品下方推荐标签：美术
            $arr = $class_id == 1 ? ['游戏策划', '游戏开发', '游戏美术', 'VR&AR'] : ($class_id == 2 ? ['游戏美术'] : ($class_id == 3 ? ['游戏策划', '游戏开发', 'VR&AR'] : ['游戏策划', '游戏开发', 'VR&AR']));
            $list = $tag->whereIn('name', $arr)->findAll(['id', 'name', 'alias']);
        }
        return response()->json($list);
    }

    /*
     * 自动初始化相关的参数
     */

    private function gatherInput($input, $tagRepository) {
        $input = array_map('xssFilter', $input);
        $input['cover'] = empty($input['cover']) ? '' : $input['cover'];
        $input['description'] = $description = mb_substr(strip_tags($input['article']['content']), 0, 200);
        $input['is_video'] = $input['is_video'] * 1 && $input['cover'] ? 1 : 0;
        $id = !empty($input['id']) ? intval($input['id']) : 0;
        $tags = !empty($input['tags']) ? explode(',', $input['tags']) : [];
        if (!in_array($input['status'], [1, 2])) {
            throw new \Exception('文章状态错误');
        }
        if (!isset($input['article']['attachments']) || !is_array($input['article']['attachments'])) {
            $input['article']['attachments'] = [];
        }
        if ($id > 0) {
            $archive = ['title' => $input['title'], 'description' => $input['description'], 'cover' => $input['cover'], 'tag' => implode(',', $tags), 'is_video' => $input['is_video'], 'status' => $input['status'], 'sort_time' => time(), 'publish_time' => date('Y-m-d H:i:s'), 'project_id' => $input['project_id']];
            $article = ['content_type' => intval($input['article']['content_type']), 'draft_content' => $input['article']['content'], 'draft_content_md' => $input['article']['content_md'], 'type' => intval($input['article']['type']), 'source' => $input['article']['source'], 'attachments' => $input['article']['attachments']];
        } else {
            $archive = ['class_id' => 1, 'title' => $input['title'], 'description' => $description, 'cover' => $input['cover'], 'tag' => implode(',', $tags), 'user_id' => Auth::user()->UserId, 'creator' => Auth::user()->UserId, 'is_video' => $input['is_video'], 'status' => $input['status'], 'extra' => [], 'sort_time' => time(), 'publish_time' => date('Y-m-d H:i:s'), 'project_id' => $input['project_id']];
            $article = ['content_type' => intval($input['article']['content_type']), 'draft_content' => $input['article']['content'], 'draft_content_md' => $input['article']['content_md'], 'type' => intval($input['article']['type']), 'source' => $input['article']['source'], 'attachments' => $input['article']['attachments']];
        }
        if (empty($tags)) {
            $tags = $tagRepository->findFromTitleContent($archive['title'], $article['draft_content']);
            $archive['tag'] = implode(',', array_column($tags->slice(0, 6)->toArray(), 'name'));
        } else {
            $tags = $tagRepository->whereIn('name', $tags)->findAll();
        }

        $archive['channel_id'] = getChannelId($tags);

        return compact('id', 'archive', 'article', 'tags');
    }

    public function postSave(Request $request, ArchiveRepository $archive, \App\Repositories\ArticleRepository $article, TagRepository $tagRepository) {
        $this->validate($request, [
            'title' => 'required',
            'article' => 'required|array',
        ]);
        $input = $this->gatherInput($request->all(), $tagRepository);
        if (Gate::allows('verify', $archive->createModel()) && $input['archive']['status'] == 2) {
            $input['archive']['status'] = 0;
        }

        $id = $input['id'];
        if (\App\Gad\Func::hasBadWord($id, $input['article']['draft_content'], $input['archive']['description'], $input['archive']['title'])) {
            return response()->json(['code' => -1, 'message' => '非法内容']);
        }
        if ($id > 0) {
            $articleInfo = $archive->with(['article'])->find($id);
            if (!\App\Models\User::judgeEditRight(Auth::user(), $articleInfo['user_id'])) {
                throw new \Exception('你没有权限修改这篇文章');
            }
            if (!(in_array($input['archive']['status'], [0, 2]) && strtotime($articleInfo['publish_time']) < strtotime($articleInfo->getOriginal('created_at'))-15)) {
                unset($input['archive']['publish_time'], $input['archive']['sort_time']); //更新发表时间的条件：本次设置为发表状态，且文章从未被设置过
            }

            list($status, $archiveInfo) = $archive->update($id, $input['archive']);
            if (!$status) {
                throw new \Exception('更新数据失败');
            }
            list($status, $temp) = $article->update($articleInfo->article->id, $input['article']);
            if (!$status) {
                throw new \Exception('更新数据失败');
            }
            if($archiveInfo->status == 0){
                $article->reviewArticle($temp);
            }

            $archive->addTags($articleInfo, $input['tags']);
        } else {
            if (Gate::denies('create', $archive->createModel())) {
                return abort(403, '你无法发表文章');
            }
            if ($archive->findWhere(['title', $input['archive']['title']])->count() >= 1) {
                throw new \Exception('标题已存在，请修改后重新提交');
            }
            if ($input['archive']['status'] == 1) {
                $input['archive']['publish_time'] = date('Y-m-d H:i:s', strtotime('-30 seconds')); //如果首次提交文章不设置为发表状态，则让publish_time等于当时30秒之前
            }

            // 特殊运营帐号添加下沉处理
            $specialUserId = ['535162', '2231152', '2191628', '451240', '33894', '704370', '1449105', '659510', '535162', '2248870'];
            if (in_array($input['archive']['user_id'], $specialUserId)) {
                $input['archive']['sort_time'] = intval($input['archive']['sort_time'] / 100);
            }

            list($status, $insertInfo) = $archive->create($input['archive']);
            if (!$status) {
                throw new \Exception('更新数据失败');
            }
            $id = $input['article']['archive_id'] = $insertInfo->id;
            list($status, $temp) = $article->create($input['article']);
            if (!$status) {
                throw new \Exception('更新数据失败');
            }
            $archive->addTags($insertInfo, $input['tags']);
            if ($insertInfo['status'] == 0) {
                $article->reviewArticle($temp);
                $followRepository = new \App\Repositories\FollowRepository();
                $fans = $followRepository->getFans($insertInfo['user_id'], ['user_id'])->toArray();
                dispatch(new \App\Jobs\SendMessage(\App\Gad\MessageType::ARTICLE_NEW, array_column($fans, 'user_id'), $insertInfo['user_id'], $insertInfo['id'], url('/article/detail', $insertInfo['id']), $insertInfo['title']));
            }
            $archive->captchaCache(\App\Entities\Archive::TYPE_ARTICLE, 'archive');  //验证码统计
        }
        if ($request->wantsJson()) {
            return response()->json(array('code' => 0, 'data' => $id, 'needReview' => $input['archive']['status'] != 0));
        } else {
            return redirect('/article/detail/' . $id);
        }
    }

    public function postDelete(Request $request, ArchiveRepository $archive) {
        $id = intval($request->input('id'));
        if (!Auth::check()) {
            return response()->json(['code' => 1, 'msg' => '未登录']);
        }
        $articleInfo = $archive->find($id, ['user_id']);
        if (!\App\Models\User::judgeEditRight(Auth::user(), $articleInfo['user_id'])) {
            throw new \Exception('你没有权限修改这篇文章');
        }
        $archive->delete($id);
        return response()->json(['code' => 0]);
    }

    public function getMyRecommendInfo(\App\Repositories\FollowUserRepository $followUserRepository, \App\Repositories\FollowRepository $follow) {
        if (Auth::check()) {
            $recommendOperation = \Redis::connection()->hGetAll('gad:community:recommendOperation:' . Auth::user()->UserId);
            $tagList = Auth::user()->tags;
            $followList = $followUserRepository->with(['user'])->findAll();
            $myFollowList = $follow->where('user_id', Auth::user()->UserId)->where('status', 0)->whereIn('follow_user', array_column($followList->toArray(), 'user_id'))->findAll(['follow_user']);
            return response()->json(['code' => 0, 'data' => ['tagList' => $tagList, 'myFollowList' => $myFollowList, 'recommendOperation' => $recommendOperation]]);
        }
    }

    public function getRecommendInfo(TagRepository $tag, \App\Repositories\FollowUserRepository $followUserRepository) {
        $tagList = $tag->findWhere(['is_recommend', '=', 1]);
        $followList = $followUserRepository->with(['user'])->findAll();
        return response()->json(['code' => 0, 'data' => ['tagList' => $tagList, 'followList' => $followList]]);
    }

    public function postSetMyTags(TagRepository $tag, Request $request) {
        if (!Auth::check()) {
            return response()->json(['code' => 1, 'msg' => '未登录']);
        }
        $this->validate($request, ['list' => 'required|array']);
        $list = $request->input('list');
        $sublist = $tag->whereIn('id', $list)->findAll();
        //自动插入父级标签
        foreach ($sublist as $r) {
            if ($r->lvl != 1) {
                $list[] = $r->p1;
            }
        }
        Auth::user()->tags()->sync(array_unique($list));
        \Redis::connection()->hSet('gad:community:recommendOperation:' . Auth::user()->UserId, 'tag', 1);
        return response()->json(['code' => 0]);
    }

    public function postFollowUsers(\App\Repositories\FollowUserRepository $followUserRepository, \App\Repositories\FollowRepository $follow, Request $request) {
        if (!Auth::check()) {
            return response()->json(['code' => -2, 'msg' => '未登录']);
        }
        $list = array();
        if (is_array($request->input('list'))) {
            foreach ($request->input('list') as $li) {
                $list[] = $li * 1;
            }
        }
        $followList = $followUserRepository->findAll();
        $myFollowList = $follow->where('user_id', Auth::user()->UserId)->whereIn('follow_user', array_column($followList->toArray(), 'user_id'))->findAll(['id', 'follow_user', 'status']);
        $myFollowListHash = array();
        foreach ($myFollowList as $r) {
            $myFollowListHash[$r->follow_user] = $r;
        }
        foreach ($followList as $r) {
            if (in_array($r->user_id, $list)) {
                //关注
                if (isset($myFollowListHash[$r->user_id])) {
                    if ($myFollowListHash[$r->user_id]->status != 0) {
                        $myFollowListHash[$r->user_id]->status = 0;
                        $myFollowListHash[$r->user_id]->save();
                    }
                } else {
                    $follow->create(['user_id' => Auth::user()->UserId, 'follow_user' => $r->user_id, 'status' => 0]);
                }
            } else {
                //取消
                if (isset($myFollowListHash[$r->user_id])) {
                    if ($myFollowListHash[$r->user_id]->status != 1) {
                        $myFollowListHash[$r->user_id]->status = 1;
                        $myFollowListHash[$r->user_id]->save();
                    }
                }
            }
        }
        \Redis::connection()->hSet('gad:community:recommendOperation:' . Auth::user()->UserId, 'follow', 1);
        return response()->json(['code' => 0]);
    }
    
    public function getTest1(){
        $shendun = new \App\Gad\Shendun();
        $shendun->report(18643, 'article', \App\Gad\Shendun::VIEW, 1);
    }

}
