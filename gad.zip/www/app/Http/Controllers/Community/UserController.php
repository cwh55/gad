<?php

namespace App\Http\Controllers\Community;

use App\Entities\Feed;
use App\Entities\User;
use App\Repositories\AnswerRepository;
use App\Repositories\ArchiveRepository;
use App\Repositories\CommentRepository;
use App\Repositories\FollowRepository;
use App\Repositories\LikeRepository;
use Illuminate\Http\Request;
use App\Presenters\CommunityPresenter;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\FeedRepository;
use App\Repositories\UserRepository;
use Auth;
use PhpParser\Node\Expr\Array_;

class UserController extends Controller
{
    private $follow;
    private $archive;
    private $like;
    private $answer;
    private $comment;

    public function __construct(
        FollowRepository $follow,
        ArchiveRepository $archive,
        LikeRepository $like,
        UserRepository $user,
        AnswerRepository $answer,
        CommentRepository $comment
    )
    {
        $this->follow = $follow;
        $this->archive = $archive;
        $this->like = $like;
        $this->user = $user;
        $this->answer = $answer;
        $this->comment = $comment;
        $this->middleware('auth', ['only'=>['getIndex','getEdit','postEdit','getFollows','getFans']]);
    }
    
    public function getIndex(Request $request, FeedRepository $feedRepository, $orderType = 'new')
    {
        $uid = $request->input('uid');
        $hasMore = 0;
        if($uid) {
            $archives = $feedRepository->getMy($uid);   //客人态
        } else if(Auth::check()) {
            $archives = $feedRepository->getMy(Auth::user()->UserId);   //主人态
        }

        if(!empty($archives)) {
            $presenter = new CommunityPresenter();
            foreach ($archives as $archive) {
                $archive->avatar = !$archive->Avatar ? 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg' : $archive->Avatar;
                if ($archive->extra) {
                    $archive->extra = json_decode($archive->extra, true);
                }
                $archive->tags = explode(',', $archive->tag);
                $archive->format_comment_count = $presenter->formatNumber($archive->comment_count);
                $archive->format_like_count = $presenter->formatNumber($archive->like_count);
                $archive->format_view_count = $presenter->formatNumber($archive->view_count);
                $archive->format_favorite_count = $presenter->formatNumber($archive->favorite_count);
                $archive->user_name = $archive->NickName;
            }
            $archives = collect($archives);
            $hasMore = $archives->count() == $pageSize ? true : false;
        }
        $archives['hasMorePage'] = $hasMore;
        $tag = 'my';
        $orderBy = $orderType;
        $hotTags = $tagRepository->getHotTags($tag);
        return view('community.feeds', compact('archives', 'page', 'tag', 'pageSize', 'tagName', 'orderBy', 'hotTags'));
    }

    public function getProfile(Request $request, FeedRepository $feedRepository, $id='')
    {
        $ARCTYPE = (object) array(
            'FEED' => [11,12],
            'ANS_QUS' => 3,
            'LOG_WORK' => [1,2],
            'TOPIC' => 4,
            'LIVE' => 5 //LIVE的判断为action_id = 61
        );
        //个人主页
        $isLogin = Auth::check();

        //以下if else 是为了兼容之前设计/u/profile 不带id进入个人主页的问题

        if(!$isLogin && empty($id)) {
            return redirect()->guest('/login');
        } else if($isLogin && ( empty($id) || ( $id == Auth::user()['UserId']))){
            if(empty($id)) {
                return redirect('/u/profile/'.Auth::user()['UserId']);
            }

            $id = Auth::user()['UserId'];
            $archives = $feedRepository->getUserActions($id);
            $userInfo = $this->user->find($id);
            $visible = $userInfo->getVisible();
            $visible[] = 'isHost';
            $visible[] = 'cover';
            $userInfo->setVisible($visible);
            $userInfo->isHost = true;
            //获取统计数
            $count = $this->getUserInfoCount($userInfo->UserId);
            $count->archives = $feedRepository->getUserActionCount($id,0,[41,42,43,44]);
            return view('community.profile.host',compact('archives', 'ARCTYPE', 'userInfo', 'isLogin', 'count'));
        } else {
            $archives = $feedRepository->getUserActions($id);
            $userInfo = $this->user->find($id);
            $visible = $userInfo->getVisible();
            //过滤敏感信息
            if($qqnoKey = array_search('QQNo',$visible)){
                array_splice($visible,$qqnoKey,1);
            }
            array_push($visible,'isHost','followStatus');
            $userInfo->setVisible($visible);
            $userInfo->isHost = false;
            //获取关注状态
            $userInfo->followStatus = $this->follow->getFollowStatus($id);
            $count = $this->getUserInfoCount($id);
            $count->archives = $feedRepository->getUserActionCount($id,0,[41,42,43,44]);
            return view('community.profile.guest',compact('archives', 'userInfo', 'ARCTYPE', 'isLogin', 'count'));
        }

    }
    

    protected function getUserInfoCount($id)
    {
        $count = collect([]);
        $count->fans = $this->follow->getMyFansCount($id);
        $count->follow = $this->follow->getMyFollowCount($id);
        //我的发表数：包含日志，作品、问答、评论
        $archiveCount = $this->archive->getMyArchiveCount($id);
        $answerCount = $this->answer->getMyAnswerCount($id);
        $commentCount = $this->comment->getMyCommentCount($id);
        $count->archives= $archiveCount + $answerCount + $commentCount;
        //我的收到的赞数，包含日志、作品、问答、评论、回答的赞数
        $archiveLikeCount = $this->archive->getMyLikeCount($id);
        $answerLikeCount = $this->answer->getMyLikeCount($id);
        $commentLikeCount = $this->answer->getMyLikeCount($id);
        $count->like = $archiveLikeCount + $answerLikeCount + $commentLikeCount;
        $count->userId = $id;

        return $count;
    }
    //编辑个人信息
    public function getEdit(Request $request, FeedRepository $feedRepository)
    {
        //user model 里使用了visible，使用append不行。
        $loginUser = $this->user->find(Auth::user()->UserId);
        $user = new \stdClass();
        $user->FullAvatar = $loginUser->FullAvatar;
        $user->NickName = $loginUser->NickName;
        $user->Age = $loginUser->Age;
        $user->AgeText = $loginUser->AgeCn;
        $user->Sex = $loginUser->Sex;
        $user->SexText = $loginUser->SexCn;
        $user->Province = $loginUser->Province;
        $user->City = $loginUser->City;
        $user->education = $loginUser->education;
        $user->School = $loginUser->School;
        $user->breif = $loginUser->breif;
        $user->Summary = $loginUser->Summary;
        $user->cover = $loginUser->cover;
        $user->isHost = true;
        $user->inEdit = true;
        $user->expert = Auth::user()->expert;
        $user->type = Auth::user()->type;
        $tagList = Auth::user()->tags->reject(function($item){
            return $item->lvl == 1;
        });
        //获取统计数
        $count = $this->getUserInfoCount(Auth::user()['UserId']);
        $count->archives = $feedRepository->getUserActionCount(Auth::user()['UserId'],0,[41,42,43,44]);

        return view('community.profile.selfinfo',compact('user','tagList','count'));
    }

    //保存个人信息
    public function postEdit(Request $request)
    {
        $all = array_map('xssFilter',$request->all());
        $this->validate($request,[
            'nickName' => 'required|string',
            'avatar' => 'required|url|max:500',
            'age' => 'string|max:20',
            'sex' => 'in:girl,boy',
            'province' => 'string|max:50',
            'city' => 'string|max:50',
            'education' => 'string|max:50',
            'school' => 'string|max:50',
            'breif' => 'string|max:40',
            'summary' => 'string|max:140'
        ]);
        $user = Auth::user();
        $user->NickName = $all['nickName'];
        $user->Avatar = $all['avatar'];
        $user->Age = $all['age'];
        $user->Sex = $all['sex'];
        $user->Province = $all['province'];
        $user->City = $all['city'];
        $user->education = $all['education'];
        $user->School = $all['school'];
        $user->breif = $all['breif'];
        $user->Summary = $all['summary'];

        if ($user->save()) {
            return response()->json([
                'code' => 0,
                'msg' => '更新成功'
            ]);
        } else {
            return response()->json([
                'code' => -1,
                'msg' => '更新失败'
            ]);
        }

    }

    //保存封面图
    public function postCover(Request $request)
    {
        $user = Auth::user();
        $user->cover = $request->input('cover');
        if ($user->save()) {
            return response()->json([
                'code' => 0,
                'msg' => '更新成功'
            ]);
        } else {
            return response()->json([
                'code' => -1,
                'msg' => '更新失败'
            ]);
        }

    }

    public function getFeedlist(Request $request,  FeedRepository $feedRepository)
    {
        try {
            $userId = intval($request->input('user_id'));
            $class_id = intval($request->input('class_id'));
            $action_ids = $request->input('action_ids');
            $page = intval($request->input('page'));
            $pageSize = intval($request->input('pageSize'));
            $archives = $feedRepository->getUserActions($userId,$class_id,$action_ids,$page,$pageSize);
            $count = $feedRepository->getUserActionCount($userId,$class_id,$action_ids);
            if (!empty($archives)) {
                $archives = collect($archives);
            }
            return response()->json(array('code' => 0, 'list' => $archives , 'total_count' => $count));
        } catch (\Exception $ex) {
            return response()->json(array('msg' => $ex->getMessage(), 'code' => 1));
        }
    }

    //获取关注列表
    public function getFollows(Request $request,$id=0)
    {
        $userId = $id;
        //没指定id时，为当前登录用户
        if ($userId == 0 and Auth::check()) {
            $userId = Auth::user()->UserId;
        }
        $isHost = false;
        //判定是主任还是客人
        if ($userId == Auth::user()->UserId) {
            $isHost = true;
        }
        $page = $request->input('page', 1);
        $followList = $this->follow->getUserFollowList($userId, $page);
        $followList->map(function($item){
            $item->isFollowed = true;
        });
        //若为客人态，需要拉去客人与主人的关注人员的关系
        if (!$isHost) {
            $followUserIds = array_column($followList->toArray()['data'], 'follow_user');
            $visitorFollows = $this->follow->getFollowRelations(Auth::user()->UserId, $followUserIds);
            $followList->each(function($item) use($visitorFollows) {
                if (!$visitorFollows->contains('follow_user', $item->follow_user)) {
                    $item->isFollowed = false;
                }
            });
        }
        if ($request->ajax()) {
            return response()->json([
                'code'=>0,
                'followList'=>$followList,
                'hasMore'=>$followList->hasMorePages()
            ]);
        } else {
            $user = $this->user->find($userId);
            $visible = $user->getVisible();
            $visible[] = 'isHost';
            $visible[] = 'cover';
            $visible[] = 'followStatus';
            $user->setVisible($visible);
            $user->isHost = $isHost;
            $user->followStatus = $this->follow->getFollowStatus($userId);
            //获取统计数
            $count = $this->getUserInfoCount($userId);
            $hasMore = $followList->hasMorePages();
            return view('community.profile.follows',compact('user', 'count', 'followList', 'hasMore', 'isHost'));
        }
    }

    //获取粉丝
    public function getFans(Request $request,$id =0)
    {
        $userId = $id;
        //没指定id时，为当前登录用户
        if ($userId == 0 and Auth::check()) {
            $userId = Auth::user()->UserId;
        }
        $isHost = false;
        //判定是主任还是客人
        if ($userId == Auth::user()->UserId) {
            $isHost = true;
        }
        $page = $request->input('page',1);
        $fansList = $this->follow->getUserFansList($userId,$page);
        $fansUserIds = array_column($fansList->toArray()['data'],'user_id');
        //查询主人和粉丝是否为相互关注
        if ($isHost) {
            $hostFollows = $this->follow->getFollowRelations(Auth::user()->UserId,$fansUserIds);
            $fansList->each(function($item) use($hostFollows) {
                if ($hostFollows->contains('follow_user',$item->user_id)) {
                    $item->isFollowed = 2;
                } else {
                    $item->isFollowed = 0;
                }
            });
        } else {
            //主人的粉丝是否为客人的粉丝
            $visitFans = $this->follow->getFansRelations(Auth::user()->UserId,$fansUserIds);
            //客人是否关注了主人的粉丝
            $visitFollows = $this->follow->getFollowRelations(Auth::user()->UserId,$fansUserIds);
            $fansList->each(function($item) use($visitFans,$visitFollows) {
                //相互关注
                if (
                    $visitFans->contains('user_id',$item->user_id)
                    and $visitFollows->contains('follow_user',$item->user_id)
                ) {
                    $item->isFollowed = 2;
                } elseif ($visitFollows->contains('follow_user',$item->user_id)) {
                    //客人关注了粉丝
                    $item->isFollowed = 1;
                } else {
                    $item->isFollowed = 0;
                }
            });

        }
        if ($request->ajax()) {
            return response()->json([
                'code'=>0,
                'fansList'=>$fansList,
                'hasMore'=>$fansList->hasMorePages()
            ]);
        } else {
            $user = $this->user->find($userId);
            $visible = $user->getVisible();
            $visible[] = 'isHost';
            $visible[] = 'cover';
            $visible[] = 'followStatus';
            $user->setVisible($visible);
            $user->isHost = $isHost;
            //获取统计数
            $count = $this->getUserInfoCount($userId);
            $hasMore = $fansList->hasMorePages();
            $user->followStatus = $this->follow->getFollowStatus($userId);
            return view('community.profile.fans', compact('user', 'count','fansList','hasMore','isHost'));
        }
    }
}
