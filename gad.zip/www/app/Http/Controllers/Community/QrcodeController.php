<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 17-5-3
 * Time: 上午10:12
 */

namespace App\Http\Controllers\Community;

use App\Http\Controllers\Controller;
use App\Repositories\LiveOrderRepositoryEloquent;
use App\Repositories\LoreLearnRepositoryEloquent;
use App\Repositories\LorePayRepositoryEloquent;
use App\Repositories\LoreRepositoryEloquent;
use App\Repositories\LoreSectionRepositoryEloquent;
use Auth;
use Gate;
use Illuminate\Http\Request;
use Endroid\QrCode\QrCode;
use Response;

class QrcodeController extends Controller
{
    //获取分享二维码
    public function getIndex(Request $request)
    {
        $url = $request->input('url');

        $qrCode = new QrCode();

        $response = Response::stream(function () use($qrCode, $url) {
            $qrCode->setText($url)->setSize(125)->setPadding(10)->setErrorCorrection('high')->render();
        }, 200, ['Content-Type' => 'image/png']);

        return $response;
    }

} 