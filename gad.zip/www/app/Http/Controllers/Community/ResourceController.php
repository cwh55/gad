<?php

namespace App\Http\Controllers\Community;

use App\Entities\Archive;
use App\Entities\Follow;
use App\Gad\Func;
use App\Gad\MessageType;
use App\Gad\Mofang;
use App\Gad\Weixin;
use App\Jobs\SendMessage;
use App\Models\User;
use App\Repositories\ArchiveRepository;
use App\Repositories\AtlasRepository;
use App\Repositories\CommentRepository;
use App\Repositories\FavoriteRepository;
use App\Repositories\FollowRepository;
use App\Repositories\LikeRepository;
use App\Repositories\OperationRepositoryEloquent;
use App\Repositories\PictureRepository;
use App\Repositories\TagRepository;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Game\GameController;
use Gate;
use Auth;
use Illuminate\Http\Request;
use App\Gad\Tgd;
use Tencent\CL5\Client as CL5;

class ResourceController extends Controller
{
    protected $picture;

    public function __construct(PictureRepository $picture)
    {
        $this->picture = $picture;
        $this->middleware('auth', ['only' => ['getEdit', 'postSaveAtlas']]);
    }

    public function getList( Request $request ,$tag =  0)
    {
        if ($request->input('activityId')) {
            return view('community.gallery.matchpub');
        }
        $tagId = empty($tag) ? 0 : $tag;
        $page = intval($request->input('p', 0));
        $pageSize = intval($request->input('ps', 20));
        $orderBy = $request->input('ob', 'is_hot');
        $works = $this->picture->getTagRelatedArchivesV2($tagId, $page, $pageSize, $orderBy);
        if ($request->ajax() || $request->wantsJson()) {
            return response()->json(array('code' => 0, 'list' => $works));
        }
        $subtags = [0 => '全部类型', 10476 => '2D', 10506 => '3D', 10559 => 'UI', 10548 => '特效',
            10530 => '动画'];
        $orderTypes = ['is_hot' => 'GAD推荐', 'hot' => '最热', 'new' => '最新'];
        $banners = $this->picture->getPicBanner();
        return view('community.gallery.list', compact(['banners', 'orderTypes', 'orderBy', 'subtags', 'works', 'tagId', 'orderby']));
    }

    public function getDetail(Request $request, ArchiveRepository $archive, $id, LikeRepository $like, FavoriteRepository $fav)
    {
        $useragent=$_SERVER['HTTP_USER_AGENT'];
        if(Func::checkIsWeixin($useragent)) {
            if ($request->has('code')) {
                $code = $request->get('code');
                $state = $request->get('state');
                $userInfo = Weixin::getUserInfoByCode($code, $state, true);
                $user = User::where('WeixinId', $userInfo->unionid)->first();
                $request->setTrustedProxies([$request->server('REMOTE_ADDR')]);
                if ($user) {
                    $user->ip = $request->ip();
                    $user->save();
                } else {
                    $user = User::create([
                        'WeixinId' => $userInfo->unionid,
                        'NickName' => $userInfo->nickname,
                        'Avatar' => $userInfo->headimgurl,
                        'ip' => $request->ip(),
                        'Created' => date('Y-m-d H:i:s'),
                        'Modified' => date('Y-m-d H:i:s')
                    ]);
                }
                Auth::login($user);
            } else {
                return redirect(Weixin::redirect($request->url(), 'snsapi_userinfo', 'user'));
            }
        }

        $atlas = $archive->with(['tags', 'user', 'pictures', 'atlas'])->find($id);
        if (empty($atlas) || !count($atlas->pictures)) {
            abort(404);
        }
        //非发布状态需要有编辑权限
        if ($atlas->status && Gate::denies('edit', $atlas)) {
            abort(403);
        }
        //非资源类型转到作品
        if (empty($atlas->atlas) || $atlas->atlas->type != 1) {
            return redirect('/gallery/detail/' . $id);
        }
        //判断是不是磨房模型
        if (count($atlas->pictures) && ($atlas->pictures[0]['source_type'] == 'model')) {
            $atlas['isModel'] = true;
        } else {
            $atlas['isModel'] = false;
        }
        if (Auth::check()) {
            $myLike = $like->myLike('App\Entities\Archive', $id, Auth::user()['UserId']);
            $myFavorite = $fav->myFavorite('App\Entities\Archive', $id, Auth::user()['UserId']);
            $myFollow = count(Follow::where('user_id', Auth::user()['UserId'])
                ->where('follow_user', $atlas->user_id)->where('status', 0)->first());
        } else {
            $myLike = $myFavorite = $myFollow = null;
        }
        $worksList = $archive->with(['firstPictures'])->where('user_id', '=', $atlas->user_id)
            ->where('class_id', '=', 2)->where('id', '!=', $id)
            ->orderBy('publish_time', 'asc')->limit(8)->findAll(['id', 'cover']);
        if (count($worksList) < 6) {
            $relatedList = $archive->getRelatedAtlasByClassId($atlas, 2, 'hot_score', 8, true);
        } else {
            $relatedList = [];
        }

        return view('community.gallery.detail', compact('atlas', 'myLike', 'myFavorite', 'myFollow', 'relatedList', 'worksList'));
    }

    public function getEdit (ArchiveRepository $archive, $id = 0)
    {
        if ($id) {
            $atlas = $archive->find($id);
            if (Gate::denies('edit', $atlas)) {
                abort(403);
            }
            $tags = $atlas->tag;
            return view('community.gallery.edit', compact('id', 'tags'));
        } else {
            if (Gate::denies('create', $archive->createModel())) {
                abort(403);
            }
            return view('community.gallery.edit', compact('id'));
        }
    }
    //编辑拉取的数据
    public function getDetailData (ArchiveRepository $archive, $id)
    {
        if ($id) {
            $atlas = $archive->with(['tags', 'user', 'pictures', 'atlas'])->find($id);
        } else {
            $atlas = null;
        }
        return response()->json(array('code' => 0, 'data' => $atlas));
    }
    //保存
    public function postSaveAtlas(Request $request, ArchiveRepository $archive, TagRepository $tagRepository, AtlasRepository $atlasRepository)
    {
        $data = $request->all();
        $data = array_map('xssFilter', $data);
        $id = intval($data['id']);
        $tags = !empty($data['archive']['tags']) ? explode(',', $data['archive']['tags']) : [];
        $content = '';
        if (!empty($data['piclist'])) {
            foreach ($data['piclist'] as $picture) {
                $content = $content . $picture['content'];
            }
        }
        if (\App\Gad\Func::hasBadWord($id, $content, '', $data['archive']['title'])) {
            return response()->json(['code' => -1, 'message' => '非法内容']);
        }
        if (empty($tags)) { //优先采用用户标签，若用户没有输入标签，则根据内容计算
            $tags = $tagRepository->findFromTitleContent($data['archive']['title'], $content);
            $tagsinput = implode(',', array_column($tags->slice(0, 6)->toArray(), 'name'));
        } else {
            $tags = $tagRepository->whereIn('name', $tags)->findAll();
            $tagsinput = trim($data['archive']['tags'], ',');
        }
        $status = intval($data['status']) == 1 ? 1 : 2;
        if ($status == 2) {
            $msg = '发表成功';
        } else {
            $msg = '保存成功';
        }
        if ($id) {  //更新图集
            $atlas = $archive->with(['pictures'])->find($id);
            $atlasInfo = $atlasRepository->findWhere(['archive_id', '=', $atlas->id])->first();
            if ($atlas) {
                if (Gate::denies('edit', $atlas)) {
                    return response()->json(array('code' => 2, 'message' => '没有权限修改'));
                }
                if ($status == 2) { //白名单判断
                    $status = Gate::allows('verify', $archive->createModel()) ? 0 : 2;
                }
                $ids = array_column($atlas->pictures->toArray(), 'id');
                $pictures = $this->picture->savePicturesNew($data, $ids, $status);
                $params = [
                    'title' => $data['archive']['title'],
                    'tag' => $tagsinput,
                    'description' => $data['archive']['description'],
                    'total' => count($pictures),
                    'status' => $status,
                    'extra' => array_slice($pictures, 0, 3)
                    //'sort_time' => time()
                ];
                //首次发表
                if ($atlas->status == 1 && $status != 1 && $atlas->publish_time == '0000-00-00 00:00:00') {
                    $params['publish_time'] = date("Y-m-d H:i:s");
                }
                if (!empty($pictures)) {
                    //更新主表的信息

                    $result = $archive->update($id, $params);
                    if ($result[0]) {
                        $atlasParams = [
                            'rights' => $data['atlas']['rights'],
                            'from_type' => $data['atlas']['from_type'],
                            'type' => $data['atlas']['type'], //佳作or点评
                            'attachments' => $data['atlas']['attachments']
                        ];
                        $result2 = $atlasRepository->update($atlasInfo->id, $atlasParams);
                        if (!$result2[0]) {
                            return response()->json(array('code' => 1, 'message' => '图片保存失败'));
                        }
                        $archive->addTags($atlas, $tags);
                        return response()->json(array('code' => 0, 'message' => $msg, 'id' => $result[1]['id']));
                    } else {
                        return response()->json(array('code' => 1, 'message' => '图集信息保存失败'));
                    }
                } else {
                    return response()->json(array('code' => 1, 'message' => '图片保存失败'));
                }
            } else {
                return response()->json(array('code' => 1, 'message' => '图集不存在'));
            }
        } else {    //添加
            if (Gate::denies('create', $archive->createModel())) {
                return response()->json(array('code' => 1, 'message' => '您没有权限创建'));
            }
            if ($status == 2) { //白名单判断
                $status = Gate::allows('verify', $archive->createModel()) ? 0 : 2;
            }
            $params = [
                'title' => $data['archive']['title'],
                'description' => $data['archive']['description'],
                'status' => $status,
                'channel_id' => 2,
                'class_id' => Archive::TYPE_WORKS,
                'user_id' => Auth::user()['UserId'],
                'user_name' => Auth::user()['NickName'],
                'creator' => Auth::user()['UserId'],
                'tag' => $tagsinput,
                'sort_time' => time()
                //'project_id' => $projectid
            ];
            if ($status != 1) {
                $params['publish_time'] = date("Y-m-d H:i:s");
            }
            $result = $archive->create($params);
            if ($result[0]) {
                $data['id'] = $result[1]['id'];
                $atlasParams = [
                    'archive_id' => $data['id'],
                    'rights' => $data['atlas']['rights'],
                    'from_type' => $data['atlas']['from_type'],
                    'type' => $data['atlas']['type'], //佳作or点评
                    'attachments' => $data['atlas']['attachments']
                ];
                $result2 = $atlasRepository->create($atlasParams);
                if (!$result2[0]) {
                    $archive->delete($result[1]['id']);
                    return response()->json(array('code' => 1, 'message' => '图片保存失败'));
                }
                $pictures = $this->picture->savePicturesNew($data, [], $status);
                $archive->addTags($result[1], $tags);
                if (!empty($pictures)) {
                    $archive->update($data['id'], ['total' => count($pictures), 'extra' => array_slice($pictures, 0, 3)]);
                    $follow = new FollowRepository();
                    $followers = $follow->getFans(Auth::user()->UserId)->pluck('user_id')->toArray();
                    if ($status == 0) {
                        $this->dispatch(new SendMessage(
                            MessageType::WORK_NEW,
                            $followers,
                            Auth::user()->UserId,
                            $data['id'],
                            url('/resource/detail', $data['id']),
                            $data['archive']['title']
                        ));
                    }
                    return response()->json(array('code' => 0, 'message' => $msg, 'id' => $result[1]['id']));
                } else {
                    $archive->delete($result[1]['id']);
                    return response()->json(array('code' => 1, 'message' => '图片保存失败'));
                }
            } else {
                return response()->json(array('code' => 1, 'message' => '图集信息保存失败'));
            }
        }
    }

    public function postUploadMofang (Request $request)
    {
        $userInfo = Mofang::login();
        if (!$userInfo->lkey) {
            return response()->json(array('code' => -1, 'msg' => '登录失败'));
        }
        $files = $request->input('files', []);
        if (count($files)) {
            $user = Auth::user();
            $loginType = session('loginType');
            $tokenResult = Tgd::getToken([
                'uid' => $loginType == 'qq' ? $user->QQNo : $user->WeixinId,
                'source' => $loginType,
                'nickname' => $user->NickName,
                'head_img_url' => $user->Avatar,
                'reg_ip' => $user->ip
            ]);
            $token = $tokenResult->code==0 ? $tokenResult->data->token : '';
            $host = app()->isLocal() ? 'ci.asset.qq.com' : 'mofang.qq.com';
            $mofangurl = 'https://'.$host.'/v1/login?jumpurl=https%3A%2F%2F'.$host.'%2Fclose%3Fslient&token='.$token;
            $saveInfo = Mofang::makeAsset($files, $userInfo->lkey);
            return response()->json(array('code' => 0, 'data' => $saveInfo, 'mofangurl' => $mofangurl));
        } else {
            return response()->json(array('code' => -1, 'msg' => '文件列表不能为空'));
        }
    }

    public function postConvertModel (Request $request, ArchiveRepository $archive, AtlasRepository $atlasRepository,
                                      PictureRepository $pictureRespository,TagRepository $tagRepository)
    {
        $userInfo = Mofang::login();
        if (!$userInfo->lkey) {
            return response()->json(array('code' => -1, 'msg' => '登录失败'));
        }
        $data = $request->all();
        $data = array_map('xssFilter', $data);
        $assetid = intval($data['assetid']);
        if (!($assetid && count($data['modelfile']))) {
            return response()->json(array('code' => -2, 'msg' => '参数不完整'));
        }
        $updateData = array(
            'name' => $data['title'],
            'category' => $data['type'],
            'sub_category' => $data['subtype']
        );
        //模型转换
        $convertResult = Mofang::convert($assetid, $data['modelfile']['uri'], $userInfo->lkey);
        if (!$convertResult[0]) {
            return response()->json(array('code' => -3, 'msg' => '转换接口调用失败'));
        }
        //修改信息
        Mofang::updateAsset($assetid, $updateData, $userInfo->lkey);
        //创建资源库
        $params = [
            'title' => $data['title'],
            'status' => 1,
            'tag' => "3D",
            'channel_id' => 2,
            'class_id' => Archive::TYPE_WORKS,
            'user_id' => Auth::user()['UserId'],
            'user_name' => Auth::user()['NickName'],
            'creator' => Auth::user()['UserId'],
            'sort_time' => time(),
            'total' => 1,
            'publish_time' => date("Y-m-d H:i:s")
        ];
        $result = $archive->create($params);
        if (!$result[0]) {
            return response()->json(array('code' => 1, 'message' => '图集保存失败'));
        }
        $tags = $tagRepository->where('name', '=', '3D')->findAll();
        $archive->addTags($result[1], $tags);
        //保存附加表信息
        $archiveid = $result[1]['id'];
        $atlasParams = [
            'archive_id' => $archiveid,
            'rights' => 0,
            'from_type' => 1,
            'type' => 1, //佳作or点评
            'attachments' => [],
            'match_qq' => $data['qqno'],
            'city' => $data['city']
        ];
        $result2 = $atlasRepository->create($atlasParams);
        if (!$result2[0]) {
            return response()->json(array('code' => 1, 'message' => '保存失败'));
        }
        //保存模型信息
        $result3 = $pictureRespository->create([
            'archive_id' => $result[1]['id'],
            'channel_id' => 15,
            'type' => 1,
            'user_id' => Auth::user()['UserId'],
            'user_name' => Auth::user()['NickName'],
            'url' => '',
            'content' => '',
            'sort' => 1,
            'status' => 3,  //未转换状态
            'publish_time' => date("Y-m-d H:i:s"),
            'width' => 0,
            'height' => 0,
            'source_type' => 'model',
            'mofang_id' => $assetid,
            'videourl' => ''
        ]);
        if (!$result3[0]) {
            return response()->json(array('code' => 1, 'message' => '保存失败'));
        }
        //如果是大赛保存到大赛表中
        if (isset($data['activityId']) && is_numeric($data['activityId'])) {
            $mdata = array('archive' => $result[1], 'piclist'=>[['url'=>'']]);
            $game = new GameController();
            $ccId = $game->addActivityWorks($mdata, 2, $data['activityId'], $data['city'], 2);
            $result4 = $archive->update($result[1]['id'], ['ccid' => $ccId, 'hot_aid' => $data['activityId']]);
        }
        return response()->json(array('code' => 0, 'id' => $assetid));
    }

    public function getNotify (Request $request, PictureRepository $pictureRespository, ArchiveRepository $archiveRespository)
    {
        $data = $request->all();
        $result = null;
        if ($data['code'] == 0 && $data['conv_res']) {
            $picture = $pictureRespository->where('mofang_id', '=', $data['asset_id'])->where('status', '=', 3)->findAll();
            if (count($picture)) {
                $result = $pictureRespository->update($picture[0]['id'], ['status' => 1]);
                $archive = $archiveRespository->find($picture[0]['archive_id']);
            }
        }
        //发送站内信
        if ($result && $result[0]) {
            $backUrl = sprintf('http://%s/resource/fill-model/%d', app()->isLocal() ? 'dev.gad.qq.com' : 'gad.qq.com', $data['asset_id']);
            $mofangUrl = sprintf('https://%s/index/model/draft?modelID=%d', app()->isLocal() ? 'ci.asset.qq.com' : 'mofang.qq.com', $data['asset_id']);
            $message = new SendMessage(
                MessageType::RESOURCE_CONVERT_SUCCESS,
                $archive['user_id'],
                0,
                $archive['id'],
                $mofangUrl.'&back_url='.$backUrl,
                $archive['title']
            );
            $this->dispatch($message);
            return response()->json(array('code' => 0, 'message' => '状态更新完成'));
        } else {
            return response()->json(array('code' => -1, 'message' => '状态更新失败'));
        }

    }

    public function getFillModel ($id = 0, PictureRepository $pictureRespository, AtlasRepository $atlasRepository, ArchiveRepository $archiveRespository)
    {
        $id = intval($id);
        //信息完善
        if (!$id) {
            return response()->redirectTo('/');
        }
        try {
            $info = Mofang::getDetail($id);
        } catch (\Exception $ex) {
            return response()->redirectTo('/draft');
        }
        $info = json_decode(json_encode($info),true);
        $info['extr_info'] = json_decode($info['extr_info'], true);
        $info = array_map('xssFilter', $info);
        $right = 7;
        if (isset($info['extr_info']['license'])) {
            $right = Mofang::getRightType($info['extr_info']['license']);
        }
        if (!isset($info['id']) || !$info['first_publish']) { //未发布，直接到草稿页
            return response()->redirectTo('/draft');
        }
        $model = $pictureRespository->where('mofang_id', '=', $id)->where('status', '=', 1)->findAll();
        if (count($model)) {    //更新信息，状态变为发布状态
            //获取图片宽高
            $img = $this->getImgSize($info['thumbnails']);
            $picParams = ['status' => 0, 'url' => $info['thumbnails'], 'width' => $img['width'], 'height' => $img['height']];
            $result1 = $pictureRespository->update($model[0]['id'], $picParams);
            $extra = array();
            $extra[0] = array('id' => $result1[1]->id, 'url' => $result1[1]->url);
            //信息补充
            $result2 = $archiveRespository->update($model[0]['archive_id'], ['status' => 2, 'extra' => $extra,
                'description' => $info['desc'], 'title' => $info['name']]);
            $atlas = $atlasRepository->where('archive_id', '=', $result2[1]['id'])->findAll();
            if(count($atlas)) {
                $atlasRepository->update($atlas[0]['id'], ['modelface_count'=>$info['model_face_count'], 'rights'=>$right]);
            }
            //大赛相关
            if ($result2[1]['hot_aid'] != 0) {
                $result2[1]['RowStatus'] = 2;
                $mdata = array('archive' => $result2[1], 'piclist'=>[['url'=>$info['thumbnails']]]);
                $game = new GameController();
                $game->updateActivityWorks($mdata, $result2[1]['ccid'], 2);
            }
            if ($result1[0] && $result2[0]) {
                return response()->redirectTo('/resource/detail/'.$result2[1]['id']);
            }
        }
    }

    public function getModelState ($id, PictureRepository $pictureRespository)
    {
        $model = $pictureRespository->where('mofang_id', '=', $id)->where('status', '=', 1)->findAll();
        if (count($model)) {
            return response()->json(array('code'=>0, 'id'=>$id));
        } else {
            return response()->json(array('code'=>-1, 'message'=>'转换未完成', 'model'=>$model));
        }
    }

    private function getImgSize ($url) {
        $config = [
            'modId' => config('app.http_proxy_cl5_modId'),
            'cmdId' => config('app.http_proxy_cl5_cmdId'),
            'default' => ['hostIp' => '10.213.154.2', 'hostPort' => 8081]
        ];
        $server = CL5::getRoute($config, app()->isLocal());
        $proxy = $server['hostIp'].':'.$server['hostPort'];
        $opts = array(
            'http'=>array(
                'method'=>"GET",
                'proxy' => $proxy,
                'request_fulluri'=>true
            )
        );
        $imginfo = [];
        try {
            $context = stream_context_create($opts);
            $data = @file_get_contents($url,FALSE,$context);
            $image = imagecreatefromstring($data);
            $imginfo['width'] = imagesx($image);
            $imginfo['height'] = imagesy($image);
        } catch (\Exception $e) {
            $imginfo = ['width' => 0, 'height' => 0];
        }

        return $imginfo;
    }
}
