<?php

namespace App\Http\Controllers\Community;
use App\Gad\Lib_Func;
use App\Gad\MessageType;
use App\Gad\TofService;
use App\Models\Article;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Register;
use App\Models\Classify;
use App\Models\Game;
use App\Models\Summercourse;
use App\Models\KeyValue;
use App\Repositories\TagRepository;
use Illuminate\Http\Request;
use App\Gad\Upload;
use App\Gad\Func;
use Auth;
use Gate;
use Mockery\CountValidator\Exception;
use Redis;
use Illuminate\Routing\Route;

class AnswerController extends Controller
{
    public function __construct(Request $request){
    }

    //sdfs
    public function getIndex(Request $request, TagRepository $tagRes, $tagName = '', $orderType = 'hot') {
        $controller = \App::make(\App\Http\Controllers\Community\QuestionController::class);
        return app()->call([$controller,'getIndex'],['tagName' => $tagName, 'orderType' => $orderType]);
    }

    public function getCreate() {
        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $user = Auth::user();
        $register = Register::where('user_id',$user->UserId)
                                ->first();
        if ($register == null || $register->status == 2) {
            return redirect()->guest('/hatch/register');
        }
    	$hatch = new Game();
        $oss = Classify::where('parent',1202)->get();
        $types = Classify::where('parent',1203)->get();

        return view('hatch.create', compact('hatch', 'types', 'oss'));
    }

    public function postCreate(Request $request)
    {
        $data = $request->all();
		$data = array_map('xssFilter', $data);
        $hatch = new Game;

        $resp = array(
            'code' => -1,
            'message' => ''
        );

        if (!Auth::check()) {
            $resp['message'] = '未登录';
            return response()->json($resp);
        }

        $user = Auth::user();
        $register = Register::where('user_id',$user->UserId)
            ->first();
        if ($register == null || $register->status == 2) {
            $resp['message'] = '未入驻或入驻被驳回';
            return response()->json($resp);
        }

        if (!$data['name'] OR
            !$data['logo'][0] OR
            !$data['content'] OR
            !$data['platform'] OR
            !$data['ppt']
        ) {
            $resp['code'] = -2;
            $resp['message'] = '数据不完整';
            return response()->json($resp);
        }

        $hatch->user_id = Auth::user()->UserId;
        $hatch->obj_type = 1;
        $hatch->register_id = Register::where('obj_type', 1)
            ->where('user_id', Auth::user()->UserId)->value('id');

        $hatch->name = $data['name'];
        $hatch->logo = json_encode($data['logo']);
        $hatch->game_type = $data['type'];
        $hatch->description = $data['content'];
        $hatch->os = $data['platform'];
        $hatch->videos = json_encode($data['video']);
        $hatch->pictures = json_encode($data['pic']);
        $hatch->ppt = json_encode($data['ppt']);
        $hatch->ppt_pub = intval($data['ppt_pub']);
        $hatch->demo = json_encode($data['demo']);
        $hatch->demo_pub = intval($data['demo_pub']);
        $hatch->cooperation = $data['cooperation'];
        $hatch->status = 1;
        $hatch->save();

        $resp['code'] = $hatch->id;
        //发送站内信
        Func::msgApi(
            MessageType::PROJECT_APPLY_SUCCESS,
            Auth::user()->UserId,
            0,
            $hatch->id,
            url('/hatch/detail',$hatch->id),
            $hatch->name
        );
        return response()->json($resp);
    }

    public function getEdit(Request $request, $id)
    {
        //判断用户是否登录
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $hatch = Game::findOrFail($id);

        $oss = Classify::where('parent',1202)->get();
        $types = Classify::where('parent',1203)->get();

        return view('hatch.create', compact('hatch', 'oss', 'types'));
    }

    public function postEdit(Request $request, $id)
    {
        $hatch = Game::findOrFail($id);
        $data = $request->all();
        $data = array_map('xssFilter', $data);

        $resp = array(
            'code' => -1,
            'message' => ''
        );
        if (!Auth::check()) {
            $resp['message'] = '未登录';
            return response()->json($resp);
        }

        if (Auth::user()->UserId != $hatch->user_id and !Auth::user()->roles->contains(2)) {
            $resp['message'] = '无权限';
            return response()->json($resp);
        }

        if (!$data['name'] OR
            !$data['logo'][0] OR
            !$data['content'] OR
            !$data['platform'] OR
            !$data['ppt']
        ) {
            $resp['code'] = -2;
            $resp['message'] = '数据不完整';
            return response()->json($resp);
        }

        $hatch->name = $data['name'];
        $hatch->logo = json_encode($data['logo']);
        $hatch->game_type = $data['type'];
        $hatch->description = $data['content'];
        $hatch->os = $data['platform'];
        $hatch->videos = json_encode($data['video']);
        $hatch->pictures = json_encode($data['pic']);
        $hatch->ppt = json_encode($data['ppt']);
        $hatch->ppt_pub = intval($data['ppt_pub']);
        $hatch->demo = json_encode($data['demo']);
        $hatch->demo_pub = intval($data['demo_pub']);
        $hatch->cooperation = $data['cooperation'];
        $hatch->status = 1;
        $hatch->save();

        $resp['code'] = $hatch->id;
        //仅自己修改才提醒
        if (Auth::user()->UserId == $hatch->user_id )
        {
            Func::msgApi(
                MessageType::PROJECT_APPLY_SUCCESS,
                Auth::user()->UserId,
                0,
                $hatch->id,
                url('/hatch/detail',$hatch->id),
                $hatch->name
            );
        }
        return response()->json($resp);
    }

    public function getDetail($id)
    {
        $hatch = Game::findOrFail($id);

        $gtype = $hatch->gameType->class_name;
        $platform = $hatch->osclass->class_name;

        $pictures = json_decode($hatch['pictures']);
        $videos = json_decode($hatch['videos']);
        $demotemp = json_decode($hatch['demo']);
        $demo = empty($demotemp) ? (object)array() : $demotemp[0];
        $demo->name = isset($demo->name) ? $demo->name : '';
        $demo->state = isset($demo->state) ? $demo->state : '';
        $demo->progress = isset($demo->progress) ? $demo->name : 0;
        $demo->url = isset($demo->url) ? $demo->url : 0;
        $demo->size = isset($demo->size) ? $demo->size : 0;

        $ppts = Func::getPreviewDocs($hatch['ppt']);

        $recommend = KeyValue::find('new_hatch_detail');
        $project = json_decode($recommend['Value'], true);

        $register = $hatch->register;

        return view('hatch.detail', compact('hatch', 'pictures', 'gtype',
            'platform', 'register', 'demo', 'ppts', 'videos', 'project'));
    }

}
