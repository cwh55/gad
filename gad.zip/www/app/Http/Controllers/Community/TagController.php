<?php

namespace App\Http\Controllers\Community;

use App\Entities\Archive;
use App\Http\Controllers\Controller;
use App\Repositories\ArchiveRepository;
use App\Repositories\PictureRepository;
use App\Repositories\TagRepository;
use Illuminate\Http\Request;
use DB;

class TagController extends Controller
{
    protected $tag;
    protected $archive;

    public function __construct(TagRepository $tag, ArchiveRepository $archive)
    {
        $this->tag = $tag;
        $this->archive = $archive;
    }

    public function getIndex(Request $request)
    {
        return redirect('community');
    }

    public function getDetail(Request $request, $name, $sort = 'hot')
    {
        $tag = $this->tag->findBy('name', $name);
        if (!$tag) {
            return abort(404);
        }

        $page = $request->get('page', 1);
        $sort = in_array($sort, ['hot', 'newest']) ? $sort : 'hot';
        $archives = $this->tag->getArchiveList($tag, [], $page, $sort);
        if ($request->wantsJson()) {
            return response()->json($archives);
        }

        $relatedTags = $this->tag->getRelateTags($tag);
        $hotTags = $this->tag->getHotTags();
        $tagTitle = ($sort == 'newest' ? '最新' : '').$tag->name;
        $page = [
            'category' => 'all',
            'sort' => $sort,
            'title' => $tagTitle.'_文章_问答_话题',
            'keywords' => sprintf('%s，%s文章，%s问答，%s话题', $tagTitle, $tagTitle, $tagTitle, $tagTitle),
            'description' => $tag->description ? $tag->description :
                ($archives->count() ? $archives->first()->description : '')
        ];

        return view('community.tag.detail', compact('tag', 'archives', 'hotTags', 'relatedTags', 'page'));
    }

    public function getArticle(Request $request, $name, $sort = 'hot')
    {
        $tag = $this->tag->findBy('name', $name);
        if (!$tag) {
            return abort(404);
        }

        $page = $request->get('page', 1);
        $sort = in_array($sort, ['hot', 'newest']) ? $sort : 'hot';
        $archives = $this->tag->getArchiveList($tag, ['class_id' => Archive::TYPE_ARTICLE], $page, $sort);
        if ($request->wantsJson()) {
            return response()->json($archives);
        }

        $relatedTags = $this->tag->getRelateTags($tag);
        $hotTags = $this->tag->getHotTags();
        $tagTitle = ($sort == 'newest' ? '最新' : '').$tag->name;
        $page = [
            'category' => 'article',
            'sort' => $sort,
            'title' => sprintf('%s文章_%s教程', $tagTitle, $tagTitle),
            'keywords' => sprintf('%s文章，%s教程，%s', $tagTitle, $tagTitle, $tagTitle),
            'description' => $tag->description ? $tag->description :
                ($archives->count() ? $archives->first()->description : '')
        ];

        return view('community.tag.detail', compact('tag', 'archives', 'hotTags', 'relatedTags', 'page'));
    }

    public function getQuestion(Request $request, $name, $sort = 'hot')
    {
        $tag = $this->tag->findBy('name', $name);
        if (!$tag) {
            return abort(404);
        }

        $page = $request->get('page', 1);
        $sort = in_array($sort, ['hot', 'newest']) ? $sort : 'hot';
        $archives = $this->tag->getArchiveList($tag, ['class_id' => Archive::TYPE_QUESTION], $page, $sort);
        if ($request->wantsJson()) {
            return response()->json($archives);
        }

        $relatedTags = $this->tag->getRelateTags($tag);
        $hotTags = $this->tag->getHotTags();
        $tagTitle = ($sort == 'newest' ? '最新' : '').$tag->name;
        $page = [
            'category' => 'question',
            'sort' => $sort,
            'title' => sprintf('%s问答', $tagTitle),
            'keywords' => sprintf('%s问答，%s', $tagTitle, $tagTitle),
            'description' => $tag->description ? $tag->description :
                ($archives->count() ? $archives->first()->description : '')
        ];

        return view('community.tag.detail', compact('tag', 'archives', 'hotTags', 'relatedTags', 'page'));
    }

    public function getTopic(Request $request, $name, $sort = 'hot')
    {
        $tag = $this->tag->findBy('name', $name);
        if (!$tag) {
            return abort(404);
        }

        $page = $request->get('page', 1);
        $sort = in_array($sort, ['hot', 'newest']) ? $sort : 'hot';
        $archives = $this->tag->getArchiveList($tag, ['class_id' => Archive::TYPE_TOPIC], $page, $sort);
        if ($request->wantsJson()) {
            return response()->json($archives);
        }

        $relatedTags = $this->tag->getRelateTags($tag);
        $hotTags = $this->tag->getHotTags();
        $tagTitle = ($sort == 'newest' ? '最新' : '').$tag->name;
        $page = [
            'category' => 'topic',
            'sort' => $sort,
            'title' => sprintf('%s话题', $tagTitle),
            'keywords' => sprintf('%s话题，%s', $tagTitle, $tagTitle),
            'description' => $tag->description ? $tag->description :
                ($archives->count() ? $archives->first()->description : '')
        ];

        return view('community.tag.detail', compact('tag', 'archives', 'hotTags', 'relatedTags', 'page'));
    }

    public function getGallery(Request $request, PictureRepository $pictureRepository, $name, $sort = 'hot')
    {
        $tag = $this->tag->findBy('name', $name);
        if (!$tag) {
            return abort(404);
        }

        $page = $request->get('page', 1);
        $sort = in_array($sort, ['hot', 'newest']) ? $sort : 'hot';
        $pictures = $pictureRepository->findByTag($this->tag, $tag, $page, $sort, 24, false);
        if ($request->wantsJson()) {
            return response()->json($pictures);
        }

        $pictures = $pictureRepository->getChunk($pictures->items());
        $relatedTags = $this->tag->getRelateTags($tag);
        $hotTags = $this->tag->getHotTags();
        $tagTitle = ($sort == 'newest' ? '最新' : '').$tag->name;
        $page = [
            'category' => 'gallery',
            'sort' => $sort,
            'title' => sprintf('%s作品', $tagTitle),
            'keywords' => sprintf('%s作品，%s', $tagTitle, $tagTitle),
            'description' => ''
        ];

        return view('community.tag.gallery', compact('tag', 'pictures', 'hotTags', 'relatedTags', 'page'));
    }
}