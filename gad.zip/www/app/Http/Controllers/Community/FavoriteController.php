<?php

namespace App\Http\Controllers\Community;
use App\Repositories\FavoriteRepository;
use App\Repositories\ArchiveRepository;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\FeedRepository;
use Illuminate\Http\Request;
use Auth;
use App\Entities\Favorite;
use Mockery\CountValidator\Exception;

class FavoriteController extends Controller
{
    protected $favorite;
    protected $archive;
    protected $feed;

    protected $prefix = 'App\\Entities\\';

    public function __construct(FavoriteRepository $favorite, ArchiveRepository $archive, FeedRepository $feed)
    {
        $this->favorite = $favorite;
        $this->archive = $archive;
        $this->feed = $feed;
        $this->middleware('auth');
    }

    //sdfs
    public function getFavorite(Request $request)
    {
        $user_id = Auth::user()->UserId;
        $model_type = $this->prefix . $request->input('model_type');
        $model_id = $request->input('model_id');

        $favorite = $this->favorite->myFavorite($model_type, $model_id, $user_id);

        return response()->json(['code' => 0, 'data' => $favorite, 'message' => '']);
    }

    public function postCreate(Request $request)
    {
        $this->validate($request, [
            'model_type' => 'required',
            'model_id' => 'required'
        ]);

        $model_type = $this->prefix . $request->input('model_type');
        $model_id = $request->input('model_id');
        $user_id = Auth::user()->UserId;

        $data = ['model_type' => $model_type, 'model_id' => $model_id, 'user_id' => $user_id];

        $favorite = Favorite::withTrashed()->where('model_type', $model_type)->where('model_id', $model_id)->where('user_id', $user_id)->first();
        if ($favorite) {
            if (!$favorite->trashed()) {
                return response()->json(['code' => -1, 'data' => $favorite, 'message' => '重复操作']);
            }
            $favorite->restore();
            $this->updateModel($favorite->favModel, 1);
            $this->feed->updateFeed($favorite,1);
            return response()->json(['code' => 0, 'data' => $favorite, 'message' => '']);
        } else {
            list($res, $favorite) = $this->favorite->create($data);
            if ($res) {
                $this->updateModel($favorite->favModel, 1);
                $this->feed->updateFeed($favorite,1);
                return response()->json(['code' => 0, 'data' => $favorite, 'message' => '']);
            }
        }

        //发送站内信
        //Func::msgApi(
        //MessageType::PROJECT_APPLY_SUCCESS,
        //Auth::user()->UserId,
        //0,
        //$hatch->id,
        //url('/hatch/detail',$hatch->id),
        //$hatch->name
        //);
        return response()->json(['code' => -1, 'data' => $favorite, 'message' => '更新有误']);
    }

    public function postEdit(Request $request, $id)
    {
        $favorite = Favorite::findOrFail($id);

        $user_id = Auth::user()->UserId;

        if ($user_id != $favorite->user_id && !Auth::user()->roles->contains(2)) {
            return response()->json(['code' => -1, 'message' => '没有权限']);
        }

        $model_type = $request->input('model_type');
        $model_id = $request->input('model_id');

        $this->updateModel($favorite->favModel, 0);
        $this->favorite->delete($id);
        $this->feed->updateFeed($favorite,0);
        return response()->json(['code' => 0, 'data' => '', 'message' => '']);
    }

    protected function updateModel($model, $status, $level = 1)
    {
        if ($level > 2) {//上上级也要更新
            return;
        }
        if ($status == 1 && $model) {
            $model->increment('favorite_count', 1);
        } else if ($status == 2 && $model) {
            if ($model->favorite_count > 0) {
                $model->decrement('favorite_couont', 1);
            }
        } else if ($status == 0 && $model) {
            if ($model->favorite_count > 0) {
                $model->decrement('favorite_count', 1);
            }
        }
        if ($model->archive) {//更新上上级
            $this->updateModel($model->archive, $status, $level + 1);
        }
        if ($model->question) {
            $archiveId = $model->question->archive_id;
            $ar = $this->archive->find($archiveId);
            if ($ar->is_hot == 1 && isset($ar->extra['id']) && $ar->extra['id'] == $model->id) {
                $extra = $model->toArray();
                //$this->archive->update($archiveId, ['extra' => $extra]);
            }
        }
    }

}
