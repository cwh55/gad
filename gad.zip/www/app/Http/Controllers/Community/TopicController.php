<?php

namespace App\Http\Controllers\Community;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\LiveRepositoryEloquent;
use App\Repositories\ArchiveRepository;
use App\Repositories\AnswerRepository;
use App\Repositories\LikeRepository;
use App\Repositories\QuestionRepository;
use App\Repositories\FavoriteRepository;
use App\Repositories\TagRepository;
use App\Entities\Archive;
use App\Entities\Answer;
use App\Entities\Question;

use App\Gad\Func;

use Auth;
use DB;
use Cache;

use Illuminate\Http\Request;
use Illuminate\Routing\Route;


class TopicController extends QuestionController
{
    public function __construct(Request $request, ArchiveRepository $archive, LiveRepositoryEloquent $live, AnswerRepository $answer, QuestionRepository $question, FavoriteRepository $fav)
    {
        $this->live = $live;
        $this->archive = $archive;
        $this->answer = $answer;
        $this->question = $question;
        $this->fav = $fav;
        $this->archive_type = Archive::TYPE_TOPIC;
        $this->is_topic = 1;
        $this->view = 'community.topic';
        $this->controller = 'topic';
        $this->middleware("auth", ['only' => ['postQuestion', 'postAnswer']]);
        $this->middleware('captcha:answer'.$this->archive_type, ['only' => ['postAnswer']]);
        $this->middleware('captcha:archive'.$this->archive_type, ['only' => ['postQuestion']]);
    }

    //点赞最多
    public function upCount($date)
    {
        $users = Cache::remember('up_count_' . $date, 10, function () use ($date) {
            return DB::table('gad_likes')
                ->join('gad_answers', function ($join) {
                    $join->on('gad_answers.id', '=', 'gad_likes.model_id')
                        ->where('gad_likes.model_type', '=', 'App\\Entities\\Answer');
                })
                ->join('User', 'gad_likes.user_id', '=', 'User.UserId')
                ->where('gad_answers.is_topic', '=', '1')
                ->where('gad_likes.created_at', '>=', $date)
                ->select('User.*', DB::raw('count(*) as total'))
                ->groupBy('gad_likes.user_id')
                ->orderBy('total', 'desc')
                ->take(5)
                ->get();
        });
        return $users;
    }

    //回复最多
    public function replyCount($date)
    {
        $users = Cache::remember('reply_count_' . $date, 10, function () use ($date) {
            return DB::table('gad_answers')
                ->join('User', 'gad_answers.user_id', '=', 'User.UserId')
                ->where('gad_answers.is_topic', '=', '1')
                ->where('gad_answers.created_at', '>=', $date)
                ->select('User.*', DB::raw('count(*) as total'))
                ->groupBy('gad_answers.user_id')
                ->orderBy('total', 'desc')
                ->take(5)
                ->get();
        });
        return $users;
    }

    //被点赞
    public function unupCount($date)
    {
        $users = Cache::remember('unup_count_' . $date, 10, function () use ($date) {
            return DB::table('gad_answers')
                ->join('User', 'gad_answers.user_id', '=', 'User.UserId')
                ->where('gad_answers.is_topic', '=', '1')
                ->where('gad_answers.created_at', '>=', $date)
                ->select('User.*', DB::raw('sum(like_count) as total'))
                ->groupBy('gad_answers.user_id')
                ->orderBy('total', 'desc')
                ->take(5)
                ->get();
        });
        return $users;
    }

    //被回复
    public function unreplyCount($date)
    {
        $users = Cache::remember('unreply_count_' . $date, 10, function () use ($date) {
            return DB::table('gad_answers')
                ->join('User', 'gad_answers.user_id', '=', 'User.UserId')
                ->where('gad_answers.is_topic', '=', '1')
                ->where('gad_answers.created_at', '>=', $date)
                ->select('User.*', DB::raw('sum(answer_count) as total'))
                ->groupBy('gad_answers.user_id')
                ->orderBy('total', 'desc')
                ->take(5)
                ->get();
        });
        return $users;
    }

    public function getHotUsers()
    {
        $xinyou = Cache::remember('tb_game_comment_topic', 60, function () {
            return DB::table('tbGame')
                ->join('tbGameComment', 'tbGame.Id', '=', 'tbGameComment.iGameId')
                ->where('tbGame.iRowStatus', '=', 0)
                ->select('tbGame.vLogo', 'tbGameComment.iScore', 'tbGame.vTitle', 'tbGameComment.iContentId')
                ->orderBy('tbGameComment.dtCreated', 'desc')->first();
        });
        $first = 1;
        $w = date("w");
        return [
            'up' => [
                'week_up' => $this->upCount(date('Y-m-d', strtotime("-" . ($w ? $w - $first : 6) . " days"))),
                'week_reply' => $this->replyCount(date('Y-m-d'), strtotime("-" . ($w ? $w - $first : 6) . " days")),
                'month_up' => $this->upCount(date('Y-m-1')),
                'month_reply' => $this->replyCount(date('Y-m-1')),
            ],
            'down' => [
                'week_up' => $this->unupCount(date('Y-m-d', strtotime("-" . ($w ? $w - $first : 6) . " days"))),
                'week_reply' => $this->unreplyCount(date('Y-m-d', strtotime("-" . ($w ? $w - $first : 6) . " days"))),
                'month_up' => $this->unupCount(date('Y-m-1')),
                'month_reply' => $this->unreplyCount(date('Y-m-1')),
            ],
            'xinyou' => $xinyou,
        ];
    }
}
