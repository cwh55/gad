<?php

namespace App\Http\Controllers\Community;
use App\Presenters\CommunityPresenter;
use App\Http\Controllers\Controller;
use App\Repositories\ArchiveRepository;
use App\Repositories\FollowRepository;
use App\Repositories\LiveRepositoryEloquent;
use App\Repositories\OperationRepository;
use App\Repositories\TagRepository;
use App\Repositories\UserTagRepository;
use App\Repositories\FeedRepository;
use Illuminate\Http\Request;
use Auth;

class HomeController extends Controller
{
    protected $repository;
    protected $archive;
    protected $follow;
    protected $live;
    protected $userTag;
    protected $tag;
    protected $operation;

    public function __construct(
        ArchiveRepository $archiveRepository,
        FollowRepository $followRepository,
        LiveRepositoryEloquent $live,
        UserTagRepository $userTag,
        TagRepository $tag,
        OperationRepository $operation,
        FeedRepository $feedRepository
    )
    {
        $this->archive = $archiveRepository;
        $this->follow = $followRepository;
        $this->live = $live;
        $this->userTag = $userTag;
        $this->tag =$tag;
        $this->operation = $operation;
        $this->feedRepository = $feedRepository;
    }

    public function getIndex(Request $request, $tag='hot', $sort='new')
    {
        if (!in_array($tag,['hot','my','plan','program','vr','art','audio','project','yunying','test'])) {
            abort(404);
        }
        //用于拉取channel下的广告
        $tagChannelMap = [
            'hot' => 0,
            'plan' => 1,
            'program' => 2,
            'art' => 3,
            'vr' => 4,
            'audio' => 5,
            'project' => 6,
            'yunying' => 7,
            'test' => 8,
        ];
        $page = $request->input('p',1);
        $pageSize = 20;//$request->input('ps',20);

        $pageSize = ($pageSize > 20) ? 20 : $pageSize;
        $orderBy = $sort;
        $classId = $request->input('cid',0);
        $tagValue = array_get(TagRepository::$tagMap,$tag,'hot');
        $ads = collect([]);

        if($request->ajax() && $tag == 'my') {
            $archives = $this->feedRepository->getMyFeeds(Auth::user()->UserId, $page, $pageSize);
            $hasMore = 0;
            if(!empty($archives)) {
                $presenter = new CommunityPresenter();
                foreach ($archives as $archive) {
                    $archive->id = $archive->archive_id;
                    $archive->avatar = !$archive->Avatar ? 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg' : $archive->Avatar;
                    if ($archive->extra) {
                        $archive->extra = json_decode($archive->extra, true);
                    }
                    $archive->tags = explode(',', $archive->tag);
                    $archive->format_comment_count = $presenter->formatNumber($archive->comment_count);
                    $archive->format_like_count = $presenter->formatNumber($archive->like_count);
                    $archive->format_view_count = $presenter->formatNumber($archive->view_count);
                    $archive->format_favorite_count = $presenter->formatNumber($archive->favorite_count);
                    $archive->user_name = $archive->NickName;
                    $archive->user_type = $archive->user_type;
                    $archive->publish_time = $archive->created_at;
                }
                $archives = collect($archives);
                $hasMore = $archives->count()>0 ? 1 : 0;
            }
            return response()->json([
                'code' => 0,
                'hasMore' => $hasMore,
                'archives' => $archives,
            ]);
        }
        $ads = $this->operation->getAds($tagChannelMap[$tag], ($page - 1) * $pageSize, $page * $pageSize);
        if ($tag != 'hot') {
            $archives = $this->archive->getListByTagName($tagValue,0, $page-1, $pageSize+1, $orderBy,false, $tag);
            $archives = $this->archive->formatArchives($archives);
            //多取一个判断是否还有下一页
            if ($pageSize+1 == $archives->count()) {
                $archives = $archives->splice(0,$pageSize);
                $archives->hasMorePage = true;
            } else {
                $archives->hasMorePage = false;
            }
        } else {
            if (Auth::check()) {
                $archives = $this->userTag->getHotByUserTag(Auth::user()->UserId, $classId, $page - 1, $pageSize, $orderBy);
                if ($archives->count() == 0) {
                    $archives = $this->archive->getHots($classId, $page, $pageSize, $orderBy);
                }
            } else {
                $archives = $this->archive->getHots($classId, $page, $pageSize, $orderBy);
            }
        }
        //异步加载时返回json
        if ($request->ajax()) {
            return response()->json([
                'code' => 0,
                'hasMore' => $archives->hasMorePage,
                'archives' => $archives,
                'ads'=>$ads->toArray()
            ]);
        } else {
            $liveList = $this->live->getAllList(3);
            $hotTags = $this->tag->getHotTags($tag);
            $ads = $ads->keyBy('position');

//            if ($tag != 'hot') {
//                $topArchives = $this->archive->getTopArchiveByTag($tagValue);
//                if ($topArchives->count()>0) {
//                    $tmp = collect(array_merge($topArchives->toArray(),$archives->toArray()));
//                    $tmp->hasMorePage = $archives->hasMorePage;
//                    $archives = $tmp;
//                }
//            }
            $tagName = $tag;
            $draftCount = Auth::User() ? $this->archive->getDraftCount(Auth::User()->UserId) : 0;
            return view('community.all',compact('archives', 'orderBy', 'page', 'classId', 'liveList', 'tag', 'hotTags', 'ads', 'tagName', 'draftCount'));
        }
    }

}
