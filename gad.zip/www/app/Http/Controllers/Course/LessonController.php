<?php

namespace App\Http\Controllers\Course;

use App\Gad\Upload;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Lesson;
use App\Models\LessonVod;
use Gate;
use Illuminate\Http\Request;

class LessonController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth', ['except' => 'postConvertVodNotify']);
    }

    public function getShow(Request $request, $id)
    {
        $lesson = Lesson::findOrFail($id);
        $course = $lesson->course;

        if (Gate::denies('learn', $course)) {
            if ($course->cost OR $course->state == 'new') {
                return redirect('/course/'.$course->id);
            } else {
                $course->registerStudent($request->user());
            }
        }

        $course->access($request->user(), $lesson);

        return view('course.lesson', compact('lesson', 'course'));
    }

    public function getItem(Request $request, $id)
    {
        $lesson = Lesson::findOrFail($id);
        $this->authorize('update', $lesson);
        $lesson = $lesson->toArray();
        unset($lesson['course']);

        return response()->json($lesson);
    }

    public function postCreate(Request $request)
    {
        $fields = [
            ['key' => 'course_id', 'name' => '分享ID', 'rule' => 'required'],
            ['key' => 'title', 'name' => '分享名称', 'rule' => 'required'],
            ['key' => 'summary', 'name' => '分享简介', 'rule' => 'required'],
            ['key' => 'begin_date', 'name' => '直播开始日期', 'rule' => 'required'],
            ['key' => 'begin_time', 'name' => '直播开始时间', 'rule' => 'required'],
            ['key' => 'end_time', 'name' => '直播结束时间', 'rule' => 'required']
        ];
        $validator  = [
            'rule' => [],
            'messages' => [
                'required' => ':attribute不能为空'
            ],
            'attr' => []
        ];
        foreach ($fields as $field) {
            $validator['rule'][$field['key']] = $field['rule'];
            $validator['attr'][$field['key']] = $field['name'];
        }
        $this->validate($request, $validator['rule'], $validator['messages'], $validator['attr']);

        $course = Course::findOrFail($request->input('course_id'));
        $this->authorize('edit', $course);

        $lessonData = $request->all();
        $lessonData['user_id'] = $request->user()->UserId;
        $lessonData['total_time'] = ceil((strtotime($lessonData['end_time']) - strtotime($lessonData['begin_time'])) / 60);

        $lesson = new Lesson($lessonData);
        $lesson->save();

        return response()->json($lesson);
    }

    public function postConvertVodNotify(Request $request)
    {
        $lesson = Lesson::findOrFail($request->get('id'));
        $ret = json_decode($request->getContent());
        if (isset($ret->data->image_video)) {
            $video = $ret->data->image_video;
            $vod = LessonVod::create([
                'course_id' => $lesson->course_id,
                'lesson_id' => $lesson->id,
                'file_id' => $ret->data->file_id,
                'sort' => $ret->data->file_id,
                'vid' => $video->vid,
                'title' => '',
                'img_url' => with($video->imgUrls[0])->url,
                'duration' => $video->duration
            ]);

            $vod->task->status = 1;
            $vod->task->save();
            $lesson->checkConvertTask();
        }

        return response('success');
    }

    public function postUpdate(Request $request, $id)
    {
        $lesson = Lesson::findOrFail($id);
        $this->authorize('update', $lesson);

        $fields = [
            ['key' => 'title', 'name' => '分享名称', 'rule' => 'required|max:20'],
            ['key' => 'summary', 'name' => '分享简介', 'rule' => 'required'],
            ['key' => 'begin_date', 'name' => '直播开始日期', 'rule' => 'required'],
            ['key' => 'begin_time', 'name' => '直播开始时间', 'rule' => 'required'],
            ['key' => 'end_time', 'name' => '直播结束时间', 'rule' => 'required']
        ];
        $validator  = [
            'rule' => [],
            'messages' => [
                'required' => ':attribute不能为空',
                'title.max' => '分享名称不能超过20个字'
            ],
            'attr' => []
        ];
        foreach ($fields as $field) {
            $validator['rule'][$field['key']] = $field['rule'];
            $validator['attr'][$field['key']] = $field['name'];
        }
        $this->validate($request, $validator['rule'], $validator['messages'], $validator['attr']);

        $lessonData = $request->all();
        $lessonData['total_time'] = ceil((strtotime($lessonData['end_time']) - strtotime($lessonData['begin_time'])) / 60);
        $lesson->fill($lessonData);
        $lesson->save();

        return response()->json($lesson);
    }

    public function destroy(Request $request, $id)
    {
        $lesson = Lesson::findOrFail($id);
        $this->authorize('update', $lesson);

        if ($lesson->state != 'new') {
            return response()->json(['code' => 1, 'message' => '直播中或已结束的分享不能删除！']);
        }
        $lesson->delete();

        return response()->json(['code' => 0, 'message' => '分享删除成功！']);
    }

    public function postUploadAttachment(Request $request)
    {
        $file = $request->file('file');
        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }

        $result = Upload::uploadQcloudCos('course', $file);
        if ($result['code'] == 0) {
            return response()->json(['code' => 0, 'url' => $result['data']['access_url']]);
        } else {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }
    }

    public function doc2Html(Request $request)
    {
        $file = $request->file('file');
        $fileExt = strtolower($file->getClientOriginalExtension());
        if (!in_array($fileExt,['doc','docx'])) {
            return ;
        }
        $result = Upload::doc2Html($file);
        if ($result['code'] == 0) {
            $content = rtrim($result['content'],"<script type=\"text/javascript\"> try{document.domain = 'qq.com';}catch(e){} </script>");
            return response($content);
        }
    }
}
