<?php

namespace App\Http\Controllers\Course;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Order;
use App\Models\User;
use Auth;
use Endroid\QrCode\QrCode;
use Illuminate\Http\Request;
use Log;
use Response;
use Tencent\WxPay\WxPayUtil;
use WxPay;

class PayController extends Controller
{
    use WxPayUtil;

    public function getWxPay(Request $request, $id)
    {
        if (!Auth::check()) {
            return abort(401);
        }

        $productId = $id.'x'.Auth::user()->UserId;
        $url = WxPay::driver('native')->prepay($productId);

        $qrCode = new QrCode();
        $response = Response::stream(function () use($qrCode, $url) {
            $qrCode->setText($url)->setSize(117)->setPadding(0)->setErrorCorrection('high')->render();
        }, 200, ['Content-Type' => 'image/png']);

        return $response;
    }

    public function postWxPayResult(Request $request)
    {
        if (!Auth::check()) {
            return abort(401);
        }

        $course = Course::findOrFail($request->input('id'));
        if ($course->hasStudent(Auth::user())) {
            return ['result' => true];
        }

        return ['result' => false];
    }
    
    public function postWxPayCallback(Request $request)
    {
        $input = $request->getContent();
        Log::info($input);
        $input = WxPay::xml2array($input);
        $config = config('wxpay');
        $return = [
            'appid' => $config['appId'],
            'mch_id' => $config['mchId'],
            'nonce_str' => $this->getRandomStr(),
        ];

        if (!WxPay::checkSign($input, $config['mchKey'])) {
            Log::info('微信扫码支付回调：SIGN指纹码错误', $input);

            return abort(500);
        }

        list ($courseId, $userId) = explode('x', $input['product_id']);
        $course = Course::findOrFail($courseId);
        $user = User::findOrFail($userId);

        $order = Order::create([
            'course_id' => $courseId,
            'total_price' => intval($course->cost * 100),
            'user_id' => $user->UserId
        ]);

        $wxPayOrder = [
            'product_id' => $courseId,
            'out_trade_no' => $order->id,
            'body' => 'GAD在线教育-'.$course->title,
            'total_fee' => '1'//$order->total_price
        ];
        
        $wxpay = WxPay::driver('native')->order($wxPayOrder);
        $return['prepay_id'] = $wxpay->wxOrder['prepay_id'];
        $return['return_code'] = 'SUCCESS';
        $return['result_code'] = 'SUCCESS';
        $return['sign'] = $this->sign($return, $config['mchKey']);

        return $this->array2xml($return);
    }

    public function postWxPayNotify(Request $request)
    {
        $notifyRaw = $request->getContent();
        Log::info($notifyRaw);
        $notify = WxPay::xml2array($notifyRaw);
        if (array_get($notify, 'return_code') !== 'SUCCESS' OR array_get($notify, 'result_code') !== 'SUCCESS') {
            Log::info('微信支付结果通知：请求数据异常', $notify);

            return 'error';
        }

        if (!WxPay::checkSign($notify, config('wxpay.mchKey'))) {
            Log::info('微信支付结果通知：SIGN指纹码错误', $notify);

            return 'error';
        }

        $wxOrder = WxPay::orderQuery($notify['transaction_id']);
        if ($wxOrder['trade_state'] !== 'SUCCESS' OR $wxOrder['out_trade_no'] != $notify['out_trade_no']) {
            Log::info('微信支付结果通知：伪造请求', $notify);

            return 'error';
        }

        $order = Order::find($notify['out_trade_no']);
        if (!$order OR $order->total_price != $notify['total_fee']) {
            Log::info('微信支付结果通知：支付价格和订单不符', $notify);

            //return 'error';
        }

        $course = Course::find($order->course_id);
        if (!$course) {
            Log::info('微信支付结果通知：购买的分享不存在', $notify);

            return 'error';
        }
        if (!$course->students()->where('user_id', $order->user_id)->exists()) {
            $course->students()->attach($order->user_id);
        }

        $order->transaction_id = $notify['transaction_id'];
        $order->pay_time = date('Y-m-d H:i:s', strtotime($notify['time_end']));
        $order->save();

        $course->study_count = $course->study_count + 1;
        $course->save();

        return 'success';
    }
}
