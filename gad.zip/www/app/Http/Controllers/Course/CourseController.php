<?php

namespace App\Http\Controllers\Course;

use App\Gad\Upload;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Lesson;
use App\Models\Teacher;
use App\Models\Refund;
use App\Qcloud\Qcloud;
use Auth;
use Endroid\QrCode\QrCode;
use Gate;
use Log;
use Illuminate\Http\Request;
use Response;

class CourseController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth', ['only' => ['postCreate', 'postEdit', 'postRegister', 'postCollect']]);
    }

    public function getIndex()
    {
        return redirect()->route('course::detail', 10000001);
    }

    public function getCreate()
    {

        if (!Auth::check()) {
            return redirect()->guest('/login');
        }

        $course = new Course();
        $this->authorize('create', $course);
        $types = collect($course->getTypes());

        return view('course.edit', compact('course', 'types'));
    }

    public function postCreate(Request $request)
    {
        $course = new Course;
        $this->authorize('create', $course);

        $fields = [
            ['key' => 'title', 'name' => '分享名称', 'rule' => 'required'],
            ['key' => 'target', 'name' => '适用人群', 'rule' => 'required'],
            ['key' => 'thumbnail', 'name' => '缩略图', 'rule' => 'required'],
            ['key' => 'cost', 'name' => '费用', 'rule' => 'required'],
            ['key' => 'summary', 'name' => '分享简介', 'rule' => 'required'],
            ['key' => 'desc', 'name' => '分享预览', 'rule' => 'required'],
            ['key' => 'teachers.*.id', 'name' => '老师信息', 'rule' => 'required'],
            ['key' => 'assistants.*.id', 'name' => '助教信息', 'rule' => 'required'],
            ['key' => 'cs_uin', 'name' => '客服QQ号', 'rule' => 'required'],
            ['key' => 'cs_name', 'name' => '客服昵称', 'rule' => 'required'],
            ['key' => 'qq_qun', 'name' => 'QQ群号码', 'rule' => 'required'],
            ['key' => 'qq_qun_name', 'name' => 'QQ群名称', 'rule' => 'required'],
            ['key' => 'qq_qun_key', 'name' => 'QQ群KEY', 'rule' => 'required'],
        ];
        $validator  = [
            'rule' => [],
            'messages' => [
                'required' => ':attribute 不能为空',
                'title.max' => '分享名称不能超过20个字'
            ],
            'attr' => []
        ];
        foreach ($fields as $field) {
            $validator['rule'][$field['key']] = $field['rule'];
            $validator['attr'][$field['key']] = $field['name'];
        }
        $this->validate($request, $validator['rule'], $validator['messages'], $validator['attr']);

        $courseData = $request->all();
        $courseData['user_id'] = Auth::user()->UserId;
        $courseData['desc'] = xssFilter($courseData['desc']);
        $course->fill($courseData);
        $course->save();

        $teacherId = array_unique(array_column($request->teachers, 'id'));
        $assistantId = array_unique(array_column($request->assistants, 'id'));
        $course->teachers()->attach($teacherId);
        $course->assistants()->attach($assistantId);

        return response()->json($course);
    }

    public function getEdit(Request $request, $id)
    {
        $course = Course::with('teachers.user', 'assistants')->findOrFail($id);
        $this->authorize('edit', $course);
        $types = collect($course->getTypes());

        return view('course.edit', compact('course', 'types'));
    }

    public function postEdit(Request $request, $id)
    {
        $course = Course::findOrFail($id);
        $this->authorize('edit', $course);

        $courseData = $request->all();
        $courseData['desc'] = xssFilter($courseData['desc']);
        $course->fill($courseData);
        $course->save();

        $teacherId = array_column($request->teachers, 'id');
        $assistantId = array_column($request->assistants, 'id');
        $course->teachers()->sync($teacherId);
        $course->assistants()->sync($assistantId);

        return response()->json($course);
    }

    public function postRelease(Request $request)
    {
        $course = Course::findOrFail($request->input('id'));
        $this->authorize('edit', $course);

        if ($course->status == '0') {
            if ($course->lessons->count()) {
                $course->status = '1';
                $course->save();
                $result = ['code' => 0, 'message' => 'ok'];
            } else {
                $result = ['code' => 1, 'message' => '分享没有添加分享，发布失败！'];
            }
        } else {
            $result = ['code' => 1, 'message' => '分享状态错误，发布失败！'];
        }

        return response()->json($result);
    }

    public function postRegister(Request $request)
    {
        $course = Course::findOrFail($request->id);
        if ($course->cost != 0) {
            return abort(403);
        }

        $course->registerStudent(Auth::user());

        return ['result' => true];
    }

    public function postCollect(Request $request, $id)
    {
        $action = $request->input('action');
        $course = Course::findOrFail($id);
        $course->collect($action);

        return response()->json(['code' => 0, 'message' => $action == 'add' ? '分享收藏成功!' : '分享取消收藏成功!']);
    }

    public function destroy(Request $request, $id)
    {
        $course = Course::findOrFail($id);
        $this->authorize('edit', $course);
        if ($course->status == Course::STATUS_RELEASE) {
            return response()->json(['code' => 1, 'message' => '分享已发布，无法删除！']);
        }
        $course->delete();

        return response()->json(['code' => 0, 'message' => '分享删除成功']);
    }

    public function getInfo(Request $request, $id)
    {
        $course = Course::findOrFail($id);
        $this->authorize('edit', $course);
        
        return view('course.info', compact('course'));
    }

    public function getDetail(Request $request, $id)
    {
        $course = Course::findOrFail($id);
        if ($course->is_lundao) {
            return redirect(url('lundao/detail', $id));
        }

        if ($course->status != Course::STATUS_RELEASE) {
            // 未发布的分享仅创建者,老师,助教可以查看
            $this->authorize('edit', $course);
        }
        $teacher = $course->teachers()->first(['name', 'position', 'desc']);
        $students = $course->getLatestStudents();

        return view('course.detail', compact('course', 'teacher', 'students'));
    }

    public function getTeacher(Request $request)
    {
        $teacher = Teacher::with('user')->teacher();
        if ($qq = $request->input('qq')) {
            $teacher->qq($qq);
        }

        $teachers = $teacher->get(['id', 'user_id', 'uin', 'name', 'desc']);

        return response()->json($teachers);
    }

    public function getAssistant(Request $request)
    {
        $teacher = Teacher::with('user')->assistant();
        if ($qq = $request->input('qq')) {
            $teacher->qq($qq);
        }

        $assistants = $teacher->get(['id', 'user_id', 'uin', 'name', 'desc']);

        return response()->json($assistants);
    }

    public function postUploadImage(Request $request)
    {
        $this->authorize('create', new Course);
        
        $file = $request->file('file');
        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '上传失败：图片太大或格式不对']);
        }

        $result = Upload::uploadQcloudImage($file);

        return response()->json($result);
    }

    public function postEditorUploadImage(Request $request)
    {
        $this->authorize('create', new Course);
        
        $file = $request->file('Filedata');
        if (!$file->isValid()) {
            return response('<script>alert("图片上传出错");</script>');
        }
        if($file->getSize() > 10*1024*1024) {
            return response('<script>alert("图片上传出错：最大上传大小10M");</script>');
        }
        $result = Upload::uploadQcloudImage($file);
        if ($result['code'] == 0) {
            return response($result['data']['downloadUrl']);
        } else {
            return response('<script>alert("图片上传出错：'.$result['message'].'");</script>');
        }
    }

    public function postStartPlay(Request $request) {
        $courseData = $request->all();
        $lesson_id = $courseData['lid'];

        $lesson = Lesson::findOrFail($lesson_id);
        $this->authorize('update', $lesson);

        $course = Course::findOrFail($courseData['cid']);
        if ($course->state == 'living' OR $lesson->state == 'living') {
            return response()->json(['code' => -1, 'message' => '分享已有正在进行的直播，无法启动直播！']);
        }

        $teacher = Auth::user()->teacher;
        if (!$teacher) {
            return response()->json(['code' => -1, 'message' => '只能是分享老师启动直播！']);
        }

        if (!$teacher->lvb_channel_id) {
            return response()->json(['code' => -1, 'message' => '老师尚未配置直播频道，无法启动直播！']);
        }

        $param = ['channelId' => $teacher->lvb_channel_id];
        $startTime = sprintf('%s %s:00', $lesson->begin_date, $lesson->begin_time);
        if ((strtotime($startTime) - time()) >= 120) {
            $param['startTime'] = $startTime;
        }
        $result = Qcloud::live('CreateRecord', $param);
        if ($result['code']) {
            Log::error('分享直播录制任务创建失败', ['message' => $result['message'], 'id' => $lesson->id, 'param' => $param]);
        } else {
            $lesson->task_id = $result['data']['task_id'];
        }
        $lesson->lvb_channel_id = $teacher->lvb_channel_id;
        $lesson->lvb_source_id = $teacher->lvb_source_id;
        $lesson->state = 'living';
        $lesson->save();

        $course->state = 'living';
        $course->save();

        return response()->json(['code' => 0, 'message' => '分享直播已启动<br />请在OBS客户端配置推流参数，并开始推流']);
    }

    public function postEndPlay(Request $request) {
        $courseData = $request->all();

        //$id = $course['next_lesson'];
        $lesson_id = $courseData['lid'];

        $lesson = Lesson::findOrFail($lesson_id);
        if($lesson['state'] != 'living' && $lesson['begin_date'].' '.$lesson['begin_time'] > date('Y-m-d H:i:s')) {
            return response()->json(['code' => 1, 'message' => '直播还未开始，不能结束！']);
        }

        $this->authorize('update', $lesson);

        $course_id = $courseData['cid'];
        $course = Course::findOrFail($course_id);
        if ($lesson['task_id']) {
            $param = ['channelId' => $lesson['lvb_channel_id'], 'taskId' => $lesson['task_id']];
            $result = Qcloud::live('StopRecord', $param);
            if ($result['code']) {
                Log::error('分享直播录制任务停止失败', ['message' => $result['message'], 'id' => $lesson_id,  'param' => $param]);
            }
        }

        $lesson->state = 'over';
        if ($course->record) {
            $lesson->type = 'playback';
        }
        $lesson->save();

        $lessons = $course->lessons()->get(['id']);
        foreach ($lessons as $lesson) {
            if ($lesson['id'] > $lesson_id) {
                $next_lesson = $lesson['id'];
                break;
            }
        }
        if (!empty($next_lesson)) {
            $course->next_lesson = $next_lesson;
        }
        $course->state = 'over';
        $course->save();

        return response()->json(['code' => 0, 'message' => '已成功结束直播！']);
    }

    public function postRefund(Request $request) {
        $courseData = $request->all();
        $course = Course::findOrFail($courseData['course_id']);
        $this->authorize('learn', $course);

        if(!empty($course)) {
            if ($course['state'] == 'new') {
                $refund = new Refund();
                $user_id = Auth::user()->UserId;
                $temp = Refund::where(['course_id'=>$courseData['course_id'],'user_id'=>$user_id])->first();
                if(!empty($temp)) {
                    return response()->json(['code' => 1, 'message' => '已申请退款，请勿重复提交!']);
                }

                $refundData = $request->all();
                $refundData['user_id'] = $user_id;
                $refundData['cost'] = $course->cost;
                $refund->fill($refundData);
                $refund->save();

                return response()->json(['code' => 0, 'message' => '']);
            } else {
                return response()->json(['code' => 1, 'message' => '已直播不可退款!']);
            }
        }
    }

    public function getShareQrCode(Request $request, $id)
    {
        $qrCode = new QrCode();
        $response = Response::stream(function () use($qrCode, $id) {
            $domain = config('app.env') === 'production' ? 'm.gad.qq.com' : 'dev.m.gad.qq.com';
            $url = sprintf('http://%s/course/detail.html?id=%s', $domain, $id);
            $qrCode->setText($url)->setSize(125)->setPadding(10)->setErrorCorrection('high')->render();
        }, 200, ['Content-Type' => 'image/png']);

        return $response;
    }
}
