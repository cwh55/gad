<?php

namespace App\Http\Controllers\SummerCamp;

use App\Models\Summercourse;
use App\Models\Article;
use App\Models\ArtWork;
use App\Models\Video;
use App\Models\Worktype;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;


class SummerCampController extends Controller
{

    public function getIndex(Request $request) {
        return view('summercamp.index');
    }

    public function getCourselist(Request $request){
        $summercourse = new Summercourse();
        $courselist =array();
        for($classid = 1101; $classid <= 1104; $classid++){
            $list = Summercourse::with('teacher')
                ->where('status',0)
                ->where('class_id','>',$classid*100)
                ->where('class_id','<',$classid*100+100)
                ->orderBy('date', 'asc')
                ->get();
            $channelflag = $summercourse->getWhitelist($classid);
            foreach($list as $key=>$acourse){
                if(empty($acourse['thumbnail'])){    //如果没有配置缩略图
                    $list[$key]['thumbnail'] = "http://gameweb-img.qq.com/gad/20160717/phpCsfaE7.1468759022.jpg";
                }
                if(!empty($acourse->teacher) && empty($acourse->teacher->head_img)){
                    $list[$key]['teacher']['head_img'] = "http://zhibo.gad.qq.com/assets/forum/img/profile2.jpg";
                }
                $worktype = Worktype::where('class_id','=',$acourse['class_id'])->first();
                $curtime = date('Y-m-d H:i:s');
                if($acourse['date']<$curtime && $curtime<$acourse['end_time'] && $channelflag) {
                    $list[$key]['submitWorkBtn'] = true;
                }else{
                    $list[$key]['submitWorkBtn'] = false;
                }
                if(!empty($worktype)){
                    if($worktype->type==2){
                        //作业提交链接
                        $list[$key]['createUrl'] = "/video/create?classid=".$acourse['class_id'];
                        //作业查看链接
                        $list[$key]['showWorkUrl'] = "/work/list/".$acourse['class_id'];
                        //有内容才显示查看作业按钮
                        $workCount = Video::where('status','=',0)
                            ->where('class_id','=',$acourse['class_id'])->count();
                        $list[$key]['showWorkBtn'] = $workCount & $acourse['has_work'];
                    }else if($worktype->type==1){
                        $list[$key]['createUrl'] = "/art/create?classid=".$acourse['class_id'];
                        $list[$key]['showWorkUrl'] = "/work/list/".$acourse['class_id'];
                        $workCount = ArtWork::where('status','=',0)
                            ->where('class_id','=',$acourse['class_id'])->count();
                        $list[$key]['showWorkBtn'] = $workCount & $acourse['has_work'];
                    }else{
                        $list[$key]['createUrl'] = "/articulo/create?classid=".$acourse['class_id'];
                        $list[$key]['showWorkUrl'] = "/work/list/".$acourse['class_id'];
                        $workCount = Article::where('status','=',0)
                            ->where('class_id','=',$acourse['class_id'])->count();
                        if($workCount && $acourse['has_work']){
                            $list[$key]['showWorkBtn'] = 1;
                        }else{
                            $list[$key]['showWorkBtn'] = 0;
                        }
                    }
                }
            }
            array_push($courselist,$list);
        }

        return $courselist;
    }


    public function getWorkslist(Request $request) {
        //策划频道的作业
        $params = $request->all();

        $channel = 2;
        if($params['id'] == 0) {
            $channel = 2;
        }
        if($params['id'] == 1) {
            $channel = 3;
        }
        if($params['id'] == 2) {
            $channel = 4;
        }
        if($params['id'] == 3) {
            $channel = 5;
        }
        $options = [
                    2=>[110101, 110199], //策划 
                    3=>[110201, 110299], //程序
                    4=>[110301, 110399], //美术
                    5=>[110401, 110499], //UI
                ];

        $list = Worktype::with('classify')->where('class_id', '>=', $options[$channel][0])
                            ->where('class_id', '<=', $options[$channel][1])
                            ->orderBy('created_at', 'desc')
                            ->take(8)
                            ->get();
        foreach ($list as $key => &$value) {
            switch ($value['type']) {
                case 0:
                    $worklist = Article::where('class_id', '=', $value['class_id'])
                                    ->where('status', '=', 0)
                                    ->orderBy('is_top', 'desc')
                                    ->orderBy('created_at', 'desc')
                                    ->with('user')
                                    ->take(6)
                                    ->get();
                    break;
                case 1:
                    $worklist = ArtWork::where('class_id', '=', $value['class_id'])
                                    ->where('status', '=', 0)
                                    ->orderBy('is_top', 'desc')
                                    ->orderBy('created_at', 'desc')
                                    ->with('user')
                                    ->take(8)
                                    ->get();
                    break;
                case 2:
                    $worklist = Video::where('class_id', '=', $value['class_id'])
                                    ->where('status', '=', 0)
                                    ->orderBy('is_top', 'desc')
                                    ->orderBy('created_at', 'desc')
                                    ->with('user')
                                    ->take(8)
                                    ->get();
                    break;
                default:
                    # code...
                    break;
            }
            $value['list'] = $worklist;
        }
        return response()->json(['code'=>1, 'data'=>$list]);
    }
}
