<?php

namespace App\Http\Controllers;

use App\Entities\Course;
use App\Entities\Lesson;
use App\Models\Activity;
use App\Models\Content;
use App\Models\Question;
use App\Models\Fame;
use App\Entities\Live;
use App\Entities\Lore;
use App\Entities\IndependGame;
use App\Repositories\OperationRepository;
use App\Repositories\PictureRepository;
use App\Repositories\ArchiveRepository;
use App\Gad\Html;
use Illuminate\Http\Request;
use Auth;
use Redis;
use Cache;

class HomeController extends Controller
{
    public function __construct(OperationRepository $operation)
    {
        $this->operation = $operation;
    }

    public function index(ArchiveRepository $archive, PictureRepository $picture, Request $request)
    {
        if(Auth::user() != null && $request->headers->get('referer') == '') {
            $hrefIndent = Redis::hGet('community::href::indent', Auth::user()->UserId);
            if ($hrefIndent == true) {
                return redirect('/community');
            }
        }
        $homedata = Cache::remember("new_homepage_alldata", 10, function () use ($archive, $picture) {
            $bannerlist = $this->operation->getAdsByType(7);
            $numberlist = implode(',', Redis::hGetAll('gad:index:statistics'));
            //开发者社区配置信息
            $communitylist = $this->operation->getAdsByType(array(10, 11, 12));
            $leftlist = $middlelist = $rightlist = [];
            //答疑解惑
            $liveitem = $this->getItemByType(101, $communitylist);
            if (empty($liveitem) || !intval($liveitem['extra'])) {   //自动拉取最新
                $live = Live::where(['state' => 0])->orderBy('id', 'desc')->first();
                $liveitem = array('cover' => '',
                    'title' => $live['name'],
                    'url' => "http://gad.qq.com/live/detail/" . $live['id']);
            } else {
                $live = Live::find(intval($liveitem['extra']));
            }
            if (!empty($live)) {
                if (date("Y-m-d h:i:s") > $live['end_time']) {
                    $liveitem['subinfo'] = '已结束';
                } else {
                    $liveitem['subinfo'] = '开始时间：' . substr($live['begin_time'], 0, 16);
                }
            } else {
                $liveitem['subinfo'] = '';
            }
            $liveitem['subtype'] = '【Live】';
            array_push($leftlist, $liveitem);

            $wendaitem = $this->getItemByType(102, $communitylist);
            if (empty($wendaitem) || !intval($wendaitem['extra'])) {   //自动拉取最新
                $wendaa = Activity::where(['status' => 0])->orderBy('id', 'desc')->first();
                $wendaitem = array('cover' => $wendaa['banner'],
                    'title' => $wendaa['title'],
                    'url' => "http://gad.qq.com/wenda/activity/" . $wendaa['id'],
                    'subinfo' => Question::where('obj_type', 1)->where('obj_id', $wendaa['id'])->where('status', 0)->sum('answers') . '个回答');
            } else {
                $wendaitem['subinfo'] = Question::where('obj_type', 1)->where('obj_id', intval($wendaitem['extra']))->where('status', 0)->sum('answers') . '个回答';
            }
            $wendaitem['subtype'] = '【问答】';
            array_push($leftlist, $wendaitem);

            $dianpingitem = $this->getItemByType(103, $communitylist);
            if (empty($dianpingitem) || !intval($dianpingitem['extra'])) {   //自动拉取最新
                $picturea = $picture->where('type', '=', 2)->where('status', '=', 0)->where('sort', '=', 0)->orderBy('id', 'desc')->first();
                $archivea = $archive->find($picturea['archive_id']);
                $dianpingitem = array('cover' => $picturea['url'],
                    'title' => $archivea['title'],
                    'url' => "http://gad.qq.com/gallery/detail/" . $picturea['archive_id'],
                    'subinfo' => $archivea['view_count'] . '人浏览');
            } else {
                $workarchive = $archive->find(intval($dianpingitem['extra']));
                $dianpingitem['subinfo'] = empty($workarchive) ? '' : $workarchive['view_count'] . '人浏览';
            }
            $dianpingitem['subtype'] = '【大咖评画】';
            array_push($leftlist, $dianpingitem);

            //深度聚焦
            $lundaoitem = $this->getItemByType(111, $communitylist);
            if (empty($lundaoitem) || !intval($lundaoitem['extra'])) {   //自动拉取最新
                $lundaocourse = Course::where(['status' => 1])->orderBy('id', 'desc')->first();
                $lundaoitem = array('cover' => $lundaocourse['thumbnail'],
                    'title' => $lundaocourse['title'],
                    'url' => "http://gad.qq.com/lundao/detail/" . $lundaocourse['id']);
            } else {
                $lundaocourse = Course::find(intval($lundaoitem['extra']));
            }
            $lundao = Lesson::where(['course_id' => $lundaocourse['id']])->first();
            if (!empty($lundao)) {
                if (date("Y-m-d") > $lundao['begin_date']) {
                    $lundaoitem['subinfo'] = $lundaocourse['study_count'] . '人观看';
                } else {
                    $lundaoitem['subinfo'] = '开始时间：' . $lundao['begin_date'] . ' ' . $lundao['begin_time'];
                }
            } else {
                $lundaoitem['subinfo'] = '';
            }
            $lundaoitem['subtype'] = '【论道】';
            array_push($middlelist, $lundaoitem);

            $duyouitem = $this->getItemByType(112, $communitylist);
            if (empty($duyouitem) || !intval($duyouitem['extra'])) {   //自动拉取最新
                $gamepie = \App\Entities\GamePai::where('status',0)->orderBy('id', 'desc')->first();
                $duyouitem = array('cover' => $gamepie['cover'],
                    'title' => $gamepie['title'],
                    'url' => "http://gad.qq.com/gamepie/detail/" . $gamepie['id']);
            } else {
                $gamepie = \App\Entities\GamePai::find(intval($duyouitem['extra']));
            }
            $duyouitem['subinfo'] = empty($gamepie) ? '' : $gamepie['view_count'] . '人浏览';
            $duyouitem['subtype'] = '【游戏派】';
            array_push($middlelist, $duyouitem);

            $fameitem = $this->getItemByType(113, $communitylist);
            if (empty($fameitem) || !intval($fameitem['extra'])) {   //自动拉取最新
                $fame = Fame::where(['status' => 0])->orderBy('id', 'desc')->first();
                $fameitem = array('cover' => $fame['logo'],
                    'title' => $fame['name'],
                    'url' => "http://gad.qq.com/fame/detail/" . $fame['id']);
            } else {
                $fame = Fame::find(intval($fameitem['extra']));
            }
            $fameitem['subinfo'] = empty($fame) ? '' : $fame['view_cnt'] . '人浏览';
            $fameitem['subtype'] = '【名人堂】';
            array_push($middlelist, $fameitem);

            //专业知识
            $loreitem = $this->getItemByType(121, $communitylist);
            if (empty($loreitem) || !intval($loreitem['extra'])) {   //自动拉取最新
                $lore = Lore::where(['state' => 0])->orderBy('id', 'desc')->first();
                $loreitem = array('cover' => $lore['banner_pic'],
                    'title' => $lore['title'],
                    'url' => "http://gad.qq.com/lore/index/" . $lore['id']);
            }
            $loreitem['subtype'] = '【知识手册】';
            array_push($rightlist, $loreitem);

            $translateitem1 = $this->getItemByType(122, $communitylist);
            if (!empty($translateitem1)) {
                $translateitem1['subtype'] = '【翻译馆】';
                array_push($rightlist, $translateitem1);
                $translateitem2 = $this->getItemByType(122, $communitylist, $translateitem1['extra']);
                if (!empty($translateitem2)) {
                    $translateitem2['subtype'] = '【翻译馆】';
                    array_push($rightlist, $translateitem2);
                } else {
                    $translate = Content::getNewestTranslate(1)[0];
                    if (!$translate->CoverImage) {
                        $translate->CoverImage = Html::getFirstImage($translate->vHtmlDetail);
                    }
                    array_push($rightlist, array('cover' => $translate->CoverImage,
                        'title' => $translate->vCnTitle,
                        'url' => "http://gad.qq.com/program/translateview/" . $translate->Id,
                        'subtype' => '【翻译馆】'));
                }
            } else {
                $translatelist = Content::getNewestTranslate(2);
                foreach ($translatelist as $translate) {
                    if (!$translate->CoverImage) {
                        $translate->CoverImage = Html::getFirstImage($translate->vHtmlDetail);
                    }
                    array_push($rightlist, array('cover' => $translate->CoverImage,
                        'title' => $translate->vCnTitle,
                        'url' => "http://gad.qq.com/program/translateview/" . $translate->Id,
                        'subtype' => '【翻译馆】'));
                }
            }
            //创客
            $chuangkelist = array_slice($this->operation->getAdsByType(8)->all(), 0, 4);
            //整理日期格式信息
            $weekArr = array("周日", "周一", "周二", "周三", "周四", "周五", "周六");
            for ($i = 0; $i < 4, $i < count($chuangkelist); $i++) {
                $starttime = $chuangkelist[$i]['starttime'];
                $endtime = $chuangkelist[$i]['endtime'];
                $endyear = substr($endtime, 0, 4);
                $startweek = $weekArr[date('w', strtotime($starttime))];
                if ($endyear == '0000') {
                    $chuangkelist[$i]['time'] = substr($starttime, 0, 11) . $startweek;
                } else {
                    $endweek = $weekArr[date('w', strtotime($endtime))];
                    if (substr($starttime, 0, 4) != $endyear) {
                        $chuangkelist[$i]['time'] = substr($starttime, 0, 10) . $startweek . '至' . substr($endtime, 0, 10) . $endweek;
                    } else {
                        $chuangkelist[$i]['time'] = substr($starttime, 0, 10) . $startweek . '至' . substr($endtime, 5, 6) . $endweek;
                    }
                }
            }
            //扶持的项目
            $hatchgamelist = array_slice($this->operation->getAdsByType(9)->all(), 0, 3);
            //友情链接，合作伙伴
            $links = $this->operation->getAdsByType(16);
            return compact('bannerlist', 'numberlist', 'chuangkelist', 'leftlist', 'middlelist', 'rightlist', 'hatchgamelist', 'links');
        });

        return view('home.index', $homedata);
    }

    //$outid：排除的extra值，关联id
    private function getItemByType($type, $list = [], $outid = -1)
    {
        $realItem = [];
        $position = -1;
        foreach ($list as $item) {
            if ($item['model_id'] == $type && $item['extra'] != $outid) {
                if ($item['position'] > $position) {
                    $position = $item['position'];
                    $realItem = $item;
                }
            }
        }
        return $realItem;
    }


    public function about()
    {
        return view("home.about");
    }


}
