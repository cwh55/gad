<?php

namespace App\Http\Controllers\User;

use App\Models\User;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function getSearchByQQ(Request $request)
    {
        $users = User::qq($request->get('qq'))->get();
        $users = $users->map(function ($user) {
            return ['id' => $user->UserId, 'qq' => $user->QQNo];
        });

        return response()->json(['users' => $users]);
    }
}
