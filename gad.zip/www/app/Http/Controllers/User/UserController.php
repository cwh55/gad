<?php

namespace App\Http\Controllers\User;
use Auth;
use App\Models\User;
use App\Models\Teacher;
use App\Models\Course;
use App\Models\Joincourse;
use App\Models\Refund;
use Carbon\Carbon;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
    private $userInfo = array();

    public function __construct()
    {
        $this->middleware('auth');
        if (!Auth::check()) {
            return redirect('/login');
        }
        $this->userInfo = Auth::user();
    }
    public function getTeacher(Request $request)
    {
        $v = $request->input('v','all');
        $status = null;
        if($v == 'released') {
            $status = 1;
        } else if($v == 'draft') {
            $status = 0;
        }
        $user = $this->userInfo;
        $teacher = $courses = array();
        $total_course = 0;
        $teacher = $this->userInfo->teacher;
        if ($teacher === null) {
            return redirect('/user/creator');
        }

        if(!empty($teacher)) {
            if($teacher->type == 0) {
                if($status === 0 || $status === 1) {
                    $courses = $teacher->courses()->where('status', $status)->paginate(10);
                } else {
                    $courses = $teacher->courses()->paginate(10);
                }
                $total_course = $teacher->courses()->count();
            } else {
                if($status === 0 || $status === 1) {
                    $courses = $teacher->assistant_courses()->where('status', $status)->paginate(10);
                } else {
                    $courses = $teacher->assistant_courses()->paginate(10);
                }
                $total_course = $teacher->assistant_courses()->count();
            }

            if(!empty($courses)) {
                foreach($courses as $key => $course) {
                    $lesson = $course->lesson;
                    if(!empty($lesson)) {
                        $courses[$key]['live_status'] = $lesson->state;
                        $courses[$key]['live_time'] = $lesson->begin_date.' '.$lesson->begin_time;
                    } else {
                        $courses[$key]['live_status'] = '';
                        $courses[$key]['live_time'] = '';
                    }
                }
            }

        }

        return view('user.teacher', compact('courses', 'teacher', 'user', 'total_course'));
    }

    public function getPersonal(Request $request)
    {
        $courses = $this->userInfo->courses()->paginate(4);

        if(!empty($courses)) {
            foreach($courses as $key => $course) {
                $refund = $course->getRefundInfo();

                if(!empty($refund)) {
                    $courses[$key]['refund'] = $refund;
                } else {
                    $courses[$key]['refund'] = null;
                }

                $lesson = $course->lesson;
                if (empty($lesson)) {
                    $courses[$key]['live_status'] = 'none';
                } else {
                    if($course['state'] == 'new' || $course['state'] == 'living') {
                        //if ($lesson['state'] == 'new' && $lesson['begin_date'] . ' ' . $lesson['begin_time'] > date('Y-m-d H:i:s', strtotime('+1 hour'))) {
                        if ($lesson['state'] == 'new') {
                            $courses[$key]['live_status'] = 'new';
                        } else if ($lesson['state'] == 'over') {
                            $courses[$key]['live_status'] = 'over';
                        } else {
                            $courses[$key]['live_status'] = $lesson['state'];
                        }

                        $courses[$key]['lesson'] = $lesson;
                    } else {
                        $courses[$key]['live_status'] = 'over';
                    }
                }
            }
        }
        /*
        $courses = DB::table('courses')
                    ->join('lessons', 'courses.next_lesson', '=', 'lessons.id')
                    ->select('courses.*', 'lessons.begin_date')
                    ->where(courses.)
                    ->get();*/
        return view('user.personal', compact('courses'));
    }

    public function getCreator(Request $request)
    {
        $v = $request->input('v','all');
        $status = null;
        if($v == 'released') {
            $status = 1;
        } else if($v == 'draft') {
            $status = 0;
        }

        $total_course = 0;
        if($status === 0 || $status === 1) {
            $courses = $this->userInfo->creator_course()->where('status', $status)->paginate(10);
        } else {
            $courses = $this->userInfo->creator_course()->paginate(10);
        }
        $total_course = $this->userInfo->creator_course()->count();

        if(!empty($courses)) {
            foreach($courses as $key => $course) {
                $lesson = $course->lesson;
                if(!empty($lesson)) {
                    $courses[$key]['live_status'] = $lesson->state;
                    $courses[$key]['live_time'] = $lesson->begin_date.' '.$lesson->begin_time;
                } else {
                    $courses[$key]['live_status'] = '';
                    $courses[$key]['live_time'] = '';
                }
            }
        }

        return view('user.creator', compact('courses', 'total_course'));
    }

    public function getCourseStudents(Request $request, $id)
    {
        $course = Course::findOrFail($id);

        $students = $course->students()->paginate(10);

        if(!empty($students)) {
            foreach($students as $key => $student) {
                $students[$key]['refund'] = Refund::where(['course_id'=>$course->id,'user_id'=>$student['UserId']])->first();
            }
        }

        return view('course.students', compact('students', 'id'));
    }

}
