<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 2017/7/13
 * Time: 11:00
 */

namespace App\Http\Controllers\Team;

use App\Repositories\ProjectRepository;
use App\Repositories\ResumeRepository;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;


class TeamController extends Controller
{

    private  $resume;
    private  $project;

    public function __construct(ResumeRepository $resume,ProjectRepository $project)
    {
        $this->resume = $resume;
        $this->project = $project;
    }

    public function getIndex(Request $request)
    {
        $curPage = 'team';
        return view('team.index',compact('curPage'));
    }

}