<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 2017/7/13
 * Time: 11:00
 */

namespace App\Http\Controllers\Team\My;

use App\Gad\Func;
use App\Gad\MessageType;
use App\Jobs\SendMail;
use App\Repositories\ProjectRepository;
use App\Repositories\ResumeRepository;
use App\Repositories\TeamActionRepository;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;


class ResumeController extends Controller
{
    private $project;
    private $resume;
    private $teamAction;

    public function __construct(ResumeRepository $resume, ProjectRepository $project,TeamActionRepository $teamAction)
    {
        $this->project = $project;
        $this->resume = $resume;
        $this->teamAction = $teamAction;
        $this->middleware('auth');
    }

    public function getIndex(Request $request)
    {

        return view('team.my.resume');
    }

    public function getInfo(Request $request)
    {
        $resume = $this->resume->findBy('user_id',$request->user()->UserId);
        if ($resume and $resume->step == 4) {
            $resume->append(['age','ageofwork','completed','completedsteps']);
            //用于编辑
            $resume->jobList = collect($resume->jobs)->map(function($job){
                $job['edit'] = false;
                return $job;
            });
            return response()->json(
                [
                    'code'=>0,
                    'resume' => $resume
                ]
            );

        } else {
            return response()->json(
                [
                    'code'=>-1
                ]
            );
        }

    }

    public function getApplies(Request $request)
    {
        $state = $request->input('state');
        $applyList = $this->teamAction->getApplyListByUser($request->user(),$state);
        $applyList->map(function($item){
            if ($item->state != 1) {
                $item->projectUser = null;
            }
        });
        $resume = $this->resume->findBy('user_id',$request->user()->UserId);
        if ($resume) {
            $resume->apply_notify = 0;
            $resume->save();
        }

        return response()->json([
            'code' => 0,
            'applyList' => $applyList
        ]);
    }

    public function getInvites(Request $request)
    {
        $state = $request->input('state');
        $inviteList = $this->teamAction->getInviteListByUser($request->user(),$state);
        $resume = $this->resume->findBy('user_id',$request->user()->UserId);
        if ($resume) {
            $resume->invite_notify = 0;
            $resume->save();
        }

        return response()->json([
            'code' => 0,
            'inviteList' => $inviteList
        ]);
    }

    //保存
    public function postSave(Request $request)
    {
        $resumeData = $request->except(['state','is_show','deleted_at','is_top']);
        $resumeData['user_id'] = Auth::user()->UserId;
        //步骤1验证规则
        $validatorStep1 = [
            'messages'=>[
                'required' => ':attribute 不能为空',
            ],
            'rule' => [
                'real_name' => 'required',
                'gender' => 'required',
                'education' => 'required',
                'province' =>'required',
                'phone' => 'required|digits:11',
                'email' =>'required|email'
            ],
            'attr' => [
                'real_name' => '姓名',
                'gender' => '性别',
                'education' => '学历',
                'province' => '省份',
                'phone' => '手机号',
                'email' => '邮箱'
            ]
        ];
        //步骤2验证规则
        $validatorStep2 = [
            'messages'=>[
                'required' => ':attribute 不能为空',
            ],
            'rule' => [
                'career_type' => 'required',
                'work_date' => 'required',
                'intent_city' =>'required',
                'workTypes'=>'required'
            ],
            'attr' => [
                'career_type' => '职业方向',
                'work_date' => '开始工作时间',
                'intent_city' => '期望工作城市',
                'workTypes' => '期望工作方式'
            ]
        ];

        switch($request->input('step')) {
            case 1:
                $this->validate($request,$validatorStep1['rule'],$validatorStep1['messages'],$validatorStep1['attr']);
                if ($resumeData['province'] == '国外') {
                    $resumeData['city'] = '国外';
                }
                break;
            case 2:
                $this->validate($request,$validatorStep2['rule'],$validatorStep2['messages'],$validatorStep2['attr']);
                $resumeData['work_type'] = join(",",$resumeData['workTypes']);
                break;
        }

        $resume = $this->resume->findBy('user_id',Auth::user()->UserId);
        $resumeData['step'] = 4;
        if ($resume) {
            list($updated,$resume) = $this->resume->update($resume->id,$resumeData);

            if ($updated) {
                $resume->append(['age','ageofwork','completed','completedsteps']);
                return response()->json([
                    'code'=> 0,
                    'msg'=>'更新成功',
                    'resume'=>$resume
                ]);
            }
        } else {

                return response()->json([
                    'code'=>-1,
                    'msg'=>'简历不存在'
                ]);
        }

    }

    //
    public function postApply(Request $request)
    {
        $resume = $this->resume->findBy('user_id',Auth::user()->UserId);
        if ($resume) {
            $resume->state = 0;
            if ($resume->save()) {
                return response()->json([
                    'code' => 0,
                    'msg' => '成功'
                ]);
            } else {
                return response()->json([
                    'code' => -1,
                    'msg' => '失败'
                ]);
            }
        }
        return response()->json([
            'code' => -1,
            'msg' => '失败'
        ]);

    }

    //处理邀请
    public function postProcess(Request $request)
    {
        $teamAction = $this->teamAction->find($request->input('id'));
        $user = $request->user();
        if ($teamAction) {
            //判断是否是自己收到的邀请
            if ($teamAction->resume_user == $user->UserId and $teamAction->action_type == 'invite') {
                if ($teamAction->state == 0) {
                    $teamAction->state = $request->input('state');
                    if ($teamAction->save()) {
                        //发送给邀请者消息
                        $project = $this->project->find($teamAction->project_id);
                        $project->invite_notify += 1;
                        $project->save();
                        //邀請人發送站內消息
                        Func::msgApi(
                            MessageType::TEAM_RESUME_ANSWER_PROJECT,
                            $project->user_id,
                            $user->UserId,
                            0,
                            url('/team/my/project#!/invite/'.$project->id. '?ADTAG=meg.boss.chk'),
                            '点击这里'
                        );
                        //发送邮件
                        if ($project->projectUser and  $project->projectUser->email != '') {
                            dispatch(new SendMail(
                                $project->projectUser->email,
                                '[腾讯GAD]你有一个找人组队需求待处理',
                                '您好,<br>你收到了一个加入申请，请尽快登录<a href="http://gad.qq.com/team/my/project#!/apply/'.$project->id.'?ADTAG=email.boss.chk">处理</a><br>-腾讯GAD项目组'
                            ));
                        }
                        return response()->json([
                            'code' => 0,
                            'msg' => '处理成功'
                        ]);
                    }

                } else {
                    return response()->json([
                        'code' => -1,
                        'msg' => '请勿重复处理'
                    ]);
                }
            } else {
                return response()->json([
                    'code' => -1,
                    'msg' => '无权限'
                ]);
            }
        } else {
            return response()->json([
                'code' => -1,
                'msg' => '消息不存在'
            ]);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function postNotify(Request $request)
    {
        $resume = $this->resume->findBy('user_id',Auth::user()->UserId);
        if ($resume) {
            $notifyType = $request->input('type');
            if ($notifyType == 'invite') {
                $resume ->invite_notify = 0;
            }
            if ($notifyType == 'apply') {
                $resume ->apply_notify = 0;
            }
            if ($resume->save()) {
                return response()->json([
                    'code' => 0,
                    'resume' => $resume
                ]);
            } else {
                return response()->json([
                    'code' => -1
                ]);
            }

        }
    }


}