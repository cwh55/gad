<?php

namespace App\Http\Controllers\Team\My;

use App\Entities\TeamAction;
use App\Gad\Func;
use App\Gad\MessageType;
use App\Jobs\SendMail;
use App\Repositories\ProjectRepository;
use App\Repositories\ResumeRepository;
use App\Repositories\TeamActionRepository;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;

class ProjectController extends Controller
{
    private $project;
    private $resume;
    private $teamAction;

    public function __construct(ProjectRepository $project, ResumeRepository $resume, TeamActionRepository $teamAction)
    {
        $this->project = $project;
        $this->resume = $resume;
        $this->teamAction = $teamAction;
        $this->middleware('auth');
    }

    public function getIndex(Request $request)
    {
        return view('team.my.project');
    }

    public function getList(Request $request)
    {
        $projects = $this->project->getListByUser($request->user());

        return response()->json($projects);
    }

    public function getDetail(Request $request, $id)
    {
        $project = $this->project->with(['jobs'])->find($id);
        if (!$project) {
            return abort(404, '项目不存在');
        }

        $this->authorize('access', $project);

        return response()->json($project);
    }

    public function getApply(Request $request, $id)
    {
        $project = $this->project->find($id);
        if (!$project) {
            return abort(404, '项目不存在');
        }

        $this->authorize('access', $project);
        $actions = $this->teamAction->getApplyListByProject($project, $request->get('state'));
        if ($project->apply_notify) {
            $this->project->update($project, ['apply_notify' => 0]);
        }

        return response()->json($actions);
    }

    public function getInvite(Request $request, $id)
    {
        $project = $this->project->find($id);
        if (!$project) {
            return abort(404, '项目不存在');
        }

        $this->authorize('access', $project);
        $actions = $this->teamAction->getInviteListByProject($project, $request->get('state'));
        $actions->map(function($item){
            if ($item->state != TeamAction::STATE_ACCEPT) {
                $item->resume->real_name = $item->resume->nickname;
                $item->resume->photo = $item->resume->nickphoto;
            }
        });
        if ($project->invite_notify) {
            $this->project->update($project, ['invite_notify' => 0]);
        }

        return response()->json($actions);
    }

    public function postApply(Request $request, $id)
    {
        $action = $this->teamAction->find($id);
        if (!$action) {
            return abort(404, '申请不存在');
        }

        $project = $this->project->find($action->project_id);
        if (!$project) {
            return abort(404, '项目不存在');
        }
        $resume = $this->resume->find($action->resume_id);
        if (!$resume) {
            return abort(404, '简历不存在');
        }

        $state = $request->get('state');
        if ($state == TeamAction::STATE_ACCEPT) {
            $action = $this->teamAction->acceptApply($action);
            $resume->apply_notify += 1;
            $resume->save();
            Func::msgApi(
                MessageType::TEAM_PROJECT_ANSWER_RESUME,
                $resume->user_id,
                $project->user_id,
                $project->id,
                url('/team/my/resume#!/apply?ADTAG=meg.worker.chk'),
                '点击这里'
            );
            //发送邮件
            if ($resume->email != '') {
                dispatch(new SendMail(
                    $resume->email,
                    '[腾讯GAD]你有一个找人组队需求待处理',
                    '您好,<br>你收到了一个回应，请尽快登录<a href="http://gad.qq.com/team/my/resume#!/apply?ADTAG=email.worker.chk">处理</a><br>-腾讯GAD项目组'
                ));
            }
            return response()->json($action);
        } elseif ($state == TeamAction::STATE_REJECT) {
            $action = $this->teamAction->rejectApply($action);
            $resume->apply_notify += 1;
            $resume->save();
            Func::msgApi(
                MessageType::TEAM_PROJECT_ANSWER_RESUME,
                $resume->user_id,
                $project->user_id,
                $project->id,
                url('/team/my/resume#!/apply'),
                '点击这里'
            );
            //发送邮件
            if ($resume->email != '') {
                dispatch(new SendMail(
                    $resume->email,
                    '[腾讯GAD]你有一个找人组队需求待处理',
                    '您好,<br>你收到了一个回应，请尽快登录<a href="http://gad.qq.com/team/my/resume#!/apply">处理</a><br>-腾讯GAD项目组'
                ));
            }
            return response()->json($action);
        } else {
            return abort(400, '参数不合法');
        }
    }

    public function postDelete(Request $request, $id)
    {
        $project = $this->project->find($id);
        if (!$project) {
            return abort(404, '项目不存在');
        }

        $this->authorize('delete', $project);
        list($result) = $this->project->delete($id);
        if ($result) {
            return response();
        }

        return abort(404);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function postNotify(Request $request)
    {
        $project = $this->project->findBy('user_id',Auth::user()->UserId);
        if ($project) {
            $notifyType = $request->input('type');
            if ($notifyType == 'invite') {
                $project ->invite_notify = 0;
            }
            if ($notifyType == 'apply') {
                $project ->apply_notify = 0;
            }
            if ($project->save()) {
                return response()->json([
                    'code' => 0,
                    'resume' => $project
                ]);
            } else {
                return response()->json([
                    'code' => -1
                ]);
            }

        }
    }
}