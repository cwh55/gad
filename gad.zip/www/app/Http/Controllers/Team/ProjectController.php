<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 2017/7/13
 * Time: 11:00
 */

namespace App\Http\Controllers\Team;

use App\Gad\Func;
use App\Gad\MessageType;
use App\Jobs\SendMail;
use App\Repositories\HatchProjectRepository;
use App\Repositories\ProjectRepository;
use App\Repositories\ResumeRepository;
use App\Repositories\ProjectJobRepository;
use App\Repositories\ProjectUserRepository;
use App\Repositories\TeamActionRepository;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use Redis;
use Cache;
use Gate;

class ProjectController extends Controller
{
    private $project;
    private $resume;

    public function __construct(
        ResumeRepository $resume,
        ProjectRepository $project,
        ProjectJobRepository $job,
        TeamActionRepository $action,
        HatchProjectRepository $hproject
    ) {
        $this->project = $project;
        $this->resume = $resume;
        $this->job = $job;
        $this->action = $action;
        $this->hproject = $hproject;
        $this->middleware('auth', ['only' => ['postAdd', 'postEdit', 'getAdd', 'getEdit', 'postDel', 'postSignUp' ,'postApply']]);
    }

    /**
     * 简历详情页
     * @param Request $request
     * @param $id
     */
    public function getAdd()
    {
        if (Auth::user()->roles->contains(1)) {
            abort(403);
        }
        $projects = $this->project->where('user_id', '=', Auth::user()['UserId'])->findAll();
        if (count($projects)) {
            return redirect()->guest('/team/my/project#!/info/edit');
        }
        $data = null;
        $step = 1;
        return view('team.project.add', compact('data', 'step'));
    }

    public function postAdd(Request $request)
    {
        if (Auth::user()->roles->contains(1)) {
            abort(403);
        }

        $data = $request->all();
        if (!$this->checkProjectData($data)) {
            return response()->json(array('code' => 1, 'msg' => '数据不完整或不合法'));
        }
        //项目通用信息存储到通用项目表
        $commondata = [
            'created_from' => 4,
            'name' => $data['project']['game_name'],
            'type' => array($data['project']['game_type']),
            'progress' => $data['project']['game_state'],
            'team_num' => $data['project']['member_count'],
            'pictures' => $data['project']['cover'],
            'intro' => $data['project']['intro'],
            'videos' => $data['project']['video'],
            'demo' => $data['project']['demo'],
            'music'=> $data['project']['music'],
            'is_public_demo' =>$data['project']['isPublicDemo']
        ];
        $projectid = $this->hproject->saveProject($commondata, $data['project']['project_id']);
        if (!$projectid) {
            return response()->json(array('code' => 1, 'msg' => '项目注册失败'));
        } else {
            $data['project']['project_id'] = $projectid;
        }
        $jobArr = array("程序"=>0, "策划"=>0, "测试"=>0, "美术"=>0, "音效"=>0, "运营推广"=>0, "其他"=>0);
        $data['project']['user_id'] = Auth::user()['UserId'];

        $jobcities = $jobtypes = '';
        foreach ($data['jobs'] as $job) {
            if ($job['status'] != -1) {
                $jobArr[$job['job_type']] += $job['need_count'];
                $jobcities .= trim($job['work_city'], ',') . ',';
            }
        }
        $data['project']['job_cities'] = implode(',', array_unique(explode(',', trim($jobcities, ','))));

        foreach($jobArr as $key => $num) {
            if ($num) {
                $jobtypes .= $key . $num . '人,';
            }
        }
        $data['project']['job_types'] = trim($jobtypes, ',');
        //过滤不允许更新的字段
        $data['project'] = array_except($data['project'], ['state', 'is_show', 'game_name', 'game_type', 'game_state',
            'member_count', 'cover', 'intro', 'video', 'demo', 'music']);
        $result = $this->project->create($data['project']);

        if ($result[0]) {
            $pid = $result[1]['id'];
            $jobs = $data['jobs'];
            foreach ($jobs as $job) {
                if ($job['status'] != -1) {
                    $job['project_id'] = $pid;
                    $job['work_city'] = trim($job['work_city'], ',');
                    $job['user_id'] = Auth::user()['UserId'];
                    $this->job->create($job);
                }
            }
            $jobs = $this->job->where('project_id', '=',$result[1]['id'])->findAll();
            return response()->json(array('code' => 0, 'msg' => '项目注册成功', 'id' => $pid, 'jobs' => $jobs));
        } else {
            return response()->json(array('code' => 1, 'msg' => '项目注册失败'));
        }
    }

    public function getEdit(Request $request, $id, ProjectUserRepository $prouser)
    {
        $data['project'] = $this->project->find($id);
        $project = $this->hproject->find($data['project']['project_id']);
        if (!$data['project'] || !$project) {
            abort(404);
        }
        if ($data['project']['user_id'] != Auth::user()['UserId'] && !Auth::user()->roles->contains(2)) {
            abort(403);
        }
        //从项目表同步所需信息
        $data['project']['game_name'] = $project['name'];
        $data['project']['game_type'] = count($project['type']) ? $project['type'][0] : '';
        $data['project']['game_state'] = $project['progress'];
        $data['project']['member_count'] = $project['team_num'];
        $data['project']['cover'] = $project['pictures'];
        $data['project']['intro'] = $project['intro'];
        $data['project']['video'] = $project['videos'];
        $data['project']['demo'] = $project['demo'];
        $data['project']['music'] = $project['music'];
        $data['project']['isPublicDemo'] = $project['is_public_demo'];

        $data['jobs'] = $this->job->where('project_id', '=', $id)->findAll();
        $signinfos = $prouser->where('creator', '=', $data['project']['user_id'])->findAll();
        if (count($signinfos)) {
            $data['signinfo'] = $signinfos[0];
            $step = 3;
        } else {
            $data['signinfo'] = [];
            $step = 2;
        }
        if ($request->ajax()) {
            return response()->json([
                'code' => 0,
                'data' => $data
            ]);
        }
        return view('team.project.add', compact('data', 'step'));
    }

    public function postEdit(Request $request,$id)
    {
        $data = $request->all();
        $project = $this->project->find($id);
        if (empty($project)) {
            abort(404);
        }
        if ($project['user_id'] != Auth::user()['UserId'] && !Auth::user()->roles->contains(2)) {
            abort(403);
        }
        if (!$this->checkProjectData($data)) {
            return response()->json(array('code' => 1, 'msg' => '数据不完整或不合法'));
        }
        //项目通用信息存储到通用项目表
        $commondata = [
            'created_from' => 4,
            'name' => $data['project']['game_name'],
            'type' => array($data['project']['game_type']),
            'progress' => $data['project']['game_state'],
            'team_num' => $data['project']['member_count'],
            'pictures' => $data['project']['cover'],
            'intro' => $data['project']['intro'],
            'videos' => $data['project']['video'],
            'demo' => $data['project']['demo'],
            'music'=> $data['project']['music'],
            'is_public_demo' =>$data['project']['isPublicDemo']
        ];
        $projectid = $this->hproject->saveProject($commondata, $project['project_id']);
        if (!$projectid) {
            return response()->json(array('code' => 1, 'msg' => '项目注册失败'));
        } else {
            $data['project']['project_id'] = $projectid;
        }
        $jobArr = array("程序"=>0, "策划"=>0, "测试"=>0, "美术"=>0, "音效"=>0, "运营推广"=>0, "其他"=>0);
        //过滤不允许更新的字段
        $data['project'] = array_except($data['project'],['state', 'is_show', 'game_name', 'game_type', 'game_state',
            'member_count', 'cover', 'intro', 'video', 'demo', 'music']);
        $jobcities = $jobtypes = '';
        foreach ($data['jobs'] as $job) {
            if ($job['status'] != -1) {
                $jobArr[$job['job_type']] += $job['need_count'];
                $jobcities .= trim($job['work_city'], ',') . ',';
            }
        }
        $data['project']['job_cities'] = implode(',', array_unique(explode(',', trim($jobcities, ','))));

        foreach($jobArr as $key => $num) {
            if ($num) {
                $jobtypes .= $key . $num . '人,';
            }
        }
        $data['project']['job_types'] = trim($jobtypes, ',');
        $result = $this->project->update($id, $data['project']);

        if ($result[0]) {
            $pid = $result[1]['id'];
            $jobs = $data['jobs'];
            foreach ($jobs as $job) {
                if (isset($job['id'])) {
                    if ($job['status'] == -1) {
                        $this->job->delete($job['id']);
                    } else {
                        $job['work_city'] = trim($job['work_city'], ',');
                        $this->job->update($job['id'], $job);
                    }
                }else {
                    if ($job['status'] != -1) {
                        $job['project_id'] = $pid;
                        $job['work_city'] = trim($job['work_city'], ',');
                        $job['user_id'] = Auth::user()['UserId'];
                        $this->job->create($job);
                    }
                }
            }
            return response()->json(array('code' => 0, 'msg' => '项目编辑成功', 'id' => $pid));
        } else {
            return response()->json(array('code' => 1, 'msg' => '项目编辑失败'));
        }
    }

    private function checkProjectData ($data)
    {
        $pro = $data['project'];
        $jobs = $data['jobs'];
        if (empty($pro['title']) || empty($pro['game_name']) || empty($pro['game_type']) || empty($pro['game_state'])
            || empty(intval($pro['member_count'])) || empty($pro['intro'])) {
            return false;
        }
        if (!count($pro['cover']) || !count($jobs)) {
            return false;
        }
        foreach ($jobs as $job) {
            if($job['status']!=-1 && (empty($job['job_type']) || empty($job['need_count']) || empty($job['work_type'])
                    || empty($job['work_city']) || empty($job['work_desc']))) {
                return false;
            }
        }
        return true;
    }

    public function postSignUp(Request $request)
    {
        $data = $request->all();
        $validator = [
            'messages'=>[
                'required' => ':attribute 不能为空',
                'digits' => ':attribute 不合法 ',
                'mail' => ':attribute 不合法'
            ],
            'rule' => [
                'phone' => 'required|digits:11',
                'code' => 'required|digits:6',
                'mail' =>'required|email'
            ],
            'attr' => [
                'phone' => '手机号',
                'code' => '验证码',
                'mail' => '邮箱'
            ]
        ];

        $this->validate($request,$validator['rule'],$validator['messages'],$validator['attr']);
        //校验验证码是否正确
        if (!$this->validUserSmsCode($request->input('code'),$request->input('phone'))) {
            return response()->json(
                [
                    'code' => -1,
                    'message' => '验证码不正确'
                ]
            );
        }
        $prouser = new ProjectUserRepository();
        $signinfo = $prouser->where('creator', '=', Auth::user()['UserId'])->findAll();
        $data['creator'] = Auth::user()['UserId'];
        if (count($signinfo)) {
            $ret = $prouser->update($signinfo[0]['id'], $data);
        } else {
            $ret = $prouser->create($data);
        }
        if ($ret[0]) {
            return response()->json(array('code' => 0, 'message' => '注册成功'));
        } else {
            return response()->json(array('code' => -1, 'message' => '注册失败'));
        }
    }

    // 验证短信验证码
    private function validUserSmsCode($code,$phone)
    {
        $isValid = false;
        $user = Auth::user();
        if ($user) {
            $userKey = 'team_register_user_smscode_'.$user->UserId.'_'.$phone;
            $userCode = Redis::get($userKey);
            if ($code == $userCode) {
                $isValid = true;
            }
        }

        return $isValid;
    }

    public function postDel($id)
    {
        $project = $this->project->find($id);
        if(empty($project)) {
            return response()->json(array('code' => -1, 'message' => '项目不存在'));
        }
        if ($project['user_id'] != Auth::user()['UserId'] && !Auth::user()->roles->contains(2)) {
            return response()->json(array('code' => -1, 'message' => '没有权限'));
        }
        $jobs = $this->job->where('project_id', '=', $id)->findAll();
        foreach($jobs as $job) {
            $this->job->delete($job['id']);
        }
        $this->project->delete($id);
        return response()->json(array('code' => 0, 'message' => '删除成功'));
    }

    public function postApply(Request $request)
    {
        $data = array_map('xssFilter', $request->all());
        $userId = Auth::user()['UserId'];
        $hasCreate = $this->action->where('creator', '=', $userId)
            ->where('project_id', '=', $data['project_id'])
            ->where('action_type', '=', 'apply')
            ->findAll()
            ->first();
        if ($hasCreate) {
            return response()->json(array('code' => -1, 'message' => '已发送申请'));
        }

        $project = $this->project->find($data['project_id']);
        $resume = $this->resume->where('user_id', '=', $userId)->findAll()->first();

        if (!$resume) {
            return response()->json(array('code' => -2, 'message' => '简历未创建'));
        }

        $data['resume_user'] = $userId;
        $data['resume_id'] = $resume->id;
        $data['project_id'] = $project->id;
        $data['project_user'] = $project->user_id;
        $data['creator'] = $userId;

        $result = $this->action->create($data);

        if ($result) {
            //发送申请消息
            $resume->apply_notify += 1;
            $resume->save();
            Func::msgApi(
                MessageType::TEAM_RESUME_APPLY_PROJECT,
                $project->user_id,
                $userId,
                $project->id,
                url('/team/my/project#!/apply/' . $project->id . '?ADTAG=meg.boss.fb'),
                '点击这里'
            );
            //发送邮件
            if ($project->projectUser and  $project->projectUser->email != '') {
                dispatch(new SendMail(
                    $project->projectUser->email,
                    '[腾讯GAD]你有一个找人组队需求待处理',
                    sprintf('您好,<br>你收到了一个加入申请，请尽快登录<a href="http://gad.qq.com/team/my/project#!/apply/%d?ADTAG=email.boss.fb">处理</a><br>-腾讯GAD项目组', $project->id)
                ));
            }
            return response()->json(array('code' => 0, 'message' => '发送成功'));
        } else {
            return response()->json(array('code' => -1, 'message' => '发送失败'));
        }

    }
    /**
     * 项目列表页
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse|\Illuminate\Http\Response
     */
    public function getList(Request $request, ResumeRepository $resume)
    {
        $curPage = 'projectList';
        $page = $request->input('page',1);
        $pageSize = $request->input('pagesize',10);
        $worktype = $request->input('worktype');
        $gametype = $request->input('gametype');
        $prostep = $request->input('projectstep');
        $membernum = $request->input('membernum');
        $workcity = $request->input('workcity');
        $projects = $this->project->getList($page, $pageSize, $worktype, $gametype, $prostep, $membernum, $workcity);
        foreach ($projects as $project) {
            $cities = explode(',', $project['job_cities']);
            if (count($cities) > 3) {
                $project->job_cities = implode(',', array_slice($cities, 0, 3)).'...';
            }
            $project->title = mb_substr($project->title, 0, 20).(mb_strlen($project->title) > 20 ? '...' : '');
        }
        if (Auth::check()) {
            $isLogin = 1;
            $myresume = count($resume->where('user_id', '=', Auth::user()['UserId'])->findAll()) ? 1 : 0;
            $myproject = count($this->project->where('user_id', '=', Auth::user()['UserId'])->findAll()) ? 1 : 0;
        } else {
            $myresume = 0;
            $isLogin = 0;
            $myproject = 0;
        }

        if ($request->ajax()) {
            return response()->json([
                'code' => 0,
                'projects' => $projects
            ]);
        } else {
            $allCities = Cache::remember("project_list_all_cities", 10, function () {
                $allProjects = $this->project->where('state', '=', 1)->findAll();
                $citiesArr = [];
                foreach($allProjects as $pro) {
                    $citiesArr = array_merge($citiesArr, explode(',', $pro['job_cities']));
                }
                return array_unique($citiesArr);
            });
            return response()->view('team.project.list',compact('projects', 'myresume', 'isLogin', 'myproject', 'allCities','curPage'));
        }
    }

    public function getMy()
    {
        if (Auth::check()) {
            $projects = $this->project->getProjectsByUserId(Auth::user()->UserId);
            return response()->json([
                'code' => 0,
                'msg' => '成功',
                'projects' => $projects
            ]);
        } else {
            return response()->json([
                'code' => -1,
                'msg' => '未登录'
            ]);
        }
    }

    public function getDetail(Request $request,$id)
    {
        $project = $this->project->find($id);

        if (!$project) {
            Abort(404);
        }
        if($project->state != 1 && Gate::denies('access',$project)){
           abort(404);
        }
        //判断用户是否创建简历，发送了项目申请
        if(Auth::check()){
            $isLogin = 1;
            $userId = Auth::user()['UserId'];
            $resumeSerch = $this->resume->where('user_id', '=', $userId)->findAll()->first();
            if ($resumeSerch) {
                $project->hasResume = TRUE;
                $project->hasApply = (bool)($this->action->where('resume_user', '=', $userId)->where('project_id', '=', $id)->findAll()->first());
            } else {
                $project->hasResume = FALSE;
                $project->hasApply = FALSE;
            }
        }else{
            $isLogin = 0;
        }

        $project->countC = count($project->cover);
        $project->countV = count($project->video);
        return response()->view('team.project.detail', compact('project', 'isLogin'));

    }
}