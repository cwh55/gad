<?php
namespace App\Http\Controllers\Team;

use App\Entities\Resume;
use App\Gad\Func;
use App\Gad\MessageType;
use App\Gad\TofService;
use App\Jobs\SendMail;
use App\Repositories\ProjectRepository;
use App\Repositories\ResumeRepository;
use App\Repositories\TeamActionRepository;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use Redis;

class ResumeController extends Controller
{

    private  $resume;
    private  $project;
    private  $teamAction;

    public function __construct(ResumeRepository $resume,ProjectRepository $project,TeamActionRepository $teamAction)
    {
        $this->resume = $resume;
        $this->project = $project;
        $this->teamAction = $teamAction;
        $this->middleware('auth', ['only' => ['postSave','getAdd','getEdit','postDel','postSms']]);
    }

    public function getIndex(Request $request,$id)
    {
        $resume = $this->resume->find($id);
        if (!$resume) {
            abort(404);
        }
        //是否接受了当前访问人是否可以查看联系方式
        $phoneVisible = $resume->phoneVisible;
        //是否注册项目
        $isCreatedProject = false;

        //判断是否有权限访问
        if (!$resume->allowAccess()) {
            if ($resume->state == 0 and !Auth::check()) {
                return redirect()->guest('login');
            } else {
                abort(404);
            }
        } else {
            if (Auth::check()) {
                $myProjects = $this->project->getProjectsByUserId(Auth::user()->UserId);
                $isCreatedProject = $myProjects? true:false;
            }
            return response()->view('team.resume.index',compact('resume','phoneVisible','isCreatedProject'));
        }

    }

    public function getAdd()
    {
        if(!Auth::check()) {
            return redirect()->guest('login');
        }
        $resume = $this->resume->findBy('user_id',Auth::user()->UserId);
        if ($resume) {
            $resume->addHidden(['created_at','deleted_at','updated_at','step','state','is_top']);
        }
        if ($resume and $resume->step == 4) {
            return redirect('/team/my/resume');
        }
        return response()->view('team.resume.add',compact('resume'));

    }

    //保存简历
    public function postSave(Request $request)
    {
        //去掉不能更新的字段
        $resumeData = $request->except(['state','is_show','deleted_at','is_top']);
        $resumeData['user_id'] = Auth::user()->UserId;
        //步骤1验证规则
        $validatorStep1 = [
            'messages'=>[
                'required' => ':attribute 不能为空',
            ],
            'rule' => [
                'real_name' => 'required',
                'gender' => 'required',
                'education' => 'required',
                'province' =>'required',
                'city'=>'required'
            ],
            'attr' => [
                'real_name' => '姓名',
                'gender' => '性别',
                'education' => '学历',
                'city' => '城市',
                'province' => '省份'
            ]
        ];
        //步骤2验证规则
        $validatorStep2 = [
            'messages'=>[
                'required' => ':attribute 不能为空',
            ],
            'rule' => [
                'career_type' => 'required',
                'work_date' => 'required',
                'intent_city' =>'required',
                'workTypes'=>'required',
                'skill' => 'required',
                'intro' => 'required'
            ],
            'attr' => [
                'career_type' => '职业方向',
                'work_date' => '开始工作时间',
                'intent_city' => '期望工作城市',
                'workTypes' => '期望工作方式',
                'skill' => '擅长技能',
                'intro' => '个人介绍'
            ]
        ];
        //步骤4验证规则
        $validatorStep4 = [
            'messages'=>[
                'required' => ':attribute 不能为空',
                'digits' => ':attribute 不合法 ',
                'email' => ':attribute 不合法'
            ],
            'rule' => [
                'phone' => 'required|digits:11',
                'code' => 'required|digits:6',
                'email' =>'required|email'
            ],
            'attr' => [
                'phone' => '手机号',
                'code' => '验证码',
                'email' => '邮箱'
            ]
        ];
        $resumeData['work_type'] = join(",",$resumeData['workTypes']);
        $resumeData['jobs'] = $this->formatJobs($resumeData['jobs']);
        switch($request->input('step',1)) {
            case 1:
                $this->validate($request,$validatorStep1['rule'],$validatorStep1['messages'],$validatorStep1['attr']);
                break;
            case 2:
                $this->validate($request,$validatorStep1['rule'],$validatorStep1['messages'],$validatorStep1['attr']);
                $this->validate($request,$validatorStep2['rule'],$validatorStep2['messages'],$validatorStep2['attr']);
                break;
            case 3:
                $this->validate($request,$validatorStep1['rule'],$validatorStep1['messages'],$validatorStep1['attr']);
                $this->validate($request,$validatorStep2['rule'],$validatorStep2['messages'],$validatorStep2['attr']);
                break;
            case 4:
                $this->validate($request,$validatorStep1['rule'],$validatorStep1['messages'],$validatorStep1['attr']);
                $this->validate($request,$validatorStep2['rule'],$validatorStep2['messages'],$validatorStep2['attr']);
                $this->validate($request,$validatorStep4['rule'],$validatorStep4['messages'],$validatorStep4['attr']);
                //校验验证码是否正确
                if (!$this->validUserSmsCode($request->input('code'),$request->input('phone'))) {
                    return response()->json(
                        [
                            'code' => -1,
                            'message' => '验证码不正确'
                        ]
                    );
                }
                break;
        }


        $resume = $this->resume->findBy('user_id',Auth::user()->UserId);
        if ($resume) {
            if ($this->resume->update($resume->id,$resumeData)) {
                return response()->json([
                    'code'=>0,
                    'msg'=>'更新成功'
                ]);
            }
        } else {
            if($this->resume->create($resumeData)) {
                return response()->json([
                    'code'=>0,
                    'msg'=>'新建成功'
                ]);
            }
        }

    }

    // 验证短信验证码
    private function validUserSmsCode($code,$phone)
    {
        $isValid = false;
        $user = Auth::user();
        if ($user) {
            $userKey = 'team_register_user_smscode_'.$user->UserId.'_'.$phone;
            $userCode = Redis::get($userKey);
            if ($code == $userCode) {
                $isValid = true;
            }
        }

        return $isValid;
    }

    //邀请加入项目
    public function postInvite(Request $request)
    {
        $user = Auth::user();
        //判断是否邀请过
        $invite = $this->teamAction->where('project_id',$request->input('projectId'))
            ->where('resume_id',$request->input('resumeId'))
            ->where('action_type','invite')->findAll();

        if ($invite->count() > 0) {
            return response()->json([
                'code' => -1,
                'msg' => '已邀请过，请勿重复邀请'
            ]);
        }
        //判断所邀请的简历是否存在
        $resume = $this->resume->find($request->input('resumeId',0));
        if ($resume) {
            //判断是否为自己的项目
            $project = $this->project->find($request->input('projectId',0));
            if (!$project or $project->user_id != $user->UserId) {
                return response()->json([
                    'code' => -1,
                    'msg' => '你的项目不存在'
                ]);
            } else {
                //发起邀请
                $teamAction = $this->teamAction->create(
                    [
                        'project_id' => $project->id,
                        'project_user' => $project->user_id,
                        'resume_id' => $resume->id,
                        'resume_user'=> $resume->user_id,
                        'message' => $request->input('msg'),
                        'action_type' => 'invite',
                        'creator' => $user->UserId
                    ]
                );
                if ($teamAction) {
                    //发送邀请消息
                    $resume->invite_notify +=1;
                    $resume->save();
                    Func::msgApi(
                        MessageType::TEAM_PROJECT_INVITE_RESUME,
                        $resume->user_id,
                        $user->UserId,
                        0,
                        url('/team/my/resume#!/invite?ADTAG=meg.worker.fb'),
                        '点击这里'
                    );
                    //发送邮件
                    if ($resume->email != '') {
                        dispatch(new SendMail(
                            $resume->email,
                            '[腾讯GAD]你有一个找人组队需求待处理',
                            '您好,<br>你收到了一个邀请，请尽快登录<a href="http://gad.qq.com/team/my/resume#!/invite?ADTAG=email.worker.fb">处理</a><br>-腾讯GAD项目组'
                        ));
                    }
                    return response()->json([
                        'code' => 0,
                        'msg' => '已发送邀请'
                    ]);
                } else {
                    return response()->json([
                        'code' => -1,
                        'msg' => '邀请失败'
                    ]);
                }
            }
        } else {
            return response()->json([
                'code' => -1,
                'msg' => '简历不存在'
            ]);
        }
    }

    //发短信
    public function postSms(Request $request)
    {
        $validators = [
            'messages'=>[
                'required' => ':attribute 不能为空',
                'phone.digits' => ':attribute 不合法 '
            ],
            'rule' => [
                'phone' =>'required|digits:11'
            ],
            'attr' => [
                'phone' =>'手机号'
            ]
        ];
        $this->validate($request,$validators['rule'],$validators['messages'],$validators['attr']);
        $phone = $request->input('phone');
        $user = Auth::user();
        $userKey = 'team_register_user_smscode_'.$user->UserId.'_'.$phone;
        $phoneKey = 'team_register_smscode_'.$phone;
        $code = Redis::get($phoneKey);
        if ($code != false) {
            return response()->json([
                'code' => -1,
                'msg' =>'验证码已发送60s不能重复获取'
            ]);
        }

        for ($i =0 ;$i < 6; $i++) {
            $code .= rand(0,9);
        }

        $msg = sprintf("[腾讯GAD]您好，您正在申请入驻GAD游戏开发者平台，验证码为%s，该验证码5分钟内有效。如非本人操作，请勿泄漏。",$code);
        try {
            $ret = TofService::sendSms($phone,$msg);
            if ($ret['code'] == 0) {
                Redis::setex($phoneKey,60,$code);
                Redis::setex($userKey,300,$code);
            }
            return response()->json([
                'code' => 0,
                'msg' =>'验证码已发送'
            ]);

        }
        catch(Exception $e) {
            return response()->json([
                'code' => -1,
                'msg' =>'验证码已发送'
            ]);

        }
    }

    public function getList(Request $request)
    {
        $curPage = 'resumeList';
        $page = $request->input('p',1);
        $orderBy = $request->input('ob','new');
        $city = $request->input('c');
        $workType =$request->input('wt');
        $careerType = $request->input('ct');
        $workAge = $request->input('wa');
        $education = $request->input('e');
        $pageSize = 10;
        $resumes = $this->resume->getList($page,$pageSize,$city,$workType,$careerType,$workAge,$education,$orderBy);
        $resumeIds = collect([]);
        if (Auth::check()) {
            $resumeIds = $this->teamAction->getMyAccessResumeIds(Auth::user()->UserId);
        }

        $resumes->each(function($item)use($resumeIds){
                $item->displayname = $item->nickname;
                $item->displayphoto = $item->nickphoto;
                if ($resumeIds->contains('resume_id',$item->id)) {
                    $item->displayname = $item->real_name;
                    $item->displayphoto = $item->photo;
                }
            $item->addHidden(['real_name','photo']);

        });
        $cities = $this->resume->getCities();
        $isCreatedProject = false;
        if (Auth::check()) {
            $myProjects = $this->project->getProjectsByUserId(Auth::user()->UserId);
            $isCreatedProject = $myProjects->count()>0? true:false;
        }
        if ($request->ajax()) {
            return response()->json([
                'code' => 0,
                'resumes' => $resumes,
                'hasMore' => $resumes->hasMorePages()
            ]);
        } else {
            return view('team.resume.list',compact('resumes','cities','isCreatedProject','curPage'));
        }
    }

    public function formatJobs($jobs)
    {
        $list = [];
        foreach($jobs as $item) {
            if(
                $item['company'] != ''
                or $item['position'] != ''
                or $item['begin_date'] != ''
                or $item['end_date'] != ''
                or $item['work'] != ''
            ) {
                $list[] = $item;
            }
        }
        return $list;
    }
}