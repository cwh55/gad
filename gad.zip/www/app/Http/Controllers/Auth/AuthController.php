<?php

namespace App\Http\Controllers\Auth;

use App\Gad\Weixin;
use App\Http\Controllers\Controller;
use App\Models\User;
use Auth;
use Cookie;
use Illuminate\Support\Str;
use Tencent\CL5\Client as CL5;
use Exception;
use GuzzleHttp\Client;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use Illuminate\Http\Request;
use Validator;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware($this->guestMiddleware(), ['except' => 'logout']);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|min:6|confirmed',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
    }

    public function getLogin(Request $request)
    {
        if (Str::contains($request->header('user-agent'), 'MicroMessenger')) {
            $host = app()->isLocal() ? 'dev.m.gad.qq.com' : 'm.gad.qq.com';

            return redirect(Weixin::redirect(url('http://'.$host.'/auth/weixin')));
        }

        $query = http_build_query([
            'platformId' => config('tgd.id'),
            'backUrl' => url('/auth/callback')
        ]);

        return redirect(config('tgd.url').'/auth/login?'.$query);
    }

    public function getCallback(Request $request)
    {
        $token = $request->get('token');
        $tgd = config('tgd');
        $sig = md5($token.$tgd['secret']);
        $query = [
            'platformId' => $tgd['id'],
            'token' => $request->get('token'),
            'sig' => $sig
        ];

        $config = [
            'modId' => $tgd['cl5_mod_Id'],
            'cmdId' => $tgd['cl5_cmd_Id'],
            'default' => ['hostIp' => '10.123.20.93', 'hostPort' => 80]
        ];
        $server = CL5::getRoute($config, app()->isLocal());
        $url = sprintf('http://%s:%s/token', $server['hostIp'], $server['hostPort']);

        $client = new Client(['timeout' => 3]);
        $response = $client->request('GET', $url, ['query' => $query]);
        if ($response->getStatusCode() != 200) {
            throw new Exception('TGD接口请求失败：'.$response->getReasonPhrase());
        }
        $body = $response->getBody();
        $result = json_decode($body, true);
        if ($result === null) {
            throw new Exception('TGD接口请求失败：'.$body);
        }

        if (array_get($result, 'code')) {
            throw new Exception('TGD接口返回异常：'.$result['message']);
        }

        $user = User::where($result['source'] == 'qq' ? 'QQNo' : 'WeixinId', $result['uid'])->first();
        $request->setTrustedProxies([$request->server('REMOTE_ADDR')]);
        if (is_null($user)) {
            $userData = [
                'NickName' => $result['nickname'],
                'Avatar' => $result['head_img_url'],
                'ip' => $request->ip(),
                'Created' => date('Y-m-d h:i:s'),
                'Modified' => date('Y-m-d h:i:s')
            ];
            if ($result['source'] == 'qq') {
                $userData['QQNo'] = $result['uid'];
            } else {
                $userData['WeixinId'] = $result['uid'];
            }

            $user = User::create($userData);
        } else {
            $user->ip = $request->ip();
            $user->save();
        }

        Auth::login($user);
        $cookie = Cookie::make('isLogined', '1', 120, null, null, false, false);
        session(['loginType' => $result['source']]);
        if ($result['source'] == 'weixin') {
            session(['openId' => $result['open_id'], 'accessToken' => $result['access_token']]);
        }

        if ($request->has('frame')) {
            return response('<script>document.domain="qq.com";top.gad.hideLogin();top.location.reload();</script>')->cookie($cookie);
        }

        return redirect()->intended()->cookie($cookie);
    }

    public function getWeixin(Request $request)
    {
        $host = app()->isLocal() ? 'dev.m.gad.qq.com' : 'm.gad.qq.com';
        if (!$request->has('code')) {
            return redirect(Weixin::redirect(url('http://'.$host.'/auth/weixin')));
        }

        $code = $request->get('code');
        $state = $request->get('state');
        try {
            $userInfo = Weixin::getUserInfoByCode($code, $state, true);
        } catch (Exception $e) {
            return redirect(Weixin::redirect(url('http://'.$host.'/auth/weixin'), 'snsapi_userinfo', 'user'));
        }

        $request->setTrustedProxies([$request->server('REMOTE_ADDR')]);
        $user = User::where('WeixinId', $userInfo->unionid)->first();
        if ($user) {
            $user->ip = $request->ip();
            $user->save();
            Auth::login($user);

            return redirect()->intended();
        }

        if ($userInfo->unionid AND ($state == 'user' OR $userInfo->subscribe)) {
            $user = User::create([
                'WeixinId' => $userInfo->unionid,
                'NickName' => $userInfo->nickname,
                'Avatar' => $userInfo->headimgurl,
                'ip' => $request->ip(),
                'Created' => date('Y-m-d H:i:s'),
                'Modified' => date('Y-m-d H:i:s')
            ]);
            Auth::login($user);

            return redirect()->intended();
        }

        return redirect(Weixin::redirect(url('http://'.$host.'/auth/weixin'), 'snsapi_userinfo', 'user'));
    }

    public function getLogout(Request $request)
    {
        Auth::logout();
        session()->flush();
        $backUrl = url()->previous();
        $url = sprintf('%s/auth/logout?backUrl=%s', config('tgd.url'), rawurlencode($backUrl));

        return redirect($url)->cookie(Cookie::forget('isLogined'));
    }
}
