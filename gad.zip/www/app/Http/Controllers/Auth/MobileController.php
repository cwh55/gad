<?php

namespace App\Http\Controllers\Auth;

use App\Gad\Weixin;
use App\Http\Controllers\Controller;
use App\Models\User;
use Auth;
use Illuminate\Support\Str;
use Exception;
use Illuminate\Http\Request;
use Tencent\Ptlogin\Ptlogin;

class MobileController extends Controller
{
    public function getIndex(Request $request)
    {
        return redirect('auth/mobile/login');
    }

    public function getLogin(Request $request)
    {
        if (Str::contains($request->header('user-agent'), 'MicroMessenger')) {
            return redirect(Weixin::redirect(url('auth/mobile/weixin')));
        }

        return Ptlogin::redirect(url('auth/mobile/qq'), ['style' => 9]);
    }

    public function getQq(Request $request)
    {
        $uin = intval(str_replace('o', '', $request->cookie('uin')));
        $sKey = $request->cookie('skey');
        if ($uin AND $sKey AND Ptlogin::check($uin, $sKey)) {
            $user = User::where('QQNo', $uin)->first();
            if ($user) {
                Auth::login($user);
                Request::setTrustedProxies([$request->server('REMOTE_ADDR')]);
                $user->ip = $request->ip();
                $user->save();

                return redirect('/#/login');
            }
        }

        return redirect('auth/mobile/login');
    }

    public function getWeixin(Request $request)
    {
        $url = url('auth/mobile/weixin');
        if (!$request->has('code')) {
            return redirect(Weixin::redirect($url));
        }

        $code = $request->get('code');
        $userInfo = Weixin::getUserInfoByCode($code, 'snsapi_userinfo', true);
        $request->setTrustedProxies([$request->server('REMOTE_ADDR')]);
        $user = User::where('WeixinId', $userInfo->unionid)->first();
        if ($user) {
            $user->ip = $request->ip();
            $user->save();
        } else {
            $user = User::create([
                'WeixinId' => $userInfo->unionid,
                'NickName' => $userInfo->nickname,
                'Avatar' => $userInfo->headimgurl,
                'ip' => $request->ip(),
                'Created' => date('Y-m-d H:i:s'),
                'Modified' => date('Y-m-d H:i:s')
            ]);
        }

        Auth::login($user);

        return redirect('/#/login');
    }

    public function getUser(Request $request)
    {
       if ($user = Auth::user()) {
           return response()->json($user);
       }

        return redirect('auth/mobile/login');
    }

    public function getLogout(Request $request)
    {
        Auth::logout();

        return redirect('/');
    }
}
