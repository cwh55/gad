<?php

namespace App\Http\Controllers\Article;
use App\Gad\Lib_Func;
use App\Models\Article;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Summercourse;
use App\Models\Classify;
use App\Models\KeyValue;
use App\Models\Register;
use Cache;
use Illuminate\Http\Request;
use App\Gad\Upload;
use App\Gad\Func;
use Auth;
use Gate;
use Illuminate\Routing\Route;

class ArticleController extends Controller
{

    public function __construct(Request $request){
        if($request->is('article/edit*')){
            if(isset($request->id) && ($id = $request->id) >= 1){
                $article = Article::find($id);
                $user_id = $article->user_id;
                $this->middleware("acl:article::edit,user_id=".$user_id, ['only' => ['getEdit','postEdit']]);
            }
        }
    }

    public function getIndex($id)
    {
        return redirect()->route('article::detail');
    }
    public function getDetail($id)
    {
        $article = Article::findOrFail($id);
		if($article->status >= 1){
			$msg = [1=>"请等待审核",2=>"审核不通过"];
			return view('errors.msg',['message'=>$msg[$article->status]]);
		} else if($article->status != 0){
			abort(404);
		}
        $author = $article->user;
		$au = Register::where('user_id',$author->UserId)->first();
		if($au && $au['company']){
			$author->NickName = $au['company'];
		}
        $article->Liked = $article->is_liked;
        $article->Favored = $article->is_favored;
        $article->labels = explode(',',$article->label);
        $classify = $article->classify;
        $article->className = $classify != null ? $classify ->class_name :'';
        //更新浏览数
        $article->increment('view_cnt',1);
        //获取预览文档
        $previewDocs = [];
        $attachments = [];
        if ($article->attachments) {
            $previewDocs = Func::getPreviewDocs($article->attachments);
            $attachments = \GuzzleHttp\json_decode($article->attachments,true);
        }
		$hatchId = 1201;
		$nav = [];
		if($article->class_id != $hatchId){
			$nav[] = ["/summercamp/index","暑期训练营"];
			$nav[] = ["/summercamp/index#/works","作业"];
		} else {
			$nav[] = ["/","首页"];
			$nav[] = ["/hatch","项目扶持"];
		}

        return view('article.detail',compact('article','author','previewDocs','attachments','nav'));
    }

	public function getList(Request $request, $classId, $pagesize=12, $orderby=1){
		$class_id = intval($classId);
		$classes = array();
		$class = Classify::getClass($class_id);//判断有没有这个分类
		if(empty($class)){
			abort(404);return;
		}
		$layer = $class->layer;
		$pid = $class_id;
		$data['worktype'] = '0';
		if($layer == Classify::MODULE_LAYER){
			$classes = Classify::getClasses($pid,false);//分类
			if(isset($classes[0])){//默认第一个分类
				//$class_id = $classes[0]->class_id;
				$data["worktype"] = $classes[0]->type;
			}
		} else if($layer == Classify::CLASS_LAYER){
			$data["worktype"] = $class->type;
			$classes = Classify::getClasses($class->parent,false);
			$class = $class->parentClass;
		} else {
			abort(404);return;
		}
		$param['class_id'] = $class_id;
		$param['orderby'] = intval($orderby);
		$param['page'] = intval($request->input("page", 0));
		$param['pagesize'] = intval($pagesize) > 100 ? 12 : intval($pagesize);
		$data = array_merge($data, $param);
		//文章列表
		$key = 'article_list_1_'.$param["class_id"].'_'.$param["orderby"].'_'.$param["page"].'_'.$param['pagesize'];
		$data["data"] = Cache::remember($key, 20, function() use ($param){
			return Article::articles($param)->paginate($param['pagesize']);
		});
		if($request->input("_display") == "json"){//输出json
			return response()->json($data);
		}
		$data['class'] = $class;
		$data['classes'] = $classes;
		$hatchId = 1201;
		$nav = [];
		if($classId == $hatchId){
			$nav[] = ["/hatch","项目扶持"];
		}
		$data["nav"] = $nav;
		$recommend = KeyValue::find('new_hatch_detail');
		$data['recommend'] = json_decode($recommend['Value'], true);
		$summercourse = new Summercourse();
		$data['hastrue'] = $summercourse->getWhitelist(1201) || (Auth::user() ? Auth::user()->roles->contains(2) : false);
		
		return view("article.list", $data);		
	}

    public function getCreate(Request $request)
    {
		$classid = $request->input("classid");

        $article = new Article();

        return view('article.edit', compact('article','classid'));
    }

    public function postCreate(Request $request)
    {

        $articleData = $request->all();
        $article = new Article;
        $fields = [
            ['key' => 'class_id', 'name' => '分类', 'rule' => 'required|between:1,10000000'],
            ['key' => 'title', 'name' => '文章名称', 'rule' => 'required'],
            ['key' => 'content', 'name' => '文章内容', 'rule' => 'required'],
            ['key' => 'label', 'name' => '文章标签', 'rule' => 'required'],
        ];
        $validator  = [
            'rule' => [],
            'messages' => [
                'required' => ':attribute 不能为空'.json_encode($articleData),
                'between' => ':attribute 错误'
            ],
            'attr' => []
        ];
        foreach ($fields as $field) {
            $validator['rule'][$field['key']] = $field['rule'];
            $validator['attr'][$field['key']] = $field['name'];
        }
        $this->validate($request, $validator['rule'], $validator['messages'], $validator['attr']);
        $summercourse = new Summercourse();
        $class_id = $request->input('class_id');
		if($class_id == 1201 && !$summercourse->getWhitelist(1201) && !Auth::user()->roles->contains(2)){
			return response()->json(['code' => -2,'message' => '您没有权限!']);
		}
        if($class_id != 1201 && !$summercourse->getWhitelist(intval($class_id/100))){
            return response()->json(['code' => -2, 'message' => '您没有创建此分类作业的权限']);
        }
        //富文本过滤
        $articleData['content'] = xssFilter($articleData['content']);
        $article->user_id = Auth::user()->UserId;
        $article->name = Auth::user()->NickName;
        $article->fill($articleData);
        $article->channel_id = intval($class_id/10000);
        $article->description = strip_tags($article->content);
		if($class_id == 1201 && !Auth::user()->roles->contains(2)){
			$article->channel_id = intval($class_id/100);
			$article->status = 1;
		}
        $article->attachments = json_encode($article->attachments);
        $article->save();
        return  response()->json(['code' => $article->id, 'message' => '上传成功']);
    }

    public function getEdit(Request $request,$id)
    {
        $article = Article::findOrFail($id);
        return view('article.edit', compact('article'));
    }

    public function postEdit(Request $request,$id)
    {
        $article = Article::findOrFail($id);
        $articleData = $request->all();
        if(!empty($articleData['class_id']))
            response()->json(['code' => -1, 'message' => '不允许的分类传值']);

        $fields = [
            ['key' => 'title', 'name' => '文章名称', 'rule' => 'required'],
            ['key' => 'content', 'name' => '文章内容', 'rule' => 'required'],
            ['key' => 'label', 'name' => '文章标签', 'rule' => 'required'],
        ];
        $validator  = [
            'rule' => [],
            'messages' => [
                'required' => ':attribute 不能为空',
                'title.max' => '分享名称不能超过20个字'
            ],
            'attr' => []
        ];
		$class_id = $article->class_id;
		$article->status = $class_id == 1201 ? 1 : $article->status;
        foreach ($fields as $field) {
            $validator['rule'][$field['key']] = $field['rule'];
            $validator['attr'][$field['key']] = $field['name'];
        }
        $this->validate($request, $validator['rule'], $validator['messages'], $validator['attr']);
        //富文本过滤
        $articleData['content'] = xssFilter($articleData['content']);
        $article->fill($articleData);
        $article->description = strip_tags($article->content);
        $article->attachments = json_encode($article->attachments);
        $article->save();
        return  response()->json(['code' => $article->id, 'message' => '修改成功']);
    }

    public function postEditorUploadImage(Request $request)
    {
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        $file = $request->file('Filedata');
        if($file->getSize() > 10*1024*1024) {
            return response('<script>alert("图片上传出错：最大上传大小10M");</script>');
        }
        if (!$file->isValid()) {
            return response('<script>alert("图片上传出错");</script>');
        }

        $result = Upload::uploadQcloudImage($file);
        if ($result['code'] == 0) {
            return response($result['data']['downloadUrl']);
        } else {
            return response('<script>alert("图片上传出错：'.$result['message'].'");</script>');
        }
    }
    public function postUploadAttachment(Request $request)
    {
        $file = $request->file('file');

        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }
        $size = round($file->getSize()/1024/1024,2)."M";
        $result = Upload::uploadQcloudCos('article', $file);
        if ($result['code'] == 0) {
            $fileExt = strtolower($file->getClientOriginalExtension());
            if (in_array($fileExt,['ppt','pptx','pdf'])) {
                $previewUrl = Upload::getPreviewDoc($result);
                $header = get_headers(str_replace("#page#","1",$previewUrl["url"]), 1);
                $page = intval($header["User-ReturnCode"]);
                if($page <=0){
                    $page = 1;
                }
                $result['data']['access_url'] .= '?newd='.urlencode($previewUrl["url"].";".$page);
            }
            return response()->json(['code' => 0, 'url' => $result['data']['access_url'],'size' =>$size]);
        } else {
            return response()->json(['code' => 1, 'message' => '附件上传出错']);
        }
    }
}
