<?php

namespace App\Http\Controllers\Game;

use App\Entities\Archive;
use App\Gad\MessageType;
use App\Jobs\SendMessage;
use App\Repositories\AtlasRepository;
use App\Repositories\FollowRepository;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Repositories\LiveRepositoryEloquent;
use App\Repositories\ArchiveRepository;
use Auth;
use Gate;
use DB;

class GameController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
        
    public function getPictureEdit(Request $request,\App\Repositories\ArchiveRepository $archive, $id = 0)
    {
        if ($id){
            $atlas = $archive->find($id);
            if (Gate::denies('edit', $atlas)) {
                abort(403);
            }
            $activityId = $atlas->hot_aid;
            return view('game.picture_edit', compact('atlas', 'id', 'activityId'));
        } else {
            if (Gate::denies('create', $archive->createModel())) {
                abort(403);
            }
            $activityId = $request->input('activityId');
            $archives = $archive->with(['atlas'])->where('hot_aid', $activityId)->where('user_id', Auth::user()->UserId)->where('class_id', 2)->where('ccid', '>', 0)->findAll();
            if (count($archives) > 0) {
                return redirect('/resource/detail/' . $archives[0]->id);
            }
            return view('game.picture_edit', compact('id', 'activityId'));
        }
    }

    public function getEdit(Request $request,\App\Repositories\ArchiveRepository $archive){
        $activityId = $request->input('activityId');
        $archives = $archive->with(['atlas'])->where('hot_aid', $activityId)->where('user_id', Auth::user()->UserId)->where('class_id', 2)->where('ccid', '>', 0)->findAll();
        if (count($archives) > 0) {
            return redirect('/resource/detail/' . $archives[0]->id);
        }
        return redirect('/resource/list?activityId=' . $request->input('activityId'));
    }

    public function getArticleEdit(Request $request, \App\Repositories\ArchiveRepository $archive, $id = 0){
        $id = intval($id);
        if($id){
            $detail = $archive->with(['article', 'user'])->find($id);
            if(!\App\Models\User::judgeEditRight(Auth::user(), $detail['user_id'])){
                throw new \Exception('你没有权限修改这篇文章');
            }
            $detail->showTags = $detail->tag ? explode(',', $detail->tag) : [];
			$activityId = $detail->hot_aid;
        }else{
            $detail = $archive->with(['article', 'user'])->where([['class_id', '=', 1], ['user_id', '=', Auth::user()->UserId], ['status', '=', 1]])->findAll()->first();
            if($detail){
                $detail->showTags = $detail->tag ? explode(',', $detail->tag) : [];
            }
			$activityId = $request->input('activityId');
        }
        return view('game.article_edit', compact('detail','activityId'));
    }
    
    public function postArticleSave(Request $request,\App\Repositories\ArchiveRepository $archive, \App\Repositories\ArticleRepository $article, \App\Repositories\TagRepository $tagRepository)
    {
        $this->validate($request, [
            'title' => 'required',
            'article' => 'required|array',
            'activityId' => 'required'
        ]);
        $activityId = $request->input('activityId');
        $input = $this->gatherInput($request->all(), $tagRepository);
        if (Gate::allows('verify', $archive->createModel()) && $input['archive']['status'] == 2) {
            $input['archive']['status'] = 0;
        }
        $id = $input['id'];
        if (\App\Gad\Func::hasBadWord($id, $input['article']['content'], $input['archive']['description'], $input['archive']['title'])) {
            return response()->json(['code' => -1, 'message' => '非法内容']);
        }
        if ($id > 0) {
            $articleInfo = $archive->with(['article'])->find($id);
            if (!\App\Models\User::judgeEditRight(Auth::user(), $articleInfo['user_id'])) {
                throw new \Exception('你没有权限修改这篇文章');
            }
            $oldCC = DB::table('ContentClass')->where('Id', $articleInfo->ccid)->first();
            if ($oldCC) {
                $status = $input['archive']['status'] > 0 ? 2 : 0;
                $oldInput = [
                    'Title' => $input['archive']['title'],
                    'Summary' => $input['archive']['description'],
                    'HtmlDetail' => $input['article']['content'],
                    'RowStatus' => $status,
                    'CoverImage' => $input['archive']['cover'],
                    'Modifier' => Auth::user()->UserId
                ];
                DB::table('ContentClass')->where('Id', $oldCC->Id)->update(['RowStatus' => $status]);
                DB::table('Content')->where('ContentId', $oldCC->ContentId)->update(
                    $oldInput);
            }
            list($status, $temp) = $archive->update($id, $input['archive']);
            if (!$status) {
                throw new \Exception('更新数据失败');
            }
            list($status, $temp) = $article->update($articleInfo->article->id, $input['article']);
            if (!$status) {
                throw new \Exception('更新数据失败');
            }

            $archive->addTags($articleInfo, $input['tags']);
        } else {
            if (Gate::denies('reply', $archive->createModel())) {
                return abort(403, '你无法发表文章');
            }
            if ($archive->findWhere(['title', $input['archive']['title']])->count() >= 1) {
                throw new \Exception('标题已存在，请修改后重新提交');
            }
            $oldInput = [
                'Title' => $input['archive']['title'],
                'Summary' => $input['archive']['description'],
                'HtmlDetail' => $input['article']['content'],
                'RowStatus' => $input['archive']['status'] > 0 ? 2 : 0,
                'CoverImage' => $input['archive']['cover'],
                'Creator' => Auth::user()->UserId,
                'ShowType' => 1,
                'Created' => date('Y-m-d H:i:s'),
                'Author' => Auth::user()->UserId,
            ];
            $oldCId = DB::table('Content')->insertGetId(
                $oldInput
            );
            $oldCCId = DB::table('ContentClass')->insertGetId([
                'ContentId' => $oldCId, 'RowStatus' => $input['archive']['status'] > 0 ? 2 : 0, 'Modified' => date('Y-m-d H:i:s'),
                'ClassLv1' => 1, 'Modifier' => Auth::user()->UserId, 'Created' => date('Y-m-d H:i:s')
            ]);
            DB::table('ActivityWorks')->insert([
                'WorksType' => 1,
                'WorksFormat' => 1,
                'ActivityId' => $activityId,
                'WorksId' => $oldCId,
                'Creator' => Auth::user()->UserId,
                'ContentClassId' => $oldCCId
            ]);
            $input['archive']['ccid'] = $oldCCId;
            $input['archive']['hot_aid'] = $activityId;
            list($status, $insertInfo) = $archive->create($input['archive']);
            if (!$status) {
                throw new \Exception('更新数据失败');
            }
            $id = $input['article']['archive_id'] = $insertInfo->id;
            list($status, $temp) = $article->create($input['article']);
            if (!$status) {
                throw new \Exception('更新数据失败');
            }
            $archive->addTags($insertInfo, $input['tags']);
        }
        return response()->json(array('code' => 0, 'data' => $id));
    }

    public function postPictureSave(Request $request, \App\Repositories\ArchiveRepository $archive, \App\Repositories\PictureRepository $pic, \App\Repositories\TagRepository $tagRepository, AtlasRepository $atlasRepository)
    {
        $data = $request->all();
        $activityId = $data['activityId'];
        $city = $data['city'];
        $classType = $data['classType'];
        if ($activityId <= 0) {
            return response()->json(['code' => -1, 'message' => 'activityId err']);
        }
        $data = array_map('xssFilter', $data);
        $id = intval($data['id']);
        $tags = !empty($data['archive']['tags']) ? explode(',', $data['archive']['tags']) : [];
        $content = '';
        if (!empty($data['piclist'])) {
            foreach ($data['piclist'] as $picture) {
                $content = $content . $picture['content'];
            }
        }
        if (\App\Gad\Func::hasBadWord($id, $content, '', '')) {
            return response()->json(['code' => -1, 'message' => '非法内容']);
        }
        if (empty($tags)) { //优先采用用户标签，若用户没有输入标签，则根据内容计算
            $tags = $tagRepository->findFromTitleContent($data['archive']['title'], $content);
            $tagsinput = implode(',', array_column($tags->slice(0, 6)->toArray(), 'name'));
        } else {
            $tags = $tagRepository->whereIn('name', $tags)->findAll();
            $tagsinput = $data['archive']['tags'];
        }
        $status = intval($data['status']) == 1 ? 1 : 2;
        if ($status == 2) {
            $msg = '发表成功';
        } else {
            $msg = '保存成功';
        }
        if (!in_array($status, array(1, 2))) {
            $status = 2;
        }
        $data['atlas']['match_qq'] = intval($data['atlas']['match_qq']);
        if ($id) {  //更新图集
            $atlas = $archive->with(['pictures'])->find($id);
            $atlasInfo = $atlasRepository->findWhere(['archive_id', '=', $atlas->id])->first();
            if ($atlas) {
                if (Gate::denies('edit', $atlas)) {
                    return response()->json(array('code' => 2, 'message' => '没有权限修改'));
                }
                if ($status == 2) { //白名单判断
                    $status = Gate::allows('verify', $archive->createModel()) ? 0 : 2;
                }
                $ids = array_column($atlas->pictures->toArray(), 'id');
                $pictures = $pic->savePicturesNew($data, $ids, $status);
                $this->updateActivityWorks($data, $atlas->ccid, $status);
                $params = [
                    'title' => $data['archive']['title'],
                    'tag' => $tagsinput,
                    'description' => $data['archive']['description'],
                    'total' => count($pictures),
                    'status' => $status,
                    'extra' => array_slice($pictures, 0, 3)
                ];
                if ($atlas->status == 1 && $status != 1 && $atlas->publish_time == '0000-00-00 00:00:00') {
                    $params['publish_time'] = date("Y-m-d H:i:s");
                }
                if (!empty($pictures)) {
                    //更新主表的信息
                    $result = $archive->update($id, $params);
                    if ($result[0]) {
                        $atlasParams = [
                            'rights' => $data['atlas']['rights'],
                            'from_type' => $data['atlas']['from_type'],
                            'type' => $data['atlas']['type'], //佳作or点评
                            'attachments' => $data['atlas']['attachments'],
                            'city' => $city,
                            'match_qq' => $data['atlas']['match_qq']
                        ];
                        $result2 = $atlasRepository->update($atlasInfo->id, $atlasParams);
                        if (!$result2[0]) {
                            return response()->json(array('code' => 1, 'message' => '图片保存失败'));
                        }
                        $archive->addTags($atlas, $tags);
                        return response()->json(array('code' => 0, 'message' => $msg, 'id' => $result[1]['id']));
                    } else {
                        return response()->json(array('code' => 1, 'message' => '图集信息保存失败'));
                    }
                } else {
                    return response()->json(array('code' => 1, 'message' => '图片保存失败'));
                }
            } else {
                return response()->json(array('code' => 1, 'msg' => '图集不存在'));
            }
        } else {    //添加
            if (Gate::denies('create', $archive->createModel())) {
                return response()->json(array('code' => 1, 'message' => '您没有权限创建'));
            }
            if ($status == 2) { //白名单判断
                $status = Gate::allows('verify', $archive->createModel()) ? 0 : 2;
            }
            $ccId = $this->addActivityWorks($data, $status, $activityId, $city, $classType);
            $result = $archive->create([
                'title' => $data['archive']['title'],
                'description' => $data['archive']['description'],
                'status' => $status,
                'channel_id' => 2,
                'class_id' => Archive::TYPE_WORKS,
                'user_id' => Auth::user()['UserId'],
                'user_name' => Auth::user()['NickName'],
                'creator' => Auth::user()['UserId'],
                'tag' => $tagsinput,
                'sort_time' => time(),
                'publish_time' => date("Y-m-d H:i:s"),
                'ccid' => $ccId,
                'hot_aid' => $activityId
            ]);
            if ($result[0]) {
                $data['id'] = $result[1]['id'];
                $atlasParams = [
                    'archive_id' => $data['id'],
                    'rights' => $data['atlas']['rights'],
                    'from_type' => $data['atlas']['from_type'],
                    'type' => $data['atlas']['type'], //佳作or点评
                    'attachments' => $data['atlas']['attachments'],
                    'city' => $data['city'],
                    'match_qq' => $data['atlas']['match_qq']
                ];
                $result2 = $atlasRepository->create($atlasParams);
                if (!$result2[0]) {
                    return response()->json(array('code' => 1, 'message' => '图片保存失败'));
                }
                $pictures = $pic->savePicturesNew($data, [], $status);
                if (!empty($pictures)) {
                    $archive->update($data['id'], ['total' => count($pictures), 'extra' => array_slice($pictures, 0, 3)]);
                    $follow = new FollowRepository();
                    $followers = $follow->getFans(Auth::user()->UserId)->pluck('user_id')->toArray();
                    if ($status == 0) {
                        $this->dispatch(new SendMessage(
                            MessageType::WORK_NEW,
                            $followers,
                            Auth::user()->UserId,
                            $data['id'],
                            url('/resource/detail', $data['id']),
                            $data['archive']['title']
                        ));
                    }
                    return response()->json(array('code' => 0, 'message' => $msg, 'id' => $result[1]['id']));
                } else {
                    return response()->json(array('code' => 1, 'message' => '图片保存失败'));
                }
            } else {
                return response()->json(array('code' => 1, 'message' => '图集信息保存失败'));
            }
        }
    }

    public function addActivityWorks($data,$status,$activityId,$city,$classType)
    {
        $cId = DB::table('Content')->insertGetId([
            'Title' => $data['archive']['title'],
            'HtmlDetail' => $data['archive']['description'],
            'Summary' => strip_tags($data['archive']['description']),
            'RowStatus' => $status > 0 ? 2 : 0,
            'Creator' => Auth::user()->UserId,
            'Created' => date('Y-m-d H:i:s'),
            'CoverImage' => $data['piclist'][0]['url'],
            'ShowType' => 8,
            'Author' => Auth::user()->UserId
        ]);
        $ccId = DB::table('ContentClass')->insertGetId([
            'ContentId' => $cId,
            'RowStatus' => $status > 0 ? 2 : 0,
            'Creator' => Auth::user()->UserId,
            'ClassLV1' => 1,
            'Created' => date('Y-m-d H:i:s'),
        ]);
        DB::table('ActivityWorks')->insert([
            'WorksType' => 2,
            'WorksFormat' => 2,
            'WorksId' => $cId,
            'ContentClassId' => $ccId,
            'ActivityId' => $activityId,
            'City' => $city,
            'ClassType' => $classType
        ]);
        return $ccId;
    }

    public function updateActivityWorks($data,$ccid,$status){
        $ccId = DB::table('ContentClass')->where('Id', $ccid)->first();
        if ($ccId) {
            DB::table('Content')->where('ContentId', $ccId->ContentId)->update([
                'RowStatus' => $status > 0 ? 2 : 0,
                'CoverImage' => $data['piclist'][0]['url'],
                'Modifier' => Auth::user()->UserId,
                'HtmlDetail' => $data['archive']['description'],
                'Summary' => strip_tags($data['archive']['description']),
                'Title' => $data['archive']['title']
            ]);
            DB::table('ContentClass')->where('Id', $ccid)->update(['RowStatus' => $status > 0 ? 2 : 0]);
        }
    }

    public function postArticleDelete(Request $request, \App\Repositories\ArchiveRepository $archive){
        $id = intval($request->input('id'));
        if(!Auth::check()){
            return response()->json(['code' => 1, 'msg' => '未登录']);
        }
        $articleInfo = $archive->find($id, ['user_id','ccid']);
        if(!\App\Models\User::judgeEditRight(Auth::user(), $articleInfo['user_id'])){
            throw new \Exception('你没有权限修改这篇文章');
        }
		$ccId = DB::table('ContentClass')->where('Id',$articleInfo->ccid)->first();
		if($ccId){
			DB::table('ContentClass')->where('Id',$articleInfo->ccid)->update(['RowStatus' => -1]);
			DB::table('Content')->where('ContentId',$ccId->ContentId)->update(['RowStatus' => -1]);
		}
        $archive->delete($id);
        return response()->json(['code' => 0]);
	}
    
    public function postPictureDelete(Request $request, \App\Repositories\ArchiveRepository $archive, \App\Repositories\PictureRepository $picture){
        $id = intval($request->input('id'));
        $atlas = null;
        if ($id) {
            $atlas = $archive->with(['tags', 'user', 'pictures'])->find($id);
        }
        if (!empty($atlas) && Gate::allows('edit', $atlas)) {
            foreach ($atlas->pictures as $onepicture) {
                $picture->delete($onepicture['id']);
            }
            $archive->removeTags($atlas);
			$ccId = DB::table('ContentClass')->where('Id',$atlas->ccid)->first();
			if($ccId){
				DB::table('ContentClass')->where('Id',$atlas->ccid)->update(['RowStatus'=>-1]);
				DB::table('Content')->where('ContentId',$ccId->ContentId)->update(['RowStatus'=>-1]);
			}
            $archive->delete($id);
            return response()->json(array('code' => 0, 'msg' => '删除成功'));
        } else {
            return response()->json(array('code' => -1, 'msg' => '删除失败'));
        }
    }
    
    public function gatherInput($input, $tagRepository){
        $input = array_map('xssFilter', $input);
        $input['cover'] = empty($input['cover']) ? '' : $input['cover'];
        $input['description'] = $description = mb_substr(strip_tags($input['article']['content']), 0, 200);
        $input['is_video'] = $input['is_video']*1 && $input['cover'] ? 1 : 0;
        $id = !empty($input['id']) ? intval($input['id']) : 0;
        $tags = !empty($input['tags']) ? explode(',', $input['tags']) : [];
        if(!in_array($input['status'], [1, 2])){
            throw new \Exception('文章状态错误');
        }
        if(!isset($input['article']['attachments']) || !is_array($input['article']['attachments'])){
            $input['article']['attachments'] = [];
        }
        if($id > 0){
            $archive = ['title'=>$input['title'],'description'=>$input['description'],'cover'=>$input['cover'],'tag'=>implode(',', $tags),'is_video'=>$input['is_video'],'status'=>$input['status'],'sort_time'=>time(),'publish_time'=>date('Y-m-d H:i:s')];
            $article = ['content_type'=>intval($input['article']['content_type']),'content'=>$input['article']['content'],'content_md'=>$input['article']['content_md'],'type'=>intval($input['article']['type']),'source'=>$input['article']['source'],'attachments'=>$input['article']['attachments']];
        }else{
            $archive = ['class_id'=>1,'title'=>$input['title'],'description'=>$description,'cover'=>$input['cover'],'tag'=>implode(',', $tags),'user_id'=>Auth::user()->UserId,'creator'=>Auth::user()->UserId,'is_video'=>$input['is_video'],'status'=>$input['status'],'extra'=>[], 'sort_time'=>time(),'publish_time'=>date('Y-m-d H:i:s')];
            $article = ['content_type'=>intval($input['article']['content_type']),'content'=>$input['article']['content'],'content_md'=>$input['article']['content_md'],'type'=>intval($input['article']['type']),'source'=>$input['article']['source'],'attachments'=>$input['article']['attachments']];
        }
        if(empty($tags)){
            $tags = $tagRepository->findFromTitleContent($archive['title'], $article['content']);
            $archive['tag'] = implode(',', array_column($tags->slice(0, 6)->toArray(), 'name'));
        }else{
            $tags = $tagRepository->whereIn('name', $tags)->findAll();
        }

        $archive['channel_id'] = getChannelId($tags);

        return compact('id', 'archive', 'article', 'tags');
	}
    
    public function addPicture(R\App\Repositories\FollowUserRepository $followUserRepository, \App\Repositories\FollowRepository $follow, Request $request){
        if (!Auth::check()) {
            return response()->json(['code' => -2, 'msg' => '未登录']);
        }
        $list = array();
        if(is_array($request->input('list'))){
            foreach($request->input('list') as $li){
                $list[] = $li*1;
            }
        }
        $followList = $followUserRepository->findAll();
        $myFollowList = $follow->where('user_id', Auth::user()->UserId)->whereIn('follow_user', array_column($followList->toArray(), 'user_id'))->findAll(['id', 'follow_user', 'status']);
        $myFollowListHash = array();
        foreach($myFollowList as $r){
            $myFollowListHash[$r->follow_user] = $r;
        }
        foreach($followList as $r){
            if(in_array($r->user_id, $list)){
                //关注
                if(isset($myFollowListHash[$r->user_id])){
                    if($myFollowListHash[$r->user_id]->status != 0){
                        $myFollowListHash[$r->user_id]->status = 0;
                        $myFollowListHash[$r->user_id]->save();
                    }
                }else{
                    $follow->create(['user_id' => Auth::user()->UserId, 'follow_user' => $r->user_id, 'status' => 0]);
                }
            }else{
                //取消
                if(isset($myFollowListHash[$r->user_id])){
                    if($myFollowListHash[$r->user_id]->status != 1){
                        $myFollowListHash[$r->user_id]->status = 1;
                        $myFollowListHash[$r->user_id]->save();
                    }
                }
            }
        }
        \Redis::connection()->hSet('gad:community:recommendOperation:'.Auth::user()->UserId, 'follow', 1);
        return response()->json(['code' => 0]);
    }
}
