<?php
/**
 * Created by PhpStorm.
 * User: v_shkliu
 * Date: 2017/8/9
 * Time: 14:00
 */

namespace App\Http\Controllers\Mgr;

use App\Repositories\HatchProjectRepository;
use App\Repositories\HatchRegisterRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Repositories\TagRepository;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Cache;
use Prettus\Validator\Exceptions\ValidatorException;

require_once(dirname(__FILE__) . '/../../../Phpexcel/ProjectExcel.php');

/**
 * Class HatchProjectController
 * @package App\Http\Controllers\Mgr
 */
class HatchProjectController extends Controller
{
    /**
     * @var TagRepository
     */
    protected $repository;
    protected $hatchRegisterRepository;

    /**
     * @var TagValidator
     */
    protected $validator;

    public function __construct(HatchProjectRepository $hatchProjectRepository, HatchRegisterRepository $hatchRegisterRepository)
    {
        $this->repository = $hatchProjectRepository;
        $this->hatchRegisterRepository = $hatchRegisterRepository;
    }

    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
     */
    public function index(Request $request)
    {


        if ($request->has('startTime')) {
            $this->repository->where('created_at', '>', $request->input('startTime'));
        }

        if ($request->has('name')) {
            $this->repository->where('name', 'like', '%' . $request->input('name') . '%');
        }

        if ($request->has('endTime')) {
            $this->repository->where('created_at', '<', $request->input('endTime'));
        }
        if ($request->has('created_from')) {
            $this->repository->where('created_from', $request->input('created_from'));
        }
        // 推送状态
        if ($request->has('push_email_status')) {
            $this->repository->where('push_email_status', $request->input('push_email_status'));
        }


        $data = $this->repository->orderBy('id', 'desc')->paginate(10);
        foreach ($data->items() as $li) {
            $li->setVisible([]);
        }
        if (request()->wantsJson()) {

            return response()->json([
                'data' => $data,
            ]);
        }

        return view('hatchProject.index', compact('hatchProject'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $expertPlan = $this->repository->find($id);
        $expertPlan->setVisible([]);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $expertPlan,
            ]);
        }

        return view('hatchProject.show', compact('hatchProject'));
    }


    /**
     * 新增
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {

        try {

            $data = $request->all();
//            $data['comment_count'] = count($data['section_comment']);
            $data['creator'] = Auth::user()['UserId'];
            list($status, $operation) = $this->repository->create($data);
            $response = [
                'message' => 'Operation created.',
                'data' => $operation,
            ];
            if ($request->wantsJson()) {

                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 更新
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function update(Request $request)
    {

        try {

            $data = $request->all();
//            $data['comment_count'] = count($data['section_comment']);
            $data['updater'] = Auth::user()['UserId'];

            list($status, $operation) = $this->repository->update($data['id'], $data);
            $response = [
                'code' => (int)$status,
                'message' => 'ok',
                'data' => $operation,
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 删除
     *
     * @param $id
     * @return \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {

        $deleted = $this->repository->deleteProject($id);

        if (request()->wantsJson()) {

            return response()->json([
                'message' => 'hatchProject deleted.',
                'deleted' => $deleted,
            ]);
        }

        return redirect()->back()->with('message', 'Operation deleted.');

    }


    //导出项目库
    public function getExcelProjectList(Request $request)
    {
        if ($request->has('startTime')) {
            $this->repository->where('created_at', '>', $request->input('startTime'));
        }

        if ($request->has('endTime')) {
            $this->repository->where('created_at', '<', $request->input('endTime'));
        }

        if ($request->has('created_from')) {
            $this->repository->where('created_from', $request->input('created_from'));
        }
        $data = $this->repository->orderBy('id', 'desc')->paginate(1000);
        $getKeys = array(
            'id',
            'user_id',
            'created_from',
            'is_public',
            'name',
            'pictures',
            'demo',
            'progress',
            'team_num',
            'intro',
            'team_name',
            'team_logo',
            'team_province',
            'team_city',
            'team_contacts',
            'team_phone',
            'team_email',
            'team_weixin',
            'comment_count',
            'view_count',
            'like_count',
            'favorite_count',
            'vote_count',
            'download_count'
        );

        //定义表格title
        $_totaltitle = array(
            'id' => 'ID',
            'user_id' => '所属用户id',
            'created_from' => '类型',
            'is_public' => '是否公开',
            'name' => '游戏名称',
            'pictures' => '截图',
            'demo' => '试玩包',
            'progress' => '开发阶段',
            'team_num' => '团队人数',
            'intro' => '游戏介绍',
            'team_name' => '团队名称',
            'team_logo' => '团队logo',
            'team_province' => '省份',
            'team_city' => '城市',
            'team_contacts' => '接口人姓名',
            'team_phone' => '电话',
            'team_email' => '邮箱',
            'team_weixin' => '微信号',
            'comment_count' => '评论数',
            'view_count' => '浏览数',
            'like_count' => '点赞数',
            'favorite_count' => '收藏数',
            'vote_count' => '投票数',
            'download_count' => '下载数'
        );

        $fileName = "ProjectList";
        $excel = new  \ProjectExcel();
        $excel->exportList($data, $getKeys, $_totaltitle, $fileName);
    }

    /**
     * 推送项目给专家
     */
    public function pushMailToExpert()
    {
        $value = Cache::get('push_mail_status', true);
        Cache::forever('push_mail_status', true);
        $this->repository->pushMailToExpert();
        Cache::forever('push_mail_status', $value);
        return response()->json([
            'message' => 'ok',
        ]);
    }

    public function editPushMailStatus()
    {
        $value = Cache::get('push_mail_status', true);
        Cache::forever('push_mail_status', !$value);
        return response()->json([
            'message' => 'ok',
            'data' => !$value,
        ]);
    }

    /**
     * 获取状态值
     * @return \Illuminate\Http\JsonResponse
     */
    public function getPushMailStatus()
    {
        $value = Cache::get('push_mail_status', true);
        Cache::forever('push_mail_status', $value);

        return response()->json([
            'message' => 'ok',
            'data' => $value,
        ]);
    }


}