<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/8/25
 * Time: 7:28
 */

namespace App\Http\Controllers\Mgr;

use App\Entities\Content;
use App\Entities\ContentClass;
use App\Entities\Archive;
use App\Entities\Picture;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Entities\Course;
use App\Entities\Comment;
use App\Entities\CourseChat;
use App\Entities\Reply;
use App\Entities\Answer;
use Illuminate\Support\Facades\DB;

class CommentAllController extends Controller
{
    protected $archiveEloquent;
    protected $answerEloquent;
    protected $archiveRepository;

    private $typelist = array(
        1 => 'App\Entities\Archive',
        2 => 'App\Entities\Comment',
        3 => 'App\Entities\Picture',
        7 => 'App\Entities\GamePai'
    );

    //根据类型查询一级评论信息
    public function postCommentType(Request $request)
    {
        $result = ['total' => 0, 'hostname' => '', 'commentlist' => []];
        $page = $request->get('page', 1);
        $skip = ($page - 1) * 10;

        $type = intval($request->input('type'));
        $is_reply = intval($request->input('is_reply'));

        if ($type == 0) {
            return response()->json($result);
        }

        if ($is_reply == 1) { //二级评论
            $obj_id = $request->input('obj_id');
            if (is_null($obj_id)) {
                return response()->json($result);
            }
        }

        $archive_id = intval($request->input('archive_id'));//内容库传过来的

        switch ($type) {
            case 1: //日志
            case 3://作品精选
                $data = Comment::query()->with("user")->where("deleted_at", null);
                if ($is_reply == 1) {
                    $entry = $data->where("model_id", $obj_id)->where("model_type", $this->typelist[2]);
                } else {
                    if ($archive_id > 0) {
                        $entry = $data->where('model_id', $archive_id);
                    } else {
                        $result = DB::table('gad_archives')->join('gad_atlas', 'gad_atlas.archive_id', '=', 'gad_archives.id')
                            ->whereNull('gad_archives.deleted_at')
                            ->orderBy('gad_archives.id', 'desc')->select('gad_archives.id')->get();
                        if (count($result) > 0) {
                            $ids = array_column(json_decode(json_encode($result), true), 'id');
                        }
                        if ($type == 1) {
                            $entry = $data->whereNotIn("model_id", $ids);
                        } else if ($type == 3) {
                            $entry = $data->whereIn("model_id", $ids);
                        }
                        $entry->where("model_type", $this->typelist[1]);
                    }
                }
                break;
            case 2: //话题
                $data = Answer::query()->with("user")->where("status", 0);
                if ($is_reply == 1) {
                    $entry = $data->where("answer_id", $obj_id);
                } else {
                    $entry = $data->where("answer_id", 0);
                }
                break;
            case 4: //视频
                if ($is_reply == 1) {
                    $entry = Reply::query()->with("user")->where("RowStatus", 0)->where("ReplyObject", '>', 0)->where('ReplyObject', $obj_id);
                } else {
                    $entry = self::getContentByType(3);
                }
                break;
            case 5: //手册（详情页评论）
                $data = \App\Models\Comment::query()->with("user")->where("status", '>', -1);
                if ($is_reply == 1) {
                    $entry = $data->where("obj_type", 5)->where("obj_id", $obj_id);
                } else {
                    $entry = $data->where("obj_type", 6);
                }
                break;
            case 6: //论道（右侧评论）
                $entry = CourseChat::query()->with("user")->where("deleted_at", null)->where("is_show", 1);
                break;
            case 7: //游戏派
                $data = Comment::query()->with("user")->where("deleted_at", null);
                if ($is_reply == 1) {
                    $entry = $data->where("model_type", $this->typelist[2])->where("model_id", $obj_id);
                } else {
                    $entry = $data->where("model_type", $this->typelist[7]);
                }
                break;
            case 8: //名人堂
                $data = \App\Models\Comment::query()->with("user")->where("status", '>', -1);
                if ($is_reply == 1) {
                    $entry = $data->where("obj_type", 5)->where("obj_id", $obj_id);
                } else {
                    $entry = $data->where("obj_type", 101);
                }
                break;
            case 9: //翻译馆
                if ($is_reply == 1) {
                    $entry = Reply::query()->with("user")->where("RowStatus", 0)->where("ReplyObject", '>', 0)->where('ReplyObject', $obj_id);
                } else {
                    $entry = self::getContentByType(12);
                }
                break;
            case 10: //习作点评
                $data = Comment::query()->with("user")->where("deleted_at", null);
                if ($is_reply == 1) {
                    $entry = $data->where("model_id", $obj_id)->where("model_type", $this->typelist[2]);
                } else {
                    if ($archive_id > 0) {
                        $entry = $data->where('model_id', $archive_id);
                    } else {
                        $entry = $data->where("model_type", $this->typelist[3]);
                    }
                }
                break;
        }

        if ($type != 4 && $type != 9) {
            if ($request->has('userid')) {
                $entry->where('user_id', $request->input('userid'));
            }
            if ($request->has('begin_date') && $request->has('end_date')) {
                $entry->where("created_at", '>=', date('Y-m-d 00:00:00', strtotime($request->input('begin_date'))))
                    ->where("created_at", '<=', date('Y-m-d 23:59:59', strtotime($request->input('end_date'))));
            }
        } else {
            if ($request->has('userid')) {
                $entry->where('Reply.Creator', $request->input('userid'));
            }
            if ($request->has('comment')) {
                $str = $request->input('comment');
                $entry->where('Reply.HtmlDetail', 'like', '%' . $str . '%');
            }
            if ($request->has('begin_date') && $request->has('end_date')) {
                $entry->where("Reply.Created", '>=', date('Y-m-d 00:00:00', strtotime($request->input('begin_date'))))
                    ->where("Reply.Created", '<=', date('Y-m-d 23:59:59', strtotime($request->input('end_date'))));
            }
        }

        if ($type == 2) {
            if ($request->has('comment')) {
                $str = $request->input('comment');
                $entry->where('answer', 'like', '%' . $str . '%');
            }
        } else if ($type == 6) {
            if ($request->has('comment')) {
                $str = $request->input('comment');
                $entry->where('content', 'like', '%' . $str . '%');
            }
        } else if ($type != 4 && $type != 9) {
            if ($request->has('comment')) {
                $str = $request->input('comment');
                $entry->where('comment', 'like', '%' . $str . '%');
            }
        }

        if ($request->has('username')) {
            $username = $request->input('username');
            $entry->whereHas('user', function ($query) use ($username) {
                $query->where('NickName', 'like', '%' . $username . '%');
            });
        }

        if ($request->has('qq')) {
            $qq = $request->input('qq');
            $entry->whereHas('user', function ($query) use ($qq) {
                $query->where('User.QQNo', $qq);
            });
        }

        $result['total'] = $entry->count();

        if ($type == 4 || $type == 9) {
            $result['commentlist'] = $entry->skip($skip)->take(20)->orderBy('ReplyId', 'desc')->get();
        } else {
            $result['commentlist'] = $entry->skip($skip)->take(20)->orderBy('id', 'desc')->get();
        }

        if ($type == 2) {
            foreach ($result['commentlist'] as $key => $item) {
                $item_id = $item["answer_id"];
                if ($item_id == 0) {
                    $result['commentlist'][$key]["archive_id"] = $item["archive_id"];
                } else {
                    $ids = Answer::where("id", $item_id)->where("status", 0)->value("archive_id");
                    $result['commentlist'][$key]["archive_id"] = $ids;
                }
            }
        }

        if ($type == 10) {
            foreach ($result['commentlist'] as $key => $item) {
                $ids = Picture::where("id", $item["model_id"])->where("deleted_at", null)->value("archive_id");
                $result['commentlist'][$key]["archive_id"] = $ids;
            }
        }

        foreach ($result['commentlist'] as $key => $item) {
            $result['commentlist'][$key]["QQNo"] = $item->user["QQNo"];
        }

        $hostname = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
        $host = app()->isLocal() ? 'http://olddev.gad.qq.com' : 'http://gad.qq.com';
        $result["host"] = $host;
        $result["hostname"] = $hostname;

        return response()->json($result);
    }

    //删除评论内容
    public function postUpdateCommentStatus(Request $request)
    {
        $type = intval($request->input('type'));
        $id = intval($request->input('id'));
        $archive_id = intval($request->input('archive_id'));
        switch ($type) {
            case 1: //日志
            case 3: //作品精选
            case 7: //游戏派（GamePai）
            case 10://习作点评（Picture）
                $entry = Comment::find($id)->delete();//->update(['comment_count' => 0])
                if ($entry > 0) {
                    Comment::where("model_id", $id)->where("model_type", $this->typelist[2])->delete();
                    if ($archive_id > 0) {
                        $data = Archive::find($archive_id);
                        if ($data->comment_count > 0) {
                            $data->decrement("comment_count");//评论数减去一
                        }
                    }
                }
                break;
            case 2: //话题
                $entry = Answer::find($id)->update(['status' => -1]);//,'answer_count' => 0
                if ($entry > 0) {
                    Answer::where("answer_id", $id)->update(['status' => -1]);
                    if ($archive_id > 0) {
                        $data = Archive::find($archive_id);
                        if ($data->comment_count > 0) {
                            $data->decrement("comment_count");//评论数减去一
                        }
                    }
                }
                break;
            case 4: //视频
            case 9: //翻译馆(ReplyType=1)
                $entry = DB::table('Reply')->where("ReplyId", $id)->update(['RowStatus' => -1]);
                if ($entry > 0) {
                    DB::table('Reply')->where("ReplyObject", $id)->where("ReplyType", 2)->update(['RowStatus' => -1]);
                }
                break;
            case 5: //手册（详情页评论obj_type=6）
            case 8: //名人堂(obj_type=101)
                $entry = \App\Models\Comment::find($id)->update(['status' => -1, 'comment_cnt' => 0]);
                if ($entry > 0) {
                    \App\Models\Comment::where("obj_id", $id)->where("obj_type", 5)->update(['status' => -1]);
                }
                break;
            case 6: //论道（右侧评论）
                $entry = CourseChat::find($id)->delete();
                break;
        }
        if ($entry > 0) {
            return json_encode(['msg' => '删除成功', 'code' => '1']);
        } else {
            return json_encode(['msg' => '删除失败', 'code' => '-1']);
        }
    }

    //删除二级评论内容
    public function postUpdateReplyStatus(Request $request)
    {
        $type = intval($request->input('type'));
        $id = intval($request->input('id'));
        $obj_id = intval($request->input('obj_id'));
        switch ($type) {
            case 1: //日志
            case 3: //作品精选
            case 7: //游戏派
            case 10: //习作点评
                $entry = Comment::find($id)->delete();
                $data = Comment::find($obj_id);
                if ($data->comment_count > 0) {
                    $data->decrement("comment_count");
                }
                break;
            case 2: //话题
                $entry = Answer::find($id)->update(['status' => -1]);
                $data = Answer::find($obj_id);
                if ($data->answer_count > 0) {
                    $data->decrement("answer_count");
                }
                break;
            case 4: //视频
            case 9: //翻译馆
                $entry = DB::table('Reply')->where("ReplyId", $id)->update(['RowStatus' => -1]);
                break;
            case 5: //手册（详情页评论）
            case 8: //名人堂
                $entry = \App\Models\Comment::find($id)->update(['status' => -1]);
                $data = \App\Models\Comment::find($obj_id);
                if ($data->comment_cnt > 0) {
                    $data->decrement("comment_cnt");
                }
                break;
            case 6: //论道（右侧评论）
                $entry = CourseChat::find($id)->delete();
                break;
        }
        if ($entry>0) {
            return json_encode(['msg' => '删除成功', 'code' => '1']);
        } else {
            return json_encode(['msg' => '删除失败', 'code' => '-1']);
        }
    }

    public function getContentByType($type)
    {
        return Reply::query()->select("Reply.ReplyId", "Reply.ReplyObject", "Reply.HtmlDetail",
            "Reply.Created", "Reply.Creator", "Content.ShowType", "User.UserId", "User.QQNo", "User.NickName")
            ->join('ContentClass', 'Reply.ReplyObject', '=', 'ContentClass.id')
            ->join('Content', 'ContentClass.contentid', '=', 'Content.ContentId')
            ->join('User', 'Reply.Creator', '=', 'User.UserId')
            ->where("Reply.ReplyType", 1)
            ->where("Reply.RowStatus", 0)->where("Reply.ReplyObject", '>', 0)
            ->where("ContentClass.RowStatus", 0)->where("Content.RowStatus", 0)->where("Content.ShowType", $type);
    }
}