<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/7/5
 * Time: 9:18
 */

namespace App\Http\Controllers\Mgr;

use App\Entities\LiveOrder;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\User;

class LoreWhiteController extends Controller
{
    //白名单列表或付费用户列表
    public function index(Request $request)
    {
        $whitelist = LiveOrder::query()->with("lores")->with("user")
            ->where('state', 1)->where('obj_type', 'App\Entities\Lore');

        if ($request->has('user_type')) {
            $whitelist->where('user_type', $request->input('user_type'));
        } else {
            $whitelist->where('user_type', 1);
        }

        if ($request->has('obj_id')) {
            $whitelist->where('obj_id', $request->input('obj_id'));
        }

        if ($request->has('qq')) {
            $qq = $request->input('qq');
            $whitelist->whereHas('user', function ($query) use ($qq) {
                $query->where('QQNo', $qq);
            });
        }

        if ($request->has('userid')) {
            $whitelist->where('user_id', $request->input('userid'));
        }

        $data = $whitelist->orderBy('id', 'desc')->paginate($request->get('pageSize', 10));
        return response()->json(['data' => $data]);
    }

    //添加白名单用户
    public function addWhiteUser(Request $request)
    {
        $userid = $request->input('userid');
        $loreid = $request->input('loreid');

        $userCount = User::where('UserId', $userid)->count();
        if ($userCount <= 0) {
            return json_encode(['data' => [], 'msg' => '用户id不存在,请重新输入', 'code' => '-1']);
        }

        $isExistList = LiveOrder::where('obj_id', $loreid)->where('user_id', $userid)->where('obj_type', 'App\Entities\Lore')->count();
        if ($isExistList > 0) {
            return json_encode(['data' => [], 'msg' => '该用户已经是该专题的白名单了,不需要重复添加', 'code' => '-1']);
        }

        $params = array("state" => 1, "obj_id" => $loreid, "user_id" => $userid, "obj_type" => 'App\Entities\Lore', "user_type" => 1, "created_at" => time());

        $rows = LiveOrder::create($params)->id;
        if ($rows <= 0) {
            return json_encode(['data' => [], 'msg' => '添加失败', 'code' => '-1']);
        }

        return json_encode(['data' => [], 'msg' => '添加成功', 'code' => '1']);
    }


    public function store(Request $request)
    {
        return response()->json(LoreWhite::create($request->all()));
    }

    public function show($id)
    {
        return response()->json($this->lore_white->find($id));
    }

    public function update(Request $request, $id)
    {
        return response()->json($this->lore_white->update($request->all(), $id));
    }

    public function destroy($id)
    {
        return response()->json($this->lore_white->delete($id));
    }


}