<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/7/14
 * Time: 2:31
 */

namespace App\Http\Controllers\Mgr;

use App\Entities\Project;
use App\Http\Controllers\Controller;
use App\Entities\Resume;
use App\Repositories\ProjectRepository;
use App\Repositories\TeamActionRepository;
use Illuminate\Http\Request;
use App\Repositories\ResumeRepository;
use League\Flysystem\Exception;
use App\Gad\Func;
use App\Gad\MessageType;
use Auth;

require_once(dirname(__FILE__) . '/../../../Phpexcel/TeamExcel.php');

class TeamController extends Controller
{
    private $resume;
    private $project;
    private $actionRepository;

    public function __construct(ResumeRepository $resume, ProjectRepository $project,TeamActionRepository $actionRepository)
    {
        $this->resume = $resume;
        $this->project = $project;
        $this->actionRepository = $actionRepository;
    }

    //获取开发者简历列表或人才库
    public function postResumeList(Request $request)
    {
        return self::isExcelResumeList($request, 0);
    }

    //审核通过or审核不通过
    public function postSetIsPass(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $state = $params['state'];
        $type = $params['type'];//1为resume 2为project
        $user_id = $params['user_id'];

        $arr_params = array('state' => $state, 'reason' => $params['reason']);
        if ($state == 1) {
            $arr_params = array('state' => $state, 'is_show' => 1, 'reason' => $params['reason']);
        }

        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';

        if ($type == 1) {
            list($arr, $res) = $this->resume->update($id, $arr_params);
            $title = '【GAD-开发者简历审核】';
            $urlinfo = url($host . '/team/my/resume#!');
        } else if ($type == 2) {
            list($arr, $res) = $this->project->update($id, $arr_params);
            $title = '【GAD-项目审核】';
            $urlinfo = url($host . '/team/my/project#!/info/' . $id);
        }

        if ($arr > 0) {
            if ($state == 2) {
                $email = $params['email'];
                $reason = $params['reason'];

                if ($type == 1) {
                    $message = MessageType::TEAM_RESUME_REJECT; //简历不通过
                } elseif ($type == 2) {
                    $message = MessageType::TEAM_PROJECT_REJECT;//项目不通过
                }

                $mail = view('hatch.mail_mgr_team', compact('email', 'reason', 'title'))->render();
                if ($host == "http://gad.qq.com") {
                    \Tof::service('message')->sendEmail('gad@tencent.com', $email, $title, $mail);
                }
            } else {
                if ($type == 1) {
                    $message = MessageType::TEAM_RESUME_ACCEPT; //简历通过
                } elseif ($type == 2) {
                    $message = MessageType::TEAM_PROJECT_ACCEPT;//项目通过
                }
            }

            $login_userId = Auth::user()['UserId'];
            Func::msgApi($message, $user_id, $login_userId, $id, $urlinfo, "查看详情");

            return response()->json(['data' => $host, 'msg' => "操作成功", "code" => 1]);
        } else {
            return response()->json(['msg' => "操作失败", "code" => -1]);
        }
    }

    //导出简历列表
    public function getExcelResumeList(Request $request)
    {
        $arr = self::isExcelResumeList($request, 1);

        $getKeys = array('id', 'real_name', 'gender', 'birthday', 'education', 'province', 'city', 'phone', 'email'
        , 'career_state', 'career_type', 'work_date', 'state', 'is_show', 'created_at', 'intent_city', 'work_type');

        //定义表格title
        $_totaltitle = array(
            'id' => 'ID',
            'real_name' => '姓名',
            'gender' => '性别',
            'birthday' => '生日',
            'education' => '学历',
            'province' => '省',
            'city' => '城市',
            'phone' => '手机',
            'email' => '邮箱',
            'career_state' => '职业状态',
            'career_type' => '职业方向',
            'work_date' => '工作年限',
            'state' => '审核状态',
            'is_show' => '上架状态',
            'created_at' => '提交时间',
            'intent_city' => '意向工作地',
            'work_type' => '工作方式'
        );

        $fileName = "ResumeList";
        $excel = new  \TeamExcel();
        $excel->exportList($arr, $getKeys, $_totaltitle, $fileName);
    }

    //获取简历列表数据或者导出
    public function isExcelResumeList(Request $request, $isExcel)
    {
        $psss_num = 0;
        $no_pass_num = 0;
        $this->resume->forgetCache();

        $type = intval($request->input('type'));

        if ($type == 1) {
            $psss_num = self::getCount(1, 1, -1);
            $no_pass_num = self::getCount(1, 2, -1);

            if ($request->has('state') && $request->input('state') != -1) {
                $this->resume->where('state', $request->input('state'));
            }
            $this->resume->where('state', '!=', 1); //审核通过的不显示

        } else if ($type == 2) {

            $this->resume->where('state', 1); //审核通过的

            $psss_num = self::getCount(1, 1, 1);
            $no_pass_num = self::getCount(1, 1, 0);

            if ($request->has('is_show') && $request->input('is_show') != -1) {
                $this->resume->where('is_show', $request->input('is_show'));
            }

            if ($request->has('real_name') && $request->input('real_name') != -1) {
                $this->resume->where('real_name', 'like', '%' . $request->input('real_name') . '%');
            }

            if ($request->has('career_type') && $request->input('career_type') != -1) {
                //$this->resume->where('career_type', $request->input('career_type'));
                $this->resume->where('career_type', 'like', '%' . $request->input('career_type') . '%');
            }
        }

        if ($request->has('id') && $request->input('id') != -1) {
            $this->resume->where('id', $request->input('id'));
        }

        if ($request->has('beginTime') && $request->has('endTime')) {
            $this->resume->where("created_at", '>=', $request->input('beginTime'))->where("created_at", '<=', $request->input('endTime'));
        }

        if ($request->has('ids')) {
            $ids = explode(",", $request->get('ids'));
            if (!empty($ids)) {
                $this->resume->whereIn("id", $ids);
            }
        }

        if ($isExcel == 0) {
            $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
            $result = $this->resume->orderBy('id', 'desc')->paginate($request->get('pageSize', 10));
            $total_num = Resume::query()->where("deleted_at", null)->count();
            return response()->json(['data' => $result, "total_num" => $total_num, "psss_num" => $psss_num, "no_pass_num" => $no_pass_num, 'hostname' => $host]);
        } else {
            return $this->resume->orderBy('id', 'desc')->paginate($request->get('pageSize', 100));
        }

    }

    //设为置顶(舍弃)
    public function postSetIsTop(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $type = $params['type'];

        if ($type == 1) {
            $arr = Resume::setTop($id);
        } else {
            $arr = Project::setTop($id);
        }

        if ($arr > 0) {
            return response()->json(['msg' => "操作成功", "code" => 1]);
        } else {
            return response()->json(['msg' => "操作失败", "code" => -1]);
        }
    }


    //获取记录数
    public function getCount($type, $state, $is_show)
    {
        if ($type == 1) {
            $entry = Resume::query()->where("deleted_at", null)->where("state", $state);
        } else {
            $entry = Project::query()->where("deleted_at", null)->where("state", $state);
        }

        if ($is_show > -1) {
            return $entry->where("deleted_at", null)->where("is_show", $is_show)->count();
        }
        return $entry->count();
    }


    //获取项目列表数据或者导出
    public function isExcelProjectList(Request $request, $isExcel)
    {
        $this->project->forgetCache();
        $psss_num = 0;
        $no_pass_num = 0;

        $type = intval($request->input('type'));
        if ($type == 1) {

            $psss_num = self::getCount(0, 1, -1);
            $no_pass_num = self::getCount(0, 2, -1);

            if ($request->has('state') && $request->input('state') != -1) {
                $this->project->where('state', $request->input('state'));
            }

            $this->project->where('state', '!=', 1); //审核通过的不显示

        } else if ($type == 2) {
            $this->project->where('state', 1); //审核通过的

            $psss_num = self::getCount(0, 1, 1);
            $no_pass_num = self::getCount(0, 1, 0);

            if ($request->has('is_show') && $request->input('is_show') != -1) {
                $this->project->where('is_show', $request->input('is_show'));
            }
        }

        if ($request->has('id')) {
            $this->project->where('id', $request->input('id'));
        }

        if ($request->has('title')) {
            $str = $request->input('title');
            $this->project->where('title', 'like', '%' . $str . '%');
        }

        if ($request->has('beginTime') && $request->has('endTime')) {
            $this->project->where("created_at", '>=', $request->input('beginTime'))->where("created_at", '<=', $request->input('endTime'));
        }

        if ($request->has('game_type') && $request->input('game_type') != -1) {
            $this->project->where("game_type", $request->input('game_type'));
        }

        if ($request->has('ids')) {
            $ids = explode(",", $request->get('ids'));
            if (!empty($ids)) {
                $this->project->whereIn("id", $ids);
            }
        }

        if ($isExcel == 0) {
            $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
            $total_num = Project::query()->where("deleted_at", null)->count();
            $result = $this->project->with(['projectUser', 'user_manager'])->orderBy('id', 'desc')->paginate($request->get('pageSize', 10));

            foreach ($result->items() as $key=> $li){
                $li->setVisible([]);
            }

            return response()->json(['data' => $result, "total_num" => $total_num, "psss_num" => $psss_num, "no_pass_num" => $no_pass_num, 'hostname' => $host]);
        } else {
            return $this->project->orderBy('id', 'desc')->paginate($request->get('pageSize', 100));
        }
    }


    //项目库
    public function postProjectList(Request $request)
    {
        return self::isExcelProjectList($request, 0);
    }

    //上架、下架状态处理
    public function postSetIsShow(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $is_show = intval($params['is_show']);
        $type = $params['type'];//1为resume 2为project

        $arrparams = array('is_show' => $is_show);

        if ($type == 1) {
            list($status, $res) = $this->resume->update($id, $arrparams);
        } else if ($type == 2) {
            list($status, $res) = $this->project->update($id, $arrparams);
        }

        if ($status) {
            return json_encode(['data' => [], 'msg' => '操作成功', 'code' => '0']);
        } else {
            return json_encode(['data' => [], 'msg' => '操作失败', 'code' => '-1']);
        }
    }

    //导出项目库
    public function getExcelProjectList(Request $request)
    {
        $arr = self::isExcelProjectList($request, 1);

        $getKeys = array('id', 'title', 'game_name', 'game_type', 'game_state', 'member_count', 'is_show', 'created_at');

        //定义表格title
        $_totaltitle = array(
            'id' => 'ID',
            'title' => '标题',
            'game_name' => '游戏名称',
            'game_type' => '游戏类型',
            'game_state' => '开发阶段',
            'member_count' => '成员人数',
            'is_show' => '上架状态',
            'created_at' => '创建时间'
        );

        $fileName = "ProjectList";
        $excel = new  \TeamExcel();
        $excel->exportList($arr, $getKeys, $_totaltitle, $fileName);
    }

    /**
     * 获取简历和需求数据
     * @param Request $request
     */
    public function anyTeamActionData(Request $request)
    {
        // 查询简历的人
        // 简历用户 resume_user
        if($request->has('resume_user')){
            $this->actionRepository->where('resume_user','=',$request->input('resume_user'));
        }
        // 查询需求
        // 需求方用户 project_user
        if ($request->has('project_user')){
            $this->actionRepository->where('project_user','=',$request->input('project_user'));
        }

        if($request->has('start_time')){
            $this->actionRepository->where('created_at','>',$request->input('start_time'));
        }
        if($request->has('end_time')){
            $this->actionRepository->where('created_at','<',$request->input('end_time'));
        }
        if($request->has('export')){
        $res=$this->actionRepository->orderBy('id','desc')->findAll();
            $data = $res->toArray();
            $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
            $statusList = [ 0=>'未接受',1=>'接受',2=>'拒绝'];

            foreach ($data as $key=>$one){
                $data[$key]['resume_id']=$host.'/team/resume/index/'.$one['resume_id'];
                $data[$key]['project_id']=$host.'/team/project/detail/'.$one['project_id'];


                $data[$key]['action_type'] = ($one['action_type']=='apply')?'申请加入项目':'邀请加入项目';
                $data[$key]['state'] =$statusList[($one['state'])];
            }


            $getKeys = array(
                'resume_user',
                'resume_id',
                'project_user',
                'project_id',
                'action_type',
                'created_at',
                'state',
              );
            //定义表格title
            $_totaltitle = array(
                'resume_user'=>'用户ID',
                'resume_id'=>'简历URL',
                'project_user'=>'需求方ID',
                'project_id'=>'需求单URL',
                'action_type'=>'类型',
                'created_at'=>'创建时间',
                'state'=>'状态',
            );

            $fileName = "TeamActionData";
            $excel = new  \TeamExcel();
            $excel->exportList2($data, $getKeys, $_totaltitle, $fileName);
        }

        $res=$this->actionRepository->orderBy('id','desc')->paginate(10);
        return response()->json($res);
    }

}