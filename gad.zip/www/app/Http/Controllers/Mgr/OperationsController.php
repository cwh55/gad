<?php

namespace App\Http\Controllers\Mgr;

use App\Entities\Operation;
use App\Entities\Tag;
use App\Http\Controllers\Controller;
use App\Repositories\OperationRepository;
use App\Repositories\OperationRepositoryEloquent;
use Illuminate\Http\Request;
use League\Flysystem\Exception;
use Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;
use Redis;

class OperationsController extends Controller
{

    /**
     * @var OperationRepository
     */
    protected $repository;

    /**
     * @var OperationValidator
     */
    protected $validator;

    public function __construct(OperationRepositoryEloquent $repository)
    {
        $this->repository = $repository;
    }


    /**
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
     */
    public function index(Request $request)
    {
        $this->repository->forgetCache();

        if ($request->has('type')) {
            $type = $request->input('type', '0');
            $this->repository->where('type', $type);
        } else {
            $type = null;
        }


        //所属频道
        if ($request->has('channel_id')) {
            $this->repository->where('channel_id', $request->input('channel_id'));
        }

        if ($request->has('whereId')) {
            $this->repository->where('id', $request->input('whereId'));
        }
        if ($request->has('date')) {
            $date = $request->input('date');
            $endDate = date('Y-m-d H:i:s', strtotime('+1 month', strtotime($date)));
            $startDate = date('Y-m-d H:i:s', strtotime($date));
            $this->repository->where('created_at', '<', $endDate);
            $this->repository->where('created_at', '>', $startDate);
        }
        //广告推送位置
        if ($request->has('position')) {
            $this->repository->where('position', $request->input('position'));
        }


        $this->repository->orderBy('id', 'desc');
        switch ($type) {
            case 0:
                //专栏
                if ($type === 0) {
                    $this->repository->where('status', '0');
                }
                $operations = $this->repository->paginate(10);
                break;
            case 1:
                //大咖
                $this->repository->where('status', '0');
                $operations = $this->repository->with(['user'])->paginate(10);
                break;
            case 2:
                //标签
                $this->repository->where('status', '0');
                $operations = $this->repository->with(['tag'])->paginate(10);

                break;
            case 7:

                $this->repository->orderBy('status', 'desc');
                $operations = $this->repository->paginate(10);
                break;
            case 16:
                $this->repository->where('status',0);
                $this->repository->orderBy('position', 'desc');
                $operations = $this->repository->paginate(10);
                break;
            default:
                $operations = $this->repository->paginate(10);
                break;

        }


        if (request()->wantsJson()) {
            return response()->json([
                'data' => $operations,
            ]);
        }

        return view('operations.index', compact('operations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        try {
            $this->validate($request,
                [
                    'type' => 'bail|required',
                ], [
                    'type.required' => 'type不能为空',
                ]
            );
            $data = $request->all();
            // 防止重复添加
            if ($data['type'] && !in_array($data['type'], array(11, 12, 13, 15,16))) {
                $operation = $this->repository->where('type', $data['type'])
                    ->where('model_id', $data['model_id'])
                    ->where('channel_id', $data['channel_id'])
                    ->where('position', $data['position'])
                    ->findAll();
                if (!$operation->isEmpty()) {
                    $operation[0]->status = 0;
                    $operation[0]->save();
                    if ($request->wantsJson()) {
                        return response()->json($operation[0]);
                    }
                }
            }
            $operation = $this->repository->create($data);
            $response = [
                'message' => 'Operation created.',
                'data' => $operation[1],
            ];
            if ($request->wantsJson()) {

                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $operation = $this->repository->find($id);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $operation,
            ]);
        }

        return view('operations.show', compact('operation'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $operation = $this->repository->find($id);

        return view('operations.edit', compact('operation'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  Request $request
     * @param  string $id
     *
     * @return Response
     */
    public function update(Request $request, $id)
    {

        try {
            $this->validate($request,
                [
                    'id' => 'bail|required',
                ], [
                    'id.required' => 'id不能为空',
                ]
            );
            $data = $request->all();
            $operation = $this->repository->update($id, $data);
            $response = [
                'code' => (int)$operation[0],
                'message' => 'ok',
                'data' => $operation[1]->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleted = $this->repository->delete($id);

        if (request()->wantsJson()) {

            return response()->json([
                'message' => 'Operation deleted.',
                'deleted' => $deleted,
            ]);
        }

        return redirect()->back()->with('message', 'Operation deleted.');
    }

    //获取qq群信息列表
    public function getQQGroupList(Request $request)
    {
        $this->repository->forgetCache();
        $entry = $this->repository->where('type', 6);
        if ($request->has('id')) {
            $entry->where('id', $request->input('id'));
        }

        if ($request->has('model_id')) {
            $entry->where('model_id', $request->input('model_id'));
        }

        if ($request->has('channel_id') && $request->input('channel_id') != 0) {
            $entry->where('channel_id', $request->input('channel_id'));
        }

        if ($request->has('status') && $request->input('status') != 1) {
            $entry->where('status', $request->input('status'));
        }

        $data = $entry->orderBy('id', 'desc')->paginate($request->get('pageSize', 10));
        return response()->json(['data' => $data, 'msg' => 'success', 'code' => '0']);
    }

    //修改qq群状态
    public function updateQQGroupStatus(Request $request)
    {
        $params = $request->all();
        $id = intval($params['id']);
        $arr = $this->repository->update($id, ['status' => $params['status'], 'updated_at' => time()]);
        return $arr;
    }

    public function getQQGroupById(Request $request)
    {
        $entry = $this->repository->find(intval($request->input('id')));
        return response()->json($entry);
    }

    //添加或更新
    public function addOrUpdateQQGroup(Request $request)
    {
        $id = $request->input('id');
        $channel_id = $request->input('channel_id');
        $model_id = $request->input('model_id');
        $type = 6;//群信息
        $cover = $request->input('cover');
        $url = $request->input('url');

        $userId = 0;//Auth::user()['UserId'];

        $params = array("channel_id" => $channel_id, "type" => $type, "user_id" => $userId, "status" => 0,
            "model_id" => $model_id, "url" => $url, "cover" => $cover, "created_at" => time());

        if (!is_numeric($channel_id)) {
            return json_encode(['data' => [], 'msg' => '标签ID必须为数字', 'code' => '-1']);
        }

        if (empty($id)) {
            $tagcount = Tag::where("id", $channel_id)->count();
            if ($tagcount <= 0) {
                return json_encode(['data' => [], 'msg' => '标签ID输入错误', 'code' => '-1']);
            }

            $count = Operation::where('channel_id', '=', $channel_id)->where('type', '=', 6)->where('status', '=', 0)->count();
            if ($count > 0) {
                return json_encode(['data' => [], 'msg' => '该标签已经添加了qq群信息', 'code' => '-1']);
            }

            $rows = $this->repository->create($params);
            if ($rows <= 0) {
                return json_encode(['data' => [], 'msg' => '添加失败', 'code' => '-1']);
            } else {
                return json_encode(['data' => [], 'msg' => '', 'code' => 1]);
            }
        } else {
            $channel = Operation::where('id', $id)->value("channel_id");

            if ($channel != $channel_id) {
                $count = Operation::where('channel_id', '=', $channel_id)->where('type', '=', 6)->where('status', '=', 0)->count();
                if ($count > 0) {
                    return json_encode(['data' => [], 'msg' => '该标签已经添加了qq群信息', 'code' => '-1']);
                }

                $tagcount = Tag::where("id", $channel_id)->count();
                if ($tagcount <= 0) {
                    return json_encode(['data' => [], 'msg' => '标签ID输入错误', 'code' => '-1']);
                }
            }

            $updatedEntity = $this->repository->update($id, $params);
            if ($updatedEntity <= 0) {
                return json_encode(['data' => [], 'msg' => '修改失败', 'code' => '-1']);
            }

            return json_encode(['data' => [], 'msg' => '', 'code' => 1]);
        }
    }


    //获取网站规模数据信息
    public function getWebSiteSizeInfo()
    {
        $data = Redis::hGetAll('gad:index:statistics');
        return response()->json(['data' => $data, 'msg' => 'success', 'code' => '0']);
    }


    //添加或修改网站规模数据
    public function addOrUpdateWebSiteSize(Request $request)
    {
        $data = array("gamer_nums" => $request->input('gamer_nums'),
            "development_team_nums" => $request->input('development_team_nums'),
            "game_incubation_nums" => $request->input('game_incubation_nums'),
            "industry_daniel_nums" => $request->input('industry_daniel_nums')
        );

        Redis::hMset("gad:index:statistics", $data);
        return response()->json(['data' => "设置成功", 'msg' => 'success', 'code' => '0']);
    }

    /**
     * 同type置顶
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function toTop(Request $request)
    {

        try {

            $operationOne = $this->repository->find($request->input('id'));
            $type = $operationOne->type ;
            $res = $this->repository->where('type', $type )->where('status','0')->orderBy('position', 'desc')->limit(1)->findAll();
            $position = $res[0]->position + 1;
            $operation = $this->repository->update($request->input('id'), ['position' => $position]);

            $response = [
                'code' => (int)$operation[0],
                'message' => 'ok',
                'data' => $operation[1]->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);


        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }

    }
    public function upward(Request $request)
    {


        try {
            $operationOne = $this->repository->find($request->input('id'));
            $res = $this->repository
                ->where('type', $operationOne->type)
                ->where('position','>',$operationOne->position )
                ->orderBy('position', 'asc')
                ->limit(1)->findAll();


            $position1 = $res[0]->position;
            $position = $operationOne->position;

            $operationOne->update(['position' => $position1]);
            $operation = $res[0]->update(['position' => $position]);

            $response = [
                'code' => (int)$operation[0],
                'message' => 'ok',
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);


        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    public function down(Request $request)
    {



        try {
            $operationOne = $this->repository->find($request->input('id'));
            $res = $this->repository
                ->where('type', $operationOne->type)
                ->where('position','<',$operationOne->position )
                ->orderBy('position', 'desc')
                ->limit(1)->findAll();


            $position1 = $res[0]->position;
            $position = $operationOne->position;

            $operationOne->update(['position' => $position1]);
            $operation = $res[0]->update(['position' => $position]);

            $response = [
                'code' => (int)$operation[0],
                'message' => 'ok',
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);


        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }

    }


}
