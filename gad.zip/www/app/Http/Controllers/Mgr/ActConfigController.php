<?php

namespace App\Http\Controllers\Mgr;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Actconfig;
use Illuminate\Http\Request;
use Log;

class ActConfigController extends Controller
{
    public function index(Request $request)
    {
        $actconfig = Actconfig::query();
        if ($request->has('type')) {
            $actconfig->where('type', $request->input('type'));
        }
        $actconfig->where('status', 0);
        $result = $actconfig->orderBy('id', 'desc')->paginate($request->get('pageSize',10));
        return response()->json($result);
    }

    public function show($id)
    {
        $actconfig = Actconfig::findOrFail($id);

        return response()->json($actconfig);
    }

    public function store(Request $request)
    {
        $actconfig = Actconfig::create($request->all());
        return response()->json($actconfig);
    }

    public function update(Request $request, $id)
    {
        $actconfig = Actconfig::findOrFail($id);
        $actconfig->fill($request->all());
        $actconfig->save();

        return response()->json($actconfig);
    }

    public function destroy()
    {

    }

}
