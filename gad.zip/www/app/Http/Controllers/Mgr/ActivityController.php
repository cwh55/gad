<?php

namespace App\Http\Controllers\Mgr;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Entities\Archive;
use App\Entities\Question;
use Illuminate\Http\Request;
use Log;

class ActivityController extends Controller
{
    public function index(Request $request)
    {
        $activity = Activity::query();
        if ($request->has('type')) {
            $activity->where('type', $request->input('type'));
        }
        if ($request->has('status')) {
            $activity->where('status', $request->input('status'));
        }

        $result = $activity->orderBy('id', 'desc')->paginate($request->get('pageSize', 10));

        foreach ($result as $key => $item) {
            $archive = Archive::where("from_activity", $item->id)->first();
            $result[$key]["question_count"] = Question::where("obj_type", 'App\Entities\WendaActivity')
                ->where("obj_id", $archive["id"])->where("activity_status", '>', -1)->count();
            $result[$key]["answer_count"] = intval($archive["comment_count"]);
        }

        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
        return response()->json(['data' => $result, 'hostname' => $host]);
    }

    public function show($id)
    {
        $teacher = Activity::findOrFail($id);

        return response()->json($teacher);
    }

    public function store(Request $request)
    {
        $activity = Activity::create($request->all());

        return response()->json($activity);
    }

    public function update(Request $request, $id)
    {
        $activity = Activity::findOrFail($id);
        $activity->fill($request->all());
        $activity->save();

        return response()->json($activity);
    }

    public function destroy()
    {

    }

}
