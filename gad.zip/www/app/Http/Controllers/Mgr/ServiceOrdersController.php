<?php

namespace App\Http\Controllers\Mgr;

use App\Entities\ServiceOrder;
use App\Http\Controllers\Controller;
use App\Repositories\ServiceMemberRepository;
use Illuminate\Http\Request;

use App\Http\Requests;
use Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Http\Requests\ServiceOrderCreateRequest;
use App\Http\Requests\ServiceOrderUpdateRequest;
use App\Repositories\ServiceOrderRepository;
use App\Jobs\SendMail;


class ServiceOrdersController extends Controller
{

    /**
     * @var ServiceOrderRepository
     */
    protected $repository;
    protected $serviceMemberRepository;


    public function __construct(ServiceOrderRepository $repository, ServiceMemberRepository $serviceMemberRepository)
    {
        $this->repository = $repository;
        $this->serviceMemberRepository = $serviceMemberRepository;
    }


    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
     */
    public function index(Request $request)
    {

        $this->repository->with(['service', 'applyMember', 'provideMember'])->orderBy('id', 'desc');

        if ($request->has('status')) {
            $this->repository->where('status', '=', $request->input('status'));
        }

        if ($request->has('service_type')) {

            $this->repository->where('service_type', '=', $request->input('service_type'));


        }

        $serviceOrders = $this->repository->paginate();
        if (request()->wantsJson()) {

            return response()->json([
                'data' => $serviceOrders,
            ]);
        }

        return view('serviceOrders.index', compact('serviceOrders'));
    }

    /**
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {

        try {

            list($status, $serviceOrder) = $this->repository->create($request->all());

            $response = [
                'message' => 'ServiceOrder created.',
                'data' => $serviceOrder->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $serviceOrder = $this->repository->find($id);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $serviceOrder,
            ]);
        }

        return view('serviceOrders.show', compact('serviceOrder'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $serviceOrder = $this->repository->find($id);

        return view('serviceOrders.edit', compact('serviceOrder'));
    }


    /**
     * @param Request $request
     * @param $id
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {

        try {

            list($status, $serviceOrder) = $this->repository->update($id, $request->all());
            if ($request->has('check') && $request->input('check', false) == true) {
                $this->pushMessage($serviceOrder);
            }


            $response = [
                'message' => 'ServiceOrder updated.',
                'data' => $serviceOrder->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleted = $this->repository->delete($id);

        if (request()->wantsJson()) {

            return response()->json([
                'message' => 'ServiceOrder deleted.',
                'deleted' => $deleted,
            ]);
        }

        return redirect()->back()->with('message', 'ServiceOrder deleted.');
    }


    protected function pushMessage($serviceOrder)
    {
        try {

           // dispatch(new SendMail('24147287@qq.com;282880423@qq.com', '测试邮件', '测试内容', 'liushoukun66@gmail.com'));

            $host = app()->isLocal() ?'http://dev.gad.qq.com/': 'http://gad.qq.com/';
            $title = 'GAD资源对接服务的通知';
            $cc = 'susuhuang@tencent.com';
            $email = '';
            $content = [];

//            hatch/service/admin/apply/
//            hatch/service/admin/provide/
            // 服务类型1-IP,2-版号，3-办公场地，4-投融资，5-发行
            switch ($serviceOrder->service_type) {
                case 1: //1-IP
                    $content[] = '与你有关的一项IP合作申请（名称：'.$serviceOrder->service->name.'），合作状态已变更为“<span style="color: red">'.ServiceOrder::$statusList[($serviceOrder->status)].'</span>”';
                    $content[] = '开发者:'.$serviceOrder->applyMember->name;
                    $content[] = 'IP提供方:'.$serviceOrder->provideMember->name;
                    $content[] = '点击查看详情：'.'<a href="'.$host.'hatch/service/admin/apply/1">开发者</a>      '.'<a href="'.$host.'hatch/service/admin/provide/1">IP提供方</a>';

                    if($serviceOrder->applyMember->email){
                        $email .=  $serviceOrder->applyMember->email.';';
                    }

                    if ($serviceOrder->provideMember->email){
                        $email .=  $serviceOrder->provideMember->email.';';
                    }

                    break;
                case 2: //2-版号
                    $content[] = '你申请的版号服务，合作状态已变更为“<span style="color: red">'.ServiceOrder::$statusList[($serviceOrder->status)].'</span>”';
                    $content[] = '开发者:'.$serviceOrder->applyMember->name;
                    $content[] = '版号服务方:'.$serviceOrder->provideMember->name;
                    $content[] = '<a href="'.$host.'hatch/service/admin/apply/2">点击查看详情></a>';

                    if($serviceOrder->applyMember->email){
                        $email =  $serviceOrder->applyMember->email.';';
                    }


                    break;
                case 3: //3-办公场地

                    $content[] = '与你有关的一项办公场地申请，合作状态已变更为“<span style="color: red">'.ServiceOrder::$statusList[($serviceOrder->status)].'</span>”';
                    $content[] = '开发者:'.$serviceOrder->applyMember->name;
                    $content[] = '场地提供方:'.$serviceOrder->provideMember->name;
                    $content[] = '场地地址:'.$serviceOrder->service->office_address;
                    $content[] = '点击查看详情：'.'<a href="'.$host.'hatch/service/admin/apply/3">开发者</a>      '.'<a href="'.$host.'hatch/service/admin/provide/3">场地提供方</a>';

                    if($serviceOrder->applyMember->email){
                        $email .=  $serviceOrder->applyMember->email.';';
                    }

                    if ($serviceOrder->provideMember->email){
                        $email .=  $serviceOrder->provideMember->email.';';
                    }


                    break;
                case 4: //4-投融资

                    $content[] = '与你有关的一项投融资合作申请，合作状态已变更为“<span style="color: red">'.ServiceOrder::$statusList[($serviceOrder->status)].'</span>”';
                    $content[] = '开发者:'.$serviceOrder->applyMember->name;
                    $content[] = '投资方:'.$serviceOrder->provideMember->name;
                    $content[] = '点击查看详情：'.'<a href="'.$host.'hatch/service/admin/apply/4">开发者</a>      '.'<a href="'.$host.'hatch/service/admin/provide/4">投资方</a>';

                    if($serviceOrder->applyMember->email){
                        $email .=  $serviceOrder->applyMember->email.';';
                    }

                   // 获取所有投资方

                   $allMember  = $this->serviceMemberRepository->getAllMember(4);
                    foreach ($allMember as $Member ){
                        if($Member->email){
                            $email .=  $Member->email.';';
                        }
                    }

                    break;
                case 5: //5-发行

                    $content[] = '你申请的发行合作，合作状态已变更为“ <span style="color: red">'.ServiceOrder::$statusList[($serviceOrder->status)].'</span> ”';
                    $content[] = '开发者:'.$serviceOrder->applyMember->name;
                    $content[] = '发行方:'.$serviceOrder->provideMember->name;
                    $content[] = '<a href="'.$host.'hatch/service/admin/apply/5">点击查看详情></a>';

                    if($serviceOrder->applyMember->email){
                        $email .=  $serviceOrder->applyMember->email.';';
                    }

                    break;

            }



            if(app()->isLocal()){
                $email = 'v_yruiwang@tencent.com;';
                $email.= 'v_chwchen@tencent.com;';
                $email.= 'billyczhang@tencent.com;';
                $cc= 'v_shkliu@tencent.com;';
            }

            if($email != ''){
                    $mail = view('email.projectServiceOrder',
                        array(
                            'title'=>$title,
                            'content'=>$content,
                        )
                    )->render();
                   dispatch(new SendMail($email, $title, $mail,$cc));
                }


        } catch (\Exception $e) {
            return $e->getMessage();
        }

    }
}
