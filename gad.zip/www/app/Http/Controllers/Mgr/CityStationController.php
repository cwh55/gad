<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/3/15
 * Time: 5:25
 */

namespace App\Http\Controllers\Mgr;

use Auth;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Illuminate\Http\Request;
use Gate;
use App\Entities\CityStation;

require_once(dirname(__FILE__) . '/../../../Phpexcel/ExportExcel.php');

class CityStationController extends Controller
{
    //批量修改状态
    public function updateStatus(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $status = $params['status'];
        $ids = explode(",", $id);
        $rows = CityStation::whereIn('id', $ids)->update(array('status' => $status, 'updated_at' => time()));
        if ($rows > 0) {
            return json_encode(['data' => [], 'msg' => '修改成功', 'code' => '1']);
        } else {
            return json_encode(['data' => [], 'msg' => '修改失败', 'code' => '-1']);
        }
    }

    //获取城市站报名列表
    public function getCityStationList(Request $request)
    {
        return self::getCityStationListByType($request, 0);
    }

    //根据类型处理显示列表或者导出excle业务
    public function getCityStationListByType(Request $request, $type)
    {
        $result = ['total' => 0, 'hostname' => '', 'cityStationlist' => []];
        $page = $request->get('page', 1);
        $skip = ($page - 1) * 10;

        $entry = CityStation::query()->with("city");

        if ($request->has('city_id') && $request->input('city_id') != -1) {
            $entry->where('city_id', $request->input('city_id'));
        }

        if ($request->has('type') && $request->input('type') != -1) {
            $entry->where('type', $request->input('type'));
        }

        if ($request->has('group_type') && $request->input('group_type') != -1) {
            $entry->where('group_type', $request->input('group_type'));
        }

        if ($request->has('name')) {
            $str = $request->input('name');
            $entry->where('name', 'like', '%' . $str . '%');
        }

        if ($request->has('status') && $request->input('status') != -1) {
            $entry->where('status', $request->input('status'));
        }

        if ($request->has('user_id')) {
            $entry->where('user_id', $request->input('user_id'));
        }

        if ($request->has('mobile')) {
            $entry->where('mobile', $request->input('mobile'));
        }

        if ($request->has('qq')) {
            $entry->where('qq', $request->input('qq'));
        }

        if ($type == 0) {
            $result['total'] = $entry->count();
            $result['cityStationlist'] = $entry->skip($skip)->take(10)->orderBy('id', 'desc')->get();

            $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
            $result["hostname"] = $host;
            return response()->json($result);
        } else {
            $skip = ($page - 1) * 10;
            $result['cityStationlist'] = $entry->skip($skip)->take(500)->orderBy('id', 'desc')->get();
            return $result['cityStationlist'];
        }
    }

    //导出城市站报名列表excel(不分页)
    public function excelCityStationList(Request $request)
    {
        $arr = self::getCityStationListByType($request, 1);
        ini_set('memory_limit','1240M');
        set_time_limit(0);

        $getKeys = array('id', 'user_id', 'name', 'position', 'type', 'group_type', 'corp', 'members', 'game_name', 'game_type',
            'game_os', 'mobile', 'qq', 'created_at', 'city_id', 'status');
        //定义表格title
        $_totaltitle = array(
            'id' => 'ID',
            'user_id' => '用户ID',
            'name' => '姓名',
            'position' => '岗位',
            'type' => '报名类型',
            'group_type' => '团队/个人',
            'corp' => '公司名称',
            'members' => '团队人数',
            'game_name' => '游戏名称',
            'game_type' => '游戏类型',
            'game_os' => '操作平台',
            'mobile' => '手机',
            'qq' => 'QQ',
            'created_at' => '报名时间',
            'city_id' => '城市',
            'status' => '审核状态'
        );

        $fileName = "CityStationList";
        $excel = new  \ExportExcel();
        $excel->exportList($arr, $getKeys, $_totaltitle, $fileName);
    }

}