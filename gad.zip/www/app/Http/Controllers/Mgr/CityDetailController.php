<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/8/9
 * Time: 9:49
 */

namespace App\Http\Controllers\Mgr;

use App\Entities\User;
use Auth;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Illuminate\Http\Request;

use App\Repositories\CityActivityRepository;
use App\Repositories\CityBannerRepository;
use App\Repositories\CityNewsRepository;
use App\Repositories\CityPartnerRepository;
use App\Repositories\CityPlaceRepository;
use App\Repositories\CityProjectRepository;
use App\Repositories\CommentRepository;
//use App\Repositories\CommentRepositoryEloquent;

use App\Entities\CityBanner;
use App\Entities\CityNews;
use App\Entities\CityPartner;
use App\Entities\CityPlace;
use App\Entities\CityProject;
use App\Entities\CityActivity;
use App\Entities\Comment;
use App\Entities\HatchProject;

class CityDetailController extends Controller
{
    protected $bannerRepository;
    protected $newsRepository;
    protected $activityRepository;
    protected $commentRepository;
    protected $projectRepository;
    protected $placeRepository;
    protected $partnerRepository;
    protected $hatchProjectRepository;

    public function __construct(CityBannerRepository $banner, CityNewsRepository $news, CityActivityRepository $activity,
                                CommentRepository $comment, CityProjectRepository $project, CityPlaceRepository $place,
                                CityPartnerRepository $partner)
    {
        $this->bannerRepository = $banner;
        $this->newsRepository = $news;
        $this->activityRepository = $activity;
        $this->commentRepository = $comment;
        $this->projectRepository = $project;
        $this->placeRepository = $place;
        $this->partnerRepository = $partner;
    }

    //根据城市id、type查询城市站模块信息
    public function postCityList(Request $request)
    {
        $type = intval($request->get('type'));
        $cityId = intval($request->get('city_id'));

        $model = self::getModel($type);

        if ($type != 6) {
            $entry = $model->where("city_id", $cityId);
        } else {
            $entry = $model->with(['user'])->where("model_type", 'App\Entities\City')->where('model_id', $cityId);
        }

        if ($request->has('id')) {
            $entry->where('id', $request->input('id'));
        }
        if ($request->has('title')) {
            $entry->where('title', 'like', '%' . $request->input('title') . '%');
        }
        if ($request->has('begin_time') && $request->has('end_time')) {
            $entry->where("created_at", '>=', $request->input('begin_time'))
                ->where("created_at", '<=', $request->input('end_time'));
        }
        if ($request->has('project_id')) {
            $entry->where('project_id', $request->input('project_id'));
        }
        if ($request->has('name')) {
            $entry->where('name', 'like', '%' . $request->input('name') . '%');
        }
        if ($request->has('status')) {
            if ($request->input('status') != -1) {
                $entry->where('status', $request->input('status'));
            }
        }
        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';

        if ($type != 6) {
            $result = $entry->orderBy('order_no', 'desc')->paginate($request->get('pageSize', 10));
        } else {
            $result = $entry->orderBy('id', 'desc')->paginate($request->get('pageSize', 10));
        }

        return response()->json(['data' => $result, 'hostname' => $host]);
    }

    //查询详情
    public function postCityById(Request $request)
    {
        $type = intval($request->get('type'));
        $id = $request->input('id');

        $model = self::getModel($type);
        $arr = $model->find($id);

        return response()->json($arr);
    }

    //添加或更新
    public function postCityUpdate(Request $request)
    {
        $id = $request->input('id');
        $type = intval($request->get('type'));
        $param = $request->all();

        //留言板
        if ($type == 6) {
            $param["model_type"] = 'App\Entities\City';
            $param["model_id"] = $param["city_id"];
            //$param["status"]=1;
            $isExistCount = User::where("UserId", $param["user_id"])->count();
            if ($isExistCount <= 0) {
                return json_encode(['data' => [], 'msg' => '输入的用户id不存在', 'code' => '-1']);
            }
        }

        $model = self::getModel($type);

        if (empty($id) || $id == 0) {
            $arr = $model->create($param);
            $model->update($arr[1]->id, array("order_no"=>$arr[1]->id));
        } else {
            $arr = $model->update($id, $param);
        }

        if ($arr[0]) {
            return json_encode(['msg' => '操作成功', 'code' => 1]);
        } else {
            return json_encode(['msg' => '操作失败', 'code' => -1]);
        }
    }

    //删除
    public function postCityDel(Request $request)
    {
        $type = intval($request->get('type'));
        $id = $request->input('id');

        $model = self::getModel($type);
        $arr = $model->delete($id);

        if ($arr[0]) {
            return json_encode(['msg' => '删除成功', 'code' => 0]);
        } else {
            return json_encode(['msg' => '删除失败', 'code' => -1]);
        }
    }

    //上移或下移
    public function postCityMove(Request $request)
    {
        $city_type = intval($request->get('citytype'));
        $current_id = intval($request->get('current_id'));
        $current_sort = intval($request->get('current_sort'));
        $next_id = intval($request->get('next_id'));
        $next_sort = intval($request->get('next_sort'));

        switch ($city_type) {
            case 1:
                $this->bannerRepository->update($current_id, array("order_no"=>$next_sort));
                $arr = $this->bannerRepository->update($next_id, array("order_no"=>$current_sort));
                break;
            case 2:
                $this->newsRepository->update($current_id, array("order_no"=>$next_sort));
                $arr = $this->newsRepository->update($next_id, array("order_no"=>$current_sort));
                break;
            case 3:
                $this->activityRepository->update($current_id, array("order_no"=>$next_sort));
                $arr = $this->activityRepository->update($next_id, array("order_no"=>$current_sort));
                break;
            case 4:
                $this->projectRepository->update($current_id, array("order_no"=>$next_sort));
                $arr = $this->projectRepository->update($next_id, array("order_no"=>$current_sort));
                break;
            case 5:
                $this->placeRepository->update($current_id, array("order_no"=>$next_sort));
                $arr = $this->placeRepository->update($next_id, array("order_no"=>$current_sort));
                break;
            case 6:
                $this->commentRepository->update($current_id, array("order_no"=>$next_sort));
                $arr = $this->commentRepository->update($next_id, array("order_no"=>$current_sort));
                break;
            case 7:
                $this->partnerRepository->update($current_id, array("order_no"=>$next_sort));
                $arr = $this->partnerRepository->update($next_id, array("order_no"=>$current_sort));
                break;
        }

        if ($arr[0]) {
            return json_encode(['msg' => '移动成功', 'code' => 0]);
        } else {
            return json_encode(['msg' => '移动失败', 'code' => -1]);
        }
    }

    //置顶
    public function postCitySetTop(Request $request)
    {
        $type = intval($request->get('type'));
        $id = $request->input('id');
        switch ($type) {
            case 1:
                $para = array("order_no" => CityBanner::max('order_no') + 1);
                $arr = $this->bannerRepository->update($id, $para);
                break;
            case 2:
                $para = array("order_no" => CityNews::max('order_no') + 1);
                $arr = $this->newsRepository->update($id, $para);
                break;
            case 3:
                $para = array("order_no" => CityActivity::max('order_no') + 1);
                $arr = $this->activityRepository->update($id, $para);
                break;
            case 4:
                $para = array("order_no" => CityProject::max('order_no') + 1);
                $arr = $this->projectRepository->update($id, $para);
                break;
            case 5:
                $para = array("order_no" => CityPlace::max('order_no') + 1);
                $arr = $this->placeRepository->update($id, $para);
                break;
            case 6:
                $para = array("order_no" => Comment::max('order_no') + 1);
                $arr = $this->commentRepository->update($id, $para);
                break;
            case 7:
                $para = array("order_no" => CityPartner::max('order_no') + 1);
                $arr = $this->partnerRepository->update($id, $para);
                break;
        }
        if ($arr[0]) {
            return json_encode(['msg' => '置顶成功', 'code' => 0]);
        } else {
            return json_encode(['msg' => '置顶失败', 'code' => -1]);
        }
    }

    //留言板状态审核
    public function postSetCommentStatus(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $arr = $this->commentRepository->update($id, ['status' => $params['status']]);
        if ($arr[0]) {
            return json_encode(['msg' => '操作成功', 'code' => 0]);
        } else {
            return json_encode(['msg' => '操作失败', 'code' => -1]);
        }
    }

    //查询所有项目信息(已舍弃)
    public function getProjectAll()
    {
        $result = HatchProject::where("name", '!=', '')->select("id", "name")->orderby("id", "desc")->get();
        return $result;
    }

    public function getModel($type)
    {
        switch ($type) {
            case 1:
                $arr = $this->bannerRepository;
                break;
            case 2:
                $arr = $this->newsRepository;
                break;
            case 3:
                $arr = $this->activityRepository;
                break;
            case 4:
                $arr = $this->projectRepository;
                break;
            case 5:
                $arr = $this->placeRepository;
                break;
            case 6:
                $arr = $this->commentRepository;
                break;
            case 7:
                $arr = $this->partnerRepository;
                break;
        }

        return $arr;
    }

}