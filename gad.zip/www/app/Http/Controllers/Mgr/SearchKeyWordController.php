<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2018/1/3
 * Time: 8:15
 */

namespace App\Http\Controllers\Mgr;

use DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\SearchWordRepository;
use App\Repositories\SearchWordRepositoryEloquent;
use App\Entities\SearchWord;
use Carbon\Carbon;
use League\Flysystem\Exception;
use Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;

class SearchKeyWordController extends Controller
{
    public function __construct(SearchWordRepository $searchRepository)
    {
        $this->searchRepository = $searchRepository;
    }

    public function index()
    {
        $this->searchRepository->forgetCache();
        $this->searchRepository->where('deleted_at', null)->orderBy('id', 'desc');
        $keyWorkList = $this->searchRepository->paginate(10);
        return response()->json(['data' => $keyWorkList]);
    }

    public function destroy($id)
    {
        $deleted = $this->searchRepository->update($id, ['deleted_at' => Carbon::now()]);
        if ($deleted[0]) {
            return response()->json(['message' => '删除成功', 'deleted' => $deleted[0]]);
        } else {
            return response()->json(['message' => '删除失败', 'deleted' => $deleted[0]]);
        }
    }

    public function show($id)
    {
        $entry = $this->searchRepository->find($id);
        return response()->json(['data' => $entry]);
    }

    public function store(Request $request)
    {
        $data = $request->all();
        $data["created_at"] = Carbon::now();
        $rows = $this->searchRepository->create($data);
        if ($rows[0]) {
            return response()->json(['message' => '添加成功', 'isAdd' => $rows[0]]);
        } else {
            return response()->json(['message' => '添加失败', 'isAdd' => $rows[0]]);
        }
    }


    public function update(Request $request, $id)
    {
        $data = $request->all();
        $data["updated_at"] = Carbon::now();
        $rows = $this->searchRepository->update($id, $data);
        if ($rows[0]) {
            return response()->json(['message' => '修改成功', 'isUpdate' => $rows[0]]);
        } else {
            return response()->json(['message' => '修改失败', 'isUpdate' => $rows[0]]);
        }
    }


}