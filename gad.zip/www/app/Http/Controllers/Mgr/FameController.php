<?php

namespace App\Http\Controllers\Mgr;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Fame;
use Illuminate\Http\Request;
use Log;

class FameController extends Controller
{
    public function index(Request $request)
    {
        $result = ['total' => 0, 'famelist' => []];
        $page = $request->get('page', 1);
        $skip = ($page - 1) * 10;
        $famequery = Fame::query();
        if ($request->has('type')) {
            $famequery->where('type', $request->input('type'));
        }
        //$actconfig->where('status', 0);

        $result['total'] = $famequery->count();
        $result['famelist'] = $famequery->skip($skip)->take(10)->orderBy('id', 'desc')->get(['id', 'phase','class', 'name', 'name_description', 'is_read','view_cnt', 'is_comment','logo','status']);
        $result['maxPhase'] = $famequery->max('phase');

        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
        foreach ($result["famelist"] as $key=>$item) {
            $result["famelist"][$key]["hostname"] = $host;
        }

        return response()->json($result);
    }

    public function show($id)
    {
        $fame = Fame::findOrFail($id);

        return response()->json($fame);
    }

    public function store(Request $request)
    {
        $fame = Fame::create($request->all());
        return response()->json($fame);
    }

    public function update(Request $request, $id)
    {
        $fame = Fame::findOrFail($id);
        $fame->fill($request->all());
        $fame->save();

        return response()->json($fame);
    }

    public function destroy()
    {

    }

}
