<?php
/**
 * Created by PhpStorm.
 * User: v_shkliu
 * Date: 2017/8/9
 * Time: 14:00
 */

namespace App\Http\Controllers\Mgr;

use App\Repositories\HatchGameRepository;
use App\Repositories\HatchProjectRepository;
use App\Repositories\HatchProjectStructureRepository;
use App\Repositories\HatchRegisterRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Repositories\TagRepository;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;


/**
 * Class HatchProjectController
 * @package App\Http\Controllers\Mgr
 */
class HatchGameController extends Controller
{

    protected $repository;
    protected $hatchProjectRepository;
    protected $hatchProjectStructureRepository;
    /**
     * @var TagValidator
     */
    protected $validator;

    public function __construct(HatchGameRepository $hatchGameRepository, HatchProjectRepository $hatchProjectRepository, HatchProjectStructureRepository $hatchProjectStructureRepository)
    {
        $this->repository = $hatchGameRepository;
        $this->hatchProjectRepository = $hatchProjectRepository;
        $this->hatchProjectStructureRepository = $hatchProjectStructureRepository;
    }

    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
     */
    public function index(Request $request)
    {

        $this->repository->with(['user', 'project']);

        if ($request->has('game_id')) {
            $this->repository->where('game_id', '=', $request->input('game_id'));
        }

        if ($request->has('whereId')) {
            $this->repository->where('project_id', '=', $request->input('whereId'));
        }
        if ($request->has('user_id')) {
            $this->repository->where('user_id', '=', $request->input('user_id'));
        }
        if ($request->has('status')) {
            $this->repository->where('status', '=', $request->input('status'));
        }

        $data = $this->repository->orderBy('id', 'desc')->paginate(10);

        foreach ($data->items() as $li) {
            if ($li) {
                $li->setVisible([]);
                if ($li->project) {
                    $li->project->setVisible([]);
                }
            }
        }

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $data,
            ]);
        }

        return view('hatchProject.index', compact('hatchProject'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $expertPlan = $this->repository->find($id);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $expertPlan,
            ]);
        }

        return view('hatchProject.show', compact('hatchProject'));
    }


    /**
     * 新增
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {

        try {

            $data = $request->all();
//            $data['comment_count'] = count($data['section_comment']);
            $data['creator'] = Auth::user()['UserId'];
            list($status, $operation) = $this->repository->create($data);



            $response = [
                'message' => 'Operation created.',
                'data' => $operation,
            ];
            if ($request->wantsJson()) {

                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 更新
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function update(Request $request)
    {

        try {

            $data = $request->all();
            $data['updater'] = Auth::user()['UserId'];

            $project = $this->repository->find($data['id']);

            // 先操作再发邮件
            list($status, $operation) = $this->repository->update($data['id'], $data);

            if ($request->has('check') && 'check' == $request->input('check')) {
                // 更新project 的 动态配置
                // 项目不存在直接更新状态
                if ($project->project) {
                    // 审核通过进行更新
                    if ($data['status'] == 0) {
                        switch (($project->game_id)){
                            case 1:
                                $project->project->structure_id = $this->hatchProjectStructureRepository->where('game_id', $project->game_id)->findAll()->first()->id;
                                break;
                        }
                    }
                    $project->project->save();
                    $user = $project->project->team_contacts ? $project->project->team_contacts : $project->user->NickName;
                    switch (($project->game_id)){
                        case 1:
                            $title = '[GAD游戏创新大赛]报名审核结果通知';
                            $viewTmp = 'email.project';
                            break;
                        case 2:
                            $title = '[腾讯GAD·极光计划手游征集活动]报名审核结果通知';
                            $viewTmp = 'email.gameProject';
                            break;

                    }

                    // 邮箱不存在 不发送邮件
                    if ($project->project->team_email) {
                        $mail = view($viewTmp, array('user' => $user, 'name' => $project->project->name, 'status' => $data['status'], 'reason' => $request->input('reason')))->render();
                        \Tof::service('message')->sendEmail('gad@tencent.com', $project->project->team_email, $title, $mail);
                    }
                }
            }


            $response = [
                'code' => (int)$status,
                'message' => 'ok',
                'data' => $operation,
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 删除
     *
     * @param $id
     * @return \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        //暂时不能删除
        return response()->json([
            'message' => 'Operation deleted.',
            'deleted' => '1',
        ]);
        $deleted = $this->repository->delete($id);

        if (request()->wantsJson()) {

            return response()->json([
                'message' => 'hatchProject deleted.',
                'deleted' => $deleted,
            ]);
        }

        return redirect()->back()->with('message', 'Operation deleted.');

    }


}