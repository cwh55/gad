<?php

namespace App\Http\Controllers\Mgr;
use App\Models\Summercourse;
use App\Models\Teacher;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Gad\Upload;

class SummercourseController extends Controller
{

    public function postCreate(Request $request){
        $courseData = $request->all();
        $course = new Summercourse;
        $course->fill($courseData);
        $course->save();

    }
    public function postlist(Request $request){
        $courselist = Summercourse::where('status',0)->get();
        return $courselist;
    }
    public function postEdit(Request $request,$id){
        $course = Summercourse::findOrFail($id);

        $course->fill($request->all());
        $course->save();
    }
    public function postDelete(Request $request,$id){
        $course = Summercourse::findOrFail($id);

        $course->status = -1;
        $course->save();
    }
    public function postUploadImage(Request $request){
        $file = $request->file('file');
        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '上传失败：图片太大或格式不对']);
        }

        $result = Upload::uploadQcloudImage($file);

        return response()->json($result);
    }

    // 白名单
    public function getWhitelist(Request $request, $id){
        $summer = new Summercourse;
        $data = $summer->getWhitelist($id);
        if($data) {
            return response()->json(['code' => 0, 'data' => $data]);
        } else {
            return response()->json(['code' => -1, 'message' => '非白名单用户']);
        }
    }

    //保存动态配置
    public function setWhitelist(Request $request) {
        $data = $request->all();
        if(!empty($data['whitelist'])) {
            foreach($data['whitelist'] as $key => $val) {
                $res[$key] = str_replace(array(' ', '　','，'), array('', '', ','), $val);
            }
            $course = new Summercourse;
            $course->setWhitelist($res);
            return response()->json(['code' => 0, 'message' => '添加白名单成功！']);
        }
        return response()->json(['code' => -1, 'message' => '添加白名单失败！']);        
    }

    public function getTeacher(Request $request){
        $teachers = Teacher::where('type','=',2)->get(['id','user_id', 'head_img','position', 'name', 'desc']);

        return response()->json($teachers);
    }
}
