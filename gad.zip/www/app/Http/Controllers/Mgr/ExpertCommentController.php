<?php

namespace App\Http\Controllers\Mgr;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
//use Illuminate\Support\Facades\Auth;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Repositories\HatchProjectRepository;
use App\Repositories\ExpertCommentRepository;
use App\Repositories\ExpertPlanRepository;
use App\Entities\ExpertComment;
use App\Entities\HatchProject;

require_once(dirname(__FILE__) . '/../../../Phpexcel/ExportExcel.php');

class ExpertCommentController extends Controller
{
    protected $repository;
    protected $commentRepository;
    protected $planRepository;

    public function __construct(HatchProjectRepository $hatchProjectRepository, ExpertCommentRepository $expertCommentRepository, ExpertPlanRepository $expertPlanRepository)
    {
        $this->repository = $hatchProjectRepository;
        $this->commentRepository = $expertCommentRepository;
        $this->planRepository = $expertPlanRepository;
    }

    //项目列表
    public function postProjectList(Request $request)
    {
        return self::isExcelList($request, 0);
    }

    //导出项目列表
    public function getExcelCommentList(Request $request)
    {
        $arr = self::isExcelList($request, 1);

        $getKeys = array('id', 'name', 'expert_comment_count', 'avg_score', 'hatch_status');
        //定义表格title
        $_totaltitle = array(
            'id' => 'ID',
            'name' => '项目名称',
            'expert_comment_count' => '点评数',
            'avg_score' => '平均分',
            'hatch_status' => '是否加入扶持'
        );
        $fileName = "ExpertCommentList";
        $excel = new \ExportExcel();
        $excel->exportList($arr, $getKeys, $_totaltitle, $fileName);
    }

    public function isExcelList(Request $request, $isExcel)
    {
        if ($request->has('project_id')) {
            $this->repository->where('id', $request->input('project_id'));
        }

        $type = intval($request->input('type'));
        if ($type == 2) {
            $this->repository->where('hatch_status', '>', 0);
        } else {
            $this->repository->where('hatch_status', 0);
        }

        if ($request->has('hatch_status')) {
            if ($request->input('hatch_status') != -1) {
                $this->repository->where('hatch_status', $request->input('hatch_status'));
            }
        }

        if ($request->has('name')) {
            $this->repository->where('name', 'like', '%' . $request->input('name') . '%');
        }

        if ($request->has('ids')) {
            $ids = explode(",", $request->get('ids'));
            if (!empty($ids)) {
                $this->repository->whereIn("id", $ids);
            }
        }

        if ($isExcel == 0) {
            $data = $this->repository->orderBy('id', 'desc')->paginate($request->get('pageSize', 10));
        } else {
            $data = $this->repository->orderBy('id', 'desc')->findAll();
        }

        $res = $data->toArray();

        if ($isExcel == 0) {
            foreach ($res["data"] as $key => &$item) {
                $score = $this->getAvgScore($item["id"]);
                $item["avg_score"] = $score;
            }
            return response()->json(['data' => $res]);
        } else {
            foreach ($res as $key => &$item) {
                $score = $this->getAvgScore($item["id"]);
                $item["avg_score"] = $score;
            }
            return $res;
        }

    }

    //获取平均数
    public function getAvgScore($id)
    {
        $score = ExpertComment::where("deleted_at", null)->Where("project_id", $id)->Where("status", 0)->avg("score");
        return sprintf("%.2f", $score / 10);
    }

    //专家点评列表
    public function postCommentList(Request $request)
    {
        $projectId = intval($request->input("project_id"));
        $data = $this->commentRepository->with(['expertplan'])->where("gad_expert_comments.project_id", $projectId)
            ->where("gad_expert_comments.status", 0)
            ->orderBy('rank', 'desc')->findAll();
        return response()->json(['data' => $data, 'total' => count($data)]);
    }

    //修改扶持状态
    public function postUpdateJoinStatus(Request $request)
    {
        $status = intval($request->get('hatch_status'));
        $id = $request->input('id');
        $type = $request->input('type');

        if ($type == 1) {
            $para = array("hatch_status" => 1);//添加项目,相当于修改状态

            $count = $this->repository->find($id);
            if (!$count) {
                return json_encode(['msg' => '输入的项目ID不存在', 'code' => -1]);
            }

        } else {
            $para = array("hatch_status" => $status);
        }

        list($status, $res) = $this->repository->update($id, $para);

        if ($status) {
            return json_encode(['msg' => '操作成功', 'code' => 0]);
        } else {
            return json_encode(['msg' => '操作失败', 'code' => -1]);
        }

    }

    //上移或下移
    public function postSetMove(Request $request)
    {
        $movetype = intval($request->get('movetype'));
        $current_id = intval($request->get('current_id'));
        $current_sort = intval($request->get('current_sort'));
        $next_id = intval($request->get('next_id'));
        $next_sort = intval($request->get('next_sort'));

        //数据库里默认rank=0，为了实现上移、下移，批量更新一下
        if ($movetype == 1) {
            $data = $this->repository->Where("rank", 0)->where("hatch_status", '>', 0)->findAll(['id', 'created_at', 'rank']);
        } else {
            $data = $this->commentRepository->Where("rank", 0)->where("status", 0)->findAll(['id', 'created_at', 'rank']);
        }

        foreach ($data as $item) {
            if (empty($item->created_at)) {
                $time = time();
            } else {
                $time = strtotime($item->created_at);
            }

            if ($movetype == 1) {
                $this->repository->update($item->id, ['rank' => $time]);
            } else {
                $this->commentRepository->update($item->id, ['rank' => $time]);
            }

        }

        if ($movetype == 1) {
            $this->repository->update($current_id, array("rank" => $next_sort));
            list($status, $res) = $this->repository->update($next_id, array("rank" => $current_sort));
        } else {
            $this->commentRepository->update($current_id, array("rank" => $next_sort));
            list($status, $res) = $this->commentRepository->update($next_id, array("rank" => $current_sort));
        }

        if ($status) {
            return json_encode(['msg' => '移动成功', 'code' => 0]);
        } else {
            return json_encode(['msg' => '移动失败', 'code' => -1]);
        }
    }

    //修改点评
    public function postUpdateComment(Request $request)
    {
        $params = $request->all();
        $id = intval($params["id"]);
        $score = $params["score"];
        $comment = $params["comment"];

        $arr = array('comment' => $comment, 'score' => $score * 10);
        list($status, $res) = $this->commentRepository->update($id, $arr);

        if ($status) {
            return json_encode(['data' => $res, 'msg' => '修改成功', 'code' => 0]);
        } else {
            return json_encode(['data' => [], 'msg' => '修改失败', 'code' => -1]);
        }

    }

    //删除点评
    public function postDelComment(Request $request)
    {
        $id = intval($request->input("id"));
        $pid = intval($request->input("pid"));

        list($status, $res) = $this->commentRepository->delete($id);
        if ($status) {
            $project = $this->repository->find($pid);
            if ($project->expert_comment_count > 0) {
                $project->decrement("expert_comment_count");
            }
            return json_encode(['msg' => '删除成功', 'code' => 0]);
        } else {
            return json_encode(['msg' => '删除失败', 'code' => -1]);
        }
    }

    //扶持进展
    public function postProgressList(Request $request)
    {
        $data = $this->repository->where("id", $request->get("project_id"))->findAll(['progress_explan']);

        if (count($data) > 0) {
            $data = $data[0]["progress_explan"];
            if (count($data) > 0) {
                array_multisort(array_column($data, 'id'), SORT_DESC, $data);
            }
        }
        return response()->json(['data' => $data == null ? [] : $data]);
    }

    //添加、修改、删除进展、上移、下移
    public function postAddProgress(Request $request)
    {
        $id = intval($request->get("project_id"));
        $arr = $request->get("arr");
        $type = intval($request->get("type"));

        if ($type == 1) {
            $data = $this->repository->where("id", $id)->findAll(['progress_explan']);
            if ($data) {
                $count = count($arr);
                if ($count > 10) {
                    return json_encode(['msg' => '最多只能添加10条信息', 'code' => -2]);
                }
            }
        }

        array_multisort(array_column($arr, 'id'), SORT_DESC, $arr);

        list($status, $res) = $this->repository->update($id, array("progress_explan" => $arr));
        if ($status) {
            return json_encode(['msg' => '操作成功', 'code' => 0]);
        } else {
            return json_encode(['msg' => '操作失败', 'code' => -1]);
        }

    }

}