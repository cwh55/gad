<?php

namespace App\Http\Controllers\Mgr;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Entities\LoreTeacher;
use App\Repositories\LoreTeacherRepositoryEloquent;

class LoreTeacherController extends Controller
{
    protected $teacher;
    public function __construct(LoreTeacherRepositoryEloquent $teacher)
    {
        $this->teacher = $teacher;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $page = $request->get('page', 1);
        $skip = ($page - 1) * 10;
        $query = LoreTeacher::query();
        if ($request->get('tid')) {
            $query->where('id', $request->input('tid'));
        }
        if ($request->get('user_id')) {
            $query->where('user_id', $request->input('user_id'));
        }
        if ($request->get('nick')) {
            $query->where('nick', 'like','%'.$request->input('nick').'%');
        }
        $total = $query->count();
        $teacherlist = $query->skip($skip)->take(10)->orderBy('id', 'desc')->get();
        return response()->json(['total' => $total, 'teacherlist' => $teacherlist]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return response()->json(LoreTeacher::create($request->all()));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return response()->json($this->teacher->find($id));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        return response()->json($this->teacher->update($request->all(),$id));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return response()->json($this->teacher->delete($id));
    }
}
