<?php
/**
 * Created by PhpStorm.
 * User: v_shkliu
 * Date: 2017/5/10
 * Time: 16:00
 */

namespace App\Http\Controllers\Mgr;

use App\Gad\Helper\Tree;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use App\Repositories\TagRepository;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;


class TagController extends Controller
{
    /**
     * @var TagRepository
     */
    protected $repository;

    /**
     * @var TagValidator
     */
    protected $validator;

    public function __construct(TagRepository $repository)
    {
        $this->repository = $repository;
        $this->repository->forgetCache();
    }

    public function getList(Request $request)
    {
        $tag = $request->input('tag', 'hot');
        if ($tag == 'hot') {
            $this->repository->where('is_hot', '=', '1');
        } else {
            $this->repository->where('is_recommend', '=', 1);
        }
        $data = $this->repository->findAll();
        return response()->json($data);

    }

    /**
     * 获取tag tree
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getTagTreeList()
    {
        $tags = $this->repository->findAll();
        foreach ($tags as $k => $tag) {
            $tags[$k]['pid'] = $tag->pid;
            $tags[$k]['text'] = $tag->name;
        }
        $tags = Tree::makeTree($tags, [
            'parent_key' => 'pid',
            /* 孩子节点属性 */
            'children_key' => 'nodes',
        ]);
        return response()->json($tags);

    }

    /**
     * 新增
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        try {
            $this->validate($request,
                [
                    'pid' => 'bail|required',
                    'name' => 'bail|required|unique:gad_tags',
                    'alias' => 'bail|required',
                ], [
                    'pid.required' => 'PID不能为空',
                    'name.required' => '标签名不能为空',
                    'alias.required' => '别名不能为空',
                ]
            );

            $data = $request->all();
            //获取父节点
            if ($data['pid']) {
                $tag = $this->repository->find($data['pid']);

                if (!$tag) {
                    throw new ValidatorException(new MessageBag(['pid' => 'pid error']));
                }

                switch ($tag->lvl) {
                    case  '1':
                        $data['p'] = $tag['id'];
                        $data['p1'] = $tag['id'];
                        $data['lvl'] = 2;
                        break;
                    case  '2':
                        $data['p'] = $tag['id'];
                        $data['p1'] = $tag['p1'];
                        $data['p2'] = $tag['id'];
                        $data['lvl'] = 3;
                        break;
                    case  '3':
                        $data['p'] = $tag['id'];
                        $data['p1'] = $tag['p1'];
                        $data['p2'] = $tag['p2'];
                        $data['p3'] = $tag['id'];
                        $data['lvl'] = 4;

                        break;
                    case  '4':

                        $data['p'] = $tag['id'];
                        $data['p1'] = $tag['p1'];
                        $data['p2'] = $tag['p2'];
                        $data['p3'] = $tag['p3'];
                        $data['p4'] = $tag['id'];
                        $data['lvl'] = 5;
                        break;
                    case  '5':
                        throw new ValidatorException(new MessageBag(['pid' => 'lsat node']));
                        break;
                }
            } else {
                //根节点
                $data['lvl'] = 1;

            }
            list($status, $operation) = $this->repository->create($data);
            $response = [
                'message' => 'Operation created.',
                'data' => $operation,
            ];
            if ($request->wantsJson()) {

                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 更新
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function update(Request $request)
    {

        try {
            $this->validate($request,
                [
                    'id' => 'bail|required',
                    'name' => 'bail|required',
                    'alias' => 'bail|required',
                ], [
                    'id.required' => 'PID不能为空',
                    'name.required' => '标签名不能为空',
                    'alias.required' => '别名不能为空',
                ]
            );
            $data = $request->all();
            $findTags = $this->repository->where('name', '=', $data['name'])->where('id', '<>', $data['id'])->findAll();
            if ($findTags->isEmpty()) {
                list($status, $operation) = $this->repository->update($data['id'], $data);
                $response = [
                    'code' => (int)$status,
                    'message' => 'ok',
                    'data' => $operation,
                ];
            } else {
                $response = [
                    'code' => -1,
                    'message' => '标签名已存在',
                ];
            }


            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 删除
     *
     * @param $id
     * @return \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        //暂时不能删除
        return response()->json([
            'message' => 'Operation deleted.',
            'deleted' => '1',
        ]);
        $deleted = $this->repository->delete($id);

        if (request()->wantsJson()) {

            return response()->json([
                'message' => 'Operation deleted.',
                'deleted' => $deleted,
            ]);
        }

        return redirect()->back()->with('message', 'Operation deleted.');

    }


}