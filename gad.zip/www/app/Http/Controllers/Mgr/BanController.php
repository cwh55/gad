<?php
/**
 * Created by PhpStorm.
 * User: v_shkliu
 * Date: 2017/8/15
 * Time: 09:39
 */

namespace App\Http\Controllers\Mgr;

use App\Entities\Ban;
use App\Repositories\BanRepository;
use App\Repositories\HatchGameRepository;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Repositories\TagRepository;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;


/**
 * Class HatchProjectController
 * @package App\Http\Controllers\Mgr
 */
class BanController extends Controller
{
    /**
     * @var TagRepository
     */
    protected $repository;
    /**
     * @var TagValidator
     */
    protected $validator;

    public function __construct(BanRepository $banRepository)
    {
        $this->repository = $banRepository;
        $this->repository->forgetCache();
    }

    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
     */
    public function index(Request $request)
    {
        if ($request->has('user_id')) {
            $this->repository->where('user_id', $request->input('user_id'));
        }
        if ($request->has('type')) {
            $this->repository->where('type', $request->input('type'));
        }
        if ($request->has('ip')) {
            $this->repository->where('ip', $request->input('ip'));
        }


        $data = $this->repository->with(['user'])->orderBy('id', 'desc')->paginate(10);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $data,
            ]);
        }

        return view('hatchProject.index', compact('hatchProject'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $expertPlan = $this->repository->find($id);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $expertPlan,
            ]);
        }

        return view('hatchProject.show', compact('hatchProject'));
    }


    /**
     * 新增
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {

        try {

            $data = $request->all();
            $data['creator'] = Auth::user()['RTXName'];

            $data['expire'] = $this->repository->getExpire($data['duration']);

            if ($data['type'] == Ban::TYPE_IP) {
                $ban = $this->repository->where('ip', $data['ip'])->where('type', Ban::TYPE_IP)->findAll();
            } elseif ($data['type'] == Ban::TYPE_USER) {
                $ban = $this->repository->where('user_id', $data['user_id'])->where('type', Ban::TYPE_USER)->findAll();
            }

            if (!$ban->isEmpty()) {
                $ban = $ban[0];
                list($status, $operation) = $this->repository->update($ban['id'], $data);
            } else {
                list($status, $operation) = $this->repository->create($data);
            }

            $response = [
                'message' => 'Operation created.',
                'data' => $operation,
            ];
            if ($request->wantsJson()) {

                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 更新
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function update(Request $request)
    {

        try {

            $data = $request->all();
            $data['updater'] = Auth::user()['UserId'];
            list($status, $operation) = $this->repository->update($data['id'], $data);
            $response = [
                'code' => (int)$status,
                'message' => 'ok',
                'data' => $operation,
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 删除
     *
     * @param $id
     * @return \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {

        $deleted = $this->repository->delete($id);

        if (request()->wantsJson()) {

            return response()->json([
                'message' => 'hatchProject deleted.',
                'deleted' => $deleted,
            ]);
        }

        return redirect()->back()->with('message', 'Operation deleted.');

    }


}