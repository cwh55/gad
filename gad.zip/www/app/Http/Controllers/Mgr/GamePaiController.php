<?php
/**
 * Created by PhpStorm.
 * User: v_shkliu
 * Date: 2017/5/10
 * Time: 16:00
 */

namespace App\Http\Controllers\Mgr;

use App\Gad\Helper\Tree;
use App\Repositories\GamePaiCodeRepository;
use App\Repositories\GamePaiRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\MessageBag;
use App\Repositories\TagRepository;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;


class GamePaiController extends Controller
{
    /**
     * @var TagRepository
     */
    protected $repository;
    protected $gamePaiCodeRepository;

    /**
     * @var TagValidator
     */
    protected $validator;

    public function __construct(GamePaiRepository $repository, GamePaiCodeRepository $gamePaiCodeRepository)
    {
        $this->repository = $repository;
        $this->gamePaiCodeRepository = $gamePaiCodeRepository;
//        $this->repository->forgetCache();
    }

    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
     */
    public function index(Request $request)
    {

        $data = $this->repository->orderBy('id','desc')->paginate(10);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $data,
            ]);
        }

        return view('expertPlans.index', compact('expertPlans'));
    }


    public function getAllList(Request $request)
    {

        $data = $this->repository->where('status','0')->orderBy('id','desc')->findAll();

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $data,
            ]);
        }

        return view('expertPlans.index', compact('expertPlans'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $expertPlan = $this->repository->find($id);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $expertPlan,
            ]);
        }

        return view('expertPlans.show', compact('expertPlan'));
    }


    /**
     * 新增
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {

        try {

            $data = $request->all();
//            $data['comment_count'] = count($data['section_comment']);
            $data['creator'] = Auth::user()['UserId'];
            list($status, $operation) = $this->repository->create($data);
            $response = [
                'message' => 'Operation created.',
                'data' => $operation,
            ];
            if ($request->wantsJson()) {

                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 更新
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function update(Request $request)
    {

        try {

            $data = $request->all();
//            $data['comment_count'] = count($data['section_comment']);
            $data['updater'] = Auth::user()['UserId'];

            list($status, $operation) = $this->repository->update($data['id'], $data);
            $response = [
                'code' => (int)$status,
                'message' => 'ok',
                'data' => $operation,
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 删除
     *
     * @param $id
     * @return \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        //暂时不能删除
        return response()->json([
            'message' => 'Operation deleted.',
            'deleted' => '1',
        ]);
        $deleted = $this->repository->delete($id);

        if (request()->wantsJson()) {

            return response()->json([
                'message' => 'Operation deleted.',
                'deleted' => $deleted,
            ]);
        }

        return redirect()->back()->with('message', 'Operation deleted.');

    }


    public function importCode($id, Request $request)
    {

        $file = $request->file('file');
        $file_type = $file->getClientOriginalExtension();

        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '上传失败：文件太大或格式不对']);
        }


        /*判别是不是.xls文件，判别是不是excel文件*/
        if (strtolower($file_type) != "xls" && strtolower($file_type) != "xlsx") {
            return response(['code' => 1, 'message' => '不是Excel文件，请重新上传'], 400);

        }

        $filePath = $file->getPathname();

        $file = dirname(__FILE__) . '/../../../Phpexcel/';
        require $file . 'PHPExcel.php';
        //$filePath = $file . $filename;

        try {
            //实例化PHPExcel类
            $PHPExcel = new \PHPExcel();

            //默认用excel2007读取excel，若格式不对，则用之前的版本进行读取
            $PHPReader = new \PHPExcel_Reader_Excel2007();
            if (!$PHPReader->canRead($filePath)) {
                $PHPReader = new \PHPExcel_Reader_Excel5();
                if (!$PHPReader->canRead($filePath)) {
                    return response()->json(['code' => 1, 'message' => '上传失败：文件为空']);
                }
            }

            //读取Excel文件
            $PHPExcel = $PHPReader->load($filePath);
            //读取excel文件中的第一个工作表
            $sheet = $PHPExcel->getSheet(0);
            //取得最大的行号
            $allRow = $sheet->getHighestRow();

            for ($currentRow = 1; $currentRow <= $allRow; $currentRow++) {
                //获取A列的值   英文名
                $rowData = [];
                $rowData['code'] = $PHPExcel->getActiveSheet()->getCell("A" . $currentRow)->getValue();
                $rowData['game_pai_id'] = $id;
                $data[] = $rowData;
                $this->gamePaiCodeRepository->create($rowData);
            }
            $repository = $this->repository->find($id);
            $repository->update(['sms_code' => ($repository->sms_code + count($data))]);
            // 添加数据到
            return response()->json(['code' => 0, 'message' => '导入成功']);
        } catch (Exception $ex) {
            return response()->json(['code' => 1, 'message' => "系统异常"]);
        }
    }


    public function getMaxPhase(Request $request)
    {
        $res = $this->repository->orderBy('phase', 'desc')->limit(1)->findAll();
        return response()->json([
            'code' => 0,
            'data' => $res[0]['phase'],
        ]);
    }


}