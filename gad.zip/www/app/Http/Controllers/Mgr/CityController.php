<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/8/8
 * Time: 8:37
 */

namespace App\Http\Controllers\Mgr;

use Auth;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Illuminate\Http\Request;
use Gate;
use App\Entities\City;
use App\Repositories\CityRepository;

class CityController extends Controller
{
    protected $cityRepository;

    public function __construct(CityRepository $city)
    {
        $this->cityRepository = $city;
    }

    //查询城市信息
    public function postCityList(Request $request)
    {
        $this->cityRepository->forgetCache();
        $result = $this->cityRepository->orderBy('id', 'desc')->paginate($request->get('pageSize', 10));
        return response()->json(['data' => $result]);
    }

    //根据id查询城市信息
    public function postCityInfoWhere(Request $request)
    {
        $id = intval($request->get('id'));
        $entry = $this->cityRepository->find($id);
        return response()->json($entry);
    }

    //所有城市信息
    public function getCityAll()
    {
        $result = City::where("deleted_at", null)->select("id", "name")->get();
        return response()->json($result);
    }

    //添加或修改
    public function postCityUpdate(Request $request)
    {
        $id = $request->input('id');
        $name = $request->input('name');

        if (empty($id)) {
            $isExistCount = $this->cityRepository->findBy('name', $name);
            if ($isExistCount > 0) {
                return json_encode(['data' => [], 'msg' => '城市已存在', 'code' => '-1']);
            }

            $arr = $this->cityRepository->create($request->all());
            //$par["created_at"] = date('Y-m-d H:i:s', time());
            if ($arr[0]) {
                $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
                $url=$host."/hatch/city/detail/".$arr[1]->id;
                $this->cityRepository->update($arr[1]->id, array("url"=>$url));

                return json_encode(['data' => $arr, 'msg' => '添加成功', 'code' => 1]);
            } else {
                return json_encode(['data' => $arr, 'msg' => '添加失败', 'code' => -1]);
            }

        } else {
            $saveDepart = $this->cityRepository->find($id);
            $isExistCount = City::where('name', $name)->where('name', '!=', $saveDepart->name)->count();
            if ($isExistCount > 0) {
                return json_encode(['msg' => '城市已存在', 'code' => '-1']);
            }

            $params = $request->all();
            //$params["updated_at"] =date('Y-m-d H:i:s', time());

            $arr = $this->cityRepository->update($id, $params);
            if ($arr[0]) {
                return json_encode(['msg' => '修改成功', 'code' => 1]);
            } else {
                return json_encode(['msg' => '修改失败', 'code' => -1]);
            }
        }


    }

    //删除
    public function postCityDel(Request $request)
    {
        $id = $request->input('id');
        $arr = $this->cityRepository->delete($id);
        if ($arr[0]) {
            return json_encode(['msg' => '删除成功', 'code' => 1]);
        } else {
            return json_encode(['msg' => '删除失败', 'code' => -1]);
        }
    }


}