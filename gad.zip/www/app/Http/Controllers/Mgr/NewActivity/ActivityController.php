<?php
/**
 * Created by PhpStorm.
 * User: v_shkliu
 * Date: 2017/8/9
 * Time: 14:00
 */

namespace App\Http\Controllers\Mgr\NewActivity;

use App\Repositories\ActivityRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;


/**
 * Class HatchProjectController
 * @package App\Http\Controllers\Mgr
 */
class ActivityController extends Controller
{

    protected $repository;

    /**
     * @var TagValidator
     */
    protected $validator;

    public function __construct(ActivityRepository $activityRepository)
    {
        $this->repository = $activityRepository;
    }

    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
     */
    public function index(Request $request)
    {

//        $this->repository->with(['user', 'project']);

        if ($request->has('user_id')) {
            $this->repository->where('user_id', '=', $request->input('user_id'));
        }
        if ($request->has('status')) {
            $this->repository->where('status', '=', $request->input('status'));
        }

        if ($request->has('whereId')) {
            $this->repository->where('id', '=', $request->input('whereId'));
        }

        $data = $this->repository->orderBy('id', 'desc')->paginate(10);

        return response()->json([
            'data' => $data->toArray(),
        ]);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $data,
            ]);
        }

        return view('activity.index', compact('activity'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $activity = $this->repository->find($id);
        if (request()->wantsJson()) {
            return response()->json([
                'data' => $activity,
            ]);
        }

        return view('activity.show', compact('activity'));
    }


    /**
     * 新增
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {

        try {

            $data = $request->all();
            $data['creator'] = Auth::user()['UserId'];
            $data['user_id'] = Auth::user()['UserId'];
            list($status, $activity) = $this->repository->create($data);
            $response = [
                'message' => 'user_id created.',
                'data' => $activity,
            ];
            if ($request->wantsJson()) {

                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 更新
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function update(Request $request)
    {

        try {

            $data = $request->all();
            $data['updater'] = Auth::user()['UserId'];

            list($status, $activity) = $this->repository->update($data['id'], $data);
            $response = [
                'code' => (int)$status,
                'message' => 'ok',
                'data' => $activity,
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 删除
     *
     * @param $id
     * @return \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {

        $deleted = $this->repository->delete($id);

        if (request()->wantsJson()) {

            return response()->json([
                'message' => 'Activity deleted.',
                'deleted' => $deleted,
            ]);
        }

        return redirect()->back()->with('message', 'Activity deleted.');

    }


}