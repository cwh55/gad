<?php

namespace App\Http\Controllers\Mgr;
use Auth;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Illuminate\Http\Request;
use Debugbar;
use App\Repositories\LiveRepositoryEloquent;
use App\Repositories\LiveSignRepositoryEloquent;
use App\Repositories\UserRepositoryEloquent;
use App\Models\User;
use App\Models\Live;
use App\Models\LiveSign;
use App\Qcloud\Qcloud;
use App\Gad\Upload;
use Gate;
use App\Gad\Midas;

class LivesController extends Controller
{
    protected $user_id = '';
    protected $live;
    protected $messageRepository;
    protected $sign;
    protected $user;

    public function __construct(LiveRepositoryEloquent $live,LiveSignRepositoryEloquent $sign,UserRepositoryEloquent $user)
    {
        $this->live = $live;
        $this->sign = $sign;
        $this->user = $user;
    }

    public function getLiveInfoList(Request $request)
    {
        $entry = Live::query();

        if ($request->has('id')) {
            $entry->where('id', $request->input('id'));
        }

        if ($request->has('name')) {
            $str = $request->input('name');
            $entry->where('name','like','%'.$str.'%');
        }

        if ($request->has('tips') && $request->input('tips') != -1) {
            $entry->where('tips', $request->input('tips'));
        }

        if ($request->has('state') && $request->input('state') != -1) {
            $entry->where('state', $request->input('state'));
        }

        if ($request->has('rowstatus') && $request->input('rowstatus') != -1) {
            $entry->where('rowstatus', $request->input('rowstatus'));
        }

        if ($request->has('class') && $request->input('class') != -1) {
            $entry->where('class', $request->input('class'));
        }

        if ($request->has('type') && $request->input('type') != -1) {
             $type=$request->input('type');

            $nowTime=date('Y-m-d H:i:s',time());

            $lastDate=date("Y-m-d",strtotime("$nowTime -1 day"));//昨天
            $nextDate=date("Y-m-d",strtotime("$nowTime +1 day"));//明天

            $nextThreeDate=date("Y-m-d",strtotime("$nowTime +4 day"));
            $nextSeverDate=date("Y-m-d",strtotime("$nowTime +8 day"));

            $day=date('d')+1;
            $firstday = date('Y-m-01', strtotime($nowTime));
            $nextMonthDate = date('Y-m-d', strtotime("$firstday +1 month $day day"));

              if($type==0)  //今天内
              {
                  $entry->where('lives.begin_time', '>', $lastDate)->where('lives.end_time','<',$nextDate);
              }
              else if($type==1)  //未来三天内
              {
                  $entry->where('lives.begin_time', '>', $nextDate)->where('lives.end_time','<',$nextThreeDate);
              }
              else if($type==2)  //未来一周内
              {
                  $entry->where('lives.begin_time', '>', $nextDate)->where('lives.end_time','<',$nextSeverDate);

              }else if($type==3)  //未来一个月内
              {
                  $entry->where('lives.begin_time', '>', $nextDate)->where('lives.end_time','<',$nextMonthDate);

              }else if($type==4)  //已结束
              {
                  $entry->where('lives.end_time','<',$nowTime);
              }
        }

        if ($request->has('sort') && $request->input('sort') != -1) {
            $sort=$request->input('sort');

            if($sort==0)  //时间倒序
            {
                $entry =$entry->orderBy('created_at', 'desc');
            }
            else if($sort==1)  //时间正序
            {
                $entry =$entry->orderBy('created_at', 'asc');

            }else if($sort==2)  //报名人数从多到少
            {
                $entry =$entry->orderBy('sign_num', 'desc');
            }else if($sort==3)  //报名人数从少到多
            {
                $entry =$entry->orderBy('sign_num', 'asc');
            }
        }else
        {
            $entry =$entry->orderBy('id', 'desc');
        }
        $result = $entry->paginate($request->get('pageSize',10));

        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
        foreach ($result as $key=>$item) {
            $result[$key]["hostname"] = $host;
        }

        return response()->json($result);
    }

    public function getLiveInfoById(Request $request)
    {
        $entry = Live::findOrFail($request->input('id'));
        return response()->json($entry);
    }


    //修改审核状态
    public function updateLiveState(Request $request){
        return self::updateLiveStatus($request,0);
    }

    //修改关闭状态
    public function updateLiveRowstatus(Request $request){
        return self::updateLiveStatus($request,0);
    }

    //修改状态-存储库的方式
    public function updateLiveStatus(Request $request,$type)
   {
       $params=$request->all();
       $id = $params['id'];
       if(isset($params['rowstatus'])){
           if($params['rowstatus']==0) {
               $countJb = LiveSign::where('live_signs.live_id', '=', $id)->where('type', '=', 1)->count();
               if ($countJb <= 0) {
                   return json_encode(['data' => [], 'msg' => '该live未添加嘉宾,不能通过。','id'=>$id,'state'=>$params['rowstatus'], 'code' => '-1']);
               }
           }
       }

       $lives = $this->live->updateLive($this->live,$params,$id);
       if ($request->wantsJson()) {
           if($type==0) {
               return json_encode(['data' => [], 'msg' => '','id'=>$lives->id,'state'=>$lives->rowstatus, 'code' => '1']);
           }else
           {
               return json_encode(['data' => [], 'msg' => '','id'=>$lives->id, 'code' => '1']);
           }
       }else
       {
           return json_encode(['data' => [], 'msg' => '修改失败', 'code' => '-1']);
       }
   }

    //修改live信息
    public function updateSignLive(Request $request,$type)
    {
        $params=$request->all();
        $id = $params['id'];
        $lives = $this->sign->updateLiveSign($this->sign,$params,$id);
        if ($request->wantsJson()) {
            if($type==0) {
                return $lives->id;
            }else
            {
                return json_encode(['data' => [], 'msg' => '', 'code' => '1']);
            }
        }else
        {
            return json_encode(['data' => [], 'msg' => '修改失败', 'code' => '-1']);
        }
    }


    //修改或添加Live信息
    public function addOrUpdateLiveInfo(Request $request){
        $txtLiveName=$request->input('name');
        $beginTime=$request->input('begin_time');
        $id=$request->input('id');
        $endTime=$request->input('end_time');
        $sltClass=$request->input('class');
        $txtDescription=$request->input('description');
        $sign_num=$request->input('sign_num');
        $sign_count=$request->input('sign_count');
        $tagInput=$request->input('tags');
        $txtPrice=$request->input('price');
        $userId =Auth::user()['UserId'];

        if(empty($id))
        {
            $isExistCount=Live::query()->where('name', $txtLiveName)->count();
            if($isExistCount>0)
            {
                return json_encode(['data' => [], 'msg' => 'live标题已存在', 'code' => '-1']);
            }

            $params=array("name"=>$txtLiveName,"begin_time"=>$beginTime,"end_time"=>$endTime,"class"=>$sltClass,
                "description"=>$txtDescription,"tags"=>$tagInput,"sign_num"=>$sign_num,"sign_count"=>$sign_count,"rowstatus"=>1,
                "state"=>0,"tips"=>0,"price"=>$txtPrice, "creator"=>$userId,"created_at"=>time());

            $rows= Live::create($params)->id;
            if($rows<=0)
            {
                return json_encode(['data' => [], 'msg' => '添加失败', 'code' => '-1']);
            }
        }else
        {
            $saveDepart = Live::findOrFail($id);
            $isExistCount=Live::query()->where('name', $txtLiveName)->where('name','!=', $saveDepart->name)->count();
            if($isExistCount>0)
            {
                return json_encode(['data' => [], 'msg' => 'live标题已存在', 'code' => '-1']);
            }
            return self::updateLiveStatus($request,1);
        }

        return json_encode(['data' => [], 'msg' => '', 'code' => 1]);
    }

    //live管理员信息
    public function getAdminInfoList(Request $request)
    {
        $entry = LiveSign::query()->with('live')->with('user');

        $entry->whereHas('live', function ($query){
            $query->where('rowstatus',"!=",2);//已删除的不出现在列表中
        });

        if ($request->has('nickname')) {
            $str = $request->input('nickname');
            $entry->where('live_signs.nickname','like','%'.$str.'%');
        }

        $name = $request->input('name', '');
        if (!empty($name)) {
            $entry->whereHas('live', function ($query) use ($name) {
                $query->where('name', 'like', "%$name%");
            });
        }

        if ($request->has('type') && $request->input('type') != -1) {
            $entry->where('live_signs.type',$request->input('type'));
        }
        $result = $entry->orderBy('live_signs.id', 'desc')->paginate($request->get('pageSize',10));
        return response()->json($result);
    }

    public function getAdminInfoById(Request $request)
    {
        $entry = LiveSign::findOrFail(intval($request->input('id')));
        return response()->json($entry);
    }

    //获取所有的Live，用于下拉选择
    public function getLiveInfo()
    {
        $result = ['liveInfolist' => []];
        $entry = Live::query()->select("id",'name')->where('lives.rowstatus','!=',2);
        $result['liveInfolist'] = $entry->orderBy('lives.id', 'desc')->get();
        return response()->json($result);
    }

    //修改或添加Live管理员、嘉宾、报名信息
    public function addOrUpdateAdminInfo(Request $request){
        $id=$request->input('id');
        $live_id=$request->input('live_id');
        $user_id=$request->input('user_id');
        $type=$request->input('type');
        $description=$request->input('description');
        $nickname=$request->input('nickname');
        $avatar=$request->input('avatar');

        $userCount=User::where('UserId', $user_id)->count();
        if($userCount<=0)
        {
            return json_encode(['data' => [], 'msg' => '用户id不存在,请重新输入', 'code' => '-1']);
        }

        $userId =Auth::user()['UserId'];

        if(empty($id))
        {
            $countUser = LiveSign::where('live_signs.live_id', $live_id);
            if($type==1) {
                $jiabin = $countUser;
                $countJb = $jiabin->where('type',1)->count();
                if ($countJb >= 5) {
                    return json_encode(['data' => [], 'msg' => '一个live最多只能添加5个嘉宾', 'code' => '-1']);
                }
            }

            $count=$countUser->where('user_id', $user_id)->where('type',$type)->count();
            if($count>0)
            {
                return json_encode(['data' => [], 'msg' => '该用户已经在同一个Live中创建过信息了,请修改后再提交', 'code' => '-1']);
            }

            $params=array("live_id"=>$live_id,"type"=>$type,"user_id"=>$user_id,"description"=>$description,
                "nickname"=>$nickname,"avatar"=> $avatar,"creator"=>$userId,"created_at"=>time());

            $rows= LiveSign::create($params)->id;
            if($rows<=0)
            {
                return json_encode(['data' => [], 'msg' => '添加失败', 'code' => '-1']);
            }else
            {
                if($type==3)  //报名
                {
                    Live::where('id', $live_id)->increment("sign_count", 1);
                }
                return json_encode(['data' => [], 'msg' => '', 'code' => 1]);
            }
        }else
        {
            /*$saveDepart = LiveSign::findOrFail($id);
            $isExistCount=LiveSign::query()->where('user_id', $user_id)->where('user_id','!=', $saveDepart->user_id)->count();
            if($isExistCount>0)
            {
                return json_encode(['data' => [], 'msg' => '该用户已经在同一个Live中创建过信息了,请修改后再提交', 'code' => '-1']);
            }*/

           return self::updateSignLive($request,1);
        }
    }



    //上传嘉宾头像
    public function postUploadImage(Request $request)
    {
        $file = $request->file('file');
        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '上传失败：图片太大或格式不对']);
        }
        $result = Upload::uploadQcloudImage($file);
        return response()->json($result);
    }


}