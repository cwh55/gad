<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2018/1/23
 * Time: 9:23
 */

namespace App\Http\Controllers\Mgr;

use App\Entities\Question;
use App\Entities\WendaActivity;
use App\Http\Controllers\Controller;
use App\Gad\MessageType;
use App\Jobs\SendMessage;
use App\Models\User;
use App\Gad\Func;
use Auth;
use App\Http\Requests;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Entities\Archive;
use App\Repositories\ArchiveRepository;
use App\Repositories\ArchiveRepositoryEloquent;

class WendaActivityController extends Controller
{
    protected $archiveEloquent;
    private $cmttypes = array(1 => 'App\Entities\WendaActivity');

    public function __construct(ArchiveRepositoryEloquent $archive, Archive $ar)
    {
        $this->archiveEloquent = $archive;
        $this->archives = $ar;
    }

    //获取社区首页内容库-根据类型
    public function postQuestionList(Request $request)
    {
        $id = $request->input('id');
        $userid = $request->input('userid');
        $user_name = $request->input('name', '');
        $ques = $request->input('title', '');
        $status = intval($request->input('status'));
        $is_hot = intval($request->input('is_hot'));
        $is_top = intval($request->input('is_top'));
        $qq = $request->input('qq');
        $begin_time = $request->input('begin_time');
        $end_time = $request->input('end_time');
        $pageSize = 30;

        $contentlist = $this->archives->withTrashed()->with('user')->with('question')->where("gad_archives.from_activity", '>', 0);

        $obj_type = $this->cmttypes[1];
        $contentlist->whereHas('question', function ($query) use ($obj_type) {
            $query->where('gad_questions.obj_type', $obj_type);
        });

        $id = intval($id);
        if ($id > 0) {
            $contentlist->where('gad_archives.id', $id);
        }

        $userid = intval($userid);
        if ($userid > 0) {
            $contentlist->where('gad_archives.user_id', $userid);
        }
        if ($user_name != "") {
            $contentlist->whereHas('user', function ($query) use ($user_name) {
                $query->where('User.NickName', 'like', "%$user_name%");
            });
        }
        if ($qq != "") {
            $contentlist->whereHas('user', function ($query) use ($qq) {
                $query->where('User.QQNo', $qq);
            });
        }

        if ($ques != "") {
            $contentlist->where('gad_archives.title', 'like', "%" . $ques . "%");
        }

        if ($status != -2) {
            //$contentlist->where('gad_archives.status', $status);
            $contentlist->whereHas('question', function ($query) use ($status) {
                $query->where('question.activity_status', $status);
            });
        }

        if ($is_hot != -1) {
            $contentlist->where('gad_archives.is_hot', $is_hot);
        }

        if ($is_top != -1) {
            $contentlist->where('gad_archives.is_top', $is_top);
        }

        if (!empty($begin_time) && !empty($end_time)) {
            $contentlist->where("created_at", '>=', date('Y-m-d 00:00:00', strtotime($begin_time)))
                ->where("created_at", '<=', date('Y-m-d 23:59:59', strtotime($end_time)));
        }

        $data = $contentlist->orderBy('gad_archives.id', 'desc')->paginate($pageSize);
        foreach ($data as $key => $item) {
            $data[$key]["QQNo"] = $item->user["QQNo"];
            $data[$key]["isDel"] = $item->getOriginal('deleted_at');

            //标签展示
            if ($item->tag != "") {
                $item->tag = ltrim($item->tag, ",");
                $data[$key]["tag"] = explode(",", $item->tag);
            }
            //把相关活动专家列表查出来
            $data[$key]["expert_info"] = WendaActivity::where("id", $item->from_activity)->value("info");

            foreach ($item->question->activity_to_user as $activity_to_user) {
                $nick_name = User::where("UserId", $activity_to_user)->value("NickName");
                if ($nick_name != "") {
                    $data[$key]["expert_info_name"] .= $nick_name . "、";
                }
            }
        }
        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
        return response()->json(['data' => $data, 'msg' => 'success', 'code' => '0', 'hostname' => $host]);
    }


    //删除或恢复
    public function postUpdateDelStatus(Request $request)
    {
        $id = $request->input('id');
        $status = $request->input('status');
        $updater_Id = Auth::user()['UserId'];
        if ($status == 0) { //恢复
            $time = null;
            $isDel = 0;
        } else {
            $time = Carbon::now();
            $isDel = -1;
        }
        $sections = Archive::withTrashed()->where("id", $id)->first();
        $comment_count = 0;
        $rows = 0;
        if (count($sections) > 0) {
            $rows = Question::where("archive_id", $id)->update(['activity_status' => $isDel, 'updated_at' => $time]);
            $sections->update(['deleted_at' => $time, 'updater' => $updater_Id, 'comment_count' => $comment_count]);
        }
        if ($rows > 0) {
            return response()->json(['msg' => '操作成功', 'code' => '0']);
        } else {
            return response()->json(['msg' => '操作失败,数据不存在', 'code' => '-1']);
        }
    }

    //修改状态（审核通过、不通过、置顶、置底）
    public function postUpdateArchiveStatus(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $type = $params['type'];
        $updater_Id = Auth::user()['UserId'];
        $reject_reason = isset($params['reject_reason']) ? $params['reject_reason'] : ''; //审核不通过的原因

        switch ($type) {
            case 1:
                $state = $params['status'];
                $this->archiveEloquent->update(['status' => $state, 'updater' => $updater_Id, 'reject_reason' => $reject_reason], $id);//审核状态
                $arr = Question::where("archive_id", $id)->update(['activity_status' => $state == 3 ? 2 : $state]);
                if ($arr > 0) {
                    //$login_userId = Auth::user()['UserId'];
                    $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
                    $urlinfo = url($host . '/wenda/activity/' . $params['activity_id']);

                    if ($state == 0) {
                        $messageType = MessageType::DAKA_INVITE_ANSWER;
                        $to_user = $params["to_user"];
                        if ($to_user != "") {
                            foreach ($to_user as $item) {
                                //$msg = "有用户在【我问专家】活动中邀请您回答问题，请点这里查看。";
                                Func::msgApi($messageType, $item["user_id"], 0, $id, $urlinfo, '这里查看');
                            }
                        }
                    } else {
                        //$msg = "很抱歉，您邀请专家回答的问题《" . $params['title'] . "》未通过审核，请修改后再次邀请专家回答，原因 " . $reject_reason . "，";
                        $messageType = MessageType::DAKA_REJECT_QUESTION;
                        Func::msgApi($messageType, $params["userid"], 0, $id, "", $params['title'], 0, $urlinfo, $reject_reason);
                    }
                }
                break;
            case 2:
                //$arr = $this->archiveEloquent->update(['is_top' => $params['is_top'], 'updater' => $updater_Id], $id);//置顶
                $arr = Question::where("archive_id", $id)->update(['activity_rank' => $params['is_top']]);
                break;
        }
        return $arr;
    }

    //修改邀请专家
    public function postUpdateExpertInfo(Request $request)
    {
        $id = $request->input('id');
        $activity_to_user = $request->input('activity_to_user');
        $rows = Question::where("id", $id)->update(array("activity_to_user" => $activity_to_user), $id);
        if ($rows > 0) {
            return json_encode(['msg' => '操作成功', 'code' => '0']);
        } else {
            return json_encode(['msg' => '操作失败', 'code' => '1']);
        }

    }


}