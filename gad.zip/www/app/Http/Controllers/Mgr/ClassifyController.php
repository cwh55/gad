<?php

namespace App\Http\Controllers\Mgr;
use Auth;
use App\Models\Classify;
use App\Models\User;
use App\Models\Summercourse;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ClassifyController extends Controller
{
	protected $user_id = '';
    public function __construct()
    {
    	if (Auth::check()) {
            $this->userInfo = Auth::user();
            $this->user_id = $this->userInfo->UserId;
        } else {
        	$this->user_id = '';
        }
        
    }	

	public function index(Request $request) {
        $classifies = Classify::all();
        $classifiesArr = json_decode($classifies, true);
        $keys = array_column($classifiesArr, 'class_id');
        $classifies = array_combine($keys, $classifiesArr);

		return response()->json($classifies);
		
		foreach($arr as $key => $val) {
			$className[$val['class_id']] = $val['class_name'];
			if($val['layer'] > 1) {
				$arr[$key]['parent_name'] = isset($className[$val['parent']]) ? $className[$val['parent']] : '';
				//$ckey = 'class'.$val['parent']
				$data[$val['parent']][] = $val;
			} 
		}

	}

	public function getClassifyList(Request $request) {
		$arr = Classify::all();
		foreach($arr as $key => $val) {
			$className[$val['class_id']] = $val['class_name'];
			if($val['layer'] > 1) {
				$arr[$key]['parent_name'] = isset($className[$val['parent']]) ? $className[$val['parent']] : '';
			} else {
				$arr[$key]['parent_name'] = '';
			}

			if($val['layer'] < 3) {
				$arr1[] = array(
					'class_id' => $val['class_id'],
					'class_name' => $val['class_name']
				);
			}
		}
/*
		$arr = json_decode($arr, true);
        $keys = array_column($arr, 'class_id');
        $data = array_combine($keys, $arr);*/

		$res['data'] = $arr;
		$res['parentClass'] = $arr1;

		unset($arr, $arr1, $data);
		return response()->json($res);
	}

	public function getClassifyLists(Request $request) {
		$arr = Classify::all();
		
		foreach($arr as $key => $val) {
			$className[$val['class_id']] = $val['class_name'];
			$data1[$val['layer']][] = $val;
			if($val['layer'] > 1) {
				$arr[$key]['parent_name'] = isset($className[$val['parent']]) ? $className[$val['parent']] : '';
				//$ckey = 'class'.$val['parent']
				$data[$val['parent']][] = $val;
			} 
		}

		$res = array(
			'L1' => $data1,
			'all' => $data,
		);

		//return $res;

		return response()->json($res);
	}

	public function postCreateClassify(Request $request) {
		$classify = new Classify;
		//$this->authorize('create', $classify);

		$fields = [
			['key' => 'class_name', 'name' => '分类名称', 'rule' => 'required'],
			['key' => 'parent_id', 'name' => '父级分类', 'rule' => 'required'],
		];
		$validator  = [
			'rule' => [],
			'messages' => [
				'required' => ':attribute 不能为空',
			],
			'attr' => []
		];

		$data = $request->all();
		if(isset($data['parentId']['class_id'])) {
			$parent = $data['parentId']['class_id'];
		} else {
			$parent = 0;
		}
		$classArr = Classify::where('parent', '=', $parent)->orderBy('class_id', 'DESC')->first();
		if ($classArr['class_id'] <= $classArr['parent']) {
			$classify->class_id = $data['parentId']['class_id'] . '01';
		} else {
			$classify->class_id = $classArr['class_id'] + 1;
		}
		$classify->class_name = $data['class_name'];
		$classify->parent = $parent;

		$data['user_id'] = $this->user_id;
		$classify->layer = $parent==0 ? 1 : strlen($parent) / 2 + 1;

		$classify->save();
		return response()->json(['code' => 0, 'message' => '添加分类成功！']);
	}

	public function postEditClassify(Request $request, $id) {

		$fields = [
			['key' => 'class_name', 'name' => '分类名称', 'rule' => 'required'],
			['key' => 'parent_id', 'name' => '父级分类', 'rule' => 'required'],
		];
		$validator  = [
			'rule' => [],
			'messages' => [
				'required' => ':attribute 不能为空',
			],
			'attr' => []
		];

		$data = $request->all();

		$classify = Classify::findOrFail($data['id']);
		//$this->authorize('edit', $classify);

		if($classify) {
			if(isset($data['parentId']['class_id'])) {
				$parent = $data['parentId']['class_id'];
			} else {
				$parent = 0;
			}

			if(empty($data['class_id']) || $classify->parent != $parent || strlen($data['class_id']) <= strlen($data['parent'])) {
				$classArr = Classify::where('parent', '=', $data['parentId']['class_id'])->orderBy('class_id', 'DESC')->first();
				$classify->class_id = $classArr['class_id'] + 1;
			} else {
				$classify->class_id = $data['class_id'];
			}

			$classify->class_name = $data['class_name'];
			$classify->parent = $parent;
			$classify->user_id = $this->user_id;
			$classify->layer = strlen($classify->class_id) / 2;

			$classify->save();
			return response()->json(['code' => 0, 'message' => '修改分类成功！']);
		}

		return response()->json(['code' => -1, 'message' => '修改分类失败！']);
	}

	public function postDeleteClassify(Request $request, $id) {
		$classify = Classify::findOrFail($id);
		//$this->authorize('del', $classify);

        if($classify) {
        	if(strlen($classify->class_id) < 6) {
        		$count = Classify::where('parent', $classify->class_id)->count();
        		if($count > 0) {
	            	return response()->json(['code' => -1, 'message' => '分类下存在子分类，不能删除！']);
        		}
        	}
        	$count = Summercourse::where('class_id', $classify->class_id)->where('status',0)->count();
        	if($count > 0) {
	            return response()->json(['code' => -1, 'message' => '分类下有内容，无法删除！']);
	        } else {
	        	$classify->delete();
	        	return response()->json(['code' => 0, 'message' => '分类删除成功！']);
	        }
        } 

		return response()->json(['code' => -1, 'message' => '分类删除失败！']);
	}

}
