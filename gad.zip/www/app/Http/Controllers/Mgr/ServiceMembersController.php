<?php

namespace App\Http\Controllers\Mgr;

use App\Http\Controllers\Controller;
use App\Repositories\ServiceRepository;
use Illuminate\Http\Request;
use App\Jobs\SendMail;
use App\Gad\TofService;
use App\Http\Requests;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Http\Requests\ServiceMemberCreateRequest;
use App\Http\Requests\ServiceMemberUpdateRequest;
use App\Repositories\ServiceMemberRepository;
use App\Entities\Service;


class ServiceMembersController extends Controller
{

    /**
     * @var ServiceMemberRepository
     */
    protected $repository;


    protected $serviceRepository;


    public function __construct(ServiceMemberRepository $serviceMemberRepository, ServiceRepository $serviceRepository)
    {
        $this->repository = $serviceMemberRepository;
        $this->serviceRepository = $serviceRepository;
        $this->repository->forgetCache();
    }


    /**
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
     */
    public function index(Request $request)
    {

        if ($request->has('service_member_type')) {
            if ($request->input('service_member_type') == 0) {
                $this->repository->where('service_member_type', '=', 0);
            } else {
                $this->repository->where('service_member_type', '>', 0);
            }

        }
        if ($request->has('status')) {
            $this->repository->where('status', '=', $request->input('status'));
        }
        $serviceMembers = $this->repository->orderBy('id', 'desc')->paginate(10);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $serviceMembers,
            ]);
        }

        return view('serviceMembers.index', compact('serviceMembers'));
    }

    /**
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {

        try {

            list($status, $serviceMember) = $this->repository->create($request->all());

            $response = [
                'message' => 'ServiceMember created.',
                'data' => $serviceMember->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $serviceMember = $this->repository->find($id);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $serviceMember,
            ]);
        }

        return view('serviceMembers.show', compact('serviceMember'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $serviceMember = $this->repository->find($id);

        return view('serviceMembers.edit', compact('serviceMember'));
    }


    /**
     * @param Request $request
     * @param $id
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {

        try {


            list($status, $serviceMember) = $this->repository->update($id, $request->all());
            if ($request->has('check') && 'check' == $request->input('check')) {
                //更新到服务表
                if ($serviceMember->status == 0) {
                    $this->addService($serviceMember);
                }

                //发送短信和邮件通知
                $this->pushMessage($serviceMember);
            }
            $response = [
                'message' => 'ServiceMember updated.',
                'data' => $serviceMember->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleted = $this->repository->delete($id);

        if (request()->wantsJson()) {

            return response()->json([
                'message' => 'ServiceMember deleted.',
                'deleted' => $deleted,
            ]);
        }

        return redirect()->back()->with('message', 'ServiceMember deleted.');
    }

    protected function pushMessage($serviceMember)
    {
        try {


            // 1、 发送邮件
            $serviceType = Service::$serviceType;
            $title = '[GAD]' . $serviceType[$serviceMember->service_member_type] . '合作审核结果通知';
            $body = '你的' . $serviceMember->name . '已审核。';
            if ($serviceMember->email) {
                $mail = view('email.projectService', array('user' => $serviceMember->contacts, 'title' => $title, 'body' => $body, 'status' => $serviceMember->status, 'reason' => $serviceMember->reason))->render();
                dispatch(new SendMail($serviceMember->email, $title, $mail));

            }
            // 2、 发送短信
            if ($serviceMember->phone) {
                $status = ($serviceMember->status == 0) ? '审核结果:已通过。' : ' 审核结果:不通过。';
                $status .= '详情官网查看';
                TofService::sendSms($serviceMember->phone, $title . $body . $status);
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }

    }


    protected function addService($serviceMember)
    {
        if (in_array($serviceMember->service_member_type, [2, 4, 5])) {
            $data = $serviceMember->toArray();
            $data['service_type'] = $data['service_member_type'];
            $data['service_member_id'] = $data['id'];
            unset($data['id']);
            $this->serviceRepository->create($data);
            return;
        } else {
            return;
        }


    }
}
