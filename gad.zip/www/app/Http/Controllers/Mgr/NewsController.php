<?php

namespace App\Http\Controllers\Mgr;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Articlecfg;

class NewsController extends Controller
{
    //获取动态配置
    public function getConfig($channel) {

    	$config = Articlecfg::channel($channel)->get()->take(1);
    	return response()->json(['config'=>!empty($config[0]) ? $config[0]->article_ids : '0']);
    }

    //保存动态配置
    public function saveConfig(Request $request) {
    	$config = Articlecfg::findOrFail(1);
    	$config->article_ids = $request->article_ids;
    	$ret = $config->save();
    	return response()->json(['code'=>1, 'msg'=>'success']);
    }

}
