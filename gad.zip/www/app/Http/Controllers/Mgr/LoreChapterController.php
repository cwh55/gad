<?php

namespace App\Http\Controllers\Mgr;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\LoreChapterRepositoryEloquent;
use App\Entities\LoreChapter;

class LoreChapterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $chapter;

    public function __construct(LoreChapterRepositoryEloquent $chapter)
    {
        $this->chapter = $chapter;
    }

    public function index(Request $request)
    {
        $page = $request->get('page', 1);
        $skip = ($page - 1) * 10;
        $query = LoreChapter::query()->with('lore');
        if ($request->get('cid')) {
            $query->where('id', $request->input('cid'));
        }
        if ($request->get('type')) {
            $query->where('type', $request->input('type'));
        }
        if ($request->get('title')) {
            $query->where('title', 'like','%'.$request->input('title').'%');
        }
        if ($request->get('state')!=-1) {
            $query->where('state', $request->input('state'));
        }
        if ($request->get('lore_id')) {
            $query->where('lore_id', $request->input('lore_id'));
        }
        $total = $query->count();
        $chapterlist = $query->skip($skip)->take(10)->orderBy('id', 'desc')->get();
        return response()->json(['total' => $total, 'chapterlist' => $chapterlist]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return response()->json(LoreChapter::create($request->all()));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return response()->json($this->chapter->find($id));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        return response()->json($this->chapter->update($request->all(),$id));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return response()->json($this->chapter->delete($id));
    }
}
