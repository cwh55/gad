<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/5/3
 * Time: 9:29
 */

namespace App\Http\Controllers\Mgr;

use App\Models\Role;
use App\Models\User_Role;
use App\Repositories\FollowUserRepository;
use Auth;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Models\User;
use App\Repositories\UserRepositoryEloquent;
use League\Flysystem\Exception;
use Illuminate\Support\Facades\Crypt;

class UserPressionController extends Controller
{
    protected $repository;
    protected $keyValueRepository;
    protected $followUserRepository;

    public function __construct(UserRepositoryEloquent $repository, FollowUserRepository $followUserRepository)
    {
        $this->repository = $repository;
        $this->followUserRepository = $followUserRepository;
    }

    //用户列表
    public function postUserList(Request $request)
    {
        $arr = array("UserId" => $request->input('UserId'),
            "QQNo" => $request->input('QQNo'),
            "RTXName" => $request->input('RTXName'),
            "NickName" => $request->input('NickName'),
            "RowStatus" => $request->input('RowStatus'),
            "Type" => $request->input('Type'),
            "WeixinId" => $request->input('WeixinId'),
            "TutorStatus" => $request->input('TutorStatus')
        );

        $this->repository->forgetCache();
        $data["userList"] = $this->repository->getList($arr);

        if (!$request->input('searchType')) {
            foreach ($data["userList"] as $key => $user) {
                $rolelist = self::getUserRoles($user["UserId"]);
                $ids = "";
                if (count($rolelist) > 0) {
                    foreach ($rolelist as $role) {
                        $ids = $ids . $role['roleId'] . ",";
                    }
                }
                if ($ids) {
                    $data['userList'][$key]['newRoles'] = substr($ids, 0, strlen($ids) - 1);
                }

                $permisslist = self::getUserPressionValue($user["UserId"]);//权限值列表
                $values = "";
                if (count($permisslist) > 0) {
                    foreach ($permisslist as $v) {
                        $values = $values . $v['title'] . ",";
                    }
                }
                if ($values) {
                    $data['userList'][$key]['permisslist'] = substr($values, 0, strlen($values) - 1);
                }
            }
        }
        return response()->json(['data' => $data["userList"]]);
    }

    //关注推荐
    public function postTest(UserRepositoryEloquent $user, Request $request)
    {
        $params = $request->all();
        $queryArray = array();
        if (!empty($params['UserId'])) {
            $queryArray['UserId'] = $params['UserId'];
        }
        if (!empty($params['QQNo'])) {
            $queryArray['QQNo'] = $params['QQNo'];
        }
        if ($params['RowStatus'] == 0) {
            $queryArray[] = ['gad_follow_users.id', '>', 0];
        } else if ($params['RowStatus'] == -1) {
            $queryArray[] = ['gad_follow_users.id', NULL];
        }
        if (!empty($params['NickName'])) {
            $queryArray['NickName'] = $params['NickName'];
        }
        if (!empty($params['RealName'])) {
            $queryArray['RealName'] = $params['RealName'];
        }

        return response()->json(['data' => $user->getFollowUserList($queryArray, $params['page'])]);
    }

    //修改用户简介
    public function postSetIntroduction(Request $request)
    {
        $params = $request->all();

        $user_id = $params['user_id'];
        $introduction = $params['introduction'];

        $userInfo = $this->followUserRepository->findWhere(['user_id', '=', $user_id]);

        if (!$userInfo->isEmpty()) {
            $res = $this->followUserRepository->update($userInfo[0]->id, ['introduction' => $introduction]);
        }
        return response()->json($res);
    }

    //修改用户状态
    public function postUpdateUserStatus(Request $request)
    {
        $params = $request->all();
        $id = $params['userId'];
        if ($params['rowstatus'] == 0) {
            $res = $this->followUserRepository->create(['user_id' => $id]);
        } else {
            $userInfo = $this->followUserRepository->findWhere(['user_id', '=', $id]);
            $res = $this->followUserRepository->delete($userInfo->first()->id);
        }
        return $res;
    }

    //修改用户状态（新）
    public function postUpdateUserStatusNew(Request $request)
    {
        $params = $request->all();
        $id = $params['userId'];
        list($status, $arr) = $this->repository->update($id, ['RowStatus' => $params['rowstatus']]);
        if ($status) {
            return json_encode(['msg' => '操作成功', 'code' => 0]);
        } else {
            return json_encode(['msg' => '操作失败', 'code' => -1]);
        }
    }

    //设置大咖状态
    public function postSetTutorStatus(Request $request)
    {
        $params = $request->all();
        $id = $params['UserId'];
        list($status, $arr) = $this->repository->update($id, ['TutorStatus' => $params['TutorStatus']]);
        if ($status) {
            return json_encode(['msg' => '操作成功', 'code' => 0]);
        } else {
            return json_encode(['msg' => '操作失败', 'code' => -1]);
        }
    }

    //设置用户类型状态
    public function postSetUserType(Request $request)
    {
        $params = $request->all();
        $id = $params['UserId'];
        list($status, $arr) = $this->repository->update($id, ['type' => $params['type']]);
        if ($status) {
            return json_encode(['msg' => '操作成功', 'code' => 0]);
        } else {
            return json_encode(['msg' => '操作失败', 'code' => -1]);
        }
    }

    //查询所有角色
    public function getAllRoles()
    {
        $result = Role::where('rowStatus', '>', 0)->get();
        return response()->json(['data' => $result]);
    }

    //查询用户的角色
    public function getUserRoles($userid)
    {
        $result = User_Role::where('rowStatus', '>', 0)->where('userId', '=', $userid)->get();
        return $result;
    }

    //查询用户的权限值
    public function getUserPressionValue($userid)
    {
        $item = Role::select('title')
            ->whereIn('id', function ($query) use ($userid) {
                $query->select('roleId')->from('User_Role')
                    ->where('User_Role.userId', $userid)->where('User_Role.rowStatus', 1);
            })->get();

        return $item;
    }


    //设置新角色
    public function postSetUserRole(Request $request)
    {
        $userid = $request->input('userid');
        $count = User::find($userid);
        if (!$count) {
            return -1;
        }

        $roleids = $request->input('roleids');
        $rolelist = explode(',', $roleids);
        $otherlist = explode(',', $request->input('otherids'));
        $row = 0;
        if (count($rolelist)) {
            foreach ($rolelist as $role) {
                if (!empty($role))
                    self::postSetRole($userid, $role, 1);
                $row = 1;
            }
        }
        if (count($otherlist)) {
            foreach ($otherlist as $role) {
                if (!empty($role)) {
                    self::postSetRole($userid, $role, -1);
                    $row = 1;
                }
            }
        }
        return $row;
    }

    //后台给某个用户设置角色
    public function postSetRole($userid, $roleid, $rowStatus)
    {
        $result = User_Role::where('userId', '=', $userid)->where('roleId', '=', $roleid)->get();
        if (count($result) > 0) {
            User_Role::where('userId', '=', $userid)->where('roleId', '=', $roleid)->update(["rowStatus" => $rowStatus]);
        } else {
            if ($rowStatus == -1) {
                return 0;
            }
            $value['userId'] = $userid;
            $value['roleId'] = $roleid;
            $value['rowStatus'] = $rowStatus;
            $params = array("userId" => $userid, "roleId" => $roleid, "rowStatus" => $rowStatus);
            User_Role::create($params)->userId;
        }
    }


}