<?php

namespace App\Http\Controllers\Mgr;

use Auth;
use App\Models\Article;
use App\Models\Answers;
use App\Models\Question;
use App\Models\Video;
use App\Models\ArtWork;
use App\Models\Worktype;
use App\Models\Classify;
use App\Models\User;
use App\Models\Live;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Gad\MessageType;
use App\Gad\Func;

class WorksController extends Controller
{
    protected $user_id = '';

    public function __construct()
    {
        if (Auth::check()) {
            $this->userInfo = Auth::user();
            $this->user_id = $this->userInfo->UserId;
        } else {
            $this->user_id = '';
        }
    }

    public function getArticleList(Request $request)
    {
        $entry = Article::query();
        if ($request->has('id')) {
            $entry->where('id', $request->input('id'));
        }
        if ($request->has('title')) {
            $entry->where('title', $request->input('title'));
        }
        if ($request->has('status') && $request->input('status') != -3) {
            $entry->where('status', $request->input('status'));
        }
        if ($request->has('is_top') && $request->input('is_top') != -3) {
            $entry->where('is_top', $request->input('is_top'));
        }
        if ($request->has('user_id')) {
            $entry->where('user_id', $request->input('user_id'));
        }
        if ($request->has('class_id')) {
            $entry->where('class_id', $request->input('class_id'));
        }
        $result = $entry->orderBy('id', 'desc')->paginate($request->get('pageSize', 10));

        $this->getHostName($result);

        return response()->json($result);
    }

    //域名判断
    public function getHostName($result)
    {
        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
        foreach ($result as $key=>$item) {
            $result[$key]["hostname"] = $host;
        }
        return $result;
    }

    public function manageArticle(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];

        $article = Article::findOrFail($id);
        if (isset($params['is_top'])) {
            $article->is_top = $params['is_top'];
        }
        if (isset($params['status'])) {
            if ($params['status'] == -1) {
                Func::msgApi(MessageType::ARTICLE_DELETE, $article['user_id'], 0, $id, 'http://gad.qq.com/article/detail/' . $id, $article['title'], 0, '', '你的文章被管理员删除<' . $article['title'] . '>');
            }
            $article->status = $params['status'];
        }
        $article->save();
        return $article->id;
    }

    public function getVideoList(Request $request)
    {
        $videolist = Video::where('status', 0)->get();
        $this->getHostName($videolist);
        return $videolist;
    }

    public function manageVideo(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];

        $video = Video::findOrFail($id);
        if (isset($params['is_top'])) {
            $video->is_top = $params['is_top'];
        }
        if (isset($params['status'])) {
            $video->status = $params['status'];
        }
        $video->save();
        return $video->id;
    }

    public function getArtworkList(Request $request)
    {
        $videolist = ArtWork::where('status', 0)->get();
        $this->getHostName($videolist);
        return $videolist;
    }

    public function manageArtwork(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];

        $artwork = ArtWork::findOrFail($id);
        if (isset($params['is_top'])) {
            $artwork->is_top = $params['is_top'];
        }
        if (isset($params['status'])) {
            $artwork->status = $params['status'];
            if ($params['status'] == -1) {
                Func::msgApi(MessageType::ART_DELETE, $artwork['user_id'], 0, $id, 'http://gad.qq.com/art/detail/' . $id, $artwork['title'], 0, '', '你的作品被管理员删除<' . $artwork['title'] . '>');
            }
        }
        $artwork->save();
        return $artwork->id;
    }


    //问题
    public function getQuestionList(Request $request)
    {
        $entry = Question::query()->with('User');

        if ($request->has('id')) {
            $entry->where('id', $request->input('id'));
        }
        if ($request->has('question')) {
            $str = $request->input('question');
            $entry->where('question', 'like', '%' . $str . '%');
        }
        if ($request->has('user_id')) {
            $entry->where('user_id', $request->input('user_id'));
        }

        if ($request->has('name')) {
            $str = $request->input('name');
            $entry->whereHas('user', function ($query) use ($str) {
                $query->where('NickName', 'like', "%$str%");
            });
        }

        if ($request->has('QQNo')) {
            $str = $request->input('QQNo');
            $entry->whereHas('user', function ($query) use ($str) {
                $query->where('QQNo', 'like', "%$str%");
            });
        }

        if ($request->has('status') && $request->input('status') != 1) {
            $entry->where('status', $request->input('status'));
        }

        if ($request->has('source') && $request->input('source') != -1) {
            $entry->where('source', $request->input('source'));
        }

        $result = $entry->orderBy('id', 'desc')->paginate($request->get('pageSize', 10));
        $this->getHostName($result);
        return response()->json($result);
    }

    public function manageQuestion(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $question = Question::findOrFail($id);
        if (isset($params['status'])) {
            $question->status = $params['status'];
            if ($params['status'] == -1) {
                if ($question['obj_type'] == 1) {       //大咖答疑
                    Func::msgApi(MessageType::DAKA_QUESTION_DELETE, $question['user_id'], 0, $id, 'http://gad.qq.com/wenda/detail/' . $question['id'], $question['question'], 0, '', '你的问题被管理员删除<' . $question['question'] . '>');
                } else {
                    Func::msgApi(MessageType::QUESTION_DELETE, $question['user_id'], 0, $id, '', $question['question'], 0, '', '你的问题被管理员删除<' . $question['question'] . '>');
                }
            }

        }
        if (isset($params['to_user'])) {
            $question->to_user = $params['to_user'];
            $user = User::findOrFail($params['to_user']);
            Func::msgApi(MessageType::DAKA_INVITE, $params['to_user'], $question->user_id, $id, 'http://gad.qq.com/wenda/detail/' . $question['id'], $question['question'], 0, '', $user['NickName'] . '邀请你回答问题<' . $question['question'] . '>');
        }
        $question->save();
        return $question->id;
    }

    public function updateRankQuestion(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];

        $question = Question::findOrFail($id);

        if (isset($params['rank'])) {
            $question->rank = $params['rank'];
        }
        $question->save();
        return $question->id;
    }


    //回答
    public function getAnswersList(Request $request)
    {
        $entry = Answers::query()->with('question')->with('User');

        if ($request->has('answer')) {
            $str = $request->input('answer');
            $entry->where('answers.answer', 'like', '%' . $str . '%');
        }
        if ($request->has('status') && $request->input('status') != 1) {
            $entry->where('answers.status', $request->input('status'));
        }
        if ($request->has('adopt') && $request->input('adopt') != -1) {
            $entry->where('adopt', $request->input('adopt'));
        }

        if ($request->has('source') && $request->input('source') != -1) {
            $entry->where('answers.source', $request->input('source'));
        }
        if ($request->has('name')) {
            $entry->where('answers.name', $request->input('name'));
        }
        $result = $entry->orderBy('id', 'desc')->paginate($request->get('pageSize', 10));
        $this->getHostName($result);
        return response()->json($result);
    }

    public function manageAnswers(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];

        $answers = Answers::findOrFail($id);

        if (isset($params['status'])) {
            $answers->status = $params['status'];
            if ($params['status'] == -1 && $answers['question_id']) {
                $question = Question::findOrFail($answers['question_id']);
                if ($question['obj_type'] == 1) {       //大咖答疑
                    Func::msgApi(MessageType::DAKA_ANSWER_DELETE, $answers['user_id'], 0, $id, 'http://gad.qq.com/wenda/detail/' . $question['id'], $question['question'], $answers['id'], 'http://gad.qq.com/wenda/detail/' . $question['id'] . '#' . $answers['id'], '你的回答被管理员删除<' . $answers['answer'] . '>');
                } else {
                    Func::msgApi(MessageType::ANSWER_DELETE, $answers['user_id'], 0, $id, '', $question['question'], $answers['id'], '', '你的回答被管理员删除<' . $answers['answer'] . '>');
                }
            }
        }
        $answers->save();
        return $answers->id;
    }

    public function updateRankAnswers(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];

        $question = Answers::findOrFail($id);

        if (isset($params['rank'])) {
            $question->rank = $params['rank'];
        }
        $question->save();
        return $question->id;
    }

    public function updateAdopt(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];

        $answers = Answers::findOrFail($id);

        if (isset($params['adopt'])) {
            $answers->adopt = $params['adopt'];
        }
        $answers->save();
        return $answers->id;
    }

    public function updateAnswers(Request $request)
    {
        $params = $request->all();
        $id = $params['questionId'];
        $status = $params['status'];

        $question = Question::findOrFail($id);

        if ($status == -1 || $status == 2) {
            if ($question->answers > 0) {
                $question->answers = $question->answers - 1;
            }
        } else {
            $question->answers = $question->answers + 1;
        }
        $question->save();
        return $question->id;
    }

    //设置回答用户信息
    public function setAnswerUserInfo(Request $request)
    {
        $params = $request->all();
        $id = intval($params['id']);
        $userid = intval($params['userid']);

        $entry = User::find($userid);
        if (!$entry) {
            return response()->json(['code' => -1, 'message' => '用户ID不存在！']);
        }

        $name = $entry->NickName;
        $rows = Answers::where("id", $id)->update(["user_id" => $userid, "name" => $name, "updated_at" => date('Y-m-d H:i:s',time())]);
        if ($rows > 0) {
            return response()->json(['code' => 0, 'message' => '修改成功！']);
        } else {
            return response()->json(['code' => -1, 'message' => '修改失败！']);
        }
    }


    public function index(Request $request)
    {
        $Classify = new Classify;
        $classifies = $Classify::all();
        //return response()->json($classifiesArr);
        $classifiesArr = json_decode($classifies, true);
        $keys = array_column($classifiesArr, 'class_id');
        $classifies = array_combine($keys, $classifiesArr);

        $Worktype = new Worktype;
        $arr = $Worktype->with('classifies')->get();

        if (!empty($arr)) {
            foreach ($arr as $key => $val) {
                $data[] = array(
                    'id' => $val['id'],
                    'class_id' => $val['class_id'],
                    'class_name' => $val['classifies'][0]['class_name'],
                    'parent' => $val['classifies'][0]['parent'],
                    'parent_name' => $classifies[$val['classifies'][0]['parent']]['class_name'],
                );
            }
            return $data;
        }
        return false;
    }


    // 作业类型
    public function getWorktypeList(Request $request)
    {
        $Classify = new Classify;
        $classifies = $Classify::all();
        //return response()->json($classifiesArr);
        $classifiesArr = json_decode($classifies, true);
        $keys = array_column($classifiesArr, 'class_id');
        $classifies = array_combine($keys, $classifiesArr);

        $Worktype = new Worktype;
        $arr = $Worktype->with('classifies')->get();

        if (!empty($arr)) {
            foreach ($arr as $key => $val) {
                $data[] = array(
                    'id' => $val['id'],
                    'class_id' => $val['class_id'],
                    'type' => $val['type'],
                    'class_name' => $val['classifies'][0]['class_name'],
                    'parent' => $val['classifies'][0]['parent'],
                    'parent_name' => $classifies[$val['classifies'][0]['parent']]['class_name'],
                );
            }
            return $data;
        }
        return false;
    }

    public function postCreateWorktype(Request $request)
    {
        $worktype = new Worktype;
        $params = $request->all();
        if (!empty($params)) {
            $data = Worktype::where('class_id', '=', $params['data']['class_id'])->count('id');
            if ($data > 0) {
                return response()->json(['code' => -1, 'message' => '该分类已添加作业类型，提交失败！']);
            }
            $worktype->class_id = $params['data']['class_id'];
            $worktype->type = $params['data']['type_id'];
            $worktype->user_id = $this->user_id;
            $worktype->save();
        }

        return response()->json(['code' => 0, 'message' => '添加作业类型成功！']);
    }

    public function postDeleteWorktype(Request $request, $id)
    {
        //$this->authorize('delete', $worktype);
        $worktype = Worktype::findOrFail($id);
        if ($worktype) {
            $worktype->delete();
            return response()->json(['code' => 0, 'message' => '删除作业类型成功！']);
        } else {
            return response()->json(['code' => -1, 'message' => '删除作业类型失败！']);
        }
    }
}
