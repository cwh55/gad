<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/5/11
 * Time: 13:33
 */

namespace App\Http\Controllers\Mgr;

use DB;
use App\Entities\Article;
use App\Entities\Comment;
use App\Entities\Picture;
use App\Entities\Question;
use App\Http\Controllers\Controller;
use App\Gad\MessageType;
use App\Jobs\SendMessage;
use App\Models\User;
use Auth;
use App\Http\Requests;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Entities\Archive;
use App\Entities\ArchiveTag;
use App\Entities\Answer;
use App\Repositories\ArchiveRepository;
use App\Repositories\ArchiveRepositoryEloquent;
use App\Repositories\AnswerRepositoryEloquent;
use App\Repositories\FollowRepository;
use Symfony\Component\VarDumper\Cloner\VarCloner;

class CommunityHomeController extends Controller
{
    protected $archiveEloquent;
    protected $answerEloquent;

    protected $followRepository;
    protected $archiveRepository;

    protected $archives;
    protected $answer;

    private $cmttypes = array(
        1 => 'App\Entities\Archive',
        2 => 'App\Entities\Comment',
        3 => 'App\Entities\Picture'
    );

    public function __construct(ArchiveRepositoryEloquent $archive, AnswerRepositoryEloquent $answer, Archive $ar,
                                ArchiveRepository $archiveR, FollowRepository $follow, Answer $ans)
    {
        $this->archiveEloquent = $archive;
        $this->answerEloquent = $answer;

        $this->followRepository = $follow;
        $this->archiveRepository = $archiveR;

        $this->archives = $ar;
        $this->answer = $ans;
    }

    //获取社区首页内容库-根据类型
    public function postContetntTypeList(Request $request)
    {
        $type = $request->input('type');
        $id = $request->input('id');
        $userid = $request->input('userid');
        $channel_id = intval($request->input('channel_id'));
        $user_name = $request->input('name', '');
        $ques = $request->input('title', '');
        $status = intval($request->input('status'));
        $is_hot = intval($request->input('is_hot'));
        $is_top = intval($request->input('is_top'));
        $qq = $request->input('qq');
        $begin_time = $request->input('begin_time');
        $end_time = $request->input('end_time');
        $article_type = $request->input('article_type');
        $picture_type = $request->input('picture_type', '');
        $pageSize = 30;

        if ($type < 5) {
            $contentlist = $this->archives->with('user')->where("gad_archives.class_id", $type);
        } else {
            $contentlist = $this->archives->onlyTrashed()->with('user'); //回收站只查已删除的数据
        }

        if ($type == 1) {
            if ($article_type != -1) {
                $contentlist->whereHas('article', function ($query) use ($article_type) {
                    $query->where('gad_articles.type', $article_type);
                });
            }
        }

        //标签查询
        if ($type == 2) {
            $tag = $request->input('tag');
            $tagEntry = null;

            if ($picture_type == "") {
                if ($tag != -1) { //只查标签
                    $tagEntry = DB::table('gad_archives')
                        ->join('gad_archive_tags', 'gad_archives.id', '=', 'gad_archive_tags.archive_id')
                        ->where('gad_archive_tags.tag_id', $tag)->where('gad_archives.class_id', $type)->whereNull('gad_archives.deleted_at');
                }
            } else {
                $tagEntry = DB::table('gad_archives');
                if ($picture_type == 1) { //佳作
                    $tagEntry->join('gad_atlas', 'gad_archives.id', '=', 'gad_atlas.archive_id');
                }
                if ($tag != -1) {
                    $tagEntry->join('gad_archive_tags', 'gad_archives.id', '=', 'gad_archive_tags.archive_id')->where('gad_archive_tags.tag_id', $tag);
                }
                $tagEntry->where('gad_archives.class_id', $type)->whereNull('gad_archives.deleted_at');
            }
        }

        $id = intval($id);
        if ($id > 0) {
            $contentlist->where('gad_archives.id', $id);
        }

        $userid = intval($userid);
        if ($userid > 0) {
            $contentlist->where('gad_archives.user_id', $userid);
        }

        $channel_id = intval($channel_id);
        if ($channel_id > 0) {
            $contentlist->where('gad_archives.channel_id', $channel_id);
        }

        if (!empty($user_name)) {
            $contentlist->whereHas('user', function ($query) use ($user_name) {
                $query->where('User.NickName', 'like', "%$user_name%");
            });
        }

        if (!empty($qq)) {
            $contentlist->whereHas('user', function ($query) use ($qq) {
                $query->where('User.QQNo', 'like', "%$qq%");
            });
        }

        if (!empty($ques)) {
            $contentlist->where('gad_archives.title', 'like', "%" . $ques . "%");
        }

        if ($status != -1) {
            if ($type == 2 && $tagEntry != null) {
                $tagEntry->where('gad_archives.status', $status);
            }
            $contentlist->where('gad_archives.status', $status);
        }

        if ($is_hot != -1) {
            if ($type == 2 && $tagEntry != null) {
                $tagEntry->where('gad_archives.is_hot', $is_hot);
            }
            $contentlist->where('gad_archives.is_hot', $is_hot);
        }

        if ($type == 2 && $tagEntry != null) {
            $result = $tagEntry->select('gad_archives.id')->get();
            if (count($result) > 0) {
                $ids = array_column(json_decode(json_encode($result), true), 'id');
                $contentlist->whereIn('id', $ids);
            }
        }

        if ($type == 2 && $picture_type == 2) {
            $ids = Picture::where("type", $picture_type)->whereNull("deleted_at")->select("archive_id")->groupBy("archive_id")->get()->toArray();
            $contentlist->whereIn('id', $ids);
        }

        if ($is_top != -1) {
            $contentlist->where('gad_archives.is_top', $is_top);
        }

        if (!empty($begin_time) && !empty($end_time)) {
            $contentlist->where("created_at", '>=', $begin_time)->where("created_at", '<=', $end_time);
        }

        if ($type <= 4) {
            $entry = $contentlist->orderBy('gad_archives.id', 'desc');
        } else {
            $entry = $contentlist->orderBy('gad_archives.deleted_at', 'desc');
        }

        $data = $entry->paginate($pageSize);

        foreach ($data as $key => $item) {
            $data[$key]["QQNo"] = $item->user["QQNo"];
            $data[$key]["isDel"] = $item->getOriginal('deleted_at');
            $data[$key]["sortTime"] = intval($item->getOriginal('sort_time'));
            $data[$key]["publish_time"] = $item->getOriginal('created_at');

            //标签展示
            if ($item->tag != "") {
                $item->tag = ltrim($item->tag, ",");
                $data[$key]["tag"] = explode(",", $item->tag);
            }

            //作品
            if ($type == 2) {
                $pictureEntry = Picture::where("archive_id", $item->id);
                if (count($pictureEntry->get()) > 0) {
                    $data[$key]["pictureId"] = $pictureEntry->value("id");
                    $data[$key]["pictureType"] = $pictureEntry->value("type");
                } else {
                    $data[$key]["pictureId"] = -1;
                    $data[$key]["pictureType"] = -1;
                }
            }

            if ($type == 4) {
                $answerlist = Answer::where("archive_id", $item->id)->select("id")->get();
                $data[$key]["child_comment_count"] = Answer::whereIn("answer_id", $answerlist)->where("status", 0)->count();
            }
        }

        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
        return response()->json(['data' => $data, 'msg' => 'success', 'code' => '0', 'hostname' => $host]);
    }

    //删除或恢复
    public function postUpdateDelStatus(Request $request)
    {
        $id = $request->input('id');
        $classid = $request->input('classid');
        $status = $request->input('status');

        $updater_Id = Auth::user()['UserId'];

        if ($status == 0) { //恢复
            $time = null;
            $isDel = 0;
        } else {
            $time = Carbon::now();
            $isDel = -1;
        }

        $sections = Archive::withTrashed()->where("id", $id)->first();
        $comment_count = 0;
        $entryPicture = Picture::withTrashed()->where("archive_id", $id);

        if (count($sections) > 0) {
            switch ($classid) {
                case 1: //文章
                    $ret = Article::where("archive_id", $id)->update(['deleted_at' => $time]);
                    if ($ret > 0) {
                        $entryComment = Comment::withTrashed()->where("model_id", $id);
                        if ($status == 0) { //恢复
                            $comment_count = $entryComment->count();
                        }
                        $entryComment->update(['deleted_at' => $time]);
                    }
                    break;
                case 2: //作品
                    if ($entryPicture->count() > 0) {
                        foreach ($entryPicture->get() as $item) {
                            Comment::withTrashed()->where("model_id", $item->id)->where("model_type", $this->cmttypes[3])->update(['deleted_at' => $time]);
                        }
                    }
                    break;
                case 3: //问答
                case 4: //话题
                    Question::where("archive_id", $id)->update(['status' => $isDel, 'updated_at' => $time]);

                    //还要删除问题
                    $entryAnswer = Answer::where("archive_id", $id);
                    if ($status == 0) { //恢复
                        $comment_count = $entryAnswer->count();
                    }

                    foreach ($entryAnswer->get() as $item) {
                        $an = Answer::where("answer_id", $item->id);
                        if ($status == 0) { //恢复
                            $answer_count = $an->count();
                        } else {
                            $answer_count = 0;
                        }
                        $an->update(['status' => $isDel, 'updated_at' => $time]);
                        Answer::where("id", $item->id)->update(['status' => $isDel, 'updated_at' => $time, 'answer_count' => $answer_count]);
                    }

                    break;
            }

            $entryPicture->update(['deleted_at' => $time]);
            $sections->update(['deleted_at' => $time, 'updater' => $updater_Id, 'comment_count' => $comment_count]);

            return response()->json(['msg' => '操作成功', 'code' => '0']);
        } else {
            return response()->json(['msg' => '操作失败,数据不存在', 'code' => '-1']);
        }

    }

    //修改状态
    public function postUpdateArchiveStatus(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $type = $params['type'];
        $classid = intval($params['classid']);
        $updater_Id = Auth::user()['UserId'];
        $reject_reason = isset($params['reject_reason']) ? $params['reject_reason'] : ''; //审核不通过的原因

        switch ($type) {
            case 1:
                $state = $params['status'];
                $arr = $this->archiveEloquent->update(['status' => $state, 'updater' => $updater_Id, 'reject_reason' => $reject_reason], $id);//审核状态

                //指定用户，审核通过的时候，把sort_time字段设为0
                if ($state == 0) {
                    $userArr = array(2191628, 451240, 33894, 704370, 1449105, 659510, 2248870);
                    $isExist = in_array($request->input('userid'), $userArr);
                    if ($isExist) {
                        $this->archiveEloquent->update(["sort_time" => 0], $id);//审核状态
                    }
                }

                if ($classid == 2) {
                    Picture::where("archive_id", $id)->update(['status' => $state]);
                    if ($state == 0) {
                        $fans = $this->followRepository->getFans($arr['user_id'], ['user_id'])->toArray();
                        dispatch(new SendMessage(MessageType::WORK_NEW, array_column($fans, 'user_id'), $arr['user_id'], $id, url('/gallery/detail', $id), $arr['title']));
                    }
                } else if ($classid == 3) {
                    Question::where("archive_id", $id)->update(['status' => $state]);
                }
                if ($classid == 1 && $state == 0) {
                    $articleRepository = app(\App\Repositories\ArticleRepository::class);
                    $articleRepository->reviewArticle($articleRepository->findBy('archive_id', $id));
                    $fans = $this->followRepository->getFans($arr['user_id'], ['user_id'])->toArray();
                    dispatch(new \App\Jobs\SendMessage(\App\Gad\MessageType::ARTICLE_NEW, array_column($fans, 'user_id'), $arr['user_id'], $id, url('/article/detail', $id), $arr['title']));
                }
                if (($classid == 1 || $classid == 2) && $state == 0) {
                    $msgType = $classid == 1 ? \App\Gad\MessageType::ARTICLE_ACCEPT : \App\Gad\MessageType::ART_ACCEPT;
                    $url = $classid == 1 ? url('/article/detail', $id) : url('/gallery/detail', $id);
                    dispatch(new \App\Jobs\SendMessage($msgType, $arr['user_id'], 0, $id, $url, $arr['title']));
                }
                if (($classid == 1 || $classid == 2) && $state == 3) {
                    $this->archiveRepository->setRejectNotice($arr['user_id']);
                    $msgType = $classid == 1 ? \App\Gad\MessageType::ARTICLE_REJECT : \App\Gad\MessageType::ART_REJECT;
                    $url = $classid == 1 ? url('/article/detail', $id) : url('/gallery/detail', $id);
                    dispatch(new \App\Jobs\SendMessage($msgType, $arr['user_id'], 0, $id, $url, $arr['title']));
                }
                break;
            case 2:
                //美术作品资源库，只有佳作类型才能设置置顶 pictureId
                if ($classid == 2 && $params['is_top'] == 1) {
                    $pictureId = $params['pictureId'];
                    $pictureType = Picture::where("id", $pictureId)
                        //->where("status", 1)
                        ->whereNull("deleted_at")->value("type");
                    if ($pictureType != 1) //佳作
                    {
                        return -2;
                    }
                }
                $arr = $this->archiveEloquent->update(['is_top' => $params['is_top'], 'updater' => $updater_Id], $id);//置顶
                break;
            case 3:
                $is_hot = $params['is_hot'];
                $arr = $this->archiveEloquent->update(['is_hot' => $is_hot, 'updater' => $updater_Id], $id);//热门推荐
                if ($classid == 2) {
                    Picture::where("archive_id", $id)->update(['is_hot' => $is_hot]);
                }
                break;
            case 4:
                $state = $params['status'];
                $sorttime = intval($params['sorttime']);
                if ($state == 0)//下沉
                {
                    $arr = $this->archiveEloquent->update(["sort_time" => ($sorttime / 100)], $id);
                } else //取消下沉
                {
                    if ($sorttime == 0) {
                        $sorttime = strtotime(Carbon::now());
                    } else {
                        $sorttime = $sorttime * 100;
                    }
                    $arr = $this->archiveEloquent->update(["sort_time" => $sorttime], $id);
                }
                break;
        }
        return $arr->id;
    }

    //修改作者
    public function postUpdateAuthor(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $userid = $params['user_id'];
        $entry = User::where("UserId", $userid)->first();
        if ($entry) {
            $arr = $this->archiveEloquent->update(['user_id' => $userid, 'user_name' => $entry->NickName], $id);
        } else {
            return json_encode(['msg' => '用户不存在', 'code' => '-1']);
        }
        if ($arr->id) {
            return json_encode(['msg' => '修改成功', 'code' => '1']);
        } else {
            return json_encode(['msg' => '修改失败', 'code' => '-1']);
        }
    }

    //修改、添加标签
    public function postUpdateTag(Request $request)
    {
        $params = $request->all();
        $archive_id = $params['archive_id'];
        $tag_name = $params['tag_name'];
        $tag_new_name = $params['tag_new_name'];
        $tag_id = $params['tag_id'];
        $type = $params['type'];

        $tagNewEntry = ArchiveTag::where("tag_id", $tag_id)->where("archive_id", $archive_id);
        $tagNewCount = count($tagNewEntry->get());
        if ($tagNewCount >= 1) {
            return json_encode(['data' => [], 'msg' => '操作失败,已经存在相同的标签', 'code' => '0']);
        }

        if ($type == 0) {
            $entry = DB::table('gad_archive_tags')
                ->join('gad_tags', 'gad_tags.id', '=', 'gad_archive_tags.tag_id')
                ->where('gad_archive_tags.archive_id', $archive_id)
                ->whereNull('gad_tags.deleted_at');

            if ($tag_name == "特效") {
                $entry = $entry->where('gad_tags.id', 10548);
            } else if ($tag_name == "原画" || $tag_name == "2D") {
                $entry = $entry->where('gad_tags.id', 10476);
            } else if ($tag_name == "3D") {
                $entry = $entry->where('gad_tags.id', 10506);
            } else if ($tag_name == "UI" || $tag_name == '游戏视觉') {
                $entry = $entry->where('gad_tags.id', 10559);
            } else if ($tag_name == "动画" || $tag_name == "美术动画") {
                $entry = $entry->where('gad_tags.id', 10530);
            } else if ($tag_name == "美术新手") {
                $entry = $entry->where('gad_tags.id', 10498);
            } else if ($tag_name == "技术美术") {
                $entry = $entry->where('gad_tags.id', 10552);
            } else {
                $entry = $entry->where('gad_tags.name', $tag_name);
            }

            $tagCount = count($entry->get());
            if ($tagCount > 0) {
                ArchiveTag::where("id", $entry->value("gad_archive_tags.id"))->update(array('tag_id' => $tag_id, 'updated_at' => Carbon::now()));
            }
        }

        //更新gad_archives表tag字段
        $archiveTag = Archive::where("id", $archive_id)->value("tag");
        $tags = ltrim($archiveTag, ",");

        if ($type == 0) {
            $tagArr = explode(",", $tags);
            foreach ($tagArr as $key => $value) {
                if ($value == $tag_name) {
                    $tagArr[$key] = $tag_new_name;
                    break;
                }
            }
            $tagNew = implode(",", $tagArr);
        } else { //添加标签
            $tagNew = $tags . "," . $tag_new_name;
            DB::table('gad_archive_tags')->insert(array('tag_id' => $tag_id, 'archive_id' => $archive_id, 'created_at' => Carbon::now()));
        }

        $rows = Archive::where("id", $archive_id)->update(array('tag' => $tagNew));
        if ($rows > 0) {
            return json_encode(['data' => [], 'msg' => '操作成功', 'code' => '1']);
        } else {
            return json_encode(['data' => [], 'msg' => '操作失败', 'code' => '0']);
        }
    }

    //删除标签
    public function postDelTag(Request $request)
    {
        $params = $request->all();
        $archive_id = $params['archive_id'];
        $tag_name = $params['tag_name'];

        $entry = DB::table('gad_archive_tags')
            ->join('gad_tags', 'gad_tags.id', '=', 'gad_archive_tags.tag_id')
            ->where('gad_archive_tags.archive_id', $archive_id)
            ->whereNull('gad_tags.deleted_at');

        if ($tag_name == "特效") {
            $entry = $entry->where('gad_tags.id', 10548);
        } else if ($tag_name == "原画" || $tag_name == "2D") {
            $entry = $entry->where('gad_tags.id', 10476);
        } else if ($tag_name == "3D") {
            $entry = $entry->where('gad_tags.id', 10506);
        } else if ($tag_name == "UI" || $tag_name == '游戏视觉') {
            $entry = $entry->where('gad_tags.id', 10559);
        } else if ($tag_name == "动画" || $tag_name == "美术动画") {
            $entry = $entry->where('gad_tags.id', 10530);
        } else if ($tag_name == "美术新手") {
            $entry = $entry->where('gad_tags.id', 10498);
        } else if ($tag_name == "技术美术") {
            $entry = $entry->where('gad_tags.id', 10552);
        } else {
            $entry = $entry->where('gad_tags.name', $tag_name);
        }

        $tagCount = count($entry->get());
        if ($tagCount > 0) {
            ArchiveTag::where("id", $entry->value("gad_archive_tags.id"))->delete();
        }

        //更新gad_archives表tag字段
        $archiveTag = Archive::where("id", $archive_id)->value("tag");
        $tags = ltrim($archiveTag, ",");
        $tagArr = explode(",", $tags);
        foreach ($tagArr as $key => $value) {
            if ($value == $tag_name) {
                unset($tagArr[$key]);
                break;
            }
        }
        $tagNew = implode(",", $tagArr);
        $rows = Archive::where("id", $archive_id)->update(array('tag' => $tagNew));
        if ($rows > 0) {
            return json_encode(['data' => [], 'msg' => '删除成功', 'code' => '1']);
        } else {
            return json_encode(['data' => [], 'msg' => '删除失败', 'code' => '0']);
        }
    }


    //批量删除
    public function postPlDel(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $classid = $request->input('classid');
        $ids = explode(",", $id);
        $time = date('Y-m-d H:i:s', time());
        $updater_Id = Auth::user()['UserId'];

        switch ($classid) {
            case 1: //文章
                $ret = Article::whereIn('archive_id', $ids)->update(array('deleted_at' => $time));
                if ($ret > 0) {
                    Comment::whereIn('model_id', $ids)->update(array('deleted_at' => $time, "comment_count" => 0));
                }
                break;
            case 2: //作品
                $entry = Picture::whereIn("archive_id", $ids)->update(['deleted_at' => $time]);
                if ($entry > 0) {
                    Comment::whereIn('model_id', $ids)->update(array('deleted_at' => $time, "comment_count" => 0));
                }
                break;
            case 3: //问答
            case 4: //话题
                Question::whereIn("archive_id", $ids)->update(['status' => -1, 'updated_at' => $time]);

                $answerEntry = Answer::whereIn("archive_id", $ids);
                foreach ($answerEntry->get() as $item) {
                    Answer::where("answer_id", $item->id)->update(['status' => -1, 'updated_at' => $time, 'answer_count' => 0]);
                }

                $answerEntry->update(['status' => -1, 'updated_at' => $time, 'answer_count' => 0]);
                break;
        }

        $rows = Archive::whereIn('id', $ids)->update(array('deleted_at' => $time, 'updater' => $updater_Id, 'comment_count' => 0
            //, 'is_hot' => 0, 'extra' => "[]", 'sort_time' => null
        ));

        if ($rows > 0) {
            return json_encode(['data' => [], 'msg' => '批量删除成功', 'code' => '1']);
        } else {
            return json_encode(['data' => [], 'msg' => '批量删除失败', 'code' => '-1']);
        }
    }

    //批量推荐
    public function postPlHot(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $ids = explode(",", $id);
        $classid = $request->input('classid');
        $is_hot = $params['is_hot'];
        $updater_Id = Auth::user()['UserId'];

        $newIdsArr = [];
        $archives = $this->archiveRepository->whereIn('id', $ids)->findAll();

        if ($is_hot == 1) {
            foreach ($archives as $archive) {
                if ($archive['status'] == 0) { //已发布状态才可以进行推荐
                    array_push($newIdsArr, $archive['id']);
                }
            }
        } else {
            $newIdsArr = $ids;
        }

        $rows = Archive::whereIn('id', $newIdsArr)->update(array('is_hot' => $is_hot, 'updater' => $updater_Id)); //热门推荐

        if ($rows > 0) {
            if ($classid == 2) {
                Picture::whereIn("archive_id", $newIdsArr)->update(['is_hot' => $is_hot]);
            }
            if ($is_hot == 1) {
                return json_encode(['msg' => '批量推荐成功,已推荐' . $rows . '条内容', 'code' => '1']);
            } else {
                return json_encode(['msg' => '批量取消推荐成功,已取消推荐' . $rows . '条内容', 'code' => '1']);
            }
        } else {
            if ($is_hot == 1) {
                return json_encode(['msg' => '只有已发布状态才可以进行推荐', 'code' => '0']);
            } else {
                return json_encode(['msg' => '已经是取消推荐状态', 'code' => '0']);
            }
        }

    }

    //批量审核
    public function postPlCheck(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $ids = explode(",", $id);
        $classid = $request->input('classid');
        $updater_Id = Auth::user()['UserId'];

        $specialArr = [];//指定用户id集合
        $newIdsArr = [];

        $archives = $this->archiveRepository->whereIn('id', $ids)->findAll();

        foreach ($archives as $archive) {
            $url = '/article/detail';
            $mType = MessageType::ARTICLE_NEW;

            if ($archive['class_id'] == 2) {
                $url = '/gallery/detail';
                $mType = MessageType::WORK_NEW;
            }

            if ($archive['status'] > 1) { //待审核或审核不通过状态
                array_push($newIdsArr, $archive['id']);

                if ($archive['class_id'] <= 2) {
                    $fans = $this->followRepository->getFans($archive['user_id'], ['user_id'])->toArray();
                    dispatch(new SendMessage($mType, array_column($fans, 'user_id'),
                        $archive['user_id'], $archive['id'], url($url, $archive['id']), $archive['title']));
                    $msgType = $classid == 1 ? \App\Gad\MessageType::ARTICLE_ACCEPT : \App\Gad\MessageType::ART_ACCEPT;
                    dispatch(new \App\Jobs\SendMessage($msgType, $archive['user_id'], 0, $id, $url, $archive['title']));
                }
                if ($archive['class_id'] == 1) {
                    $articleRepository = app(\App\Repositories\ArticleRepository::class);
                    $articleRepository->reviewArticle($articleRepository->findBy('archive_id', $archive['id']));
                }
            }

            $userArr = array(2191628, 451240, 33894, 704370, 1449105, 659510, 2248870);
            $isExist = in_array($archive['user_id'], $userArr);
            if ($isExist) {
                array_push($specialArr, $archive['id']);
            }
        }

        if ($classid == 2) {
            Picture::whereIn("archive_id", $newIdsArr)->update(['status' => 1]);//发布
        } elseif ($classid == 3) {
            Question::whereIn("archive_id", $newIdsArr)->update(['status' => 0]);
        }

        if (count($specialArr) > 0) { //指定用户，审核通过的时候，把sort_time字段设为0
            Archive::whereIn('id', $specialArr)->update(array("sort_time" => 0, 'updater' => $updater_Id));
        }

        $count = Archive::whereIn('id', $newIdsArr)->update(array('status' => 0, 'updater' => $updater_Id));
        if ($count > 0) {
            return json_encode(['msg' => '批量审核成功,已通过' . $count . '个可审核的内容', 'code' => '1']);
        } else {
            return json_encode(['msg' => '只有待审核、不通过状态的内容可进行审核操作', 'code' => '0']);
        }
    }


    /******************回答列表***********************/
    public function postAnswerList(Request $request)
    {
        $obj_id = intval($request->input('obj_id'));

        $entry = $this->answer->with('question')->with('user_manager');

        if ($obj_id == 0) {
            $entry->where("gad_answers.archive_id", '>', 0);

            $entry->whereHas('question', function ($query) {
                $query->where('gad_archives.deleted_at', null);
            });

            if ($request->has('title')) {
                $str = $request->input('title');
                $entry->whereHas('question', function ($query) use ($str) {
                    $query->where('gad_archives.title', 'like', '%' . $str . '%');
                });
            }

            if ($request->has('is_hot') && $request->input('is_hot') != -1) {
                if ($request->input('is_hot') == 1) {
                    $entry->whereHas('question', function ($query) {
                        $query->where('gad_archives.hot_aid', '>', 0);
                    });
                } else {
                    $entry->whereHas('question', function ($query) {
                        $query->where('gad_archives.extra', '[]')->where('gad_archives.hot_aid', '<=', 0);
                    });
                }
            }

        } else {
            $type = intval($request->input('type'));
            if ($type == 1) {
                $entry->where("gad_answers.archive_id", $obj_id);
            } else {
                $entry->where("gad_answers.answer_id", $obj_id);
            }
        }

        $entry->whereHas('user_manager', function ($query) {
            $query->where('User.RowStatus', 0);
        });


        if ($request->has('id')) {
            $entry->where('gad_answers.id', $request->input('id'));
        }

        if ($request->has('answer')) {
            $str = $request->input('answer');
            $entry->where('gad_answers.answer', 'like', '%' . $str . '%');
        }

        if ($request->has('userid')) {
            $entry->where('gad_answers.user_id', $request->input('userid'));
        }

        if ($request->has('username')) {
            $str = $request->input('username');
            $entry->whereHas('user_manager', function ($query) use ($str) {
                $query->where('User.NickName', 'like', '%' . $str . '%');
            });
        }

        if ($request->has('qq')) {
            $qq = $request->input('qq');
            $entry->whereHas('user_manager', function ($query) use ($qq) {
                $query->where('User.QQNo', $qq);
            });
        }

        if ($request->has('rank') && $request->input('rank') != -1) {
            $entry->where('gad_answers.rank', $request->input('rank'));
        }

        if ($request->has('source') && $request->input('source') != -1) {
            $entry->where('gad_answers.source', $request->input('source'));
        }

        if ($request->has('adopt') && $request->input('adopt') != -1) {
            $entry->where('gad_answers.adopt', $request->input('adopt'));
        }

        if ($request->has('status') && $request->input('status') != 1) {
            $entry->where('gad_answers.status', $request->input('status'));
        }

        if ($request->has('is_topic') && $request->input('is_topic') != -1) {
            $entry->where('gad_answers.is_topic', $request->input('is_topic'));
        }

        $begin_time = $request->input('begin_time');
        $end_time = $request->input('end_time');

        if (!empty($begin_time) && !empty($end_time)) {
            $entry->where("gad_answers.created_at", '>=', $begin_time)->where("gad_answers.created_at", '<=', $end_time);
        }

        $data = $entry->orderBy('gad_answers.id', 'desc')->paginate($request->input('pageSize', 30));

        if ($obj_id == 0) {
            foreach ($data as $key => $item) {
                if ($item->hot_aid > 0 && $item->hot_aid == $item->id) {
                    $data[$key]["is_recommend"] = 1;
                } else {
                    $data[$key]["is_recommend"] = 0;
                }
            }
        }


        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
        return response()->json(['data' => $data, 'msg' => 'success', 'code' => '0', 'hostname' => $host]);
    }

    //修改回答用户
    public function postUpdateAnswer(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $userid = $params['user_id'];
        $entry = User::where("UserId", $userid)->first();
        if ($entry) {
            $arr = $this->answerEloquent->update(['user_id' => $userid, 'user_name' => $entry->NickName], $id);
        } else {
            return json_encode(['msg' => '用户不存在', 'code' => '-1']);
        }
        if ($arr->id) {
            return json_encode(['msg' => '修改成功', 'code' => '1']);
        } else {
            return json_encode(['msg' => '修改失败', 'code' => '-1']);
        }
    }

    //删除或恢复
    public function postUpdateAnswerStatus(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $status = $params['status'];

        if ($status == 0) { //恢复
            $time = null;
            $isDel = 0;
        } else {
            $time = Carbon::now();
            $isDel = -1;
        }

        $answer_row = Answer::find($id);
        if (!empty($answer_row)) { //二级回复
            if ($answer_row->answer_id > 0) {
                $answer_row->update(array('status' => $isDel, 'updated_at' => $time));
                if ($status == 0) { //恢复
                    Answer::where("id", $answer_row->answer_id)->increment('answer_count', 1);
                } else {
                    Answer::where("id", $answer_row->answer_id)->decrement('answer_count', 1);
                }
                return 1;
            } else {
                //删掉所有的二级回复
                Answer::where("answer_id", $id)->update(array('status' => $isDel, 'updated_at' => $time));

                if ($status == 0) { //恢复
                    $countOld = Answer::where("answer_id", $id)->count();
                } else {
                    $countOld = 0;
                }

                $answer_row->update(array('status' => $isDel, 'answer_count' => $countOld, 'updated_at' => $time));

                $archive = Archive::find($answer_row->archive_id);
                $updater_Id = Auth::user()['UserId'];

                if ($answer_row->id == $archive->hot_aid) {
                    if ($status == 0) { //恢复
                        $archive->update(array(
                            'updater' => $updater_Id, 'comment_count' => $archive->comment_count + 1));
                    } else {
                        $archive->update(array(
                            'extra' => [], "hot_aid" => 0,
                            //'sort_time' => strtotime($archive->created_at),
                            'updater' => $updater_Id, 'comment_count' => $archive->comment_count - 1));
                    }
                } else {
                    if ($status == 0) { //恢复
                        $archive->update(['comment_count' => $archive->comment_count + 1, 'updater' => $updater_Id]);//被评论次数
                    } else {
                        $archive->update(['comment_count' => $archive->comment_count - 1, 'updater' => $updater_Id]);//被评论次数
                    }
                }

            }
        } else {
            return -1;
        }

        return 1;
    }

    //答案置顶、置底
    public function postUpdateAnswerRank(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $arr = $this->answerEloquent->update(['rank' => $params['rank']], $id);
        return $arr->id;
    }

    //推荐
    public function postUpdateIsHot(Request $request)
    {
        $time = time();
        $params = $request->all();
        $id = $request->input('id');
        $archive_id = $request->input('archive_id');
        $ishot = $params['is_hot'];

        if ($ishot == 1)//推荐
        {
            $archive = Archive::find($archive_id);
            $answer = Answer::find($id);
            $is_hot = false;
            if ($archive->hot_aid > 0) {
                $hot_answer = Answer::find($archive->hot_aid);
                //获取已经推荐过了的答案的最大点赞数
                if ($hot_answer && $hot_answer->like_count > $answer->like_count) {
                    $is_hot = true;
                }
            }

            if ($is_hot == true) {
                return -1;
            }

            $extra = $answer;
            if (!empty($extra)) {
                $extra->answer = strip_tags($extra->answer);
            }
            $extra->avatar = User::where("UserId", $extra->user_id)->value("avatar");
            $hot_aid = $id;
            $time = strtotime($extra->created_at);

        } else //取消推荐
        {
            $extra = [];
            $time = null;
            $hot_aid = 0;
        }

        $updater_Id = Auth::user()['UserId'];
        $arr = $this->archiveEloquent->update(['is_hot' => $params['is_hot'], "hot_aid" => $hot_aid, 'updater' => $updater_Id, 'extra' => $extra], $archive_id);
        return $arr->id;
    }

    //批量删除答案
    public function postPlDelAnswer(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $ids = explode(",", $id);
        $time = date('Y-m-d H:i:s', time());

        foreach ($ids as $item) {
            $answer_row = Answer::find($item);
            if (!empty($answer_row)) { //二级回复
                if ($answer_row->answer_id > 0) {
                    $answer_row->update(array('status' => -1));
                    $panswer = Answer::find($answer_row->answer_id);
                    if ($panswer->answer_count > 0) {
                        $panswer->decrement('answer_count');//更新父级的answer_count数量
                    }
                } else {
                    //删掉下面的二级回复
                    Answer::where("answer_id", $item)->update(array('status' => -1, 'updated_at' => $time));
                    $answer_row->update(array('status' => -1, 'answer_count' => 0, 'updated_at' => $time));

                    $updater_Id = Auth::user()['UserId'];
                    $archive = Archive::find($answer_row->archive_id);
                    if ($answer_row->id == $archive->hot_aid) {
                        $archive->update(array(
                            'extra' => [], "hot_aid" => 0,
                            //'sort_time' => strtotime($archive->created_at),
                            'updater' => $updater_Id, 'comment_count' => $archive->comment_count - 1));
                    } else {
                        $archive->update(['comment_count' => $archive->comment_count - 1, 'updater' => $updater_Id]);//被评论次数
                    }
                }
            }
        }
        return json_encode(['data' => [], 'msg' => '批量删除成功', 'code' => '1']);
    }

    //批量推荐答案
    public function postPlAnswerHot(Request $request)
    {
        $params = $request->all();
        $id = $params['id'];
        $ids = explode(",", $id);

        $rows = 0;
        $list = Answer::whereIn("id", $ids)->get();

        foreach ($list as $key => $answer) {
            $archive = Archive::find($answer->archive_id);
            if ($archive->hot_aid > 0) {
                $hot_answer = Answer::find($archive->hot_aid);
                //获取已经推荐过了的答案的最大点赞数
                if ($hot_answer && $hot_answer->like_count > $answer->like_count) {
                    continue;
                }
            }

            if (!empty($answer)) {
                $answer->answer = strip_tags($answer->answer);
            }
            $answer->avatar = User::where("UserId", $answer->user_id)->value("avatar");

            $updater_Id = Auth::user()['UserId'];
            $rows .= $archive->update(array('extra' => $answer, 'updater' => $updater_Id,
                "hot_aid" => $answer->id, 'is_hot' => $params['is_hot']
                //, 'sort_time' => time()
            ));
        }

        if ($rows > 0) {
            return json_encode(['data' => [], 'msg' => '批量推荐成功', 'code' => '1']);
        } else {
            return json_encode(['data' => [], 'msg' => '批量推荐失败', 'code' => '-1']);
        }

    }


}