<?php

namespace App\Http\Controllers\Mgr;

use App\Gad\TofService;
use App\Http\Controllers\Controller;
use App\Jobs\SendMail;
use Illuminate\Http\Request;

use App\Http\Requests;
use Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Http\Requests\ServiceCreateRequest;
use App\Http\Requests\ServiceUpdateRequest;
use App\Repositories\ServiceRepository;
use App\Entities\Service;


class ServicesController extends Controller
{

    /**
     * @var ServiceRepository
     */
    protected $repository;

    public function __construct(ServiceRepository $serviceRepository)
    {
        $this->repository = $serviceRepository;
    }


    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
     */
    public function index(Request $request)
    {
        if ($request->has('status')) {
            $this->repository->where('status', '=', $request->input('status'));
        }

        if ($request->has('service_type')) {
            // 获取新增没有审核的服务
            if (0 == $request->input('service_type')) {

                $this->repository->whereIn('service_type', [1, 3]);
                $this->repository->where('status', '=', 1);
            } else {
                $this->repository->where('service_type', '=', $request->input('service_type'));
            }

        }

        $this->repository->with(['member']);
        $services = $this->repository->orderBy('id', 'desc')->paginate(10);
        if (request()->wantsJson()) {
            return response()->json([
                'data' => $services,
            ]);
        }

        return view('services.index', compact('services'));
    }

    /**
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        try {
            list($status, $service) = $this->repository->create($request->all());
            $response = [
                'message' => 'Service created.',
                'data' => $service->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $service = $this->repository->find($id);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $service,
            ]);
        }

        return view('services.show', compact('service'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $service = $this->repository->find($id);

        return view('services.edit', compact('service'));
    }


    /**
     * @param Request $request
     * @param $id
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        try {
            list($status, $service) = $this->repository->update($id, $request->all());
            if ($request->has('check') && 'check' == $request->input('check')) {
                // 发送邮件
                $this->pushMessage($service);

            }
            $response = [
                'message' => 'Service updated.',
                'data' => $service->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleted = $this->repository->delete($id);

        if (request()->wantsJson()) {

            return response()->json([
                'message' => 'Service deleted.',
                'deleted' => $deleted,
            ]);
        }

        return redirect()->back()->with('message', 'Service deleted.');
    }


    protected function pushMessage($service)
    {

        // 1、 发送邮件
        try {
            $serviceType = Service::$serviceType;
            $title = '[GAD]' . $serviceType[$service->service_type] . '合作审核结果通知';
            $body = '你的' . $service->name . '已审核。';
            if ($service->member && $service->member->email) {

                $serviceType[$service->service_type];

                $mail = view('email.projectService', array('user' => $service->member->contacts, 'title' => $title,'body'=>$body,'status' => $service->status, 'reason' => $service->reason))->render();
                dispatch(new SendMail($service->member->email, $title, $mail));
                // \Tof::service('message')->sendEmail('gad@tencent.com', $service->member->email, $title, $mail);
            }
            // 2、 发送短信
            if ($service->member->phone) {
                $status = ($service->status == 0) ? '审核结果:已通过。' : ' 审核结果:不通过。';
                $status .= '详情官网查看';
                TofService::sendSms($service->member->phone, $title . $body . $status);
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }

    }
}
