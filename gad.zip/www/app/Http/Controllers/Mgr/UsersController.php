<?php

namespace App\Http\Controllers\Mgr;

use App\Http\Requests;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Repositories\UserRepositoryEloquent;
use App\Models\UserManager;

class UsersController extends Controller
{

    /**
     * @var UserRepository
     */
    protected $repository;

    /**
     * @var UserValidator
     */
    protected $validator;

    public function __construct(UserRepositoryEloquent $repository)
    {
        $this->repository = $repository;

    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $request = Request::capture();
        $this->repository = $this->repository;
        if ($request->has('UserId')) {
            $this->repository = $this->repository->where('UserId', $request->input('UserId'));
        }
        if ($request->has('NickName')) {
            $this->repository = $this->repository->where('NickName', 'like', "%" . $request->input('NickName') . "%");
        }
        if ($request->has('QQNo')) {
            $this->repository = $this->repository->where('QQNo', 'like', "%" . $request->input('QQNo') . "%");
        }
        $users = $this->repository->paginate(10);
        if (request()->wantsJson()) {

            return response()->json([
                'data' => $users,
            ]);
        }

        return view('users.index', compact('users'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        try {

            $this->validate($request,
                [
                    'QQNo' => 'bail|unique:User',
                    'WeixinId' => 'bail|unique:User',
                ], [
                    'QQNo.unique' => 'QQ重复',
                    'WeixinId.unique' => '微信重复',
                ]
            );

            $user = $this->repository->create($request->all());

            if ($user[0]) {
                $response = [
                    'error' => 0,
                    'message' => 'User created.',
                    'data' => $user[1],
                ];

            } else {
                $response = [
                    'error' => 1,
                    'message' => '创建失败',
                ];
            }


            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (\Exception $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error' => 1,
                    'message' => 'QQ或微信重复'
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = $this->repository->find($id);
        if (request()->wantsJson()) {
            return response()->json([
                'data' => $user,
            ]);

        }
        return view('users.show', compact('user'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = $this->repository->find($id);

        return view('users.edit', compact('user'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  Request $request
     * @param  string $id
     *
     * @return Response
     */
    public function update(Request $request, $id)
    {
        try {
            $param = $request->all();
            $param['Created'] = Carbon::now();
            $user = $this->repository->update($id, $param);

            $response = [
                'message' => '修改成功',
                'data' => $user[0],
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleted = $this->repository->delete($id);

        if (request()->wantsJson()) {

            return response()->json([
                'message' => 'User deleted.',
                'deleted' => $deleted,
            ]);
        }

        return redirect()->back()->with('message', 'User deleted.');
    }
}
