<?php

namespace App\Http\Controllers\Mgr;


use App\Http\Controllers\Controller;
use App\Repositories\ExpertPlanRepository;
use App\Repositories\TutorRepository;
use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Support\Facades\App;
use Auth;
use Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;


class ExpertPlansController extends Controller
{

    /**
     * @var ExpertPlanRepository
     */
    protected $repository;

    /**
     * @var ExpertPlanValidator
     */
    protected $validator;

    /**
     * @var TutorRepository
     */
    protected $tutorRepository;

    public function __construct(ExpertPlanRepository $repository, TutorRepository $tutorRepository)
    {
        $this->repository = $repository;

        $this->tutorRepository = $tutorRepository;

    }


    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
     */
    public function index(Request $request)
    {

        if ($request->has('order_by')){
            $this->repository->where('is_recommend','>',0);
            $expertPlans = $this->repository->with(['category'])->orderBy('is_recommend', 'desc')->limit(4)->paginate(4);
            if (request()->wantsJson()) {

                return response()->json([
                    'data' => $expertPlans,
                ]);
            }
        }



        if ($request->has('whereId')) {
            $this->repository->where('id', $request->input('whereId'));
        }
        if ($request->has('name')) {
            $this->repository->where('name', 'like', "%" . $request->input('name') . "%");
        }
        if ($request->has('phone')) {
            $this->repository->where('phone', 'like', "%" . $request->input('phone') . "%");
        }
        if ($request->has('status')) {
            $this->repository->where('status', $request->input('status'));
        }
        if ($request->has('wish')) {
            //["\\\u7b54\u7591\","\\\u987e\u95ee\","\\\u8bc4\u5ba1\","\\\u5206\u4eab\"]
            //dd(json_encode( ["晨星答疑团", "晨星顾问团", "晨星评审团", "晨星分享团"]));
            //   WTF...
            $wish = $request->input('wish');
            switch ($wish) {
                case 1:
                    $wishType = 'u7591';
                    $this->repository->where('wish', 'like', "%u7b54%");
                    break;
                case 2:
                    $wishType = 'u95ee';
                    $this->repository->where('wish', 'like', "%u987e%");

                    break;
                case 3:
                    $wishType = 'u5ba1';
                    $this->repository->where('wish', 'like', "%u8bc4%");
                    break;
                case 4:
                    $wishType = 'u4eab';
                    $this->repository->where('wish', 'like', "%u5206%");
                    break;
            }


        }




        $expertPlans = $this->repository->with(['category'])->orderBy('sort', 'asc')->paginate(10);


        if (request()->wantsJson()) {

            return response()->json([
                'data' => $expertPlans,
            ]);
        }

        return view('expertPlans.index', compact('expertPlans'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {

        try {

            $expertPlan = $this->repository->create($request->all());

            $response = [
                'message' => 'ExpertPlan created.',
                'data' => $expertPlan->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $expertPlan = $this->repository->with(['category'])->find($id);

        if (request()->wantsJson()) {

            return response()->json([
                'data' => $expertPlan,
            ]);
        }

        return view('expertPlans.show', compact('expertPlan'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $expertPlan = $this->repository->find($id);

        return view('expertPlans.edit', compact('expertPlan'));
    }


    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param $id
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {

        try {


            $expertPlan = $this->repository->update($id, $request->all());
            $expertPlanRepository = $this->repository->find($id);
            if ($request->input('category'))
                $expertPlanRepository->category()->sync($request->input('category'));
            //如果是审核的操作 发送邮件
            if ($request->has('check') && 'check' == $request->input('check')) {
                $title = '[GAD专家团]审核结果通知';
                $mail = view('hatch.expert_plan.mail_notify', array('user' => $expertPlan[1]->name, 'title' => $title, 'status' => $expertPlan[1]->status, 'reason' => $request->input('reason')))->render();
                \Tof::service('message')->sendEmail('gad@tencent.com', $expertPlan[1]->email, $title, $mail);
            }

            $response = [
                'message' => 'ExpertPlan updated.',
                'data' => $expertPlan[1]->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleted = $this->repository->delete($id);

        if (request()->wantsJson()) {

            return response()->json([
                'message' => 'ExpertPlan deleted.',
                'deleted' => $deleted,
            ]);
        }

        return redirect()->back()->with('message', 'ExpertPlan deleted.');
    }

    /**
     * 置顶
     * @param $id
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function toTop($id, Request $request)
    {
        try {

            $expertPlan = $this->repository->update($id, ['sort' => $this->repository->getMaxSort() - 1]);

            $response = [
                'message' => 'ExpertPlan updated.',
                'data' => $expertPlan[1]->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }


    }

    /**
     * 向上
     * @param $id
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function upward($id, Request $request)
    {

        try {
            $this->repository->upward($id);
            $response = [
                'message' => 'ExpertPlan updated.',
                'data' => [],
            ];
            if ($request->wantsJson()) {

                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }

    }

    /**
     * 向下
     * @param $id
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function down($id, Request $request)
    {
        try {
            $this->repository->down($id);
            $response = [
                'message' => 'ExpertPlan updated.',
                'data' => [],
            ];
            if ($request->wantsJson()) {

                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }

    }


    /**
     * 晨星首页 专家配置 添加
     * @param $id
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     * @throws \Rinvex\Repository\Exceptions\RepositoryException
     */
    public function toHomePage($id, Request $request)
    {
        try {
            $expertPlan = $this->repository->update($id, ['is_recommend' => $this->repository->getMaxIsRecommend() + 1]);
            $response = [
                'message' => 'ExpertPlan updated.',
                'data' => $expertPlan[1]->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }


    }

    /**
     * 晨星首页 专家配置 移除
     * @param $id
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     * @throws \Rinvex\Repository\Exceptions\RepositoryException
     */
    public function removeHomePage($id, Request $request)
    {
        try {
            $expertPlan = $this->repository->update($id, ['is_recommend' => 0 ]);
            $response = [
                'message' => 'ExpertPlan updated.',
                'data' => $expertPlan[1]->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }


    }

    /**
     * 晨星首页 专家配置 向上
     * @param $id
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function upwardHomePage($id, Request $request)
    {

        try {
            $this->repository->upwardHomePage($id);
            $response = [
                'message' => 'ExpertPlan updated.',
                'data' => [],
            ];
            if ($request->wantsJson()) {

                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }

    }

    /**
     * 晨星首页 专家配置 向下
     * @param $id
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function downHomePage($id, Request $request)
    {
        try {
            $this->repository->downHomePage($id);
            $response = [
                'message' => 'ExpertPlan updated.',
                'data' => [],
            ];
            if ($request->wantsJson()) {

                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }

    }

    // | ==============================================
    // | 晨星每月专家配置
    // | ==============================================

    /**
     * 获取列表
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getTutorList(Request $request)
    {

        try {

            $res = $this->tutorRepository
                ->orderBy('year_month', 'desc')
                ->paginate(10);
            $response = [
                'message' => 'success',
                'data' => $res,
                'code' => 0
            ];
            return response()->json($response);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }


    }

    /**
     *  添加专家
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function createTutor(Request $request)
    {

        try {
            $data = $request->input();
            $data['creator'] = Auth::user()['UserId'];

            $count = $this->tutorRepository->where('year_month', '=', $data['year_month'])->findAll();
            if (count($count) >= 4) {
                return response()->json([
                    'error' => 1,
                    'message' => '该月份下已经有四条了'
                ]);
            }

            $this->tutorRepository->create($data);

            $response = [
                'message' => 'ExpertPlan updated.',
                'data' => [],
            ];
            if ($request->wantsJson()) {
                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }

    }

    /**
     * 获取
     * @param $id
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function showTutor($id, Request $request)
    {
        $res = $this->tutorRepository->find($id);
        return response()->json([
            'error' => 0,
            'message' => 'success',
            'data' => $res
        ]);
    }

    /**
     * 更新专家
     * @param $id
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
     */
    public function updateTutor($id, Request $request)
    {
        try {
            $data = $request->input();
            $data['creator'] = Auth::user()['UserId'];

            $count = $this->tutorRepository
                ->where('year_month', '=', $data['year_month'])
                ->where('id', '<>', $id)
                ->findAll();
            if (count($count) >= 4) {
                return response()->json([
                    'error' => 1,
                    'message' => '该月份下已经有四条了'
                ]);
            }

            $this->tutorRepository->update($id, $data);

            $response = [
                'message' => 'ExpertPlan updated.',
                'data' => [],
            ];
            if ($request->wantsJson()) {
                return response()->json($response);
            }
            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {

            if ($request->wantsJson()) {

                return response()->json([
                    'error' => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

    /**
     * 删除专家
     * @param $id
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function deleteTutor($id, Request $request)
    {

        $res = $this->tutorRepository->delete($id);

        return response()->json([
            'error' => 0,
            'message' => '删除成功'
        ]);
    }





}
