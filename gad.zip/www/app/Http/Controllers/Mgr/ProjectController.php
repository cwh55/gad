<?php

namespace App\Http\Controllers\Mgr;

use App\Entities\HatchProject;
use App\Models\Game;
use App\Models\Register;
use App\Gad\MessageType;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Gad\TofService;
use App\Gad\Func;
use Illuminate\Support\Facades\DB;
use Auth;

class ProjectController extends Controller
{
    public function postGameList(Request $request)
    {
        $params = $request->all();
        $queryArray = array();
        if (!empty($params['id']) && is_numeric($params['id'])) {
            $queryArray['id'] = $params['id'];
        }
        if (!empty($params['name'])) {
            $queryArray['name'] = $params['name'];
        }
        if (is_numeric($params['status']) && $params['status'] != -3) {
            $queryArray['status'] = $params['status'];
        }
        if (is_numeric($params['obj_type']) && $params['obj_type'] != -3) {
            $queryArray['obj_type'] = $params['obj_type'];
        }
        if (is_numeric($params['obj_id']) && $params['obj_id'] != 0) {
            $queryArray['obj_id'] = $params['obj_id'];
        }
        if (!empty($params['reg_step']) && is_numeric($params['reg_step'])) {
            $queryArray['reg_step'] = $params['reg_step'];
        }
        !empty($params['startTime']) && ($queryArray[] = ['created_at', '>=', date('Y-m-d 00:00:00', strtotime($params['startTime']))]);
        !empty($params['endTime']) && ($queryArray[] = ['created_at', '<=', date('Y-m-d 23:59:59', strtotime($params['endTime']))]);
        $projectlist = Game::with('project');

        if (!empty($params['project_name'])) {
            $project_name = $params['project_name'];
            $projectlist->whereHas('project', function ($query) use ($project_name) {
                $query->where('gad_projects.name', "like", "%" . $project_name . "%");
            });
        }

        $projectlist = $projectlist->where($queryArray);
        $result = $projectlist->orderBy('updated_at', 'desc')->paginate($request->get('pageSize', 10));

        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
        foreach ($result as $project) {
            if ($project->project) {
                $project->project->setVisible([]);
            }
            $result["hostname"] = $host;
        }
        return $result;
    }

    public function excelProjectList(Request $request)
    {
        require_once(dirname(__FILE__) . '/../../../Phpexcel/Excel.php');
        $params = $request->all();
        $condtions = [];
        !empty($params['startTime']) && ($condtions[] = ['created_at', '>=', date('Y-m-d 00:00:00', strtotime($params['startTime']))]);
        !empty($params['endTime']) && ($condtions[] = ['created_at', '<=', date('Y-m-d 23:59:59', strtotime($params['endTime']))]);
        !empty($params['id']) && ($condtions[] = ['id', '=', $params['id']]);
        !empty($params['status']) && $params['status'] != -3 && ($condtions[] = ['status', '=', $params['status']]);
        !empty($params['obj_type']) && $params['obj_type'] != -3 && ($condtions[] = ['obj_type', '=', $params['obj_type']]);
        !empty($params['obj_id']) && ($condtions[] = ['obj_id', '=', $params['obj_id']]);
        !empty($params['reg_step']) && ($condtions[] = ['reg_step', '=', $params['reg_step']]);
        !empty($params['name']) && ($condtions[] = ['name', 'like', $params['name']]);
        ini_set('memory_limit', '512M');
        set_time_limit(0);
        $rows = Game::with('project')->where($condtions)->get();

        foreach ($rows as $project) {
            if ($project["project"]) {
                $project["project"]->setVisible([]);

                $project["project"]['platform']= implode('、',$project["project"]['platform']);
                $demoStr = '';
                foreach ($project["project"]['demo'] as $demo){
                   $demoStr .= $demo['name'].':'.$demo['url'].';';
                }
                $videosStr ='';
                foreach ($project["project"]['videos'] as $demo){
                    $videosStr .= $demo['name'].':'.$demo['url'].';';
                }

                $pptStr ='';
                foreach ($project["project"]['ppt'] as $demo){
                    $pptStr .= $demo['name'].':';
                }

                $picturesStr ='';
                foreach ($project["project"]['pictures'] as $demo){
                    $picturesStr .= $demo['name'].':'.$demo['url'].';';
                }



                $project["project"]['demo']= $demoStr;
                $project["project"]['videos']= $videosStr;
                $project["project"]['ppt']= $pptStr;
                $project["project"]['pictures']= $picturesStr;

            }
        }



        $header = array(
            'id' => 'ID',
            'project.name' => '游戏名称',
//            'name' => '游戏名称',

            'project.team_name' => '团队名称',
            'project.team_logo' => '团队logo',
            'project.team_intro' => '团队介绍',
            //'project.company' => '公司全称',
            'project.team_logo' => '公司logo',
            //'project.info' => '公司介绍',
            'project.team_business_license' => '营业执照注册号',
            //'project.member_count' => '人数',

            'area' => '所在地',
            'project.user_name' => '姓名',
            'project.team_id_card' => '证件号码',

            'project.platform' => '运行平台',
//            'project.game_oses' => '运行平台',
            'project.intro' => '游戏介绍',
            'project.demo' => '试玩安装包',
            'project.videos' => '演示视频',
            'project.pictures' => '游戏截图',
            'other_attachment' => '其他展示资料',
            'hatch_service' => '扶持服务',

            'user_id' => '作者ID',
            'project.team_phone' => '手机号',
            'project.team_weixin' => '微信号',
            //'project.team_email' => 'QQ号',
            'project.team_email' => '邮箱',
            'created_at' => '提交申请时间'
        );
        foreach ($rows as &$r) {
            $r['logo'] = is_array($r['logo']) ? implode(',', array_column($r['logo'], 'url')) : $r['logo'];
            $r['hatch_service'] = is_array($r['hatch_service']) ? implode(',', $r['hatch_service']) : $r['hatch_service'];
            $r['game_oses'] = is_array($r['game_oses']) ? implode(',', $r['game_oses']) : $r['game_oses'];
            $r['videos'] = is_array($r['videos']) ? implode(',', array_column($r['videos'], 'url')) : $r['videos'];
            $r['other_attachment'] = is_array($r['other_attachment']) ? implode(',', array_column($r['other_attachment'], 'url')) : $r['other_attachment'];
            $r['demo'] = is_array($r['demo']) ? implode(',', array_column($r['demo'], 'url')) : $r['demo'];
            foreach ($header as $h => $v) {
                $x = explode('.', $h);
                if (count($x) > 1) {
                    $r[$h] = isset($x[0]) && isset($r[$x[0]][$x[1]]) ? $r[$x[0]][$x[1]] : '';
                }
            }
            if (isset($r['project'])) {
                $r['area'] = $r['project']['team_province'] . $r['project']['team_city'];
            } else {
                $r['area'] = '';
            }
        }
        $file_name = 'resultProjret_' . substr(str_replace(" ", "", microtime(false)), 2) . ".xls";
        $excel = new \Excel();

        $excel->downloadToExcel($header, $rows, $file_name);
    }

    public function manageGame(Request $request)
    {
        $params = $request->all();
        if (!empty($params['ids'])) {
            $ids = explode(',', $params['ids']);
        }
        $games = Game::with("project")->whereIn('id', $ids)->get();

        $flow=0;
        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
        $status = $params['status'];
        $login_userId = Auth::user()['UserId'];

        //状态审核
        if (isset($status) && is_numeric($status)) {
            $gamecount = Game::whereIn('id', $ids)->update(array('status' => $params['status'], 'reason' => $params['reason']));
            foreach ($games as $game) {
                $urlContent = sprintf('http://%s/hatch/detail/%d', config('SERVER_ENVIRONMENT') == 'dev' ? 'dev.gad.qq.com' : 'gad.qq.com', $game->id);
                if ($status == 2) {
                    $flow=1;
                    $msg = "很抱歉，您提交的游戏项目《" . $game->project->name . "》未通过资料初审";
                    $title = "【GAD-项目扶持】您的项目暂未通过资料审核";
                    $reason2 = $params['reason'];
                    $messageType = MessageType::PROJECT_AUDIT_FAIL;
                    Func::msgApi($messageType, $game->user_id, $login_userId, $game->id, url($urlContent),'查看详情',0, '', $params['reason']);
                } else {
                    $flow=2;
                    $msg = "经过资料初审，已确认您提交的游戏项目《" . $game->project->name . "》资料完整，后续会有专人联系跟进";
                    $title = "【GAD-项目扶持】您的项目已通过资料审核";
                    $messageType = MessageType::PROJECT_AUDIT_SUCCESS;
                    Func::msgApi($messageType, $game->user_id, $login_userId, $game->id, url($urlContent), '查看详情');
                }

                $email = $game->project->team_email;
                $phone = $game->project->team_phone;
                $reason = $msg;

                if (!empty($email)) {
                    $mail = view('hatch.mail_mgr_team', compact('email', 'reason', 'reason2', 'title'))->render();
                    if ($host == "http://gad.qq.com") {
                        \Tof::service('message')->sendEmail('gad@tencent.com', $email, $title, $mail);
                    }
                }

                if (!empty($phone)) {
                    if ($params['status'] == 2) {
                        $reason = "，原因是：" . $reason2;
                        TofService::sendsms($phone, $msg . $reason);
                    } else {
                        TofService::sendsms($phone,$msg);
                    }
                }
            }


        }
        //孵化进度更改
       if (isset($flow) && is_numeric($flow)) {
            $gamecount = Game::whereIn('id', $ids)->update(array('flow' => $flow));
        }
        return $gamecount;
    }

    public function getRegisterList(Request $request)
    {
        $result = ['total' => 0, 'entrylist' => []];
        $page = $request->get('page', 1);
        $skip = ($page - 1) * 10;
        $entry = Register::query()->where('type', $request->input('type'));
        if ($request->has('id')) {
            $entry->where('id', $request->input('id'));
        }
        if ($request->has('user_name')) {
            $entry->where('user_name', $request->input('user_name'));
        }
        if ($request->has('status') && $request->input('status') != -3) {
            $entry->where('status', $request->input('status'));
        }
        if ($request->has('obj_type') && $request->input('obj_type') != -3) {
            $entry->where('obj_type', $request->input('obj_type'));
            if ($request->has('obj_id')) {
                $entry->where('obj_id', $request->input('obj_id'));
            }
        }
        $result['total'] = $entry->count();
        $result['entrylist'] = $entry->skip($skip)->take(10)->orderBy('id', 'desc')->get();
        //转化member
        $result['entrylist']->map(function ($item) {
            $members = $item->members;
            if ($members && $item->type == 0) {
                $members = json_decode($members);
                if ($members) {
                    $content = '';
                    foreach ($members as $member) {
                        $content .= '姓名:' . $member->name . ';<br/>';
                        $content .= '身份证:' . $member->team_id_card . ';<br/>';
                        $content .= '职位:' . $member->position . ';<br/>';
                    }
                    $item->members = $content;
                }
            }
        });

        return response()->json($result);

    }

    public function setRegister(Request $request)
    {
        $params = $request->all();
        if (!empty($params['ids'])) {
            $ids = explode(',', $params['ids']);
        }
        if (isset($params['status']) && is_numeric($params['status'])) {
            if ($params['status'] == 2) {
                $msg = "你所登记的开发者（机构）信息由于" . $params['reason'] . "原因，未能通过审核，请完善后再次上传；Gad腾讯游戏开发者平台，做有梦想的游戏人";
                $count = Register::whereIn('id', $ids)->update(array('status' => $params['status'], 'reason' => $params['reason']));
                //$count = HatchProject::whereIn('id', $ids)->update(array('status' => $params['status'], 'reason' => $params['reason']));
            } else {
                $msg = "你所登记的开发者（机构）信息已通过审核；Gad腾讯游戏开发者平台，做有梦想的游戏人";
                $count = Register::whereIn('id', $ids)->update(array('status' => $params['status']));
                //$count = HatchProject::whereIn('id', $ids)->update(array('status' => $params['status']));
            }
            $phonelist = Register::whereIn('id', $ids)->get(['mobile']);
            foreach ($phonelist as $phone) {
                if ($msg && $phone->mobile) {//短信
                    try {
                        TofService::sendsms($phone->mobile, $msg);
                    } catch (Exception $e) {
                        //var_dump($e);//错误
                    }
                }
            }
        }
        return $count;
    }
}
