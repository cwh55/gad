<?php

namespace App\Http\Controllers\Mgr;

use App\Models\LoreWhite;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\LoreRepositoryEloquent;
use App\Entities\Lore;
use League\Flysystem\Exception;
use Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;
use Illuminate\Support\Facades\Storage;
use App\Models\User;

class LoreController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $lore;

    public function __construct(LoreRepositoryEloquent $lore)
    {
        $this->lore = $lore;
    }

    public function index(Request $request)
    {
        $page = $request->get('page', 1);
        $skip = ($page - 1) * 10;
        $lorequery = Lore::query();
        if ($request->get('nid')) {
            $lorequery->where('id', $request->input('nid'));
        }
        if ($request->get('type')) {
            $lorequery->where('type', $request->input('type'));
        }
        if ($request->get('title')) {
            $lorequery->where('title', 'like', '%' . $request->input('title') . '%');
        }
        if ($request->get('state') != -1) {
            $lorequery->where('state', $request->input('state'));
        }
        $total = $lorequery->count();
        $notebooklist = $lorequery->skip($skip)->take(10)->orderBy('id', 'desc')->get();

        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';

        return response()->json(['total' => $total, 'notebooklist' => $notebooklist, 'hostname' => $host]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return response()->json(Lore::create($request->all()));
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return response()->json($this->lore->find($id));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        return response()->json($this->lore->update($request->all(), $id));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return response()->json($this->lore->delete($id));
    }


    public function getDescInfo($id)
    {
        return response()->json($this->lore->find($id));
    }

    public function updateDescInfo(Request $request)
    {
        $id = $request->input("id");
        $returnInfo = $this->lore->update($request->all(), $id);
        return json_encode(['data' => $returnInfo, 'msg' => '操作成功', 'code' => '1']);
    }


    //查询评论信息
    public function getDaKaCommentInfo($id)
    {
        return $this->lore->findWhere(array("id" => $id), ['id', 'daka_comment_list']);
    }

    //更新评论信息
    public function updateCommentInfo(Request $request)
    {
        $id = $request->input("id");
        $para = $request->all();
        $returnInfo = $this->lore->update(array("daka_comment_list" => $para["daka_comment_list"]), $id);
        return json_encode(['data' => $returnInfo, 'msg' => '操作成功', 'code' => '1']);
    }

    //删除
    public function delCommentInfo(Request $request)
    {
        $id = intval($request->input("id"));
        $type = intval($request->input("type"));

        $isExist = $this->lore->findWhere(array("id" => $id), ['id', 'daka_comment_list']);
        if ($isExist) {
            $arr = $isExist[0]["daka_comment_list"];
            if (empty($arr)) {
                return json_encode(['msg' => '找不到评论信息', 'code' => '-1']);
            }
            foreach ($arr as $key => $item) {
                if ($type == 0) {
                    $arr[$key]["status"] = 1;//删除
                } else {
                    $arr[$key]["status"] = 0;//启用
                }
            }
            $jsonStr = $arr;
            $returnInfo = $this->lore->update(array("daka_comment_list" => $jsonStr), $id);
            if ($returnInfo->id > 0) {
                return json_encode(['msg' => '操作成功', 'code' => '1']);
            }
        } else {
            return json_encode(['msg' => '评论不存在', 'code' => '-1']);
        }
    }

}
