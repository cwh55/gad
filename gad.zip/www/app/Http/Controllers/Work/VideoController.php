<?php

namespace App\Http\Controllers\Work;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Models\Video;
use Auth;
use App\Gad\Upload;
use App\Models\User;
use App\Models\Article;
use App\Models\Classify;
use App\Models\Summercourse;
use App\Http\Controllers\Controller;
use DB;
use Cache;

class VideoController extends Controller
{
	const NOT_EXISTS_MSG = "信息不存在";
	const SUCCESS_MSG = "发表成功";
	const TAG_ERROR_MSG = "标签输入错误";

	static $allowTypes = array('mp4','flv','avi','mov');

	public function __construct(Request $request)
	{
        if($request->route() AND strpos($request->route()->getActionName(), "create") >= 0){
			if(isset($request->id) && ($id = $request->id) >= 1){
				$video = Video::findOrFail($id);
				$user_id = $video->user_id;
				$this->middleware("acl:video::create,user_id=".$user_id, ['only' => 'createView']);
				$this->middleware("acl:video::createview,user_id=".$user_id, ['only' => 'postCreate']);
			}
		}
	}
	
    //创建页面
	public function postCreate(Request $request, $id)
	{
		if (!Auth::check()) {
			return redirect()->guest('/login');
		}
		$this->validate($request, [
			'title' => 'required',
			'description' => 'required',
			'tag' => 'required',
			'content' => 'required',
			'class_id' => 'required',
		]);
		$tag = $request->input("tag");
		$tag = array_unique(explode(",", $tag));
		if (count($tag) > 5) {
			$data = ['code' => -1, 'msg' => self::TAG_ERROR_MSG];
			return response()->json($data);
		}
		$id = intval($id);
		$data = [];//返回信息
		$channelId = 11;
		$videoData = $request->all();
		if($id >= 1){//修改
			$video = Video::findOrFail($id);
		} else {//新增
			$video = new Video();
			$class = Classify::getClass(intval($request->input('class_id')), false);//获取分类
			if(empty($class)){
				return response()->json(['code' => -1, 'msg' => self::NOT_EXISTS_MSG]);
			}
			$summer = new Summercourse();
			if(!$summer->getWhitelist($class->parent)){
				return response()->json(['code' => -1, 'msg' => '非法提交']);
			}
			$uuid = $request->input("uuid");
			$videoData["cover"] = $uuid ? "http://p.qpic.cn/wecam_pic/0/".$uuid."_1/0" : "";
			$videoData['channel_id'] = $channelId;
		}
		//文本过滤
		$videoData['description'] = xssFilter($videoData['description']);
		$videoData['label'] = implode(",", $tag);
		$videoData['user_id'] = Auth::user()->UserId;
		$videoData['name'] = Auth::user()->NickName;
		$videoData['type'] = 1;
		//填充数据
		$video->fill($videoData);
		$id = $video->save();
		//返回结果
		$data = array("code" => 0, "data" => $video->id, "msg" => self::SUCCESS_MSG);
		return response()->json($data);
	}

	//video创建页
	public function createView(Request $request, $id = 0)
	{
		if(!Auth::check()){
			return redirect()->guest('/login');
		}
		$id = intval($id);
		$data['classId'] = intval($request->input('classid'));
		$video = new Video();
		$dataarr = array();
		if($id >= 1){
			$video = Video::findOrFail($id);
			$data['classId'] = $video->class_id;
			if(!empty($video->content)){
				foreach(explode(";", $video->content) as $val){
					if(!empty($val)){
						$datatmp = explode("::", $val);
						$datatmp[2] = $val;
						$dataarr[] = $datatmp;
					}
				}
			}
		}
		$video->content = $dataarr;
		$data["title"] = "";
		$video->id = intval($video->id);
		$data["data"] = $video;
		return view("video.create", $data);
	}

	//详情
	public function detail(Request $request, $id)
	{
		$id = intval($id);
		$video = Video::findOrFail($id);
		$data = [];
		$video->increment('view_cnt',1);
		$video->Liked = $video->is_liked;
		$video->Favored = $video->is_favored;

		$data['class'] = $video->classify;//分类
		$data['parent'] = $video->classify->parentClass;//模块
		$data['user'] = $video->user;
		$dataarr = array();//解析video url
		if(!empty($video->content)){
			$datatmp = explode(";", $video->content);
			foreach($datatmp as $val){
				if(!empty($val)){
					$datatmp2 = explode("::", $val);
					$datatmp2[2] = $val;
					$dataarr[] = $datatmp2;
				}
			}
		}
		$video->content = $dataarr;
		$data["tags"] = explode(",", $video->label);
		$data["code"] = 0;
		$data["video"] = $video;
		$data["classId"] = $video->class_id;
		$data["title"] = "";
		return view("video.detail", $data);
	} 

	//列表
	public function getList(Request $request, $classId, $pagesize=12, $orderby=1)
	{
		$class_id = intval($classId);
		$classes = array();
		$class = Classify::getClass($class_id);//判断有没有这个分类
		if(empty($class)){
			abort(404);return;
		}
		$layer = $class->layer;
		$pid = $class_id;
		$data['worktype'] = '0';
		if($layer == Classify::MODULE_LAYER){
			$classes = Classify::getClasses($pid);//分类
			if(isset($classes[0])){//默认第一个分类
				$class_id = $classes[0]->class_id;
				$data["worktype"] = $classes[0]->type;
			}
		} else if($layer == Classify::CLASS_LAYER){
			$data["worktype"] = $class->type;
			$classes = Classify::getClasses($class->parent);
			$class = $class->parentClass;
		} else {
			abort(404);return;
		}
		$param['class_id'] = $class_id;
		$param['orderby'] = intval($orderby);
		$param['page'] = intval($request->input("page", 0));
		$param['pagesize'] = intval($pagesize) > 100 ? 12 : intval($pagesize);
		$data = array_merge($data, $param);
		if($data["worktype"] == '0'){//文章列表
			$key = 'article_list_'.$param["class_id"].'_'.$param["orderby"].'_'.$param["page"].'_'.$param['pagesize'];
			$data["data"] = Article::articles($param)->paginate($param['pagesize']);

		} else if($data["worktype"] == '1'){//image列表
			return redirect()->action('Art\ArtController@showList', ['classid' => $class_id]);
		} else {//video列表
			$key = 'video_list_'.$param['class_id'].'_'.$param['orderby'].'_'.$param['page'].'_'.$param['pagesize'];
			$data["data"] = Video::videos($param)->paginate($param['pagesize']);

		}
		if($request->input("_display") == "json"){//输出json
			return response()->json($data);
		}
		$data['class'] = $class;
		$data['classes'] = $classes;
		return view("video.list", $data);
	} 

	//上传视频
	public function uploadVideo(Request $request)
	{
		$file = $request->file('Filedata');
		if($file == null || !$file->isValid()){
			echo json_encode(['code'=>-1,'msg'=>'出错啦!']);
			return;
		}
		$ret = Upload::file($file);
		if(isset($ret["url"])){
			$url = parse_url($ret['url']);
			if(isset($url['query'])){
				parse_str($url['query']);
			}
			$ret['uuid'] = $uuid;
			$url = parse_url($ret['url']);
			$ret["url"] = "/work/showVideo/?fileurl=".Upload::hideFileServer($ret["url"])."|||".$file->getClientOriginalName();
		}
		echo json_encode($ret);
		return;
	}
	
	//查看视频
	public function showVideo(Request $request)
	{
		$fileurl = $request->input("fileurl");
		if(empty($fileurl)){
			return response()->json(["code" => -1, "msg" => "地址错误"]);
		}
		$tmp = explode("|||", Upload::showFileServer($fileurl));
		if(null != $request->input('HTTP_IF_MODIFIED_SINCE')){
			header('HTTP/1.0 304 Not Modified');
			return true;
		}
        header("Expires:" . gmdate("D, d M Y H:i:s", strtotime("+1 year")) . " GMT");
        header("Pragma: Pragma");
        header("Cache-Control: max-age=31536000");
        header("Last-Modified:" . gmdate("D, d M Y H:i:s", strtotime("-1 day")) . " GMT");
        if (strpos($tmp[0], "http://file.tig.oa.com/") === 0
            || strpos($tmp[0], "http://file.ieg.local/") === 0
            || strpos($tmp[0], "http://tig.oa.com/") === 0
        ) {
            $ft= substr($tmp[0], strrpos($tmp[0], '.')+1);
            if (!strpos($tmp[0],"mod/VideoAo.php?")&&!in_array(strtolower($ft),self:: $allowTypes)) {
                exit('Invalid file type.');
            }
			Upload::getFile($tmp[0], $tmp[1]);
        }
	}

}
