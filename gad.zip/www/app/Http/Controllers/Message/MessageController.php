<?php

namespace App\Http\Controllers\Message;
use App\Http\Controllers\Controller;
use Auth;

class MessageController extends Controller
{

    public function index() {
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        return view('message.index');
    }

    public function setting(){
        if (!Auth::check()) {
            return redirect()->guest('/login');
        }
        return view('message.setting');
    }
}