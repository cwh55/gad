<?php

namespace App\Http\Controllers\Search;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Qcloud\Search\Api as SearchApi;
use App\Repositories\SearchWordRepository;

class SearchController extends Controller {
    public function getIndex(Request $request,$tagName='index',SearchApi $search)
    {
        // app 参数 需要在哪个APP下搜索
        // app参数中的各项对应value的值 参见https://cloud.tencent.com/document/product/270/1318
        $tagConfig = [
            'index' => [
                'app' => [
                    'archive' => [],
                    'user' => ['page_id' => 0,'num_per_page' => 3],
                    'tag' => ['page_id' => 0,'num_per_page' => 3],
                ],
            ],
            'article' => [
                'app' => [
                    'archive' => ['cl_filter' => '[C:CA:1]']
                ],
            ],
            'question' => [
                'app' => [
                    'archive' => ['cl_filter' => '[C:CA:3]']
                ],
            ],
            'topic' => [
                'app' => [
                    'archive' => ['cl_filter' => '[C:CA:4]']
                ]
            ],
            'works' => [
                'app' => [
                    'archive' => ['cl_filter' => '[C:CA:2]']
                ],
            ],
            'video' => [
                'app' => [
                    'archive' => ['cl_filter' => '[C:CC:1]']
                ],
            ],
            'tag' => [
                'app' => ['tag' => []],
            ],
            'user' => [
                'app' => ['user' => []],
            ]
        ];

        $time = [
            '全部时间' => 0,
            '一周内' => strtotime('-1 week'),
            '一月内' => strtotime('-1 month'),
            '一年内' => strtotime('-1 year')
        ];

        $searchStr = xssFilter($request->input('word',''));
        $searchTimeKey = xssFilter($request->input('startTime', '全部时间'));
        $searchTime = $time[$searchTimeKey];
        $page = $request->input('page',0);
        $pageSize = $request->input('pageSize',20);
        //  前端Ajax请求
        if ($request->ajax()) {
            $data = [];
            if($searchStr) {
                if($tagName == 'index' && $page != 0){
                    // 非首页不用拉取user和works数据
                    $key = 'archive';
                    $APP = strtoupper($key);
                    $res = $search->find($searchStr, $APP, $searchTime, [] ,$page,$pageSize);
                    $data[$key] = $res;
                }else {
                    foreach($tagConfig[$tagName]['app'] as $key => $condition){
                        $APP = strtoupper($key);
                        $res = $search->find($searchStr, $APP, $searchTime, $condition ,$page,$pageSize);
                        $data[$key] = $res;
                    }
                }

            }
            // index首页下需要对archive 中的works做聚合
            if ($tagName == 'index' && $page == '0') {
                $data['works'] = $search->find($searchStr, 'ARCHIVE', $searchTime, ['cl_filter' => '[C:CA:2]','page_id' => 0,'num_per_page' => 4] ,$page,$pageSize);
            };
            return response()->json([
                'code' => 0,
                'data' => $data
            ]);
        }
        // 侧边栏配置 省略全部的配置
        $sliderConfig = [
            [
                'article' => [
                    'txt' => '文章',
                    'totalCount' => 0
                ],
                'question' => [
                    'txt' => '问答',
                    'totalCount' => 0
                ]
            ],[
                'topic' => [
                    'txt' => '话题',
                    'totalCount' => 0
                ],
                'works' => [
                    'txt' => '作品',
                    'totalCount' => 0
                ],
                'video' => [
                    'txt' => '视频',
                    'totalCount' => 0
                ]
            ],[
                'tag' => [
                    'txt' => '标签',
                    'totalCount' => 0
                ],
                'user' => [
                    'txt' => '用户',
                    'totalCount' => 0
                ]
            ]
        ];
        $slider = [
            [
                'index' => [
                    'txt' => '全部',
                    'totalCount' => 0
                ]
            ]
        ];
        // 获取各分类下的总数
        if($searchStr){
            foreach ($sliderConfig as $i =>  $partTab){
                $tempPart = [];
                foreach ($partTab as $tag => $tab){
                    foreach($tagConfig[$tag]['app'] as $key => $condition){
                        // 获取某个tab下的总数
                        $APP = strtoupper($key);
                        $res = $search->find($searchStr, $APP, 0, $condition ,0,1);
                        $sliderConfig[$i][$tag]['totalCount'] += $res['totalCount'];
                    }

                    if($sliderConfig[$i][$tag]['totalCount'] > 0){
                        $tempPart[$tag] = $sliderConfig[$i][$tag];
                        // 设置 tab[全部] 下的总数
                        // 云搜服务不稳定，只能使把其它tab的总数相加得到全部的总数
                        $slider[0]['index']['totalCount'] += $sliderConfig[$i][$tag]['totalCount'];
                    }
                }
                if(count($tempPart) > 0) {
                    $slider[] = $tempPart;
                }
            }

        }
        // 获取热词
        $sw = new SearchWordRepository();
        $allSearchWords = $sw->findAll()->toArray();
        // 最多随机三个热词
        $randomIndexArr = array_rand($allSearchWords,min(3,count($allSearchWords)));
        $searchWords = [];
        for($i = 0 , $length = count($randomIndexArr); $i < $length;$i++){
            $searchWords[] = $allSearchWords[$randomIndexArr[$i]]['name'];
        }

        // 返回对应变量的名称给前端
        $variableConfig = [];
        foreach($tagConfig[$tagName]['app'] as $key => $value){
            $variableConfig[] = $key;
        }
        if($tagName=='index' && $page == 0) {
            $variableConfig[] = 'works';
        }
        return view('search.index',[
            'curTagName' => $tagName,
            'searchStr' => $searchStr,
            'tabConfig' => $slider,
            'time' => $time,
            'searchTime' => $searchTimeKey,
            'variableConfig' => $variableConfig,
            // 每次刷新页面获取随机三个热词
            'searchWords' => $searchWords
        ]);
    }

}
