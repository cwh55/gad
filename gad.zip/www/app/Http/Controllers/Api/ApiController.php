<?php

namespace App\Http\Controllers\Api;
use Auth;
use App\Models\KeyValue;
use Redis;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Content;
use App\Models\Articlecfg;
use App\Models\Subject;
use App\Models\Lore;
use App\Models\Fame;
use App\Models\Question;
use Illuminate\Http\Request;
use DB;
use Cache;
use App\Gad\Html;
use Illuminate\Support\Str;
use App\Gad\TofService;
use App\Repositories\ArchiveRepository;
use App\Repositories\PictureRepository;
use GuzzleHttp\Client;

class ApiController extends Controller
{
    //列表数据
    public function get(Request $request) {
    	$params = $request->all();
    	$showType = array_get($params,'showtype', 1);
        $list = array();
        
        $groupId = array_get($params,'groupid',1);
        $page = array_get($params,'page',0);
        $pageSize = array_get($params,'size',10);

        
        $key = 'list_'.$showType.'_'.$groupId.'_'.$page.'_'.$pageSize;
        $cache = Redis::get($key);
        
        if(!empty($cache)) {
        	$list = json_decode($cache, true);
        } else {
        	switch($showType){
	            case '1':
	                $list = Content::getArticlesBy($params);
	                break;
	            case '2':
	                $list = Content::getWenList($params);
	                break;
	            case '7':
	            case '8':
	                $list = Content::getArtList($params);
					break;
				case '11'://资讯类型
					$list = Content::getNewsBy($params);
	        }
	        $ret = Redis::setex($key, 60*10, json_encode($list));
        }
        return response()->json($list);
    }

    //详情页
    public function detail(Request $request,$id){
        $params = $request->all();
        $content = Content::getDetail($id);
		$wxcodes = KeyValue::find('h5_article_wxcode');
		if($wxcodes){
			$wxcodes = json_decode($wxcodes['Value'],true);
			if(count($wxcodes)){
				foreach($wxcodes as $v){
					if($v['title'] == $content['ClassLV1']){
						$content['wxcode'] = $v;
						break;
					}
				}
			}else{
				$content['wxcode'] = array();
			}
		}
        return response()->json($content);
    }

	//下载文件
	public function downFile(Request $request)
	{
		$url=$request->input('url');
		if(!empty($url)) {
			$url_p = parse_url($url);
			if($url_p) {
				if($url_p["host"]=='file.gad.qq.com') {
					return view("layouts.downfile", compact('url'));
				}
			}
			echo '非法链接';
		}
	}

	//发送短信
    public function SendSms(Request $request)
	{
		$phone = $request->input('phone');
		$msg = $request->input('msg');

		try {

			if(strpos($phone,",")>-1)
			{
				$errorPhone="";
				$phoneArr = explode(",", $phone);
				foreach($phoneArr as $phones) {
					if(!preg_match('#^13[\d]{9}$|^14[5,7]{1}\d{8}$|^15[^4]{1}\d{8}$|^17[0,6,7,8]{1}\d{8}$|^18[\d]{9}$#',$phones)) {
						//记录发送出错的手机号
						$errorPhone.=$phones.",";
						continue;
					}
				$ret = TofService::sendSms($phones, $msg);
				if ($ret['code'] != 0) {
					$errorPhone.=$phones.",";
					continue;
				}
			   }

				if(!empty($errorPhone))
				{
					return response()->json(['code' => 1, 'msg' =>$errorPhone]);
				}else
				{
					return response()->json(['code' => 0, 'msg' =>'短信已发送']);
				}

			}else
			{
				if(!preg_match('#^13[\d]{9}$|^14[5,7]{1}\d{8}$|^15[^4]{1}\d{8}$|^17[0,6,7,8]{1}\d{8}$|^18[\d]{9}$#',$phone)) {
					return response()->json(['code' => -1, 'msg' =>'发送失败,手机号不合法']);
				}

				$ret = TofService::sendsms($phone, $msg);
				if ($ret['code'] == 0) {
					return response()->json(['code' => 0, 'msg' =>'短信已发送']);
				}else
				{
					return response()->json(['code' => 1, 'msg' =>$phone]);
				}
			}
		}
		catch(Exception $e) {
			return response()->json(['code' => 1,'msg' =>$phone]);
		}
	}

    //评论
    public function comment(Request $request,$id){
        $params = $request->all();
        $params['replyobject'] = $id;
        $comments = Content::getComment($params);
        return response()->json($comments);
    }

	//作品列表
	public function getWorksList(Request $request, $activityId){
		$page = $request->input("page", 0);
		$pageSize = $request->input("pageSize", 6);
		$orderBy = $request->input("orderBy", 1);
		$activityId = intval($activityId);
		$page = intval($page);
		$pageSize = intval($pageSize);
		$orderBy = intval($orderBy);

		if($pageSize > 100){//限制page大小
			$pageSize = 6;
		}

		if($orderBy == 1){
			$orderby = "Works.Created DESC";
		} else if($orderBy == 2){
			$orderby = "Works.VoteCount DESC";
		} else {
			$orderby = "Works.DiscussCount DESC";
		}

		$list = array();
		$megagame = $this->object_array(DB::select("select * from Megagame where ActivityId = :activityId and RowStatus != -1", ['activityId' => $activityId]));
		$megagame = $megagame[0];

		$megagame['baseInfo'] = $this->object_array(DB::select("select * from salon where salon_id = ?", [$activityId]))[0];

		$list['megagame'] = $megagame;
		$workslist = $this->object_array(Cache::remember('get_work_list'.$activityId.'_'.$orderBy.'_'.$page.'_'.$pageSize, 10, function() use($orderby, $activityId, $page, $pageSize) {
			return DB::select("select ActivityWorks.WorksId,ActivityWorks.WorksFormat,Works.Title,ActivityWorks.WorksId ContentClassId,Works.ConverImg,Works.VoteCount,Works.Creator,Works.Created from ActivityWorks left join Works on ActivityWorks.WorksId = Works.WorksId where ActivityId = ? and ActivityWorks.WorksFormat = ? and ActivityWorks.RowStatus = 0 and Works.RowStatus = 0 order by ".$orderby." limit ?, ?", [$activityId, 5, $page * $pageSize, $pageSize]);
		}));

		$list['allcount'] = $this->object_array(DB::select("select count(*) count from ActivityWorks left join Works on ActivityWorks.WorksId = Works.WorksId where ActivityId = ? and ActivityWorks.WorksFormat = ? and ActivityWorks.RowStatus = 0 and Works.RowStatus = 0", [$activityId, 5]))[0]['count'];
		$list['worksList'] = $workslist;
		$data['data'] = $list;
		return response()->json($data);
	}

	//作品详情页
	public function getWorkDetail(Request $request, $workId){
		$workId = intval($workId);
		if($workId > 1){//判断Id合法
			$work = Cache::remember('getWorkDetail'.$workId, 10, function() use ($workId) {
				return DB::select("Select * from Works where WorksId = ?",[$workId]);
			});
			$work = $this->object_array($work);
		}

		$data = array();
		if(empty($work)){
			$work = array();
		} else {
			$team = Cache::remember('getWorkDetail_team'.$workId, 10, function() use ($workId) {
				return DB::select('select aw.PrizeName,aw.PrizeImg,w.WorksId,aw.ActivityId,mg.TeamIntro,aw.ContentClassId,mg.UserName,mg.TeamName from Works w left join ActivityWorks aw on aw.WorksId = w.WorksId left join MegagameInfo mg on mg.MegagameId = aw.ActivityId and mg.UserId = w.Creator where w.WorksId = ? and aw.WorksId = ?',[$workId,$workId]);
			});
			$team = $this->object_array($team);
			$data['team'] = $team;
		}

		$data = array();
		$data['data'] = $work[0];
		$data['data']['videoUrl'] = '';
		if(!empty($data['data']['Video'])) {
			$videos = json_decode($data['data']['Video'], true);
            $videoUrl = is_array($videos) ? $videos[0]['url'] : '';
            $data['data']['videoUrl'] = $videoUrl;
		}

		if(!empty($data['data']['PPT'])) {
			$ppts = json_decode($data['data']['PPT'], true);
            $ppturl = is_array($ppts) ? $ppts[0]['url'] : '';
            //$data['data']['pptUrl'] = $ppturl;
            $info = explode("newd=",$ppturl);
			$idInfo = urldecode($info[1]);
			$url = explode(";",$idInfo);
			$data['data']['pptPageSize'] = !empty($url[1]) ? $url[1] : 0;
			$data['data']['pptUrltpl'] = !empty($url[0]) ? $url[0] : '';
		}
		
		$data['team'] = $team[0];
		return response()->json($data);
	}

	//评论列表
	public function getReplyList(Request $request, $id){
		$page = $request->input("page", 0);
		$pageSize = $request->input("pageSize", 12);
		$orderBy = $request->input("orderBy", 1);
		$replyType = $request->input("replyType", 1);
		$data = array();
		if($id < 1){
			$data['allcount'] = 0;
			$data['data'] = array();
			return response()->json($data);
		}
		if($pageSize > 100){//限制page大小
			$pageSize = 12;
		}
		$cc = $this->object_array(DB::select("Select cc.RowStatus CCRowStatus,cc.Id,cc.ClassLV1,cc.ClassLV2,cc.ClassLV3,cc.GroupClassLV1,Author UserId,c.* from ContentClass cc Left Join Content c on cc.ContentId = c.ContentId where Id = ?", [$id]))[0];
		if(!empty($cc)){//判断数据存在
			$cclass = $this->object_array(DB::select("Select Id from ContentClass where ContentId = ?", [$cc['ContentId']]));
			$cclassIds = [-11];
			foreach($cclass as $cId){
				$cclassIds[] = $cId["Id"];
			}
			$count = DB::table("Reply")->select(DB::raw("count(*) count"))->whereIn("ReplyObject", $cclassIds)->where("ReplyType",$replyType)->get();
			$data['allcount'] = $count[0]->count;
			$list = $this->object_array(Cache::remember('get_reply_list'.$id.'_'.$replyType.'_'.$page.'_'.$pageSize, 10, function() use ($cclassIds, $replyType, $page, $pageSize) {
				return DB::table("Reply")->whereIn("ReplyObject",$cclassIds)->where("ReplyType",$replyType)->orderBy("UpCount","desc")->orderBy("Created","desc")->skip($page*$pageSize)->take($pageSize)->get();
			}));
			foreach($list as &$val){
				$val["User"] = $this->object_array(DB::table("User")->where("UserId",$val["Creator"])->get()[0]);
			}
			$data['data'] = $list;
		}
		return response()->json($data);
	}

	//精彩点评
	public function getHotReplyList(Request $request, $id){
		$data['data'] = array();
		if($id > 1){
			$reply = Cache::remember('get_hot_reply_list', 10, function() use($id){
				return DB::table("Reply")->join("User", "User.UserId", "=", "Reply.Creator")->where("ReplyObject", $id)->where("ReplyType", 102)->take(10)->get();
			});
			$data['data'] = $this->object_array($reply);
		}
		return response()->json($data);
	}

	function object_array($array) {  
		if(is_object($array)) {  
			$array = (array)$array;  
		 } if(is_array($array)) {  
			 foreach($array as $key=>$value) {  
				 $array[$key] = $this->object_array($value);  
				 }  
		 }  
		 return $array;  
	}

    //相关内容
    public function relatedContent(Request $request)
    {
        $params = $request->all();
        $object = array_get($params,'object',0);
        if(empty($object)) {
            return response()->json([]);
        }
        //var_dump($object);
        $item = Content::getContentById($object);
        //var_dump($item);
        if(empty($item[0])) {
            return response()->json([]);
        }
        $item = $item[0];
        $paramArr = ['showtype'=>$item->ShowType, 
            'tags'=>$item->Tag, 
            'classid'=>($item->ClassLV2 == 3595) ? 3595 : $item->ClassLV1,
            'ruleoutid'=>$object
        ];
        $content = Content::getRelatedContents($paramArr);
        return response()->json($content);
    }

    //获取视频中转接口
    public function getVideo(Request $request) {
    	$params = $request->all();
    	if(!empty($params['file']) && is_string($params['file'])) {
    		$ret = Html::getVideoUrl($params['file']);
    		return response()->json(['code'=>$ret['code'], 'msg'=>$ret['msg']]);
    	} else {
    		return response()->json(['code'=>1, 'msg'=>'请求数据出错']);
    	}
    }

    //拉取暑期俱乐部动态信息
    public function getSummerNews(Request $request, $id) {
    	$config = Articlecfg::channel(config('app.summercamp_news_id'))->get()->take(1);
    	$params = $request->all();

    	$ids = !empty($config[0]) ? $config[0]->article_ids : '0';
    	if(!empty($ids)) {
    		$page = !empty($params['page']) ? $params['page'] : 0;
    		$size = !empty($params['size']) ? $params['size'] : 12;
    		$list = Content::getContentByIds($ids, $page, $size);
    		$ret = array_map(function($item) {
    			if(!empty($item->Summary)) {
    				$len = Str::length($item->Summary);
    				$item->NeedShowMore = $len>= 230 ? true : false;
    				$item->Summary = Str::substr($item->Summary, 0, 230);
    				$item->article_url = (config('app.env') == 'production') ? 'http://gad.qq.com/article/detail/'.$item->Id : 'http://ymbtest.qq.com/article/detail/'.$item->Id;
    			}
    			return $item;
    		}, $list);
    		return response()->json(['code'=>0, 'data'=>$ret]);
    	}
    	return response()->json(['code'=>0, 'data'=>[]]);
    }
	//404页面活动列表拉取
	public function getSubjectList(Request $request)
	{
		$subjectlist = Subject::get404Subject();
        return response()->json($subjectlist)->setCallback(request()->input('callback'));
	}

	public function postAddViewcnt(Request $request, ArchiveRepository $archive)
	{
		$path = parse_url($request->server('HTTP_REFERER'))['path'];
		$infos = explode('/', $path);
		if (count($infos) > 3) {
			$controller = $infos[1];
			$action = $infos[2];
			$id = $infos[3];
		} else {
			return;
		}
		if ($action != "detail" || !is_numeric($id)) {
			return;
		}
		switch ($controller) {
			case "article":
			case "resource":
			case "question":
			case "topic":
				$archive->addVisitCount($id);
				break;
			case "gallery":
				if (count($infos) > 4) {
					$pid = $infos[4];
					$picture = new PictureRepository();
					$archive->addVisitCount($id, $pid, $picture);
				} else {
					$archive->addVisitCount($id);
				}
				break;
			case "fame":
				$fame = Fame::findOrFail($id);
				$fame->increment('view_cnt');
				break;
			case "lore":
				$lore = Lore::findOrFail($id);
				$lore->increment('view_cnt');
				break;
			case "wenda":
				$question = Question::findOrFail($id);
				$question->increment('views');
				break;
		}
		return;
	}

}
