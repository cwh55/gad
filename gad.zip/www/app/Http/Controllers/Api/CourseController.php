<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Jobs\SendCourseRegisteredNotify;
use App\Jobs\SendCourseStartNotify;
use App\Models\Course;
use Auth;
use Gate;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    public function index(Request $request)
    {
        $courses = Course::where('status', 1)->orderBy('id', 'DESC')->take(11)->get(['id', 'title']);
        $courses = $courses->filter(function ($course) use($request) {
            $course->setAppends([]);
            
            return $course->id != $request->get('id');
        });

        return $courses->take(10);
    }
    
    public function show(Request $request, $id)
    {
        $course = Course::with(['lessons.videos', 'teachers.user'])->findOrFail($id);
        if ($request->user() AND $course->state != 'new' AND Gate::denies('learn', $course)) {
            $course->registerStudent($request->user());
        }

        $course->study_count = mock_course_user_count($course->study_count);

        return response()->json($course);
    }

    public function update(Request $request, $id)
    {
        if (!Auth::check()) {
            return abort(401, '用户尚未登录');
        }

        $course = Course::findOrFail($id);
        $action = $request->get('action');
        if ($action != 'register') {
            return abort(403, '非法操作');
        }

        if ($course->cost != 0) {
            return abort(403, '收费分享无法直接报名');
        }

        $user = Auth::user();
        $course->registerStudent($user);

        // 发送微信报名成功提醒，课前提醒
        $job = new SendCourseStartNotify($course, $user);
        $delay = strtotime($course->lesson->begin_date.' '.$course->lesson->begin_time) - time() - 300;
        $this->dispatch($job->delay($delay));
        $this->dispatch(new SendCourseRegisteredNotify($course, $user));

        return response()->json(['code' => 0, 'result' => 'success', 'study_count' => mock_course_user_count($course->study_count)]);
    }
}