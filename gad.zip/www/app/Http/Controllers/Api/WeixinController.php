<?php

namespace App\Http\Controllers\Api;

use App\Gad\Weixin;
use App\Http\Controllers\Controller;
use Auth;
use Illuminate\Http\Request;
use App\Models\User;

class WeixinController extends Controller
{
    public function getConfig(Request $request)
    {
        $url = $request->get('url');
        $isSub = $request->get('sub');
        $result = Weixin::getJsConfig(rawurldecode($url), $isSub);

        return response()->json($result);
    }

    public function getUser(Request $request)
    {
        $courseUrl = url('course/detail.html?id='.$request->get('course'));
        if ($request->has('code')) {
            $code = $request->get('code');
            $state = $request->get('state');
            $userInfo = Weixin::getUserInfoByCode($code, $state, true);
            $user = User::where('WeixinId', $userInfo->unionid)->first();
            $request->setTrustedProxies([$request->server('REMOTE_ADDR')]);
            if ($user) {
                $user->ip = $request->ip();
                $user->save();
            } else {
                $user = User::create([
                    'WeixinId' => $userInfo->unionid,
                    'NickName' => $userInfo->nickname,
                    'Avatar' => $userInfo->headimgurl,
                    'ip' => $request->ip(),
                    'Created' => date('Y-m-d H:i:s'),
                    'Modified' => date('Y-m-d H:i:s')
                ]);
            }
    
            Auth::login($user);

            return response()->json(['code' => 0, 'user' => $user, 'subscribe' => 0]);
        }

        return response()->json(['code' => 401, 'url' => Weixin::redirect($courseUrl, 'snsapi_userinfo', 'user')]);
    }

     public function getLivedetailuser(Request $request)
     {
        $liveUrl = url('live/detail/'.$request->get('liveId'));
        if ($request->has('code')) {
            $code = $request->get('code');
            $state = $request->get('state');
            $userInfo = Weixin::getUserInfoByCode($code, $state, true);
            $user = User::where('WeixinId', $userInfo->unionid)->first();
            $request->setTrustedProxies([$request->server('REMOTE_ADDR')]);
            if ($user) {
                $user->ip = $request->ip();
                $user->save();
            } else {
                $user = User::create([
                    'WeixinId' => $userInfo->unionid,
                    'NickName' => $userInfo->nickname,
                    'Avatar' => $userInfo->headimgurl,
                    'ip' => $request->ip(),
                    'Created' => date('Y-m-d H:i:s'),
                    'Modified' => date('Y-m-d H:i:s')
                ]);
            }
    
            Auth::login($user);

            return response()->json(['code' => 0, 'user' => $user, 'subscribe' => 0]);
        }

        return response()->json(['code' => 401, 'url' => Weixin::redirect($liveUrl, 'snsapi_userinfo', 'user')]);
    }
}