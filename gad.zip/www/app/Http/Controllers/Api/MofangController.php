<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Repositories\TagRepository;
use Illuminate\Http\Request;

class MofangController extends Controller
{
    public function getIndex(Request $request, TagRepository $tagRepository)
    {
        $user = $request->header('PHP_AUTH_USER');
        $password = $request->header('PHP_AUTH_PW');
        if ($user !== 'mofang' AND $password !== 'mofang2017') {
            return response()->json(['code' => 1, 'message' => 'Invalid credentials.'], 401, [
                'WWW-Authenticate' => 'Basic'
            ]);
        }

        $page = $request->get('page', 1);
        $tag = $tagRepository->find(10506);
        $archives = $tagRepository->getArchiveListForMofang($tag, $page);
        $archives->getCollection()->makeHidden('pivot')->each(function ($archive) {
            $archive->user->setVisible(['tgd_uid', 'QQNo', 'WeixinId', 'NickName', 'Avatar', 'Province', 'City', 'breif']);
            $archive->article->setVisible(['content']);
        });

        return response()->json(['code' => 0, 'data' => $archives]);
    }
}