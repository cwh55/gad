<?php

namespace App\Http\Controllers\GamePai;
use App\Gad\Lib_Func;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Game;
use App\Entities\GamePai;
use App\Models\User;
use Illuminate\Http\Request;
use App\Repositories\GamePaiRepository;
use App\Repositories\GamePaiCodeRepository;
use App\Repositories\GamePaiSignupRepository;
use Auth;
use Gate;

class GamePaiController extends Controller
{
    public function __construct(Request $request){
        if($request->is('hatch/edit*')){
            if(isset($request->id) && ($id = $request->id) >= 1){
                $hatch = Game::find($id);
                $user_id = $hatch->user_id;
                //$this->middleware("acl:hatch::edit,user_id=".$user_id, ['only' => ['getEdit','postEdit']]);
            }
        }
    }

    public function getList()
    {
        $pielist = GamePai::where('status', 0)->orderBy('phase', 'desc')->paginate(12);
        return view('gamepie.list',compact('pielist'));
    }

    public function getDetail(GamePaiRepository $gamepai, $id, \App\Repositories\LikeRepository $like, \App\Repositories\FavoriteRepository $fav, GamePaiSignupRepository $gamePaiSignup)
    {
        $gamepie = $gamepai->find($id);
        $user = Auth::user();
        if ($gamepie) {
            if ($gamepie->status != 0 && !($user &&  $user->roles->contains(2))) {
                abort(404);
            }
            $commentlist = [];
            if (!empty($gamepie->section_comment)) {
                foreach ($gamepie->section_comment as $comment) {
                    $userinfo = User::where('UserId', $comment['user_id'])->first();
                    if (!empty($userinfo)) {
                        $comment['Avatar'] = $userinfo->Avatar;
                        $comment['NickName'] = $userinfo->NickName;
                    }
                    $commentlist[] = $comment;
                }
            }

            $gamepie['commentlist'] = $commentlist;
            $signinfo = null;
            if (Auth::check()) {
                $signup = $gamePaiSignup->where('user_id','=',Auth::user()->UserId)->where('game_pai_id','=',$id)
                    ->findAll(['user_name','qq','tel','company','game_type','game_desc']);
                if (count($signup)) {
                    $signinfo = $signup[0];
                }
            }
            if ($gamepie->is_show_video) {
                $tabClass = 'video';
            } elseif ($gamepie->is_show_text) {
                $tabClass = 'article';
            } elseif ($gamepie->is_show_text) {
                $tabClass = 'gamedata';
            } else {
                $tabClass = 'dianping';
            }
            $relates = [];
            if (count($gamepie->related)) {
                foreach ($gamepie->related as $phase) {
                    $item = $gamepai->find($phase);
                    if ($item && $item->status == 0) {
                        array_push($relates, $item);
                    }
                    if (count($relates) == 2) {
                        break;
                    }
                }
            } else {
                $relates = $gamepai->getRelatedPies($gamepie->phase);
            }
            $myLike = $like->myLike('App\Entities\GamePai', $gamepie->id, Auth::user()['UserId']);
            $myFavorite = $fav->myFavorite('App\Entities\GamePai', $gamepie->id, Auth::user()['UserId']);
        } else {
            abort(404);
        }
        return view('gamepie.detail', compact('gamepie', 'myFavorite', 'myLike', 'relates', 'signinfo', 'tabClass'));
    }

    public function postSmsCode(GamePaiRepository $gamePai, GamePaiCodeRepository $gamePaiCode, Request $request, $id) {
        if (!Auth::check()) {
            return response()->json(['code' => -1, 'message' => '请登录']);
        }
        $user = Auth::user();
        $usercodes = $gamePaiCode->where('game_pai_id','=',$id)->where('user_id','=',$user->UserId)->findAll();
        if(count($usercodes) > 0){
            return response()->json(['code' => 0, 'message' => '你已经获得激活码', 'data'=>$usercodes[0]['code']]);
        }
        $register = $gamePaiCode->where('game_pai_id','=',$id)->where('user_id','=',0)->findAll();
        $game_pai = $gamePai->find($id);
        if(!empty($game_pai) && count($register) > 0 && $game_pai->sms_code > 0){
            $res = $gamePaiCode->update($register[0]->id, ['user_id' => $user->UserId]);
            $game_pai->decrement('sms_code');
            return response()->json(['code' => 0, 'data' => $register[0]['code'], 'message' => '成功']);
        }
        return response()->json(['code' => -1, 'message' => '已经没有激活码']);
    }

    public function postSignup(GamePaiRepository $gamePai, GamePaiSignupRepository $gamePaiSignup, Request $request, $id) {
        if (!Auth::check()) {
            return response()->json(['code' => -1, 'message' => '请登录']);
        }
        $user = Auth::user();
        $game_pai = $gamePai->find($id);
        if($game_pai == null) {
            return response()->json(['code' => -2, 'message' => '游戏派不存在']);
        }
        $this->validate($request,[
            'user_name' => 'required',
            'qq' => 'required',
            'tel' => 'required',
            'company' => 'required',
            'game_type' => 'required',
            'game_desc' => 'required'
        ]);
        $all = $request->all();
        $signUp = $gamePaiSignup->where('user_id', '=', $user->UserId)->where('game_pai_id', '=', $id)->findAll();
    	$data = ['game_pai_id' => $id, 'qq' => $all['qq'], 'user_name' => $all['user_name'], 'company' => $all['company'], 'game_type' => $all['game_type'], 'user_id' => $user->UserId, 'tel' => $all['tel'], 'game_desc' => $all['game_desc']];
    	if(count($signUp) > 0) {
            $res = $gamePaiSignup->update($signUp[0]->id, $data);
        } else {
            $res = $gamePaiSignup->create($data);
        }
        if($res[0]) {
            return response()->json(['code' => 0, 'data' => '', 'message' => '成功']);
        }
        return response()->json(['code' => -1, 'message' => '提交出错']);
    }

    public function getSignUp(GamePaiSignupRepository $gamePaiSignup, Request $request, $id)
    {
        if (!Auth::check()) {
            return response()->json(['code' => -1, 'message' => '请登录']);
        }
        $user = Auth::user();
        $data = $gamePaiSignup->where('user_id','=',$user->UserId)->where('game_pai_id','=',$id)->findAll();
        if(count($data) > 0) {
            $data = $data[0];
        } else {
            $data = [];
        }
        return response()->json(['code' => 0, 'data' => $data]);
    }

    public function postUploadAttachment(Request $request)
    {
        $file = $request->file('file');

        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '']);
        }
        $size = round($file->getSize()/1024/1024,2)."M";
        $result = Upload::uploadQcloudCos('hatch', $file);
        if ($result['code'] == 0) {
            $fileExt = strtolower($file->getClientOriginalExtension());
            if (in_array($fileExt,['ppt','pptx','pdf'])) {
                $previewUrl = Upload::getPreviewDoc($result);
                $header = get_headers(str_replace("#page#","1",$previewUrl["url"]), 1);
                $page = intval($header["User-ReturnCode"]);
                if($page <=0){
                    $page = 1;
                }
                $result['data']['access_url'] .= '?newd='.urlencode($previewUrl["url"].";".$page);
            }
            return response()->json(['code' => 0, 'url' => $result['data']['access_url'],'size' =>$size]);
        } else {
            return response()->json(['code' => 1, 'message' => '']);
        }
    }

    public function postUploadVideo(Request $request)
    {
        $file = $request->file('file');
        if (!$file->isValid()) {
            return response()->json(['code' => 1, 'message' => '']);
        }

        $ret = Upload::file($file);
        if(isset($ret["url"])){
            $url = parse_url($ret['url']);
            if(isset($url['query'])){
                parse_str($url['query']);
            }
            $ret['uuid'] = $uuid;
            $url = parse_url($ret['url']);
            $ret["url"] = "/hatch/showVideo/?fileurl=".Upload::hideFileServer($ret["url"])."%26videotype=30|||".$file->getClientOriginalName();
        }
        return response()->json(['code' => 0, 'uuid' => $ret['uuid'], 'url' => $ret['url']]);
    }
}
