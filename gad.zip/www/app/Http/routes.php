<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', ['as' => 'home', 'uses' => 'HomeController@index']);

//关于我们
Route::get('/home/about/{id?}', ['as' => 'home', 'uses' => 'HomeController@about']);

// User
Route::group(['namespace' => 'User', 'as' => 'user::'], function () {
    Route::get('user/personal', 'UserController@getPersonal');
    Route::get('user/teacher', 'UserController@getTeacher');
    Route::get('user/creator', 'UserController@getCreator');
    Route::get('user/course/{id}', 'UserController@getCourseStudents');
    Route::get('user/searchByQQ', ['as' => 'search', 'uses' => 'HomeController@getSearchByQQ']);
});

// Auth
Route::group(['namespace' => 'Auth'], function () {
    Route::get('login', 'AuthController@getLogin');
    Route::get('auth/callback', 'AuthController@getCallback');
    Route::get('auth/weixin', 'AuthController@getWeixin');
    Route::controller('auth/mobile', 'MobileController');
    Route::get('logout', 'AuthController@getLogout');
});

Route::get('bon/{id}', ['as' => 'bon', 'uses' => 'BonController@testBadword', 'middleware' => 'acl:article::index']);
Route::get('bon/index', 'BonController@index');

// Course
Route::group(['namespace' => 'Course', 'as' => 'course::'], function () {
    Route::get('course', ['as' => 'home', 'uses' => 'CourseController@getIndex']);
    Route::get('course/{id}', ['as' => 'detail', 'uses' => 'CourseController@getDetail']);
    Route::get('course/info/{id}', ['as' => 'info', 'uses' => 'CourseController@getInfo']);
    Route::get('course/create', ['as' => 'create', 'uses' => 'CourseController@getCreate']);
    Route::get('course/edit/{id}', ['as' => 'edit', 'uses' => 'CourseController@getEdit']);
    Route::post('course/edit/{id}', ['uses' => 'CourseController@postEdit']);
    Route::get('course/wxpay/{id}', 'PayController@getWxPay');
    Route::post('course/wxpay/notify', 'PayController@postWxPayNotify');
    Route::post('course/wxpay/result', 'PayController@postWxPayResult');
    Route::post('course/wxpay/callback', 'PayController@postWxPayCallback');
    Route::post('course/create', 'CourseController@postCreate');
    Route::delete('course/{id}', 'CourseController@destroy');
    Route::post('course/release', 'CourseController@postRelease');
    Route::get('course/teacher', 'CourseController@getTeacher');
    Route::get('course/assistant', 'CourseController@getAssistant');
    Route::post('course/uploadImage', 'CourseController@postUploadImage');
    Route::post('course/editorUploadImage', 'CourseController@postEditorUploadImage');
    Route::get('course/lesson/{id}', 'LessonController@getShow');
    Route::get('course/lesson/item/{id}', 'LessonController@getItem');
    Route::post('course/lesson/create', 'LessonController@postCreate');
    Route::post('course/lesson/update/{id}', 'LessonController@postUpdate');
    Route::post('course/lesson/uploadAttachment', 'LessonController@postUploadAttachment');
    Route::post('course/lesson/convertVodNotify', 'LessonController@postConvertVodNotify');
    Route::delete('course/lesson/{id}', 'LessonController@destroy');
    Route::post('course/startPlay', 'CourseController@postStartPlay');
    Route::post('course/endPlay', 'CourseController@postEndPlay');
    Route::post('course/register', 'CourseController@postRegister');
    Route::post('course/collect/{id}', 'CourseController@postCollect');
    Route::post('course/doc2Html', 'LessonController@doc2Html');
    Route::post('course/refund', 'CourseController@postRefund');
    Route::get('course/weixin/share/{id}', 'CourseController@getShareQrCode');
});

//W
Route::group(['namespace' => 'Work', 'as' => 'W::'], function () {
    Route::get('video/create/{id}', ['as' => 'workvideo', 'uses' => 'VideoController@createView']);
    Route::get('video/create', ['as' => 'workvideo', 'uses' => 'VideoController@createView']);
    Route::post('work/video/create/{id}', ['as' => 'workvideo', 'uses' => 'VideoController@postCreate']);
    Route::get('video/detail/{id}', ['as' => 'workvideo1', 'uses' => 'VideoController@detail']);
    Route::post('work/uploadVideo', ['as' => 'workvideo', 'uses' => 'VideoController@uploadVideo']);
    Route::get('work/showVideo', ['as' => 'workvideo', 'uses' => 'VideoController@showVideo']);
    Route::get('work/list/{classId}', ['as' => 'workvideo', 'uses' => 'VideoController@getList']);
    Route::get('work/list/{classId}/{Pagesize}', ['as' => 'workvideo', 'uses' => 'VideoController@getList']);
    Route::get('work/list/{classId}/{pagesize}/{orderby}', ['as' => 'workvideo', 'uses' => 'VideoController@getList']);
});

// 移动端
Route::group(['namespace' => 'Mobile', 'as' => 'Mobile::'], function () {
    Route::get('activity/problemwx/getFriendship', ['as' => 'problemwxgetFriendship', 'uses' => 'Activity\ProblemwxController@getFriendship']);
    Route::controller('m/activity/problem', 'Activity\ProblemMiddleController');
    Route::get('activity/problemwx/getProblems', ['as' => 'problemwxgetProblems', 'uses' => 'Activity\ProblemwxController@getProblems']);
    Route::get('activity/problemwx/answerProblem', ['as' => 'problemwxanswerProblem', 'uses' => 'Activity\ProblemwxController@answerProblem']);
    Route::get('activity/problemwx/getScore', ['uses' => 'Activity\ProblemwxController@getScore']);
    Route::get('activity/problemwx/summitQQ', ['as' => 'problemwxsummitQQ', 'uses' => 'Activity\ProblemwxController@summitQQ']);
    Route::get('activity/problemwx/addNum', ['as' => 'problemwxaddNum', 'uses' => 'Activity\ProblemwxController@addNum']);
    Route::get('activity/problemwx/answerQuestion', ['as' => 'answerquestionIndex', 'uses' => 'Activity\ProblemwxController@answerQuestion']);
    Route::get('m/wenda/detail/{questionId}', ['as' => 'wendaactivitydetail', 'uses' => 'Wenda\WendaController@detail'])
        ->where(['questionId' => '[0-9]+']);
    Route::get('m/wenda/answerList/{questionId}', ['as' => 'wendaactivitydetailanswerlist', 'uses' => 'Wenda\WendaController@answerList'])
        ->where(['questionId' => '[0-9]+']);
    Route::post('m/wenda/saveAnswer', ['uses' => 'Wenda\WendaController@postAnswer']);
    Route::post('m/wenda/adoptanswer', ['as' => 'wendaactivitydetailadoptanswer', 'uses' => 'Wenda\WendaController@adoptAnswer']);


    Route::get('m/wenda/activity/{activityId}', ['as' => 'wendaphoneactivity', 'uses' => 'Wenda\WendaController@index']);
    Route::get('m/wenda/activity/getquestion/{activityId}', ['uses' => 'Wenda\WendaController@getQuestion']);
    Route::post('m/wenda/activity/savequestion', ['uses' => 'Wenda\WendaController@saveQuestion']);

    Route::get('m/fame/detail/{id}', '\App\Http\Controllers\Fame\FameController@mdetail');

    //2017抽奖活动
    Route::get('m/activity/newyear/activity2017', ['uses' => 'Activity\NewyearController@activity2017']);
    Route::post('m/activity/newyear/do_lottery', ['uses' => 'Activity\NewyearController@do_lottery']);
    Route::post('m/activity/newyear/get_lottery_chance', ['uses' => 'Activity\NewyearController@get_lottery_chance']);
    Route::post('m/activity/newyear/get_user_info', ['uses' => 'Activity\NewyearController@get_user_info']);
    Route::post('m/activity/newyear/submit_qq', ['uses' => 'Activity\NewyearController@submit_qq']);
    Route::get('m/activity/newyear/test', ['uses' => 'Activity\NewyearController@test']);

    //live宣传h5
    Route::controller('m/livepub', 'Activity\LiveController');

    //live
    Route::get('m/live/list', 'Live\Live2Controller@getList');
    Route::get('m/live/my', 'Live\Live2Controller@getMy');
    Route::get('m/live/detail/{id}', 'Live\Live2Controller@getDetail');
    Route::post('m/live/buy/{id}', 'Live\Live2Controller@postBuy');
    Route::get('m/live/chatroom/{liveId}', 'Live\LiveController@getMChatroom');
    Route::post('m/live/uploadwx', 'Live\LiveController@postUploadwx');
    Route::get('m/live/login', 'Live\Live2Controller@getLogin');

    Route::controller('m/live2', 'Live\Live2Controller');
    //知识专题
    Route::controller('m/lore', 'Lore\LoreController');

    Route::get('m/activity/teacher','Activity\TeacherController@getIndex');

    //新手引导
    Route::get('m/live/guide', 'Live\Live2Controller@getGuide');
    //offer活动
    Route::controller('m/activity/offer', 'Activity\OfferController');
});

//新手引导
Route::get('live/guide', 'Live\LiveController@getGuide');

Route::get('live/rcode', 'Live\LiveController@getRcode');
Route::get('live/detail/{id}', 'Live\LiveController@getDetail');
Route::post('live/buy/{id}', 'Live\LiveController@postBuy');
Route::get('live/list', 'Live\LiveController@getList');
Route::get('live/ship', 'Live\LiveController@getShip');
Route::get('live/my', ['middleware' => 'auth', 'uses' => 'Live\LiveController@getMy']);
Route::get('live/messageList', 'Mobile\Live\LiveController@getMessageList');
Route::post('live/likeMessage', 'Mobile\Live\LiveController@postLikeMessage');
Route::get('live/liveList', 'Mobile\Live\LiveController@getLiveList');
Route::controller('live', 'Mobile\Live\LiveController');

// wenda
Route::group(['namespace' => 'Wenda', 'as' => 'Wenda::'], function () {

    Route::get('wenda/activity/{activityId}', ['as' => 'wendaactivity', 'uses' => 'Activity2Controller@index'])
        ->where(['activityId' => '[0-9]+']);
    Route::get('wenda/detail/{questionId}', ['uses' => 'ActivityController@wendetail'])
        ->where(['questionId' => '[0-9]+']);
    Route::get('wenda/getanswerlist', ['uses' => 'ActivityController@getAnswerList']);
    Route::post('wenda/saveanswer', ['uses' => 'ActivityController@saveAnswer']);
    Route::post('wenda/adoptanswer', ['uses' => 'ActivityController@adoptAnswer']);
    Route::get('wenda/activity/wenxin/share/{activityId}/{questionId}', ['uses' => 'ActivityController@getShareQrCode']);
    Route::post('wenda/delanswer', ['uses' => 'ActivityController@delAnswer']);
    Route::get('wenda/getcommentlist', ['uses' => 'ActivityController@getCommentList']);
    Route::post('wenda/savecomment', ['uses' => 'ActivityController@saveComment']);
    Route::post('wenda/delcomment', ['uses' => 'ActivityController@delComment']);

    Route::post('wenda/activity/savequestion', ['uses' => 'ActivityController@saveQuestion']);
    Route::get('wenda/activity/getquestion/{activityId}', ['uses' => 'ActivityController@getQuestion']);

});

// fames
Route::group(['namespace' => 'Fame', 'as' => 'Fame::'], function () {
    Route::get('fame/detail/{id}', ['uses' => 'FameController@detail']);
    Route::get('fame/getShare/{id}', 'FameController@getShare');
    Route::get('fame/list', 'FameController@getList');
    Route::get('fame/listdata', 'FameController@getListData');
});

// helps
Route::group(['namespace' => 'Help', 'as' => 'help::'], function () {
    Route::get('help/course/student', ['as' => 'student', 'uses' => 'CourseController@getStudent']);
    Route::get('help/course/teacher', ['as' => 'teacher', 'uses' => 'CourseController@getTeacher']);
    Route::get('help/course/protocol', ['as' => 'teacher', 'uses' => 'CourseController@getProtocol']);
});

// Admin
if (app()->isLocal() OR (request()->server('SERVER_ADDR') == '10.123.135.165')) {
    Route::group(['namespace' => 'Admin', 'as' => 'admin::', 'middleware' => 'admin'], function () {
        Route::controller('admin/auth', 'AuthController');
        Route::controller('admin/upload', 'UploadController');
        Route::resource('admin/user', 'UserController');
        Route::resource('admin/teacher', 'Course\TeacherController');
        //Route::get('admin/course/{id}/type', 'Course\CourseController@getType');
        Route::resource('admin/course/type', 'Course\TypeController');
        Route::post('admin/course/{id}/release', 'Course\CourseController@postRelease');
        Route::resource('admin/course', 'Course\CourseController');
        Route::post('admin/course/{courseId}/lesson/{id}/start', 'Course\LessonController@postStart');
        Route::post('admin/course/{courseId}/lesson/{id}/stop', 'Course\LessonController@postStop');
        Route::post('admin/course/{courseId}/lesson/{id}/reset', 'Course\LessonController@postReset');
        Route::post('admin/course/{courseId}/lesson/{id}/convert', 'Course\LessonController@postConvert');
        Route::controller('admin/course/chat', 'Course\ChatController');
        Route::resource('admin/course.lesson', 'Course\LessonController');
        Route::resource('admin/course.student', 'Course\StudentController');
    });
}

// restful api
Route::group(['namespace' => 'Api', 'as' => 'api::'], function () {
    Route::get('api', ['as' => 'home', 'uses' => 'ApiController@get']);
    Route::get('api/content/{id}', ['uses' => 'ApiController@detail']);
    Route::get('api/comment/{id}', ['uses' => 'ApiController@comment']);
    Route::get('api/getworkslist/{activityId}', ['uses' => 'ApiController@getWorksList']);
    Route::get('api/getworkdetail/{workId}', ['uses' => 'ApiController@getWorkDetail']);
    Route::get('api/getReplyList/{id}', ['uses' => 'ApiController@getReplyList']);
    Route::get('api/getHotReplyList/{id}', ['uses' => 'ApiController@getHotReplyList']);
    Route::get('api/relatedContent', ['uses' => 'ApiController@relatedContent']);
    Route::controller('api/weixin', 'WeixinController');
    Route::resource('api/course', 'CourseController', ['only' => ['index', 'show', 'update']]);

    //下载文件
    Route::get('api/downFiles', ['uses' => 'ApiController@downFile']);

    //发送短信-支持批量发
    Route::post('api/sendSms', ['uses' => 'ApiController@SendSms']);

    //视频接口
    Route::get('api/video', ['uses' => 'ApiController@getVideo']);

    //暑期俱乐部
    Route::get('api/summercamp/news/{id}', ['uses' => 'ApiController@getSummerNews']);

    //404页面活动列表
    Route::get('api/subjectlist', ['uses' => 'ApiController@getSubjectList']);
    //浏览数统计
    Route::post('api/addviewcnt', ['uses' => 'ApiController@postAddViewcnt']);

    // 磨坊接口
    Route::get('api/mofang', ['uses' => 'MofangController@getIndex']);
});
//暑期训练营
Route::group(['namespace' => 'SummerCamp'], function () {
    Route::get('summercamp/index', ['uses' => 'SummerCampController@getIndex']);
    Route::get('summercamp/courselist', ['uses' => 'SummerCampController@getCourselist']);
    Route::get('summercamp/workslist', ['uses' => 'SummerCampController@getWorkslist']);
});

//operate
Route::group(['namespace' => 'Operate'], function () {
    Route::post('operate/like', ['uses' => 'LikeController@postOperate']);
    Route::get('operate/getlikerelate', ['uses' => 'LikeController@getLikeRelate']);
    Route::post('operate/favor', ['uses' => 'FavoriteController@postOperate']);
    Route::get('comment/getcount', ['uses' => 'CommentController@getCount']);
    Route::get('comment/getlist', ['uses' => 'CommentController@getList']);
    Route::post('comment/add', ['uses' => 'CommentController@postAdd']);
    Route::post('comment/editorUploadImage', ['uses' => 'CommentController@postEditorUploadImage']);
    Route::post('comment/edit', ['uses' => 'CommentController@postEdit']);
    Route::post('comment/del/{id}', ['uses' => 'CommentController@postDel']);
    Route::get('comment/index', ['uses' => 'CommentController@index']);
    Route::get('pv/click', ['uses' => 'PvController@click']);
    Route::get('pv/main', ['uses' => 'PvController@main']);
    Route::get('pv/main.png', ['uses' => 'PvController@main']);
});

//管理端配置
if (app()->isLocal() OR (request()->server('SERVER_ADDR') == '10.123.135.165')) {
    Route::group(['namespace' => 'Mgr', 'as' => 'mgr::', 'middleware' => 'admin'], function () {
        Route::get('mgr/news/config/{id}', ['uses' => 'NewsController@getConfig']);
        Route::post('mgr/news/save', ['uses' => 'NewsController@saveConfig']);
        //暑期分享表
        Route::post('mgr/summercourse/create', 'SummercourseController@postCreate');
        Route::post('mgr/summercourse/edit/{id}', 'SummercourseController@postEdit');
        Route::post('mgr/summercourse/delete/{id}', 'SummercourseController@postDelete');
        Route::post('mgr/summercourse/list', 'SummercourseController@postList');
        Route::post('mgr/summercourse/uploadImage', 'SummercourseController@postUploadImage');
        Route::get('mgr/summercourse/teacher', 'SummercourseController@getTeacher');
        // 白名单
        Route::get('mgr/summercourse/list/{id}', 'SummercourseController@getWhitelist');
        Route::post('mgr/summercourse/saveConfig', 'SummercourseController@setWhitelist');

        // 分类
        Route::get('mgr/classify/list', 'ClassifyController@getClassifyList');
        Route::post('mgr/classify/create', 'ClassifyController@postCreateClassify');
        Route::post('mgr/classify/edit/{id}', 'ClassifyController@postEditClassify');
        Route::post('mgr/classify/delete/{id}', 'ClassifyController@postDeleteClassify');
        Route::get('mgr/classify/all', 'ClassifyController@index');
        Route::get('mgr/classify/lists', 'ClassifyController@getClassifyLists');

        // 作业类型
        Route::get('mgr/worktype/list', 'WorksController@getWorktypeList');
        Route::post('mgr/worktype/create', 'WorksController@postCreateWorktype');
        Route::post('mgr/worktype/edit/{id}', 'WorksController@postEditWorktype');
        Route::post('mgr/worktype/delete/{id}', 'WorksController@postDeleteWorktype');
        Route::get('mgr/worktype/all', 'WorksController@index');

        //基本对象管理
        Route::post('mgr/article/list', 'WorksController@getArticleList');
        Route::post('mgr/article/set', 'WorksController@manageArticle');

        //文章QQ群列表
        Route::post('mgr/qqgroup/list', 'OperationsController@getQQGroupList');
        //文章QQ群设置状态
        Route::post('mgr/qqgroup/set', 'OperationsController@updateQQGroupStatus');

        Route::post('mgr/qqgroup/getQQGroupById/', 'OperationsController@getQQGroupById');

        //添加或更新qq群信息
        Route::post('mgr/qqgroup/addOrUpdateQQGroup', 'OperationsController@addOrUpdateQQGroup');

        //获取网站规模数据信息
        Route::get('mgr/websitesize/getWebSiteSizeInfo', 'OperationsController@getWebSiteSizeInfo');

        //添加或修改网站规模数据
        Route::post('mgr/websitesize/addOrUpdateWebSiteSize', 'OperationsController@addOrUpdateWebSiteSize');

        Route::get('mgr/video/list', 'WorksController@getVideoList');
        Route::post('mgr/video/set', 'WorksController@manageVideo');

        Route::get('mgr/picture/list', 'WorksController@getArtworkList');
        Route::post('mgr/picture/set', 'WorksController@manageArtwork');

        //问题
        Route::post('mgr/question/list', 'WorksController@getQuestionList');
        Route::post('mgr/question/set', 'WorksController@manageQuestion');
        Route::post('mgr/question/updateRank', 'WorksController@updateRankQuestion');

        //回答
        Route::post('mgr/answers/list', 'WorksController@getAnswersList');
        Route::post('mgr/answers/set', 'WorksController@manageAnswers');
        Route::post('mgr/answers/updateRank', 'WorksController@updateRankAnswers');
        Route::post('mgr/answers/updateAdopt', 'WorksController@updateAdopt');
        Route::post('mgr/answers/updateAnswers', 'WorksController@updateAnswers');
        //设置问题回答者
        Route::post('mgr/answers/setAnswerUserInfo', 'WorksController@setAnswerUserInfo');

        //live
        Route::post('mgr/live/addOrUpdateLiveInfo', 'LivesController@addOrUpdateLiveInfo');
        Route::post('mgr/live/getLiveInfoById', 'LivesController@getLiveInfoById');
        Route::post('mgr/live/getLiveInfoList', 'LivesController@getLiveInfoList');

        //修改审核状态
        Route::post('mgr/live/updateLiveState', 'LivesController@updateLiveState');

        //修改关闭状态
        Route::post('mgr/live/updateLiveRowstatus', 'LivesController@updateLiveRowstatus');

        //live管理员信息
        Route::post('mgr/live/getAdminInfoList', 'LivesController@getAdminInfoList');
        //Route::post('mgr/live/updateAdminStatus', 'LivesController@updateAdminStatus');
        Route::post('mgr/live/addOrUpdateAdminInfo', 'LivesController@addOrUpdateAdminInfo');
        Route::post('mgr/live/getAdminInfoById', 'LivesController@getAdminInfoById');
        Route::post('mgr/live/getLiveInfo', 'LivesController@getLiveInfo');
        Route::post('mgr/live/uploadImage', 'LivesController@postUploadImage');

        //项目孵化管理
        Route::post('mgr/project/list', 'ProjectController@postGameList');
        Route::post('mgr/project/set', 'ProjectController@manageGame');
        Route::post('mgr/entry/list', 'ProjectController@getRegisterList');
        Route::post('mgr/entry/set', 'ProjectController@setRegister');

        //项目列表导出
        Route::get('mgr/project/excelProjectList', 'ProjectController@excelProjectList');

        //活动管理，问答活动,嘉年华活动,名人堂
        Route::resource('mgr/wenda/activity', 'ActivityController');

        //我问专家
        Route::controller('mgr/wendaActivity', 'WendaActivityController');

        Route::resource('mgr/activity/actconfig', 'ActConfigController');
        Route::resource('mgr/activity/mingrentang', 'FameController');

        //城市站报名列表
        Route::post('mgr/citystation/getCityStationList', 'CityStationController@getCityStationList');
        //导出城市站导出
        Route::get('mgr/citystation/excelCityStationList', 'CityStationController@excelCityStationList');
        //批量修改状态
        Route::post('mgr/citystation/updateStatus', 'CityStationController@updateStatus');

        //城市站-新版
        Route::controller('mgr/city', 'CityController');

        //城市站详细信息
        Route::controller('mgr/citydetail', 'CityDetailController');

        //用户列表-管理端
        Route::controller('mgr/userpression', 'UserPressionController');

        //内容库管理端
        Route::controller('mgr/communityhome', 'CommunityHomeController');

        //内容库管理端
        Route::controller('mgr/commentall', 'CommentAllController');

        //组队管理端
        Route::controller('mgr/team', 'TeamController');

        //知识手册
        Route::resource('mgr/lore', 'LoreController');

        //知识手册添加白名单
        Route::post('mgr/lorewhite/addWhiteUser', 'LoreWhiteController@addWhiteUser');

        //获取白名单列表
        Route::resource('mgr/lorewhite/getWhiteUserList', 'LoreWhiteController');

        Route::resource('mgr/lorepay/getLorePayUserList', 'LoreWhiteController@getLorePayUserList');

        Route::resource('mgr/loreteacher', 'LoreTeacherController');
        Route::resource('mgr/lorechapter', 'LoreChapterController');
        Route::resource('mgr/loresection', 'LoreSectionController');

        Route::get('mgr/loredesc/{id}', 'LoreController@getDescInfo');
        Route::post('mgr/loredesc/update', 'LoreController@updateDescInfo');
        //大咖评论
        Route::get('mgr/daka/comment/{id}', 'LoreController@getDaKaCommentInfo');
        Route::post('mgr/daka/update', 'LoreController@updateCommentInfo');
        //大咖评论删除
        Route::post('mgr/daka/del', 'LoreController@delCommentInfo');

        //推荐设置
        Route::resource('mgr/user', 'UsersController');//检索用户
        Route::put('mgr/Operations/totop', 'OperationsController@toTop');//设置置顶
        Route::put('mgr/Operations/upward', 'OperationsController@upward');//推荐向上
        Route::put('mgr/Operations/down', 'OperationsController@down');//推荐向上
        Route::resource('mgr/Operations', 'OperationsController');//推荐设置

        Route::resource('mgr/SearchKeyWord', 'SearchKeyWordController');//关键字设置


        //晨星计划 排序操作
        Route::get('mgr/expertPlansToTop/{id}', 'ExpertPlansController@toTop');
        Route::get('mgr/expertPlansUpward/{id}', 'ExpertPlansController@upward');
        Route::get('mgr/expertPlansDown/{id}', 'ExpertPlansController@down');

        Route::get('mgr/expertPlansToHomePage/{id}', 'ExpertPlansController@toHomePage');
        Route::get('mgr/expertPlansRemoveHomePage/{id}', 'ExpertPlansController@removeHomePage');
        Route::get('mgr/expertPlansUpwardHomePage/{id}', 'ExpertPlansController@upwardHomePage');
        Route::get('mgr/expertPlansDownHomePage/{id}', 'ExpertPlansController@downHomePage');

        // 晨星计划每月专家
        Route::get('mgr/expertPlans/tutor', 'ExpertPlansController@getTutorList');
        Route::get('mgr/expertPlans/tutor/{id}', 'ExpertPlansController@showTutor');
        Route::post('mgr/expertPlans/tutor/create', 'ExpertPlansController@createTutor');
        Route::put('mgr/expertPlans/tutor/{id}', 'ExpertPlansController@updateTutor');
        Route::delete('mgr/expertPlans/tutor/{id}', 'ExpertPlansController@deleteTutor');

        //晨星计划
        Route::resource('mgr/expertPlans', 'ExpertPlansController');


        //获取TAG tree
        Route::get('mgr/tag/getTagTreeList', 'TagController@getTagTreeList');
        //创建
        Route::post('mgr/tag/create', 'TagController@store');
        //更新
        Route::post('mgr/tag/update', 'TagController@update');
        //删除
        Route::delete('mgr/tag/delete/{id}', 'TagController@destroy');
        // 获取推荐的标签
        Route::get('mgr/tag/getList', 'TagController@getList');


        //游戏派
        // 游戏派 导入邀请码
        Route::post('mgr/gamePai/importCode/{id}', 'GamePaiController@importCode');
        //游戏派 rest
        Route::get('mgr/gamePai/getMaxPhase', 'GamePaiController@getMaxPhase');
        Route::get('mgr/gamePai/getAllList', 'GamePaiController@getAllList');

        Route::resource('mgr/gamePai', 'GamePaiController');
        //导出报名
        Route::get('mgr/gamePaiSignup/excelList', 'GamePaiSignupController@excelList');
        Route::resource('mgr/gamePaiSignup', 'GamePaiSignupController');
        // 项目管理
        Route::get('mgr/hatchProject/getExcelProjectList', 'HatchProjectController@getExcelProjectList');
        Route::get('mgr/hatchProject/pushMailToExpert', 'HatchProjectController@pushMailToExpert');
        Route::put('mgr/hatchProject/editPushMailStatus', 'HatchProjectController@editPushMailStatus');
        Route::get('mgr/hatchProject/getPushMailStatus', 'HatchProjectController@getPushMailStatus');
        Route::resource('mgr/hatchProject', 'HatchProjectController');
        Route::resource('mgr/structure', 'StructureProjectController');
        // 大赛项目管理
        Route::resource('mgr/hatchGame', 'HatchGameController');

        //专家点评详情
        Route::controller('mgr/expertcomment', 'ExpertCommentController');

        // 禁言设置
        Route::resource('mgr/ban', 'BanController');
        Route::resource('mgr/projectComment', 'ProjectCommentController');
        //专题
        Route::resource('mgr/specialTopic', 'SpecialTopicController');
        //新版活动管理
        Route::resource('mgr/new/activity', 'NewActivity\ActivityController');
        Route::any('mgr/new/activitySignUp/export', 'NewActivity\ActivitySignUpController@export');
        Route::resource('mgr/new/activitySignUp', 'NewActivity\ActivitySignUpController');

        //项目扶持
        Route::resource('mgr/serviceMember', 'ServiceMembersController'); // 项目成员
        Route::resource('mgr/service', 'ServicesController'); // 服务
        Route::resource('mgr/serviceOrder', 'ServiceOrdersController'); // 服务

    });
}

//文章
Route::group(['namespace' => 'Article', 'as' => 'article::'], function () {
    Route::get('articulo', ['as' => 'home', 'uses' => 'ArticleController@getIndex']);
    Route::get('articulo/detail/{id}', ['as' => 'detail', 'uses' => 'ArticleController@getDetail']);
    Route::get('articulo/info/{id}', ['as' => 'info', 'uses' => 'ArticleController@getInfo']);
    Route::get('articulo/create', ['as' => 'create', 'uses' => 'ArticleController@getCreate', 'middleware' => 'acl:article::create']);
    Route::get('articulo/edit/{id}', ['as' => 'edit', 'uses' => 'ArticleController@getEdit']);
    Route::post('articulo/edit/{id}', ['uses' => 'ArticleController@postEdit']);
    Route::post('articulo/create', ['uses' => 'ArticleController@postCreate', 'middleware' => 'acl:article::create']);
    Route::post('articulo/editorUploadImage', 'ArticleController@postEditorUploadImage');
    Route::get('articulo/editorUploadImage', 'ArticleController@postEditorUploadImage');
    Route::post('articulo/uploadAttachment', 'ArticleController@postUploadAttachment');
    Route::get('articulo/list/{classId}', 'ArticleController@getList');
});

//美术作品
Route::group(['namespace' => 'Art', 'as' => 'art::'], function () {
    Route::get('art', ['as' => 'home', 'uses' => 'ArtController@index']);
    Route::get('art/detail/{id}', ['as' => 'detail', 'uses' => 'ArtController@getDetail']);
    Route::get('art/create', ['as' => 'create', 'uses' => 'ArtController@getCreate']);
    Route::get('art/edit/{id}', ['as' => 'edit', 'uses' => 'ArtController@getEdit']);

    Route::post('art/uploadImage', 'ArtController@postUploadImage');
    Route::post('art/create', 'ArtController@postCreate');
    Route::post('art/edit/{id}', 'ArtController@postEdit');

    //分页列表
    Route::get('art/getlist', 'ArtController@getList');
    Route::get('art/list', 'ArtController@showList');
});

Route::controller('act', 'Activity\ActivityController');
//推广活动、宣传
Route::controller('pub', 'Act\PublishController');
Route::controller('fool', 'Activity\FoolController');
Route::controller('activity/game', 'Activity\FoolController');
Route::controller('activity/expert', 'Activity\ExpertController');
Route::controller('m/activity/expert', 'Mobile\Activity\ExpertController');

Route::group(['namespace' => 'Hatch', 'as' => 'hatch::'], function () {
    //GET
    Route::get('hatch', ['as' => 'home', 'uses' => 'HatchController@getIndex']);
    Route::get('hatch/create', ['as' => 'create', 'uses' => 'HatchController@getCreate',
        'middleware' => 'acl:hatch::create']);
    Route::get('hatch/edit/{id}', ['as' => 'edit', 'uses' => 'HatchController@getEdit']);
    Route::get('hatch/detail/{id}', ['as' => 'detail', 'uses' => 'HatchController@getDetail']);
    Route::get('hatch/getDownloadCnt/{id}', 'HatchController@getDownloadCnt');
    Route::get('hatch/showVideo', 'HatchController@getShowVideo');
    Route::get('hatch/skill', 'HatchController@getSkill');

    //POST
    Route::post('hatch/create', ['uses' => 'HatchController@postCreate',
        'middleware' => 'acl:hatch::create']);
    Route::post('hatch/edit/{id}', ['uses' => 'HatchController@postEdit']);
    Route::post('hatch/uploadAttachment', 'HatchController@postUploadAttachment');
    Route::post('hatch/uploadVideo', 'HatchController@postUploadVideo');

    //列表页
    Route::get('hatch/list/{os}/{type}/{stage}', 'HatchController@showList');
    Route::get('hatch/list', 'HatchController@showList');
    Route::get('hatch/register', ['as' => 'Register', 'uses' => 'HatchController@getRegister']);
    Route::get('hatch/getregisterinfo', ['uses' => 'HatchController@getRegisterInfo']);
    Route::post('hatch/postregister', ['uses' => 'HatchController@postRegister']);
    Route::post('hatch/getsmscode', ['uses' => 'HatchController@getSmsCode']);

    Route::post('hatch/save', ['uses' => 'HatchController@postSave']);

    Route::get('hatch/create-old', ['as' => 'create', 'uses' => 'HatchController@getCreateOld', 'middleware' => 'acl:hatch::create']);

    Route::controller('hatch/expert-plan', 'ExpertPlanController');
    
    Route::controller('hatch/city', 'CityController');

    Route::controller('hatch/project', 'ProjectController');

    Route::controller('hatch/service','ServiceController');
});

//类似嘉年华的那些活动
Route::group(['namespace' => 'Act', 'as' => 'act::'], function () {
    Route::get('act/jianianhua/index', ['uses' => 'ActController@index']);
    Route::get('act/jianianhua', ['uses' => 'ActController@index']);
    Route::get('act/jianianhua/rule', ['uses' => 'ActController@rule']);
    Route::get('act/jianianhua/updateconfig', ['uses' => 'ActController@updateConfig']);
    Route::get('act/jianianhua/getanswer', ['uses' => 'ActController@answer']);
    Route::post('act/jianianhua/checkanswer', ['uses' => 'ActController@givePrize']);
    Route::get('act/jianianhua/actStatus', ['uses' => 'ActController@getUseActStatus']);
    Route::get('act/jianianhua/prizelist', ['uses' => 'ActController@getGainPrizeList']);
    Route::post('act/jianianhua/prizetext', ['uses' => 'ActController@amsPrizeStat']);

    Route::get('act/jianianhua/test', ['uses' => 'ActController@testApi']);
});

Route::post('city/storeInfo', ['uses' => 'Activity\CityPreachController@postStoreInfo']);
Route::get('city/index/{city_id}', ['uses' => 'Activity\CityPreachController@getIndex']);
Route::get('city/index', ['uses' => 'Activity\CityPreachController@getIndex']);


//vr新首页
Route::group(['namespace' => 'Vr', 'as' => 'vr::'], function () {
    Route::get('vr/index', ['uses' => 'VrController@index']);
    Route::get('vr', ['uses' => 'VrController@index']);
});

Route::group(['namespace' => 'Message', 'as' => 'message::'], function () {
    Route::get('message/index', ['uses' => 'MessageController@index']);
    Route::get('message', ['uses' => 'MessageController@index']);
    Route::get('message/setting', ['uses' => 'MessageController@setting']);
});

Route::group(['namespace' => 'Lundao', 'as' => 'lundao::'], function () {
    Route::controller('lundao', 'LundaoController');
});

Route::group(['namespace' => 'Community', 'as' => 'community::'], function () {

    Route::get('community/{tag?}/{sort?}', 'HomeController@getIndex');
    Route::get('article/{tag?}/{sort?}', 'ArticleController@getIndex')->where(['tag' => 'my|hot|plan|art|vr|program|audio|project|yunying|test']);
    Route::get('question/{tag?}/{sort?}', 'QuestionController@getIndex')->where(['tag' => 'my|hot|plan|art|vr|program|audio|project|yunying|test']);
    Route::get('topic/{tag?}/{sort?}', 'TopicController@getIndex')->where(['tag' => 'my|hot|plan|art|vr|program|audio|project|yunying|test']);

    //Route::get('article/{tag?}/{sort?}', 'ArticleController@getIndex');
    Route::get('gallery/{tag?}/{type?}/{subtag?}/{order?}', 'PictureController@getIndex')->where('tag', 'my|hot|plan|art|vr|program|audio|project|yunying|test');
    Route::controller('community', 'HomeController');
    Route::controller('ncomment', 'CommentController');
    Route::controller('gallery', 'PictureController');
    Route::controller('nlike', 'LikeController');
    Route::controller('nfavorite', 'FavoriteController');
    Route::controller('question', 'QuestionController');
    Route::controller('nanswer', 'AnswerController');
    Route::controller('topic', 'TopicController');
    Route::controller('article', 'ArticleController');
    Route::controller('qrcode', 'QrcodeController');
    Route::controller('follow', 'FollowController');
    Route::controller('feeds', 'FeedController');
    Route::get('tag/{name}/{sort?}', 'TagController@getDetail')->where(['sort' => 'newest']);
    Route::controller('tag', 'TagController');
    //用户中心,个人profile页
    Route::get('u/profile/edit', 'UserController@getEdit');
    Route::controller('u', 'UserController');
    Route::controller('draft', 'DraftController');
});

Route::group(['namespace' => 'Feature', 'as' => 'feature::'], function () {
    Route::controller('feature', 'FeatureController');

});

Route::controller('hatch_game','Hatch\GameController');
Route::controller('hatch_collect','Hatch\GameCollectController');
//美术资源库
Route::controller('resource','Community\ResourceController');

//大赛
Route::controller('game','Game\GameController');
//游戏派
Route::controller('gamepie', 'GamePai\GamePaiController');

//知识专题
Route::controller('lore', 'Lore\LoreController');
Route::group(['namespace' => 'Team', 'as' => 'team::'], function () {
    Route::get('team', 'TeamController@getIndex');
    Route::controller('team/my/project', 'My\ProjectController');
    Route::controller('team/my/resume', 'My\ResumeController');
    Route::controller('team/resume', 'ResumeController');
    Route::controller('team/project', 'ProjectController');
});

//专题
Route::controller('specialtopic', 'SpecialTopic\SpecialTopicController');

//搜索
Route::group(['namespace' => 'Search', 'as' => 'search::'], function () {
    Route::get('search/{tagName?}', 'SearchController@getIndex')->where(['tagName' => 'index|article|question|topic|works|video|tag|user']);
    Route::controller('search', 'SearchController');
});

