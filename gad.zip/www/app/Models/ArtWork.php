<?php

namespace App\Models;

use Auth;
use Illuminate\Database\Eloquent\Model;

class ArtWork extends Model
{
    //
    protected  $table = 'pictures';
    protected $fillable = ['title','description', 'content','contents','label', 'cover', 'user_id', 'class_id', 'channel_id'];
    protected $append = ['is_liked','is_favored'];
    //对象类型，表示在点赞、收藏、评论表里的所属的obj_type
    const OBJ_TYPE = 1;

    public function user()
    {
        return $this->belongsTo('App\Models\User');
    }

    public function classify() {
        return $this->belongsTo('App\Models\Classify','class_id','class_id');
    }

    public function getIsLikedAttribute()
    {
        if (!Auth::check()) {
            return false;
        }

        $like = Like::where('obj_id',$this->id)
            ->where('obj_type',self::OBJ_TYPE)
            ->where('user_id',Auth::user()->UserId)
            ->where('status',0)
            ->first();
        return !$like ? false :true;
    }

    public function getIsFavoredAttribute()
    {
        if (!Auth::check()) {
            return false;
        }

        $like = Favorite::where('obj_id',$this->id)
            ->where('obj_type',self::OBJ_TYPE)
            ->where('user_id',Auth::user()->UserId)
            ->where('status',0)
            ->first();
        return !$like ? false :true;
    }
}
