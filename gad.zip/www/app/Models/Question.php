<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2016/10/11
 * Time: 8:54
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Auth;


class Question extends Model
{

   protected $fillable = ['question','description','label','user_id','name','to_user','to_name',
        'obj_type','obj_id','created_at','answers','views','attents','source','rank','status','update_user','updated_at'];

    protected $append = ['is_liked','is_favored'];
    //对象类型，表示在点赞、收藏、评论表里的所属的obj_type
    const OBJ_TYPE = 0;

    public function scopeQuestion($query, $param){
        if($param['orderby'] == 1){
            $query = $query->where('status', 0)->orderBy('rank', 'desc')->orderBy('created_at', 'desc');
        } else {
            $query = $query->where('status', 0)->orderBy('rank', 'desc')->orderBy('views', 'desc');
        }
        return $query;
    }

    public function user(){
		return $this->belongsTo('App\Models\User','user_id','UserId');
    }

	public function getAllQuestionCount($activityId,$date,$no = false)
	{
		$ques = [];
		if(!$no){
			$quesT = Question::where('obj_type',1)
			->where('obj_id',$activityId)
			->where('created_at','>',$date)
			->where('status',0)
			->count();
			$quesD = Question::where('obj_type',1)
			->where('obj_id',$activityId)
			->where('created_at','<=',$date)
			->where('status',0)
			->count();
			$ques[] = $quesT;
			$ques[] = $quesD;
		} else {
			$quesT = Question::where('obj_type',1)
			->where('obj_id',$activityId)
			->where('answers',0)
			->where('status',0)
			->count();
			$ques[] = $quesT;
		}
		return $ques;
	}

	public function getAllQuestion($activityId,$date,$a,$as,$d,$ds,$no = false)
	{
		$ques = [];
		if(!$no){
			$quesT = [];
			$quesD = [];
			if($as > 0){
				$quesT = Question::where('obj_type',1)
				->where('obj_id',$activityId)
				->where('created_at','>',$date)
				->where('status',0)
				->orderBy('rank','desc')->orderBy('answers','desc')->orderBy('id','desc')->skip($a)->take($as)->get();
			}
			if($ds > 0){
				$quesD = Question::where('obj_type',1)
				->where('obj_id',$activityId)
				->where('created_at','<=',$date)
				->where('status',0)
				->orderBy('rank','desc')->orderBy('id','desc')->skip($d)->take($ds)->get();
			}
			foreach($quesT as $v){
				$ques[] = $v;
			}
			foreach($quesD as $v){
				$ques[] = $v;
			}
		} else {
			$ques = Question::where('obj_type',1)
				->where('obj_id',$activityId)
				->where('answers',0)
				->where('status',0)
				->orderBy('created_at','desc')->skip($a)->take($as)->get();
		}
		return $ques;
	}

    public function getIsLikedAttribute()
    {
        if (!Auth::check()) {
            return false;
        }

        $like = Like::where('obj_id',$this->id)
            ->where('obj_type',self::OBJ_TYPE)
            ->where('user_id',Auth::user()->UserId)
            ->where('status',0)
            ->first();
        return !$like ? false :true;
    }

    public function getIsFavoredAttribute()
    {
        if (!Auth::check()) {
            return false;
        }

        $like = Favorite::where('obj_id',$this->id)
            ->where('obj_type',self::OBJ_TYPE)
            ->where('user_id',Auth::user()->UserId)
            ->where('status',0)
            ->first();
        return !$like ? false :true;
    }


}