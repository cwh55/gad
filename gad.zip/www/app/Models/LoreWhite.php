<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/7/5
 * Time: 8:23
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;
use Illuminate\Database\Eloquent\SoftDeletes;

class LoreWhite extends Model implements Transformable
{
    use TransformableTrait;
    use SoftDeletes;

    protected $table = 'lore_whites';
    protected $fillable = ['lore_id', 'user_id', 'creator','created_at','updated_at', 'deleted_at'];

    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }

    public function lore()
    {
        return $this->hasOne('App\Entities\Lore', 'id', 'lore_id')->where('state',0);
    }

}