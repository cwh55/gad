<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserManager extends Model
{
    //管理端用
    protected $primaryKey = "UserId";
    protected $table = 'User';
    protected $fillable = ['UserId', 'QQNo', 'RTXName', 'RealName', 'NickName', 'RowStatus', 'Email', 'Phone', 'Created',"type",
        'TutorIsShow', 'TutorStatus', 'Sex', 'WeixinId', 'Province', 'City', 'Summary', 'breif', 'education', 'School', 'Avatar','Profession'];

    public $timestamps = false;

    //public $dates=['Created'];
}