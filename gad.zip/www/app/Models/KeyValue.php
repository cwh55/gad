<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KeyValue extends Model
{
    public $primaryKey = 'Key';
    public $table = "KeyValue";
    public $fillable = ['KeyDesc', 'Value', 'RowStatus', 'Created', 'Creator', 'Modified', 'Modifier'];
    public $incrementing = false;//解决数据表中没有id,无法修改的问题

    /*public function user()
    {
        return $this->hasMany('App\Models\User');
    }*/

}
