<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/2/27
 * Time: 7:28
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class LiveSign extends Model
{
    protected $table = 'live_signs';
    protected $fillable = ['live_id','type','user_id', 'description', 'nickname','avatar','creator','created_at','updater','updated_at'];

    public function user()
    {
        return $this->hasOne('App\Models\User','UserId', 'user_id');
    }

    public function live()
    {
        return $this->hasOne('App\Models\Live','id', 'live_id');
    }

}