<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2016/10/11
 * Time: 8:54
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Auth;


class Answers extends Model
{
    protected $fillable = ['id', 'question_id' ,'answer','user_id','name','created_at','adopt','source','rank','status','update_user','updated_at'];

    protected $append = ['is_liked','is_favored'];
    //对象类型，表示在点赞、收藏、评论表里的所属的obj_type
    const OBJ_TYPE = 4;

    public function scopeAnswers($query, $param){

        if($param['orderby'] == 1){
            $query = $query->where('status', 0)->orderBy('rank', 'desc')->orderBy('created_at', 'desc');
        } else {
            $query = $query->where('status', 0)->orderBy('rank', 'desc')->orderBy('updated_at', 'desc');
        }
        return $query;
    }

    public function user(){
        return $this->belongsTo('App\Models\User','user_id','UserId');
    }

    public function question(){
        return $this->belongsTo('App\Models\Question','question_id','id');
    }

    public static function getUsers(array $userIds)
    {
        return User::whereIn('UserId',$userIds)
            ->where('RowStatus',0)
            ->get();
    }

	public function getQAnswer($qid,$userid)
	{
		$answer = Answers::where('question_id',$qid)->where('user_id',$userid)->where('status',0)->orderBy('created_at','desc')->first();
		if(!$answer){
			$answer = Answers::where('question_id',$qid)->where('status',0)->orderBy('vip','desc')->orderBy('adopt','desc')->orderBy('rank','desc')->orderBy('created_at','desc')->first();
		}
		if(!$answer){
			$answer = [];
		}
		return $answer;
	}

    public function getIsLikedAttribute()
    {
        if (!Auth::check()) {
            return false;
        }

        $like = Like::where('obj_id',$this->id)
            ->where('obj_type',self::OBJ_TYPE)
            ->where('user_id',Auth::user()->UserId)
            ->where('status',0)
            ->first();
        return !$like ? false :true;
    }

    public function getIsFavoredAttribute()
    {
        if (!Auth::check()) {
            return false;
        }

        $like = Favorite::where('obj_id',$this->id)
            ->where('obj_type',self::OBJ_TYPE)
            ->where('user_id',Auth::user()->UserId)
            ->where('status',0)
            ->first();
        return !$like ? false :true;
    }

    public static function getUserLikeRelates($userId,array $answerIds)
    {
        $like = Like::whereIn('obj_id',$answerIds)
            ->where('obj_type',self::OBJ_TYPE)
            ->where('user_id',$userId)
            ->get();
        return $like;
    }

}