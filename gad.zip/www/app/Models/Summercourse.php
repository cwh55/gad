<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Redis;
use Auth;
use Illuminate\Support\Facades\Log;

class Summercourse extends Model
{
    protected $fillable = ['class_id', 'title' , 'description', 'date','thumbnail' ,'video', 'teacher_id', 'video', 'has_work',
        'end_time', 'user_id', 'update_user'];
    //
    protected $userInfo = array();
    public function type(){
        return $this->belongsTo('App\Models\Classify','class_id');
    }
    public function teacher(){
        return $this->belongsTo('App\Models\Teacher');
    }


    public function getWhitelist($channelId){
    	$redisKey = 'gad:summer:work:whitelist';
    	if($channelId == 0) {
    		return Redis::hgetall($redisKey);
    	} else {
    		if (!Auth::check()) {
                Log::error('getWhitelist:', ['msg' => 'auth check']);
	            return false;
	        }
    		if(!in_array($channelId, array(1101, 1102, 1103, 1104, 1201))) {
                Log::error('getWhitelist:', ['msg' => 'channelId']);
	    		return false;
	    	} else {
                $keys = array(
                    1101 => 'config1',
                    1102 => 'config2',
                    1103 => 'config3',
                    1104 => 'config4',
                    1201 => 'config5'
                );
	    		$this->userInfo = Auth::user();
	        	$qq = $this->userInfo->QQNo;
	        	$data = Redis::hget($redisKey, $keys[$channelId]);
	        	if(in_array($qq, explode(',', $data))) {
                    Log::error('getWhitelist:', ['msg' => $qq]);
	        		return true;
	        	}
	    	}
    	}
    	return false;
    }

    public function setWhitelist($arr){
    	$redisKey = 'gad:summer:work:whitelist';
    	if(empty($arr) && !is_array($arr)) {
    		return false;
    	}

    	$ret = Redis::hmset($redisKey, $arr);        

    	return true;
    }
}
