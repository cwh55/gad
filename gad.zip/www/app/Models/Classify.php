<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Cache;

class Classify extends Model
{
	const MODULE_LAYER = 2;
	const CLASS_LAYER = 3;

    protected $fillable = ['clsss_id', 'class_name', 'parent', 'layer', 'user_id'];

	public static $class_table = 'classifies';

    public function user()
    {
        return $this->belongsTo('App\Models\User');
    }

	public function parentClass(){
		return $this->belongsTo('App\Models\Classify', 'parent', 'class_id');
	}

	public static function getClasses($class_id, $join = true){
		if($join){
			return Cache::remember('getClasses_Classify_'.$class_id, 2, function() use($class_id) {
				return Classify::join('worktypes', self::$class_table.'.class_id', '=', 'worktypes.class_id')
					->select(self::$class_table.'.*', 'worktypes.type')
					->where('parent', $class_id)->orderBy('worktypes.created_at', 'desc')->get();
			});
		}
		return Cache::remember('getClasses_Classify_1_'.$class_id, 2, function() use($class_id) {
			return Classify::select(self::$class_table.'.*')
				->where('parent', $class_id)->get();
		});
	}

	public static function getClass($class_id, $join = true){
		if($join){
			$worktype = Worktype::where('class_id', $class_id)->first();
			if(empty($worktype)){
				$class = new Classify();
				$class->type = null;
				return Classify::where('class_id', $class_id)->first();				
			}
			$class = $worktype->classify;

			$class->type = $worktype->type;

			return $class;
		}
		return Classify::where('class_id', $class_id)->first();	
	}
}
