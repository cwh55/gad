<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Actconfig extends Model
{
    protected $fillable = ['act_id', 'type', 'title', 'content', 'answer', 'img','date', 'status'];


}
