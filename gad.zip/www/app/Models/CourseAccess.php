<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CourseAccess extends Model
{
    protected $table = 'course_access';
    protected $fillable = ['course_id', 'lesson_id', 'user_id', 'type'];
}
