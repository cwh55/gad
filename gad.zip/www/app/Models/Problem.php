<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Problem extends Model
{
	public $primaryKey = 'openid';
	//

	protected static $date = "2016-09-05";

	public static function checkDate($ex = false){
		if(date("Y-m-d") > self::$date){
			if($ex == false){
				throw new Exception('-11', 'not right');
			} else {
				return true;
			}
		}
		return false;
	}
}
