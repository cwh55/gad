<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Auth;

class Fame extends Model
{
    protected $fillable = ['phase','class', 'name', 'name_description', 'person_description', 'desciption', 'logo','banner', 'mbanner', 'user_id', 'person_picture', 'detail', 'view_cnt', 'aye_cnt', 'fav_cnt', 'is_read', 'is_comment', 'tags', 'attachments', 'status'];

	public function getIsLikedAttribute(){
		if(!Auth::check()){
			return false;
		}
		$userId = Auth::user()['UserId'];
		$isLiked = Like::where('obj_id',$this->id)->where('obj_type',101)->where('user_id',$userId)->where('status',0)->first();
		return $isLiked ? true : false;
	}

	public function getIsFavorAttribute(){
		if(!Auth::check()){
			return false;
		}
		$userId = Auth::user()['UserId'];
		$favor = Favorite::where('obj_id',$this->id)->where('obj_type',101)->where('user_id',$userId)->where('status',0)->first();
		return $favor ? true : false;
	}
}
