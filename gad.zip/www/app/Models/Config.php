<?php

namespace App\Models;

use Auth;
use Gate;
use Illuminate\Database\Eloquent\Model;
use Log;
use Redis;

class Config extends Model
{
	public $table = 'Config';
    protected $primaryKey = 'ConfigId';

    const STATUS_DRAFT = 0;
    const STATUS_RELEASE = 1;

}
