<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Activity extends Model
{
    protected $fillable = ['title', 'banner', 'starttime', 'endtime', 'module', 'info', 'status','mobilebanner','bullet','partner','bg_color'];
    //判断用户是否为指定专题的专家
    public static function  isExpert($activityId, $userId)
    {
        $activity = self::find($activityId);
        if (!$activity) {
            return false;
        }
        $experts = \GuzzleHttp\json_decode($activity->info);
        if (!$experts) {
            return false;
        }
        $item = collect($experts)->where('userid',(string)$userId);
        return !$item->count() ? false : true;
    }

    public function getModuleNameAttribute ()
    {
        $title = [
            '0'=>'gad',
            '1'=>'游戏策划',
            '2'=>'游戏美术',
            '3'=>'游戏程序',
            '3595'=>'VR'
        ];
        if (array_key_exists($this->module,$title)) {
            return $title[$this->module];
        }

        return 'gad';
    }
}
