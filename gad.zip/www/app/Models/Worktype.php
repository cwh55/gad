<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class Worktype extends Model
{
    protected $fillable = ['clsss_id', 'type', 'user_id'];


    public function classify() {
    	return $this->hasOne('App\Models\Classify', 'class_id', 'class_id');
    }

    public function classifies() {
        return $this->hasMany('App\Models\Classify', 'class_id', 'class_id');
    }
}
