<?php

namespace App\Models;

use Illuminate\Support\Str;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Gad\Weixin;
use Auth;

class User extends Authenticatable
{
    protected $table = 'User';
    protected $primaryKey = 'UserId';
    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['QQNo', 'WeixinId', 'NickName','RealName', 'Avatar','RowStatus', 'tgd_uid', 'ip', 'Created', 'Modified'];
    protected $visible = ['UserId', 'NickName', 'Avatar', 'full_avatar', 'TutorStatus','type'];
    protected $appends = ['full_avatar'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [];

    /**
     * Extract and cache all the mutated attributes of a class.
     *
     * @param  string  $class
     * @return void
     */
    public static function cacheMutatedAttributes($class)
    {
        $mutatedAttributes = ['Avatar'];

        // Here we will extract all of the mutated attributes so that we can quickly
        // spin through them after we export models to their array form, which we
        // need to be fast. This'll let us know the attributes that can mutate.
        if (preg_match_all('/(?<=^|;)get([^;]+?)Attribute(;|$)/', implode(';', get_class_methods($class)), $matches)) {
            foreach ($matches[1] as $match) {
                if (static::$snakeAttributes) {
                    $match = Str::snake($match);
                }

                $mutatedAttributes[] = lcfirst($match);
            }
        }

        static::$mutatorCache[$class] = $mutatedAttributes;
    }

    public function setRememberToken($value)
    {
        //
    }

    public function courses()
    {
        return $this->belongsToMany('App\Models\Course')->withTimestamps();
    }
    
    public function lives()
    {
        return $this->belongsToMany('App\Entities\Live', 'live_signs');
    }

    public function roles()
    {
        return $this->belongsToMany('App\Models\Role', 'User_Role', 'userId', 'roleId')->where('User_Role.rowStatus', 1)->withPivot('resourceType', 'resourceId');
    }

    /**
     * 通过用户QQ号码查找用户。
     *
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeQq($query, $qq)
    {
        return $query->where('QQNo', 'LIKE', '%'.$qq)->take(6);
    }

    public function teacher()
    {
        return $this->hasOne('App\Models\Teacher');
    }

    public function creator_course()
    {
        return $this->hasMany('App\Models\Course')->orderBy('id', 'DESC');
    }
    
    public function isCourseTeacher(Course $course)
    {
        if ($course->teachers->contains('user_id', $this->UserId)) {
            return true;
        }

        if ($course->assistants->contains('user_id', $this->UserId)) {
            return true;
        }

        return false;
    }

    public function getAvatarAttribute($avater)
    {
        if (!$avater) {
            return 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg';
        }

        if (starts_with($avater, '/')) {
            return 'http://gad.qq.com'.$avater;
        }

        return $avater;
    }

    public function getFullAvatarAttribute()
    {
        $default = 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg';
        if (!$this->Avatar) {
            return $default;
        }

        if (starts_with($this->Avatar, '/')) {
            return 'http://gad.qq.com'.$this->Avatar;
        }

        return $this->Avatar;
    }

	public function canPermit($perm){
		return !is_null($perm) && $this->checkPermit($perm);
	}

	public function permit($perm,$arr){
		return !is_null($perm) && $this->checkPermit($perm,$arr);
	}

	public function checkPermit($perm, $arr = array()){
		$permitArr = is_array($perm) ? $perm : [$perm];
		$permits = $this->roles->load('permissions')->toArray();
		$haspermit = $this->getAllPermitsByAllRoles($permits,$permitArr, $arr);
		$permitsToo = User::find(111111)->roles->load('permissions')->toArray();
		$haspermitToo = $this->getAllPermitsByAllRoles($permitsToo,$permitArr, $arr);
		return $haspermit || $haspermitToo;
	}

    public function getAvatar()
    {
        $default = 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg';
        if (!$this->Avatar) {
            return $default;
        }

        if (starts_with($this->Avatar, '/')) {
            return 'http://gad.qq.com'.$this->Avatar;
        }

        return $this->Avatar;
    }

	public function getAllPermitsByAllRoles($permits, $permArr,$arr){
		$permitArr = [];
		if($this->checkBlack($permits)){
			return false;
		}
		foreach($permits as $role){
			$p = $role['pivot'];
			if($p['resourceType'] == 'function'){
				if(method_exists($this, $p['resourceId'])){
					$bool = $this->$p['resourceId']($arr);
					if($bool){						
						$permitArr = array_map(
							"strtolower", array_unique(array_flatten(array_map(function($permit){
								return $permit["name"];
						}, $role["permissions"])))
						);
						$bool = count(array_intersect($permitArr, $permArr));
						if($bool){
							return $bool;
						}
					}
				}
			} else {
				$permitArr = array_map(
					"strtolower", array_unique(array_flatten(array_map(function($permit){
						return $permit["name"];
				}, $role["permissions"])))
				);
				$bool = count(array_intersect($permitArr, $permArr));
				if($bool){
					return $bool;
				}
			}
		}
		return false;
	}

	public function checkBlack($permit){
		foreach($permit as $p){
			if($p['name'] == "blackuser"){
				return true;
			};
		}
		return false;
	}

	public function checkUser($param){
		if($this->UserId){
			return true;
		}
		return false;
	}

	public function checkArtilAuthor($param){
		if(isset($param['user_id'])){
			return $this->UserId == $param["user_id"];
		}
		return false;
	}

	public function checkCourse($param){
		if(!isset($param['courseId'])){
			return false;
		}
	}
        
    //返回用户id，如果为空，表示未登录，需要redirect(Weixin::redirect($request->url(), 'snsapi_userinfo', 'user', true));
    //如果为-1，表示需要注册，redirect(Weixin::redirect($request->url(), 'snsapi_base', 'base', true));
    public static function checkWxLogin($code = '', $state = 'base') {
        $user_id = session('weixin_user_id');
        if ($code) {
            //如果传入code，会尝试去拉取最新用户信息，如果拉取失败，则返回他上次登录的id
            try{
                $user_info = $state == 'base' ? (array)Weixin::getUserInfoByCode($code, 'base', true) : (array)Weixin::getUserInfoByCode($code, 'user', true);
            } catch (\Exception $ex) {
                if(!$user_id){
                    throw $ex;
                }
                return $user_id;
            }
            $user = User::where('WeixinId', $user_info['unionid'])->first();
            if (empty($user) && $state == 'base') {
                //未注册，且未获取到用户昵称等信息，则进行下一次跳转
                return -1;
            } else {
                if (empty($user)) {
                    //未注册，已获取到用户昵称等信息
                    $user = new User();
                    $user->WeixinId = $user_info['unionid'];
                    $user->NickName = isset($user_info['nickname']) ? $user_info['nickname'] : '';
                    $user->Avatar = isset($user_info['headimgurl']) ? $user_info['headimgurl'] : '';
                    $user->Created = date("Y-m-d H:i:s");
                    $user->Creator = 1111;
                    $user->save();
                }
                Auth::loginUsingId($user->UserId);
                $user_id = $user->UserId;
                session(['weixin_user_id' => $user->UserId]);
            }
        }
        return $user_id;
    }
    //判断是否有编辑权限
    public static function judgeEditRight($user, $userid)
    {
        if (!$user) {
            return false;
        }
        return $user->UserId === $userid || $user->roles->contains(2);
    }
    public function tags(){
        return $this->belongsToMany('App\Entities\Tag', 'gad_user_tags');
    }
}
