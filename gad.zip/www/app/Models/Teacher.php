<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{
    const TYPE_TEACHER = 0;
    const TYPE_ASSISTANT = 1;
    const TYPE_OTHER = 2;

    protected $table = 'teachers';
    protected $fillable = ['user_id', 'type', 'uin', 'name', 'position', 'desc', 'lvb_channel_id', 'lvb_source',
        'status', 'created_user'];
    protected $visible = ['id', 'user_id', 'name', 'position', 'desc', 'user'];

    public function courses()
    {
        return $this->belongsToMany('App\Models\Course')->orderBy('courses.id', 'DESC');
    }

    public function assistant_courses()
    {
        return $this->belongsToMany('App\Models\Course', 'course_assistant')->orderBy('courses.id', 'DESC');
    }

    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }

    public function scopeTeacher($query)
    {
        return $query->where('status', 0)->where('type', 0);
    }

    public function scopeAssistant($query)
    {
        return $query->where('status', 0)->where('type', 1);
    }

    public function scopeQq($query, $qq)
    {
        return $query->where('uin', 'LIKE', $qq.'%');
    }

    public function getLiveSource($type = 'all')
    {
        $source = ['url' => null, 'path' => null];
        if ($this->lvb_source == '') {
            return $type == 'all' ? $source : '';
        }

        $ret = pathinfo($this->lvb_source);
        $source['url'] = array_get($ret, 'dirname').'/';
        $source['path'] = array_get($ret, 'basename');
        if ($type == 'all') {
            return $source;
        }

        return array_get($source, $type);
    }
}
