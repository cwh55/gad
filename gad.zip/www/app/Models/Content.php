<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use App\Models\User;
use App\Gad\Html;

class Content extends Model
{
	public $table = 'Content';
    protected $primaryKey = 'ContentId';
    
    //拉取列表
    public static function getList()
    {
    	$list = DB::table('Content')->where('ShowType', 1)->skip(0)->take(5)->get();
    	return $list;
    }

	public function user(){
		return $this->belongsTo('App\Models\User','Creator','UserId');
	}

	public function author(){
		return $this->belongsTo('App\Models\User','Author','UserId');
	}

    //分页获取资源列表页面
    public static function getArticlesCountBy($groupId)
    {
        $articleCount = DB::table('ContentClass')
            ->join('Content','ContentClass.ContentId','=','Content.ContentId')
            ->where('ContentClass.RowStatus','=',0)
            ->where('Content.RowStatus','=',0)
            ->count();

        return $articleCount;

    }

    //根据object ID拉取主题内容
    public static function getContentById($object = 0) {
        $one = DB::table('ContentClass')
                ->join('Content', 'ContentClass.ContentId', '=', 'Content.ContentId')
                ->where('ContentClass.RowStatus','=',0)
                ->where('Content.RowStatus','=',0)
                ->where('ContentClass.Id', '=', $object)
                ->select(
                    'ContentClass.Id',
                    'ContentClass.ClassLV1',
                    'ContentClass.ClassLV2',
                    'Content.ContentId',
                    'Content.Tag',
                    'Content.ShowType'
                    )
                ->skip(0)
                ->take(1)
                ->get();

        return $one;
    }

    //根据object ids 拉取主题内容
    public static function getContentByIds($objectArr = '0', $page = 0, $pageSize = 9999) {
      $arr = explode(',', $objectArr);
      
      if(!empty($arr)) {
        $list = DB::table('ContentClass')
                ->join('Content', 'ContentClass.ContentId', '=', 'Content.ContentId')
                ->where('ContentClass.RowStatus','=',0)
                ->where('Content.RowStatus','=',0)
                ->whereIn('ContentClass.Id', $arr)
                ->select(
                    'ContentClass.Id',
                    'ContentClass.ClassLV1',
                    'ContentClass.ClassLV2',
                    'Content.ContentId',
                    'Content.Title',
                    'Content.HtmlDetail',
                    'Content.CoverImage',
                    'Content.ReadCount',
                    'Content.ReplyCount',
                    'Content.Created',
                    'Content.Summary'
                    )
                ->orderBy('Created', 'desc')
                ->skip($page*$pageSize)
                ->take($pageSize)
                ->get();
        //var_dump($list);
        //设置封面图片
        $ret = array_map(function($item){
            if (!$item->CoverImage){
                $item->CoverImage = Html::getFirstImage($item->HtmlDetail);

                if (!$item->CoverImage){
                    $item->CoverImage = 'http://gameweb-img.qq.com/gad/20151231/phpGT81Oa.1451534376.PNG';
                }
            }
            return $item;
        },$list);

        return $ret;
      }
      return [];
    }

    /*
     *
     */
    public static function getArticlesBy(Array $params)
    {

        $type = array_get($params,'showtype',1);
        $groupId = array_get($params,'groupid',1);
        $page = array_get($params,'page',0);
        $pageSize = array_get($params,'size',10);
        $order = array_get($params, 'order', 'new');
        $groupField = 'ClassLV1';
        //排序
        $orderCols=[
            'new'=>['Content.Created','DESC']
        ];

        $articles = DB::table('ContentClass')
            ->join('Content','ContentClass.ContentId','=','Content.ContentId')
            ->where('ContentClass.RowStatus','=',0)
            ->where('Content.RowStatus','=',0)
            ->where('Content.ShowType','=',$type)
            ->where('ContentClass.'.$groupField,'=',$groupId)
            ->select(
                'ContentClass.Id',
                'ContentClass.ClassLV1',
                'ContentClass.ClassLV2',
                'Content.ContentId',
                'Content.Title',
                'Content.HtmlDetail',
                'Content.CoverImage',
                'Content.ReadCount',
                'Content.ReplyCount',
                'Content.Created'
            )
            ->orderBy($orderCols[$order][0],$orderCols[$order][1])
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();

        //设置封面图片
        $ret = array_map(function($item){
            if (!$item->CoverImage){
                $item->CoverImage = Html::getFirstImage($item->HtmlDetail);

                if (!$item->CoverImage){
                    $item->CoverImage = 'http://gameweb-img.qq.com/gad/20151231/phpGT81Oa.1451534376.PNG';
                }
            }
            return $item;
        },$articles);

        return $ret;
    }

    /**
     * @param array $params
     * @return array 资讯列表
     */
    public static function getNewsBy(Array $params)
    {

        $type = 1;  //资讯属于文章
        $groupId = array_get($params,'groupid',1);
        $page = array_get($params,'page',0);
        $pageSize = array_get($params,'size',10);
        $order = array_get($params, 'order', 'new');
        $shortname = 'news';
        //排序
        $orderCols=[
            'new'=>['Content.Created','DESC']
        ];

        $configIds = DB::table('Config')
            ->select('ConfigId')
            ->where('ParentId','=',$groupId)
            ->where('ShortName','=',$shortname)
            ->where('RowStatus','=',0)
            ->get();
        $configIdsArray = array();
        if(!empty($configIds)){
            foreach($configIds as $configId){
                array_push($configIdsArray,$configId->ConfigId);
            }
        }
        $articles = DB::table('ContentClass')
            ->join('Content','ContentClass.ContentId','=','Content.ContentId')
            ->where('ContentClass.RowStatus','=',0)
            ->where('Content.ShowType','=',$type)
            ->where(function($query) use($configIdsArray){
                $query->orWhereIn('ContentClass.ClassLV2', $configIdsArray)
                    ->orWhereIn('ContentClass.ClassLV3', $configIdsArray);
            })
            ->select(
                'ContentClass.Id',
                'ContentClass.ClassLV1',
                'ContentClass.ClassLV2',
                'Content.ContentId',
                'Content.Title',
                'Content.HtmlDetail',
                'Content.CoverImage',
                'Content.ReadCount',
                'Content.ReplyCount',
                'Content.Created'
            )
            ->orderBy($orderCols[$order][0],$orderCols[$order][1])
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();

        //设置封面图片
        $ret = array_map(function($item){
            if (!$item->CoverImage){
                $item->CoverImage = Html::getFirstImage($item->HtmlDetail);

                if (!$item->CoverImage){
                    $item->CoverImage = 'http://gameweb-img.qq.com/gad/20151231/phpGT81Oa.1451534376.PNG';
                }
            }
            return $item;
        },$articles);

        return $ret;
    }
    //查询问答列表 for weixin
    //order : new|reply
   	public static function getWenList($params = array())
    {
   		$groupid = array_get($params, 'groupid', 1);
   		$page = array_get($params, 'page', 0); 
   		$size = array_get($params, 'size', 6);
   		$order = array_get($params, 'order', 'new');
		$ids = array_get($params, 'ids', []);

   		$order = ($order == 'new') ? 'c.Created' : 'c.LastReplyDate';
		if($ids){
			$list = DB::table(DB::raw('Content c'))
				->leftJoin(DB::raw('ContentClass cc'), 'c.ContentId', '=', 'cc.ContentId')
				//->leftJoin(DB::raw('Config cf'), DB::raw("GREATEST(cc.ClassLV1,cc.ClassLV2,cc.ClassLV3)"), '=', 'cf.ConfigId')
				->select(DB::raw('c.Title, cc.Id, c.ReplyCount, cc.ClassLV1, cc.ClassLV2, c.Summary'))
				->where('c.ShowType', '=', 2)
				->where('c.RowStatus', '=', 0)
				->where('cc.RowStatus', '=', 0)
				->where(function($query) use($groupid){
				  $query->orWhere('cc.ClassLV1', '=', $groupid)
					  ->orWhere('cc.ClassLV2', '=', $groupid);
				})
				->whereIn('cc.Id',$ids)
				->orderBy($order, 'desc')
				->skip($page*$size)
				->take($size)
				->get();
		} else {
			$list = DB::table(DB::raw('Content c'))
				->leftJoin(DB::raw('ContentClass cc'), 'c.ContentId', '=', 'cc.ContentId')
				//->leftJoin(DB::raw('Config cf'), DB::raw("GREATEST(cc.ClassLV1,cc.ClassLV2,cc.ClassLV3)"), '=', 'cf.ConfigId')
				->select(DB::raw('c.Title, cc.Id, c.ReplyCount, cc.ClassLV1, cc.ClassLV2, c.Summary, c.Author'))
				->where('c.ShowType', '=', 2)
				->where('c.RowStatus', '=', 0)
				->where('cc.RowStatus', '=', 0)
				->where('c.ReplyCount', '>', 0)
				->where(function($query) use($groupid){
				  $query->orWhere('cc.ClassLV1', '=', $groupid)
					  ->orWhere('cc.ClassLV2', '=', $groupid);
				})
				->orderBy($order, 'desc')
				->skip($page*$size)
				->take($size)
				->get();
		}

   		if (!empty($list)) {
   			foreach ($list as $k => &$v) {
   				if ($v->ReplyCount>0) {
   					$_reply = Content::getReply(['object' => $v->Id, 'size'=>1]);
   					$v->reply = !empty($_reply[0]) ? $_reply[0] : [];
   				} else {	
   					$v->reply = [];
   				}
   			}
   		}

   		return $list;
   	}

   	//拉取问题的回复列表
   	public static function getReply($params = array())
    {
   		if(empty($params['object'])) {
   			return array();
   		}

   		$page = !empty($params['page']) ? $params['page'] : 0; 
   		$size = !empty($params['size']) ? $params['size'] : 6;
   		$order =!empty($params['order']) ? $params['order'] : 'hot';

   		$order = ($order == 'hot') ? 'r.UpCount' : 'r.Created';

   		$list = DB::table(DB::raw('Reply r'))
   				->leftJoin(DB::raw('User u'), 'u.UserId', '=', 'r.Creator')
   				->select(DB::raw('r.HtmlDetail, u.NickName, u.Avatar, r.UpCount, r.Created, r.Creator'))
   				->where('r.ReplyObject', '=', $params['object'])
   				->where('r.RowStatus', '=', 0)
   				->orderBy($order, 'desc')
   				->skip($page*$size)
   				->take($size)
   				->get();
      $ret = array_map(function($item) {
        if (!empty($item->HtmlDetail)) {
          $item->HtmlDetail = strip_tags($item->HtmlDetail);
        }
        if (isset($item->Avatar)) {
          $item->Avatar = Html::getAvatar($item->Avatar);
        }

        return $item;
      }, $list);
   		return $ret;
   	}

    /**
     * 获取美术作品
     * @param array $params
     */
    public static function  getArtList($params = array())
    {

        $type = array_get($params,'showtype',1);
        $groupId = array_get($params,'groupid',1);
        $page = array_get($params,'page',0);
        $pageSize = array_get($params,'size',10);
        $order = array_get($params, 'order', 'new');
        //排序
        $orderCols=[
            'new'=>['Content.Created','DESC']
        ];

        $arts = DB::table('ContentClass')
            ->join('Content','ContentClass.ContentId','=','Content.ContentId')
            ->where('Content.RowStatus','=',0)
            ->where('ContentClass.RowStatus','=',0)
            ->where('Content.ShowType','=',$type)
            ->where('ContentClass.ClassLV1','=',$groupId)
            ->select(
                'ContentClass.Id',
                'ContentClass.ClassLV1',
                'ContentClass.ClassLV2',
                'Content.ContentId',
                'Content.Title',
                'Content.CoverImage',
                'Content.ReadCount',
                'Content.ReplyCount',
                'Content.UpCount',
                'Content.Creator',
                'Content.Created'
            )
            ->orderBy($orderCols[$order][0],$orderCols[$order][1])
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();

        //获取用户基本信息
        $userIds = array_map(function($art) {
            return $art->Creator;
        },$arts);
        $users = DB::table('User')
            ->whereIn('UserId',$userIds)
            ->select(
                'UserId',
                'NickName',
                'RealName',
                'Avatar'
            )
            ->get();
        //以userId 为key
        $userMap = array();
        foreach ($users as $user) {
            $userMap[$user->UserId] = $user;
        }
        //拼接数据
        $ret = array();
        foreach ($arts as $art ) {
            $userMap[$art->Creator] -> Avatar = Html::getAvatar($userMap[$art->Creator] -> Avatar );
            $ret[] = array_merge(
                (array) $art,
                (array) $userMap[$art->Creator]
            );
        }

        return $ret;


    }

    /**
     *获取评论列表
     * @param $contentClassId
     * @param array $params
     */
    public static function getComment($params = array())
    {
        $replyObjectId = array_get($params,'replyobject');
        $type = array_get($params,'replytype',1);
        $page = array_get($params,'page',0);
        $pageSize = array_get($params,'size',10);
        $order = array_get($params, 'order', 'new');
        //排序
        $orderCols=[
            'new'=>['Reply.Created','DESC']
        ];

        $comment = DB::table('Reply')
            ->join('User','User.UserId','=','Reply.Creator')
            ->where('Reply.RowStatus','=',0)
            ->where('Reply.ReplyType','=',$type)
            ->where('Reply.ReplyObject','=',$replyObjectId)
            ->select(
                'Reply.ReplyId',
                'Reply.HtmlDetail',
                'Reply.UpCount',
                'Reply.Creator',
                'Reply.Created',
                'User.NickName',
                'User.Avatar'
            )
            ->orderBy($orderCols[$order][0],$orderCols[$order][1])
            ->skip($page * $pageSize)
            ->take($pageSize)
            ->get();

        $ret = array_map(function($item){
            $item->Avatar = Html::getAvatar($item->Avatar);
            $item->Reply = self::getReply(['object'=>$item->ReplyId,'page'=>0,'size'=>10,'order'=>'new']);
            return $item;
        },$comment);

        return $ret;
    }

    /**
     * 根据contentClassId 获取详情
     * @param $contentClassId
     */
    public static function getDetail($contentClassId, $status = 0)
    {

        $contentClass = DB::table('ContentClass')
            ->where('Id','=',$contentClassId)
            ->where('RowStatus','=',$status)
            ->select(
                'Id',
                'ContentId',
                'RowStatus',
                'ClassLV1'
            )
            ->first();

        if ($contentClass) {
            //查询详情
            $content = DB::table('Content')
                ->where('ContentId','=',$contentClass->ContentId)
                ->select(
                    'ContentId',
                    'Title',
                    'HtmlDetail',
                    'ReadCount',
                    'ReplyCount',
                    'ShowType',
                    'Creator'
                )
                ->first();

            if ($content) {
                //美术作品加载图片
                if(in_array($content->ShowType,array(7,8))){
                    $contentModules = DB::table('ContentModule')
                        ->where('ContentId','=',$content->ContentId)
                        ->where('RowStatus','=',0)
                        ->select(
                            'Title',
                            'Attachment',
                            'DetailDesc',
                            'ModuleType'
                        )
                        ->orderBy('Index','ASC')
                        ->get();
                    $content -> Images =$contentModules;

                }
                //查询用户基本信息
                $author = DB::table('User')
                    ->where('UserId','=',$content->Creator)
                    ->select(
                        'RealName',
                        'UserId',
                        'NickName',
                        'Avatar'
                    )
                    ->first();

                //组装数据
                $ret = array_merge(
                    (array)$contentClass,
                    (array)$content,
                    (array)$author
                );
                return $ret;
            }
        }
        return null;
    }

    /**
     * 将content 浏览数+1
     * @param $contentId
     * @param int $addCount
     */
    public static function addContentReadCount($contentId)
    {
        return DB::table('Content')
            ->increment('ReadCount',1,['ContentId'=>$contentId]);
    }

    /**
     * 将ContentClass 浏览数加1
     * @param $contentClassId
     * @return mixed
     */
    public static function addContentClassReadCount($contentClassId)
    {
        return DB::table('ContentClass')
            ->increment('ReadCount',1,['Id'=>$contentClassId]);
    }

    /**
     * 获取相关内容
     * @param array $params
     */
    public static function getRelatedContents(array $params = array())
    {
        $classId = array_get($params,'classid',0);
        $tags = array_get($params,'tags', '');
        $ruleOutId = array_get($params,'ruleoutid', 0);
        $showType = array_get($params,'showtype',1);
        $showCount = array_get($params,'showcount',3);

        //查询全站标签相同的内容
        $ret = self::getHotContents($showType,0,$showCount,9*7,$ruleOutId,$tags);
        if (count($ret) < $showCount) {
            if ($ret) {
                foreach($ret as $item){
                    if($ruleOutId == null || $ruleOutId == 0){
                        $ruleOutId = $item->Id;
                    }
                    else {
                        $ruleOutId .= ','+$item->Id;
                    }
                }
            }
            $groupRet = self::getHotContents($showType,$classId,$showCount -count($ret),0,$ruleOutId,$tags);
            return array_merge($ret,$groupRet);
        }

        return $ret;


    }

    /**
     *获取热点文章
     * @param int $showType
     * @param int $classId
     * @param int $showCount
     * @param int $day
     * @param int $ruleOutId
     * @param null $tags
     */
    public static function getHotContents($showType = 1,$classId =0,$showCount =3,$day =7 ,$ruleOutId =0 ,$tags = null)
    {
        $query = DB::table('Content')
            ->join('ContentClass','Content.ContentId','=','ContentClass.ContentId')
            ->join('User','Content.Creator','=','User.UserId')
            ->where('Content.RowStatus','=',0)
            ->where('ContentClass.RowStatus','=',0)
            ->where('Content.ShowType','=',$showType);

        if ($day != 0) {
            $preDay = date('Y-m-d',strtotime('-'.$day.' day'));
            $query->where('Content.Created','>=',$preDay);
        }

        if($classId != 0){
            $query ->Where(function($query) use($classId){
                $query->orWhere('ContentClass.ClassLV1','=',$classId)
                    ->orWhere('ContentClass.ClassLV2','=',$classId)
                    ->orWhere('ContentClass.ClassLV3','=',$classId);
            });
        }

        if($tags != null && $tags != ""){
            $tags = explode(',',$tags);
            $query ->where(function($query) use($tags){
                foreach ($tags as $tag) {
                    $query ->orWhere('Content.Tag','=',$tag);
                }
            });
        }

        if (strpos($ruleOutId,",") !== false) {
           $ruleOutIds = explode(',',$ruleOutId);
           $query ->where('ContentClass.Id','not in',$ruleOutIds);
        }
        else {
            $query->where('ContentClass.Id','!=',$ruleOutId);
        }

        $query->select(
            'ContentClass.Id',
            'ContentClass.ContentId',
            'Content.Title',
            'ContentClass.ClassLV1',
            'ContentClass.ClassLV2',
            'Content.ReplyCount',
            'Content.ReadCount',
            'Content.Creator',
            'User.NickName',
            'User.RealName'
        )
              -> orderBy('Content.Created','DESC')
              -> take($showCount);

        return $query->get();



    }

    //获取最新线上专题
    public static function getNewSubject()
    {
        return DB::table('Subject')
            ->where('RowStatus',0)
            ->orderBy('Created','DESC')
            ->first();
    }

	public static function getContentByClassType($classType, $categoryid, $showType, $page = 0, $pagesize = 10)
	{		
        $end = date('Y-m-d', strtotime('+1 day'));
        $start = date('Y-m-d', strtotime('-4 week'));

        $offset = ($page)*$pagesize;
        if(strpos($showType, ',') != false) {
            $showType = explode(',', $showType);
        } else {
            $showType = array($showType);
        }
        $list = DB::table(DB::raw('Content C'))
                ->join(DB::raw('ContentClass CC'),'C.ContentId', '=', 'CC.ContentId')
                ->join(DB::raw('Config Cf'),'Cf.ConfigId', '=', 'CC.ClassLv'.$classType)
				->select(DB::raw('CC.Id, C.ShowType, C.ContentId, C.Title, Cf.ConfigId, Cf.ConfigName, Cf.Logo, max(C.ReadCount+C.UpCount+C.ReplyCount+C.FocusCount) total'))
                ->where('C.RowStatus', '=', 0)
                ->where('CC.RowStatus', '=', 0)
                ->whereIn('C.ShowType', $showType)
                ->whereIn('CC.ClassLv'.$classType, $categoryid)
                ->where('C.Created', '>=', $start)
                ->where('C.Created', '<=', $end)
                ->groupBy('CC.ClassLv'.$classType)
                ->orderBy('total', 'desc')
                ->skip($offset)
                ->take($pagesize)
                ->get();

		return $list;
	}

	public static function getTran($istran,$groupId,$order='new',$limit=10,$ids=[])
	{
		$select = DB::raw('c.Creator,c.Title, c.ReadCount, c.ReplyCount, c.UpCount, c.Tag, c.Summary, cc.Id ccId, u.UserId, u.Avatar,u.Experience, u.NickName,ct.*');
        $myData = DB::table(DB::raw('ContentClass cc'))
                ->join(DB::raw('tbContentTranslate ct'), 'cc.ContentId', '=', 'ct.iContentId')
                ->join(DB::raw('Content c'), 'c.Contentid', '=', 'ct.iContentid')
                ->join(DB::raw('User u'), 'u.UserId', '=', 'c.Creator')
			    ->select($select)
                ->where('c.RowStatus', '=', 0)
                ->where('cc.RowStatus', '=', 0)
                ->where('c.ShowType', '=', 12);

		if($ids){
			$myData = $myData->whereIn('cc.Id',$ids);
		}

        if($istran == 0) {
            $myData->where('ct.vCnTitle', '=', '');
        } else if ($istran == 1) {
             $myData->where('ct.vCnTitle', '<>', '');
        }
        if($groupId>0) {
                $myData->where(function($query) use($groupId){
                //查当前圈子及子圈子的内容
                $query->orWhere("cc.ClassLV1","=",$groupId);
                $query->orWhere("cc.ClassLV2","=",$groupId);
                $query->orWhere("cc.ClassLV3","=",$groupId);
				});
        }
        if($order == 'new') {
            switch ($istran) {
                case 0:
                    $myData->orderBy('ct.dtCreated', 'desc');
                    break;
                case 1:
                    $myData->orderBy('ct.dtTranslateCreated', 'desc');
                    break;
                default:
                    $myData->orderBy(DB::raw('CASE WHEN ct.dtTranslateCreated is not NULL THEN ct.dtTranslateCreated ELSE  ct.dtCreated  END '),'desc');

            }
        } else if($order == 'hot') {
            $myData->orderBy('c.UpCount', 'desc');
        }
        //if($getCount) {
            //$list = $myData->execute()->count();
        //} else {
        $list = $myData->take($limit)->get();
        //}

        return $list;
	} 

	public static function getNews($groupIds,$limit = 10,$showType = 1,$outIds=[],$inIds=[])
    {
        $order = 'c.ContentId';
        if ($inIds) {
            $list = DB::table(DB::raw('Content c'))
                ->join(DB::raw('ContentClass cc'), 'c.ContentId', '=', 'cc.ContentId')
                ->leftJoin(DB::raw('User u'), 'u.UserId', '=', 'c.Author')
                ->select(DB::raw('cc.Id, c.Title, c.Summary, c.Creator, c.ReplyCount, c.ReadCount, c.CoverImage, c.Author, c.Created, u.NickName, c.HtmlDetail,c.IsTransfer'))
                ->where('c.ShowType', '=', $showType)
                ->where('cc.RowStatus', '=', 0)
                ->where(function ($query) use ($groupIds) {
                    $query->orWhereIn('cc.ClassLV1', $groupIds)
                        ->orWhereIn('cc.ClassLV2', $groupIds)
                        ->orWhereIn('cc.ClassLV3', $groupIds);
                })
                ->whereIn('cc.Id', $inIds)
                ->whereNotIn('cc.Id', $outIds)
                ->orderBy($order, 'desc')
                ->take($limit)
                ->get();
        } else {
            $list = DB::table(DB::raw('Content c'))
                ->join(DB::raw('ContentClass cc'), 'c.ContentId', '=', 'cc.ContentId')
                ->leftJoin(DB::raw('User u'), 'u.UserId', '=', 'c.Author')
                ->select(DB::raw('cc.Id, c.Title, c.Summary, c.Creator, c.ReplyCount, c.ReadCount, c.CoverImage, c.Author, c.Created, u.NickName, c.HtmlDetail,c.IsTransfer'))
                ->where('c.ShowType', '=', $showType)
                ->where('cc.RowStatus', '=', 0)
                ->where(function ($query) use ($groupIds) {
                    $query->orWhereIn('cc.ClassLV1', $groupIds)
                        ->orWhereIn('cc.ClassLV2', $groupIds)
                        ->orWhereIn('cc.ClassLV3', $groupIds);
                })
                ->whereNotIn('cc.Id', $outIds)
                ->orderBy($order, 'desc')
                ->take($limit)
                ->get();
        }

        return $list;
    }

    public static function getRelatedListByType($archive, $type = 1)
    {
        if (!in_array($type, array(1, 2, 3, 3595))) {
            return false;
        }
        if ($type == 3595) {
            $type = 4;
        }
        $list = $archive->where('channel_id', '=', $type)->where('class_id',1)->orderBy('id', 'desc')->simplePaginate(4, ['id', 'title']);
        return $list;
    }

    /*
     * 查询最新的文章列表(新版问答活动相关推荐)
     * @params $type 文章分类(1策划,2美术,3开发,3595VR)
     * @params $size 大小
     * order(时间倒序)
     */
    public static function getNewsListByType($type=1, $size=4,$showType = 1,$inIds = [],$outIds=[])
    {
      if(!in_array($type, array(1, 2, 3, 3595))) {
        return false;
      }

      $list = array();
      $order = 'c.ContentId';
	  if($inIds){
		  $list = DB::table(DB::raw('Content c'))
			  ->join(DB::raw('ContentClass cc'), 'c.ContentId', '=', 'cc.ContentId')
			  ->select(DB::raw('cc.Id, c.Title, c.Summary, c.Creator, c.ReplyCount, c.ReadCount, c.CoverImage, c.Author, c.Created,c.IsTransfer'))
			  ->where('c.ShowType', '=',  $showType)
			  ->where('cc.RowStatus', '=', 0)
			  ->where(function($query) use($type){
				  $query->orWhere('cc.ClassLV1', '=', $type)
					  ->orWhere('cc.ClassLV2', '=', $type);
			  })
			  ->whereIn('cc.Id',$inIds)
			  ->whereNotIn('cc.Id',$outIds)
			  ->take($size)
			  ->get();
	  } else {
		  $list = DB::table(DB::raw('Content c'))
			  ->join(DB::raw('ContentClass cc'), 'c.ContentId', '=', 'cc.ContentId')
			  ->select(DB::raw('cc.Id, c.Title, c.Summary, c.Creator, c.ReplyCount, c.ReadCount, c.CoverImage, c.Author, c.Created, c.HtmlDetail,c.IsTransfer'))
			  ->where('c.ShowType', '=',  $showType)
			  ->where('cc.RowStatus', '=', 0)
			  ->where(function($query) use($type){
				  $query->orWhere('cc.ClassLV1', '=', $type)
					  ->orWhere('cc.ClassLV2', '=', $type);
			  })
			  ->whereNotIn('cc.Id',$outIds)
			  ->orderBy($order, 'desc')
			  ->take($size)
			  ->get();
	  }

      return $list;
    }

    //获取嘉年华用户包
    public static function getJnhUserIds()
    {
        //获取2016年4-01以来创建和修改过content 表的用户
        $contentUserIds = DB::table('Content')
            ->where('Content.RowStatus','=',0)
            ->where(function($query) {
                $query->where('Content.Created','>=','2016-04-01')
                    ->orWhere('Content.Modified','>=','2016-04-01');
            })
            ->where(function($query) {
                $query->where('Content.Created','<','2016-10-01')
                    ->orWhere('Content.Modified','<','2016-10-01');
            })
            ->select(DB::raw('Distinct(Content.Author)'))
            ->get();
        foreach ($contentUserIds as $item) {
            $userIds[] = $item->Author;
        }
        //获取2016-04-01以来创建和修改过reply的用户
        $replyUserIds = DB::table('Reply')
            ->where('Reply.RowStatus','=',0)
            ->where(function($query) {
                $query->where('Reply.Created','>','2016-04-01')
                    ->orWhere('Reply.Modified','>','2016-04-01');
            })
            ->where(function($query) {
                $query->where('Reply.Created','<','2016-10-01')
                    ->orWhere('Reply.Modified','<','2016-10-01');
            })
            ->select(DB::raw('Distinct(Reply.Creator)'))
            ->get();
        foreach($replyUserIds as $item) {
            $userIds[] = $item->Creator;
        }

        $userIds = array_unique($userIds);

        return $userIds;
    }

    //获取嘉年华用户QQ号
    public static function getJnhUserQQs($userIds)
    {
        $userQQs = User::whereIn('UserId',$userIds)
            ->where('QQNo','>',0)
            ->select('QQNo')
            ->get();

        return array_column($userQQs->toArray(),'QQNo');
    }
    //获取最新的翻译馆文章
    public static function getNewestTranslate($num){
        $list = DB::table('ContentClass')
            ->join('Content', 'ContentClass.ContentId', '=', 'Content.ContentId')
            ->join('tbContentTranslate', 'tbContentTranslate.iContentId', '=', 'Content.ContentId')
            ->where('ContentClass.RowStatus','=',0)
            ->where('Content.RowStatus','=',0)
            ->where('Content.ShowType','=',12)
            ->where('tbContentTranslate.vCnTitle', '!=', '')
            ->select(
                'ContentClass.Id',
                'Content.CoverImage',
                'tbContentTranslate.vCnTitle',
                'tbContentTranslate.vHtmlDetail'
            )
            ->orderBy('tbContentTranslate.dtCreated', 'desc')
            ->take($num)
            ->get();
        return $list;
    }

}
