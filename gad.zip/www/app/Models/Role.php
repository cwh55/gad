<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Role extends Model
{
    use SoftDeletes;

    protected $table = 'Role';

	public $fillable = ['userId', 'roleId', 'RowStatus', 'Created', 'Creator', 'Modified', 'Modifier'];

	public function users(){
		return $this->belongsToMany('App\Models\User', 'User_Role', 'roleId', 'userId');
	}

	public function permissions(){
		return $this->belongsToMany('App\Models\Rule', 'Role_Rule', 'roleId', 'ruleId');
	}
}
