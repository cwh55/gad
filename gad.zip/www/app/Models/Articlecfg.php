<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Articlecfg extends Model
{
   	
    //根据频道拉取配置
    public function scopeChannel($query, $channel) {
    	$ret = $query->where('channel_id', '=', $channel);
    	return $ret;
    }
}
