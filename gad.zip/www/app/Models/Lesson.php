<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Lesson extends Model
{
    use SoftDeletes;

    protected $fillable = ['course_id', 'vod', 'title', 'summary', 'notice', 'attachment', 'info', 'begin_date',
        'begin_time', 'end_time', 'total_time', 'creator'];
    protected $casts = [
        'attachment' => 'array'
    ];
    protected $visible = ['id', 'course_id', 'task_id', 'lvb_channel_id', 'lvb_source_id', 'type', 'vod', 'title',
        'begin_date', 'begin_time', 'end_time', 'total_time', 'total_online', 'peak_online', 'summary', 'notice',
        'info', 'attachment', 'state', 'created_at', 'updated_at', 'videos'];
    protected $dates = ['deleted_at'];

    public static function boot()
    {
        parent::boot();

        // 分享保存时更新分享系信息
        static::saved(function ($lesson) {
            $course = $lesson->course;
            $course->total_time = $course->lessons->sum('total_time');
            $course->total_count = $course->lessons->count();
            if ($course->next_lesson == '') {
                $course->next_lesson = $lesson->id;
            }
            $course->save();
        });

        static::deleted(function ($lesson) {
            $course = $lesson->course;
            $course->total_time = $course->lessons->sum('total_time');
            $course->total_count = $course->lessons->count();
            $course->save();
        });
    }

    public function course()
    {
        return $this->belongsTo('App\Models\Course');
    }

    public function videos()
    {
        return $this->hasMany('App\Models\LessonVod')->orderBy('lesson_vod.sort');
    }

    public function convertTasks()
    {
        return $this->hasMany('App\Models\LessonVodTask');
    }

    public function checkConvertTask()
    {
        if ($this->convertTasks()->where('status', 'IN', [0, -1])->count() == 0) {
            $this->vod = 2; // 分享转码任务已完成
            $this->save();
        }
    }

    public function getStartTimeOffset($unit = null)
    {
        static $diff;

        $key = ['y', 'm', 'd', 'h', 'i', 's'];
        if (!$this->exists) {
            return $unit ? 0 : array_fill_keys($key, 0);
        }

        if (!$diff) {
            $diff = (array) (new Carbon($this->begin_date.' '.$this->begin_time))->diff(Carbon::now());
            $diff = array_only($diff, $key);
        }

        return $unit ? array_get($diff, $unit) : $diff;
    }

    public function getLiveSource($type='all')
    {
        if(!empty($this->lvb_source_id)) {
            list($bizId, $_) = explode('_', $this->lvb_source_id);
            $arr = [
                'source_url' => 'rtmp://' . $bizId . '.livepush.myqcloud.com/live/',
                'source_path' => $this->lvb_source_id . '?bizid=' . $bizId
            ];

            if ($type == 'all') {
                return $arr;
            } else {
                if (isset($arr[$type])) {
                    return $arr[$type];
                }
            }
        }

        return '';
    }
}
