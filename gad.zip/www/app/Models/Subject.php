<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Subject extends Model
{
    public $table = 'Subject';

    public static function get404Subject(){
        return DB::table('Subject')
            ->where('RowStatus','=',0)
            ->orderBy('Created', 'desc')
            ->take(4)
            ->get(['SubjectId','Title','Logo']);
    }

}
