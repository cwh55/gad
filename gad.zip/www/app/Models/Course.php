<?php

namespace App\Models;

use Auth;
use Gate;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Log;
use Redis;

class Course extends Model
{
    use SoftDeletes;

    const STATUS_DRAFT = 0;
    const STATUS_RELEASE = 1;

    protected $visible = ['id', 'title', 'type_id' , 'first_type_id', 'target', 'thumbnail', 'cost', 'record',
        'summary', 'desc', 'user_id', 'total_time', 'total_count', 'next_lesson', 'cs_uin', 'cs_name',
        'qq_qun', 'qq_qun_name', 'qq_qun_key', 'created_at', 'updated_at', 'state', 'status', 'study_count',
        'is_registered', 'is_collected', 'is_lundao', 'type', 'first_type', 'teacher', 'assistant','teachers', 'assistants',
        'lessons', 'lesson'];
    protected $fillable = ['title', 'type_id' , 'first_type_id', 'target', 'thumbnail', 'cost', 'record',
        'summary', 'desc', 'user_id', 'cs_uin', 'cs_name', 'qq_qun', 'qq_qun_name', 'qq_qun_key','is_lundao'];
    protected $dates = ['deleted_at'];
    protected $appends = ['is_registered', 'is_collected'];

    public function type()
    {
        return $this->belongsTo('App\Models\Type');
    }

    public function lesson()
    {
        return $this->belongsTo('App\Models\Lesson', 'next_lesson');
    }

    public function user()
    {
        return $this->belongsTo('App\Models\User');
    }

    public function lessons()
    {
        return $this->hasMany('App\Models\Lesson');
    }

    public function teachers()
    {
        return $this->belongsToMany('App\Models\Teacher')->withTimestamps();
    }

    public function assistants()
    {
        return $this->belongsToMany('App\Models\Teacher', 'course_assistant')->withTimestamps();
    }

    public function students()
    {
        return $this->belongsToMany('App\Models\User')->withPivot('attend_at')->withTimestamps();
    }

    public function collects()
    {
        return $this->belongsToMany('App\Models\User', 'course_collect')->withTimestamps();
    }

    public function accesses()
    {
        return $this->hasMany('App\Models\CourseAccess');
    }

    public function attend($user)
    {
        if ($this->hasStudent($user)) {
            $this->students()->updateExistingPivot($user->UserId, ['attend_at' => date('Y-m-d H:i:s')]);
        }
    }

    public function access($user, $lesson)
    {
        $access = new CourseAccess();
        $access->course_id = $this->id;
        $access->lesson_id = $lesson->id;
        $access->user_id = $user->UserId;
        $access->type = $lesson->type;
        $access->save();
    }

    public function getIsRegisteredAttribute()
    {
        static $isResgistered = null;

        if (!Auth::check()) {
            return false;
        }

        if ($isResgistered === null) {
            $isResgistered = Gate::allows('learn', $this);
        }

        return $isResgistered;
    }

    public function getIsCollectedAttribute()
    {
        static $isCollected = null;

        if (!Auth::check()) {
            return false;
        }

        if ($isCollected === null) {
            $isCollected = $this->hasCollect(Auth::user());
        }

        return $isCollected;
    }

    public function getTypeAttribute()
    {
        $types = $this->getTypes();
        $first = array_get($types, $this->first_type_id);
        if ($first) {
            $sub = array_first($first['subs'], function ($key, $value) {
                return $value['id'] == $this->type_id;
            });

            return $sub['name'];
        }

        return '';
    }

    public function getFirstTypeAttribute()
    {
        $types = $this->getTypes();
        $first = array_get($types, $this->first_type_id);
        return $first['name'];
    }

    public function getTeacherAttribute()
    {
        $result = [];
        foreach ($this->teachers as $teacher) {
            $result[] = ['id' => $teacher->id, 'name' => $teacher->name];
        }

        return $result;
    }

    public function getAssistantAttribute()
    {
        $result = [];
        foreach ($this->assistants as $assistant) {
            $result[] = ['id' => $assistant->id, 'name' => $assistant->name];
        }

        return $result;
    }

    public function hasStudent($user)
    {
        return $this->students()->where('course_user.user_id', $user->UserId)->exists();
    }

    public function hasCollect($user)
    {
        return $this->collects()->where('course_collect.user_id', $user->UserId)->exists();
    }

    public function registerStudent($user)
    {
        if (!$this->hasStudent($user)) {
            $this->students()->attach($user->UserId, ['attend_at' => date('Y-m-d H:i:s')]);
            $this->study_count = $this->study_count + 1;
            $this->save();
        }

        return $this;
    }

    public function collect($action)
    {
        $user = Auth::user();
        if ($action == 'add') {
            if (!$this->is_collected) {
                $this->collects()->attach($user->UserId);
            }
        }

        if ($action == 'cancel') {
            if ($this->is_collected) {
                $this->collects()->detach($user->UserId);
            }
        }

        return $this;
    }

    public function getLiveSource()
    {
        list($bizId, $_) = explode('_', $this->lvb_source_id);

        return [
            'source_url' => 'rtmp://'.$bizId.'.livepush.myqcloud.com/live/',
            'source_path' => $this->lvb_source_id.'?bizid='.$bizId
        ];
    }

    public function getLatestStudents($count = 8)
    {
        return $this->students()->take($count)->orderBy('course_user.id', 'DESC')->get(['UserId', 'NickName', 'Avatar']);
    }

    public function getRelates()
    {
        return $this->where('id', '<>', $this->id)->where('first_type_id', '<>', 0)->where('status', 1)->orderBy('id', 'DESC')->take(3)->get();
    }

    public function getStatus()
    {
        return array_get(['草稿', '已发布'], $this->status);
    }

    public function refunds()
    {
        return $this->hasMany('App\Models\Refund');
    }

    public function getRefundInfo()
    {
        return $this->refunds->where('user_id', Auth::user()->UserId)->first();
    }

    public function getTypes()
    {
        $types = [
            ['id' => 0, 'name' => '未分类', 'url' => '', 'subs' => [
                ['id' => 0, 'name' => '未分类'],
            ]],
            ['id' => 1, 'name' => '游戏策划', 'url' => 'plan', 'subs' => [
                ['id' => 15, 'name' => '新手'],
                ['id' => 10, 'name' => '玩法'],
                ['id' => 104, 'name' => '数值'],
                ['id' => 106, 'name' => '系统'],
                ['id' => 105, 'name' => '关卡'],
                ['id' => 103, 'name' => '运营'],
                ['id' => 102, 'name' => '剧情']
            ]],
            ['id' => 2, 'name' => '游戏美术', 'url' => 'art', 'subs' => [
                ['id' => 28, 'name' => '新手'],
                ['id' => 108, 'name' => '原画'],
                ['id' => 109, 'name' => '3D美术'],
                ['id' => 110, 'name' => '游戏UI'],
                ['id' => 111, 'name' => '动画'],
                ['id' => 112, 'name' => '特效']
            ]],
            ['id' => 3, 'name' => '游戏开发', 'url' => 'program', 'subs' => [
                ['id' => 100, 'name' => '新手'],
                ['id' => 96, 'name' => 'Unity3D'],
                ['id' => 1933, 'name' => 'Cocos2d'],
                ['id' => 1955, 'name' => 'HTML5'],
                ['id' => 1956, 'name' => '虚幻引擎'],
                ['id' => 1939, 'name' => '游戏安全'],
                ['id' => 94, 'name' => '服务器技术'],
                ['id' => 97, 'name' => '渲染技术']
            ]],
            ['id' => 3595, 'name' => 'VR/AR', 'url' => 'vr', 'subs' => [
                ['id' => 5640, 'name' => '行业动态'],
                ['id' => 5641, 'name' => '技术速递'],
                ['id' => 5642, 'name' => '产品资讯'],
                ['id' => 5644, 'name' => '独家评测'],
                ['id' => 5653, 'name' => '软件向'],
                ['id' => 5654, 'name' => '硬件向'],
                ['id' => 9327, 'name' => '独家评测']
            ]]
        ];

        return $types;
    }

    public function getFirstType($key = null)
    {
        $types = $this->getTypes();
        $type = collect($types)->first(function($_, $value) {
            return $value['id'] == $this->first_type_id;
        });

        return $key ? $type[$key] : $type;
    }
}
