<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-7-8
 * Time: 下午4:14
 */

namespace App\Models;

use Auth;
use Gate;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Favorite extends Model
{
    const ARTICLE_TYPE = 0;
    const ART_TYPE = 1;
    const VIDEO_TYPE = 2;
    const QUESTION_TYPE =3;
    const ANSWER_TYPE = 4;
    const COMMENT_TYPE =5;
	const FAME_TYPE = 101;

    protected  $table = 'favorites';

    protected $fillable = [
        'obj_type',
        'obj_id',
        'user_id',
        'status',
        'updated_at',
        'created_at'
    ];


    public function getOperateObj()
    {
        switch($this->obj_type){
            case self::ARTICLE_TYPE:
                return Article::find($this->obj_id);
            case self::ART_TYPE:
                return ArtWork::find($this->obj_id);
            case self::VIDEO_TYPE:
                return Video::find($this->obj_id);
            case self::COMMENT_TYPE:
                return Comment::find($this->obj_id);
			case self::FAME_TYPE:
				return Fame::find($this->obj_id);
        }

        return null;
    }

} 