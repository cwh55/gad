<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LessonVodTask extends Model
{
    protected $table = 'lesson_vod_task';
    protected $fillable = ['lesson_id', 'file_id', 'status'];
}
