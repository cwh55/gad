<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LessonVod extends Model
{
    protected $table = 'lesson_vod';
    protected $fillable = ['course_id', 'lesson_id', 'file_id', 'sort', 'vid', 'title', 'img_url', 'duration'];

    public function task()
    {
        return $this->belongsTo('App\Models\LessonVodTask', 'file_id', 'file_id');
    }
}
