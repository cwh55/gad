<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/5/16
 * Time: 9:38
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class User_Role extends Model
{
    protected $table = 'User_Role';
    protected $fillable = ['userId','roleId','rowStatus'];
    public $timestamps=false;
    public $incrementing = false;
}