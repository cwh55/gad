<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Rule extends Model
{
    protected $table = 'Rule';

	public function roles(){
		return $this->belongsToMany('App\Models\Rule', 'Role_Rule', 'ruleId', 'roleId');
	}
}
