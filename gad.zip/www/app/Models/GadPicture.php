<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/6/1
 * Time: 5:02
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class GadPicture extends Model
{
    protected $table = "gad_pictures";
    protected $fillable = ['archive_id', 'channel_id', 'type', 'user_id', 'user_name', 'url', 'content',
        'comment_count', 'like_count', 'favorite_count', 'view_count', 'sort', 'status'];
}