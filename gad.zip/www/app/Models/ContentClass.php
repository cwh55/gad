<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 17-3-6
 * Time: 下午4:54
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;


class ContentClass extends Model {
    public $table = 'ContentClass';
    protected $primaryKey = 'Id';

} 