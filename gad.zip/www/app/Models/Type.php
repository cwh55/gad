<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Type extends Model
{
    protected $table = 'course_type';

    public function parent()
    {
        return $this->belongsTo('App\Models\Type', 'parent_id');
    }

    public function subs()
    {
        return $this->hasMany('App\Models\Type', 'parent_id');
    }

    public static function getAll()
    {
        return self::with('subs')->where('parent_id', 0)->get();
    }
}
