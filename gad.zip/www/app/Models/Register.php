<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-8-25
 * Time: 下午5:20
 */

namespace App\Models;

use Auth;
use Gate;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Register extends Model
{
    protected $fillable = [
        'obj_type',//对象类型(1扶持/2salon)
        'obj_id',//所属的对象id
        'type',//对象类型(0个人/1机构)
        'user_id',//报名用户id
        'user_name',//联系人姓名
        'mobile',
        'email',
        'qq',
        'id_card',//身份证号
        'position',//职位/与公司关系
        'company',//所属公司/团队名称
        'logo',//公司/机构logo
        'company_type',//公司类型
        'members',//公司规模/机构成员(json)
        'start_date',//公司创建日期
        'province',
        'city',
        'address',
        'phone',//公司电话
        'info',//团队/机构简介
        'status',
        'member_count', //公司人数
        'weixin', //微信号
        'id_card_picture', //身份证照片
        'business_license', //营业执照注册号
        'business_license_pic' //营业执照照片
    ];

    public function games() {
        return $this->hasMany('App\Models\Game');
    }

}