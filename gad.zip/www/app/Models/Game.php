<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-8-25
 * Time: 下午5:20
 */

namespace App\Models;

use Auth;
use Gate;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Game extends Model
{
    protected $fillable = [
        'name',
        'game_type',
        'os',
        'flow',
        'package_size',
        'publish_date',
        'player_age',
        'intro',
        'profit_model',
        'feature',
        'logo',
        'ppt',
        'videos',
        'demo',
        'obj_id',
        'obj_type',
        'user_id',
        'status',
        'update_user',
        'register_id',
        'reg_step',
        'game_oses',
        'hatch_service',
        'description',
        'other_attachment',
        'pictures',
        'project_id'
    ];
    protected $casts = [
        'game_oses' => 'array',
        'demo' => 'array',
        'videos' => 'array',
		'logo' => 'array',
		 'ppt' => 'array',
        'hatch_service' => 'array',
        'other_attachment' => 'array',
        'pictures' => 'array'
    ];
    
    public function register() {
        return $this->hasOne('App\Models\Register', 'id', 'register_id');
    }
    public function osclass() {
        return $this->hasOne('App\Models\Classify', 'class_id', 'os');
    }

    public function gameType() {
        return $this->hasOne('App\Models\Classify', 'class_id', 'game_type');
    }

    public function getIntroAttribute()
    {
        if ($this->description) {
            return strip_tags($this->description);
        }

        return "";
    }
    
    public function project() {
        return $this->hasOne('App\Entities\HatchProject', 'id', 'project_id');
    }
} 