<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/2/23
 * Time: 11:36
 */

namespace App\Models;

use Auth;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Live extends Model
{
    protected $fillable = ['name','description','begin_time', 'end_time','class','tags','sign_num','sign_count',
                  'price','state','tips','creator','created_at','updater','updated_at','rowstatus','deleted_at'];
}