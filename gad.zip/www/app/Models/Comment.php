<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-7-8
 * Time: 下午4:53
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Auth;

class Comment extends Model
{
    //对应comments表里的obj_type
    const ARTICLE_TYPE = 0;
    const ART_TYPE = 1;
    const VIDEO_TYPE = 2;
    const QUESTION_TYPE =3;
    const ANSWER_TYPE = 4;
    const COMMENT_TYPE =5;
    const LORE_SECTION_TYPE = 6;
    const FAME_TYPE = 101;

    //对象类型，表示在点赞、收藏、评论表里的所属的obj_type
    const OBJ_TYPE = 5;


    protected $fillable = [
        'obj_type',
        'obj_id',
        'comment',
        'user_id',
        'name',
        'aye_cnt',
        'fav_cnt',
        'comment_cnt',
        'status',
        'created_at',
        'updated_at',
        'update_user'
    ];

    public static $objTypes = [0,1,2,3,4,5,6,101];//101名人堂
	public function user()
    {
       return $this->belongsTo('App\Models\User');
    }

    public function reply()
    {
        return $this->where('obj_id',$this->id)
            ->where('obj_type',5)
            ->where('status',0)
            ->get();
    }

    public function getOperateObj()
    {
        switch($this->obj_type){
            case self::ARTICLE_TYPE:
                return Article::find($this->obj_id);
            case self::ART_TYPE:
                return ArtWork::find($this->obj_id);
            case self::VIDEO_TYPE:
                return Video::find($this->obj_id);
            case self::COMMENT_TYPE:
                return Comment::find($this->obj_id);
            case self::LORE_SECTION_TYPE:
                return LoreSection::find($this->obj_id);
			case self::FAME_TYPE:
				return Fame::find($this->obj_id);
        }

        return null;
    }

    public static function getReply(array $commentIds)
    {
       return self::whereIn('obj_id',$commentIds)
            ->where('obj_type',self::COMMENT_TYPE)
            ->where('status',0)
            ->orderBy('created_at','DESC')
            ->get();
    }

    public static function getUsers(array $userIds)
    {
        return User::whereIn('UserId',$userIds)
            ->where('RowStatus',0)
            ->get();
    }

    public static function getLikeList(array $commentIds)
    {
        if (!Auth::check()) {
            return collect([]);
        }
        return Like::whereIn('obj_id',$commentIds)
            ->where('obj_type',self::OBJ_TYPE)
            ->where('user_id',Auth::user()->UserId)
            ->where('status',0)
            ->get();
    }


} 