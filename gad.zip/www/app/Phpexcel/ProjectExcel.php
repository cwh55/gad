<?php

/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2018/1/15
 * Time: 12:36
 */

require_once('PHPExcel.php');

class ProjectExcel
{
//导出Excel
    function exportList($userList, $getKeys, $_totaltitle, $fileName)
    {
        date_default_timezone_set('Asia/Shanghai');
        ini_set('memory_limit', '1024M');
        set_time_limit(0);

        //定义此数组存储excel列标
        $_totalmark = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
            'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK', 'AL',
            'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV', 'AW', 'AX');

        //截取与字段数目等值的一段列标数组
        for ($i = 0; $i < count($getKeys); $i++) {
            $columnmark[$i] = $_totalmark[$i];
        }
        //组装成 列标=>字段名 的数据结构。
        $fieldmap = array_combine($columnmark, $getKeys);
        $objExcel = new PHPExcel();
        $objActSheet = $objExcel->getActiveSheet(0);
        //error_reporting(E_ALL);
        //使用cache_towincache方式，单元格对象会保存在Wincache中，只在内存中保存索引
        $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_to_wincache;
        $cacheSettings = array('cacheTime' => 600);
        PHPExcel_Settings::setCacheStorageMethod($cacheMethod, $cacheSettings);

        //第一行插入title，设置居中
        for ($i = 1; $i <= count($userList); $i++) {
            foreach ($fieldmap as $key => $value) {
                $objActSheet->setCellValue($key . '1', $_totaltitle[$value]);//列值
                $objActSheet->getColumnDimension($key)->setWidth(15);//宽度
                $objActSheet->getStyle($key . '1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $objActSheet->getStyle($key . '1')->getFont()->setBold(true);

                if ($value == 'team_email') {
                    $info = $userList[$i - 1]['team_email'];
                    if (filter_var($info, FILTER_VALIDATE_EMAIL)) {
                        $userList[$i - 1]['team_email'] = $info;
                    } else {
                        $userList[$i - 1]['team_email'] = "";
                    }
                }

                if ($value == 'is_public') {
                    $info = $userList[$i - 1]['is_public'];
                    if ($info == 0) {
                        $userList[$i - 1]['is_public'] = "不公开";
                    } else if ($info == 1) {
                        $userList[$i - 1]['is_public'] = "公开";
                    }
                }

                if ($value == 'intro') {
                    $info = $userList[$i - 1]['intro'];
                    if ($info != "") {
                         $info=strip_tags($info);
                    }
                    $userList[$i - 1]['intro'] = $info;
                }

                if ($value == 'created_from') {
                    $info = $userList[$i - 1]['created_from'];
                    if ($info == 0) {
                        $userList[$i - 1]['created_from'] = "手动创建";
                    } else if ($info == 1) {
                        $userList[$i - 1]['created_from'] = "项目扶持";
                    } else if ($info == 2) {
                        $userList[$i - 1]['created_from'] = "晨星计划";
                    } else if ($info == 3) {
                        $userList[$i - 1]['created_from'] = "大赛";
                    } else if ($info == 4) {
                        $userList[$i - 1]['created_from'] = "组队项目";
                    } else if ($info == 11) {
                        $userList[$i - 1]['created_from'] = "独立游戏大赛";
                    } else if ($info == 12) {
                        $userList[$i - 1]['created_from'] = "高校游戏创意大赛";
                    } else if ($info == 13) {
                        $userList[$i - 1]['created_from'] = "故宫游戏创意大赛";
                    } else if ($info == 14) {
                        $userList[$i - 1]['created_from'] = "第一届创新大赛";
                    } else if ($info == 15) {
                        $userList[$i - 1]['created_from'] = "第二届创新大赛";
                    }
                }

                if (is_array($userList[$i - 1][$value])) {
                    if ($value == 'pictures') {
                        $str = "";
                        $arr = $userList[$i - 1][$value];
                        if (count($arr) == null) {
                            $userList[$i - 1]['pictures'] = "";
                        } else {
                            foreach ($arr as $item) {
                                if (isset($item["url"])) {
                                    $str .= $item["url"] . "、";
                                }
                            }
                            $userList[$i - 1]['pictures'] = rtrim($str, "、");
                        }
                    }
                }

                if (is_array($userList[$i - 1][$value])) {
                    if ($value == 'demo') {
                        $str = "";
                        $arr = $userList[$i - 1][$value];
                        if (count($arr) == null) {
                            $userList[$i - 1]['demo'] = "";
                        } else {
                            foreach ($arr as $item) {
                                if (isset($item["url"])) {
                                    $str .= $item["url"] . "、";
                                }
                            }
                            $userList[$i - 1]['demo'] = rtrim($str, "、");
                        }
                    }
                }

                if ($value == 'created_at') {
                    $objActSheet->setCellValue($key . ($i + 1), date('Y-m-d H:i:s', strtotime($userList[$i - 1][$value])));
                } else {
                    $objActSheet->setCellValue($key . ($i + 1), $userList[$i - 1][$value]);
                }

                $objActSheet->getStyle($key . ($i + 1))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
            }
        }

        header('Content-Type: application/vnd.ms-excel;charset=UTF-8');
        $name = $fileName . "_" . date('Ymdhis') . "_Excel.xls";
        header('Content-Disposition: attachment;filename=' . $name);
        header('Cache-Control: max-age=0');
        $objWriter = PHPExcel_IOFactory::createWriter($objExcel, 'Excel5');
        $objWriter->save('php://output');
        exit;
    }
}