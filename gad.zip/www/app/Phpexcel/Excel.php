<?php

require_once(dirname(__FILE__) . '/PHPExcel.php');
require_once(dirname(__FILE__) . '/PHPExcel/Writer/Excel5.php');
require_once(dirname(__FILE__) . '/PHPExcel/Reader/Excel5.php');
require_once(dirname(__FILE__) . '/PHPExcel/Writer/Excel2007.php');
require_once(dirname(__FILE__) . '/PHPExcel/Reader/Excel2007.php');
require_once(dirname(__FILE__) . '/PHPExcel/Cell/DataType.php');
require_once(dirname(__FILE__) . '/PHPExcel/Worksheet/ColumnDimension.php');

class Excel {

    public function exportToExcel($excelData, $filePath, $sheetName = 'sheet1', $isUse2007 = false) {
        //创建PHPExcel 这里使用Excel5格式，使用低版本以兼容客户端各Excel版本
        $objExcel = new PHPExcel();
        $objWriter;
        if ($isUse2007 == true)
            $objWriter = new PHPExcel_Writer_Excel2007($objExcel);
        else
            $objWriter = new PHPExcel_Writer_Excel5($objExcel);
        //设置文件属性
        $objProps = $objExcel->getProperties();
        $objExcel->setActiveSheetIndex(0);
        $objSheet = $objExcel->getSheet(0);
        $objSheet->setTitle($sheetName);
        $defaultStyle = $objSheet->getDefaultStyle();
        $defaultStyle->getFont()->setSize(10);
        $defaultStyle->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        $excel_data_header = array();
        $excel_data_header = $excelData["cols"];
        $colIndex = 0;
        $rowIndex = 1;
        //用于计算每一列的最大宽度
        //PS: setAutoSize函数对中文支持有问题，故自己计算
        $widthToSet = array();
        //写头
        foreach ($excel_data_header as $excelCol) {
            $objStyle = $objSheet->getStyleByColumnAndRow($colIndex, $rowIndex);
            $objFont = $objStyle->getFont();
            $objFont->setName('Courier New');
            $objFont->setBold(true);
            $objAlignA = $objStyle->getAlignment();
            $objAlignA->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $objAlignA->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
            $objFillA = $objStyle->getFill();
            $objFillA->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
            $objFillA->getStartColor()->setARGB('0099CC00');

            //计算字符像素宽度
            $widthToSet["{$colIndex}"] = mb_strwidth($excelCol);
            $objSheet->setCellValueByColumnAndRow($colIndex, 1, $excelCol, PHPExcel_Cell_DataType::TYPE_STRING);
            $colIndex ++;
        }
        $rowIndex = 2;
        //写内容
        foreach ($excelData["rows"] as $excelRow) {
            for ($colIndex = 0; $colIndex < count($excelRow); $colIndex++) {
                $cellValue = $excelRow[$colIndex];
                $cellDataType = PHPExcel_Cell_DataType::TYPE_STRING;
                $cellValue = strval($cellValue);
                $objSheet->setCellValueByColumnAndRow($colIndex, $rowIndex, $cellValue, $cellDataType);
                //替换为最大宽度
                if (mb_strwidth($cellValue) > $widthToSet["{$colIndex}"]) {
                    $widthToSet["{$colIndex}"] = mb_strwidth($cellValue);
                }
            }
            $rowIndex ++;
        }
        //设置列宽度
        for ($i = 0; $i < count($excel_data_header); $i++) {
            $width = $widthToSet["{$i}"] > 50 ? 50 : $widthToSet["{$i}"] + 1;
            $objSheet->getColumnDimensionByColumn($i)->setWidth($width);
        }
        //输出到文件
        $objWriter->save($filePath);
        unset($objProps);
        unset($objWriter);
    }

    /**
     * 修复 exportToExcel 的一个 bug：
     *      exportToExcel 在写入内容的时候，每一行的下标是数字的，从 0 开始。但是很多表格的数据下标是字符串
     * @author nanhaoliao
     */
    public function exportToExcel2($excelData, $filePath, $sheetName = 'sheet1', $isUse2007 = false) {
        //创建PHPExcel 这里使用Excel5格式，使用低版本以兼容客户端各Excel版本
        $objExcel = new PHPExcel();
        $objWriter;
        if ($isUse2007 == true)
            $objWriter = new PHPExcel_Writer_Excel2007($objExcel);
        else
            $objWriter = new PHPExcel_Writer_Excel5($objExcel);
        //设置文件属性
        $objProps = $objExcel->getProperties();
        $objExcel->setActiveSheetIndex(0);
        $objSheet = $objExcel->getSheet(0);
        $objSheet->setTitle($sheetName);
        $defaultStyle = $objSheet->getDefaultStyle();
        $defaultStyle->getFont()->setSize(10);
        $defaultStyle->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        $excel_data_header = array();
        $excel_data_header = $excelData["cols"];
        $colIndex = 0;
        $rowIndex = 1;
        //用于计算每一列的最大宽度
        //PS: setAutoSize函数对中文支持有问题，故自己计算
        $widthToSet = array();
        //写头
        foreach ($excel_data_header as $key => $excelCol) {
            $objStyle = $objSheet->getStyleByColumnAndRow($colIndex, $rowIndex);
            $objFont = $objStyle->getFont();
            $objFont->setName('Courier New');
            $objFont->setBold(true);
            $objAlignA = $objStyle->getAlignment();
            $objAlignA->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $objAlignA->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
            $objFillA = $objStyle->getFill();
            $objFillA->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
            $objFillA->getStartColor()->setARGB('0099CC00');

            //计算字符像素宽度
            $widthToSet[$key] = mb_strwidth($excelCol);
            $objSheet->setCellValueByColumnAndRow($colIndex, 1, $excelCol, PHPExcel_Cell_DataType::TYPE_STRING);
            $colIndex ++;
        }
        $rowIndex = 2;
        //写内容
        foreach ($excelData["rows"] as $excelRow) {
            $colIndex = 0;
            foreach ($excel_data_header as $key => $val) {
                $cellValue = $excelRow[$key];
                $cellDataType = PHPExcel_Cell_DataType::TYPE_STRING;
                $cellValue = strval($cellValue);
                if ('' == $cellValue) {
                    $cellValue = 0;
                }
                $objSheet->setCellValueByColumnAndRow($colIndex, $rowIndex, $cellValue, $cellDataType);
                //替换为最大宽度
                if (mb_strwidth($cellValue) > $widthToSet[$key]) {
                    $widthToSet[$key] = mb_strwidth($cellValue);
                }
                ++$colIndex;
            }
            $rowIndex ++;
        }
        //设置列宽度
        $i = 0;
        foreach ($excel_data_header as $key => $val) {
            $width = $widthToSet[$key] > 50 ? 50 : $widthToSet[$key] + 1;
            $objSheet->getColumnDimensionByColumn($i)->setWidth($width);
            ++$i;
        }
        //输出到文件
        $objWriter->save($filePath);
        unset($objProps);
        unset($objWriter);
    }

    /**
     * 生成Excel文件，并发送到浏览器直接下载，支持Excel 2005, Excel 2007
     * 和download_csv类的Excel文件下载相比：
     * 		优点：使用这个函数，较使用download_csv类，得到的excel更美观，可自动设置列宽，容易扩展Excel的样式设置
     * 		缺点：使用本函数在记录较多的时候，生成速度相对较慢
     * 
     * @author jimglelin 2013-04-12
     * @param array $excelHeader
     * @param array $excelContent
     * @param string $fileName
     * @param string $sheetName
     * @param bool $isUse2007
     */
    public function downloadToExcel($excelHeader, $excelContent, $fileName = 'download.xls', $filPath = 'php://output', $sheetName = 'sheet1', $isUse2007 = false) {
        //创建PHPExcel 这里使用Excel5格式，使用低版本以兼容客户端各Excel版本
        PHPExcel_Settings::setCacheStorageMethod(PHPExcel_CachedObjectStorageFactory::cache_to_discISAM);
        $objExcel = new PHPExcel();
        $objWriter;
        if ($isUse2007 == true) {
            $objWriter = new PHPExcel_Writer_Excel2007($objExcel);
            $fileName = $fileName . 'x';
        } else {
            $objWriter = new PHPExcel_Writer_Excel5($objExcel);
        }
        //设置文件属性
        $objProps = $objExcel->getProperties();
        $objExcel->setActiveSheetIndex(0);
        $objSheet = $objExcel->getSheet(0);
        $objSheet->setTitle($sheetName);
        $defaultStyle = $objSheet->getDefaultStyle();
        $defaultStyle->getFont()->setSize(10);
        $defaultStyle->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        $excel_data_header = array_values($excelHeader);
        $colIndex = 0;
        $rowIndex = 1;
        //用于计算每一列的最大宽度
        //PS: setAutoSize函数对中文支持有问题，故自己计算
        $widthToSet = array();
        //写头
        foreach ($excel_data_header as $excelCol) {
            $objStyle = $objSheet->getStyleByColumnAndRow($colIndex, $rowIndex);
            $objFont = $objStyle->getFont();
            $objFont->setName('Courier New');
            $objFont->setBold(true);
            $objAlignA = $objStyle->getAlignment();
            $objAlignA->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $objAlignA->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
            $objFillA = $objStyle->getFill();
            $objFillA->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
            $objFillA->getStartColor()->setARGB('0099CC00');

            //计算字符像素宽度
            $widthToSet["{$colIndex}"] = mb_strwidth($excelCol);
            $objSheet->setCellValueByColumnAndRow($colIndex, 1, $excelCol, PHPExcel_Cell_DataType::TYPE_STRING);
            $colIndex ++;
        }
        $rowIndex = 2;
        //写内容
        $colKeys = array_keys($excelHeader);
        $colCount = count($excel_data_header);
        foreach ($excelContent as $excelRow) {
            for ($colIndex = 0; $colIndex < $colCount; $colIndex++) {
                $colKey = $colKeys[$colIndex];
                $cellValue = $excelRow[$colKey];
                $cellDataType = PHPExcel_Cell_DataType::TYPE_STRING;
                $cellValue = strval($cellValue);
                $objSheet->setCellValueExplicitByColumnAndRow($colIndex, $rowIndex, $cellValue, $cellDataType);
                //替换为最大宽度
                if (mb_strwidth($cellValue) > $widthToSet["{$colIndex}"]) {
                    $widthToSet["{$colIndex}"] = mb_strwidth($cellValue);
                }
            }
            $rowIndex ++;
        }
        //设置列宽度
        for ($i = 0; $i < count($excel_data_header); $i++) {
            $width = $widthToSet["{$i}"] > 50 ? 50 : $widthToSet["{$i}"] + 1;
            $objSheet->getColumnDimensionByColumn($i)->setWidth($width);
        }
        //输出到浏览器
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header('Content-Disposition:inline;filename="' . $fileName . '"');
        header("Content-Transfer-Encoding: binary");
        header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Pragma: no-cache");
        $objWriter->save($filPath);
        unset($objProps);
        unset($objWriter);
    }

    public function exportMultiSheetToExcel($fileName = "export.xls", $excelData, $isUse2007 = false) {
        //创建PHPExcel 这里使用Excel5格式，使用低版本以兼容客户端各Excel版本
        $objExcel = new PHPExcel();
        //$objWriter = new PHPExcel_Writer_Excel5($objExcel); 
        //$objWriter = new PHPExcel_Writer_Excel2007($objExcel);
        $objWriter;
        if ($isUse2007 == true)
            $objWriter = new PHPExcel_Writer_Excel2007($objExcel);
        else
            $objWriter = new PHPExcel_Writer_Excel5($objExcel);
        //设置文件属性
        $objProps = $objExcel->getProperties();
        $objProps->setCreator("Sniper");
        $objProps->setLastModifiedBy("Sniper");
        $objProps->setTitle($fileName);
        $objProps->setSubject($fileName);
        $objProps->setDescription("Sniper Export Excel Document, generated by Sniper, powered by PHPExcel.");
        $objProps->setKeywords("Sniper Excel PHPExcel");
        $objProps->setCategory("Sniper Export Document");
        //设置值 列的索引从0开始计算 行的索引从1开始计算
        //目前只考虑一层关联数组 第一行固定为表头
        $sheetIndex = 0;
        $sheetCount = count($excelData);
        foreach ($excelData as $sheetName => $sheetData) {
            if ($sheetIndex > 0 && ($sheetIndex <= ($sheetCount - 1))) {
                $objExcel->createSheet();
            }
            $sheet_rows_count = count($sheetData);
            $objExcel->setActiveSheetIndex($sheetIndex);
            $objSheet = $objExcel->getSheet($sheetIndex);
            if ($sheetName != "Sheet1") {//模板使用说明
                $objSheet->setTitle($sheetName . '(' . (string) ($sheet_rows_count - 1) . '条)');
            } else {
                $objSheet->setTitle($sheetName);
            }
            $colIndex = 0;
            $rowIndex = 1;
            $sheet_data_header = array();
            if ($sheet_rows_count > 0) {
                //$sheet_data_header = array_values($sheetData[0]);
                foreach ($sheetData as $excelRow) {
                    //foreach($sheet_data_header as $excelCol)
                    foreach ($excelRow as $excel_cell_key => $excel_cell_value) {
                        if ($rowIndex == 1) {
                            $objStyle = $objSheet->getStyleByColumnAndRow($colIndex, $rowIndex);
                            $objFont = $objStyle->getFont();
                            $objFont->setName('Courier New');
                            $objFont->setSize(10);
                            $objFont->setBold(true);
                            $objAlignA = $objStyle->getAlignment();
                            $objAlignA->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                            $objAlignA->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
                            $objFillA = $objStyle->getFill();
                            $objFillA->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
                            $objFillA->getStartColor()->setARGB('0099CC00');

                            $objSheet->getColumnDimensionByColumn($colIndex)->setAutoSize(true);
                        }
                        $cellValue = '';
                        if (!is_null($excel_cell_value)) {
                            $cellValue = $excel_cell_value;
                        }
                        //(isset($excelData[$rowIndex - 1]) && isset($excelData[$rowIndex - 1][$excelCol]))?$excelData[$rowIndex - 1][$excelCol]:"";
                        $cellDataType = PHPExcel_Cell_DataType::TYPE_STRING;
                        if (is_float($cellValue)) {
                            $cellDataType = PHPExcel_Cell_DataType::TYPE_NUMERIC;
                            $objStyleCell = $objSheet->getStyleByColumnAndRow($colIndex, $rowIndex);
                            $objStyleCell->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER);
                        } else {
                            $cellValue = strval($cellValue);
                        }
                        $objSheet->setCellValueByColumnAndRow($colIndex, $rowIndex, $cellValue, $cellDataType);
                        $colIndex ++;
                    }
                    $colIndex = 0;
                    $rowIndex ++;
                }
            }
            $sheetIndex ++;
        }
        if ($sheetCount > 0) {
            $objExcel->setActiveSheetIndex(0);
        }
        //输出到文件
        $objWriter->save('./temp/' . $fileName);

        unset($objProps);
        unset($objWriter);
    }

    /*
     * $templateMaxColumnArr 模板各Sheet的最大列数，不包括第一个帮助Sheet，该数组索引从0开始对应模板的第2个Sheet
     * $limitedMaxRowCount 模板每个Sheet导入的最大行数
     * $limitedMaxSheetCount 模板最大Sheet数，包括第一个帮助Sheet的总Sheet数
     * $begin_row 从第几行开始读取,默认是从第二行开始读取,前面两行是表头
     * $sheet_index 读取第几个sheet的内容，0代表第一个sheet，一般第一个sheet为帮组sheet，故默认读取第二个sheet
     */

    public function importExcelToArray($templateMaxColumn, $limitedMaxRowCount, $limitedMaxSheetCount, $fileName = null, $begin_row = 1, $sheet_index = 1) {
        $sheetData = array();
        if ($fileName != null && $fileName != "") {
            $no_excel_error_msg = '导入的文件不是xls文件，或文件已损坏，请用word打开并另存为新的文件后重试。';
            $objReader = new PHPExcel_Reader_Excel2007();
            try {
                if (!$objReader->canRead($fileName)) {
                    $objReader = new PHPExcel_Reader_Excel5();
                    if (!$objReader->canRead($fileName)) {
                        throw new Exception($no_excel_error_msg);
                    }
                }
                $objExcel = $objReader->load($fileName);
            } catch (Exception $e) {
                throw new Exception($no_excel_error_msg);
            }
            try {
                if ($objExcel != null) {
                    $sheetCount = $objExcel->getSheetCount();
                    if ($sheetCount >= 1) {
                        if ($sheetCount <= $limitedMaxSheetCount && $sheetCount > $sheet_index) {
                            $rtn = array();
                            $sheetObj = $objExcel->getActiveSheet($sheet_index);
                            if ($sheetObj != null) {
                                $sheetName = $sheetObj->getTitle();
                                $highestRow = $sheetObj->getHighestRow();
                                if ($highestRow >= 2) {
                                    //读取表头
                                    //  $headData = array();
                                    /*   if($templateMaxColumn == 0)
                                      {
                                      $templateMaxColumn = PHPExcel_Cell::columnIndexFromString($sheetObj->getHighestColumn());
                                      }
                                      for($columnIndex = 0; $columnIndex < $templateMaxColumn; $columnIndex++)
                                      {
                                      $cellValue = $sheetObj->getCellByColumnAndRow($columnIndex, 1)->getValue();
                                      $headData[$columnIndex] = $cellValue;
                                      }
                                     */
                                    for ($rowIndex = $begin_row; $rowIndex <= $highestRow; $rowIndex++) {
                                        for ($columnIndex = 0; $columnIndex < $templateMaxColumn; $columnIndex++) {
                                            $cell = $sheetObj->getCellByColumnAndRow($columnIndex, $rowIndex);
                                            $value = $cell->getValue();
                                            //对富文本做特殊处理
                                            if ($value instanceof PHPExcel_RichText)
                                                $value = $cell->getValue()->getPlainText();
                                            //对日期格式做特殊处理
                                            if ($cell->getDataType() == PHPExcel_Cell_DataType::TYPE_NUMERIC) {
                                                $cellstyleformat = $cell->getStyle()->getNumberFormat();
                                                $formatcode = $cellstyleformat->getFormatCode();
                                                if (preg_match('/^(\[\$[A-Z]*-[0-9A-F]*\])*[hmsdy]/i', $formatcode)) {
                                                    $value = gmdate("Y-m-d", PHPExcel_Shared_Date::ExcelToPHP($value));
                                                } else {
                                                    $value = PHPExcel_Style_NumberFormat::toFormattedString($value, $formatcode);
                                                }
                                            }
                                            $sheetData[$rowIndex - $begin_row][$columnIndex] = $value;
                                        }
                                    }
                                }
                            }
                        } else {
                            throw new Exception('导入的Excel的Sheet数超过模板要求，请使用界面提供下载的Excel模板，第一个Sheet为帮助内容，数据从第二个Sheet开始。');
                        }
                    } else {
                        throw new Exception('导入的Excel的Sheet数少于模板要求，请使用界面提供下载的Excel模板，第一个Sheet为帮助内容，数据从第二个Sheet开始。');
                    }
                }
            } catch (Exception $e) {
                throw $e;
            }
        }
        return $sheetData;
    }

    /**
     * 读取Excel 为 array
     */
    public function readExcelToArray($fileName = null) {

        $result = array();
        if ($fileName != null && $fileName != "") {
            /*
              $objReader = new PHPExcel_Reader_Excel5();
              try
              {
              $objExcel = $objReader->load($fileName);
              }
              catch(Exception $e)
              {
              throw new Exception('导入的文件不是xls文件，或文件已损坏，请确认后重试。');
              }
             */
            $no_excel_error_msg = '导入的文件不是xls文件，或文件已损坏，请确认后重试。';
            $objReader = new PHPExcel_Reader_Excel2007();
            try {
                if (!$objReader->canRead($fileName)) {
                    $objReader = new PHPExcel_Reader_Excel5();
                    if (!$objReader->canRead($fileName)) {
                        throw new Exception($no_excel_error_msg);
                    }
                }
                $objExcel = $objReader->load($fileName);
            } catch (Exception $e) {
                throw new Exception($no_excel_error_msg);
            }
            try {
                if ($objExcel != null) {
                    $sheetCount = $objExcel->getSheetCount();
                    if ($sheetCount >= 1) {
                        for ($sheet_index = 0; $sheet_index < $sheetCount; $sheet_index++) {
                            $rtn = array();
                            $sheetObj = $objExcel->getActiveSheet($sheet_index);
                            if ($sheetObj != null) {
                                $sheetName = $sheetObj->getTitle();
                                $highestRow = $sheetObj->getHighestRow();
                                $templateMaxColumn = PHPExcel_Cell::columnIndexFromString($sheetObj->getHighestColumn());
                                if ($highestRow >= 1) {
                                    //读取列头
                                    $headData = array();
                                    $bodyData = array();
                                    for ($columnIndex = 0; $columnIndex < $templateMaxColumn; $columnIndex++) {
                                        $cellValue = $sheetObj->getCellByColumnAndRow($columnIndex, 1)->getValue();
                                        //过滤没有表头的列
                                        if ($cellValue == NULL)
                                            continue;
                                        $headData[$columnIndex] = $cellValue;
                                    }
                                    //刷新列总数
                                    $templateMaxColumn = count($headData);
                                    for ($rowIndex = 2; $rowIndex <= $highestRow; $rowIndex++) {
                                        $temp = array();
                                        for ($columnIndex = 0; $columnIndex < $templateMaxColumn; $columnIndex++) {
                                            $cell = $sheetObj->getCellByColumnAndRow($columnIndex, $rowIndex);
                                            $value = $cell->getValue();
                                            //对富文本做特殊处理
                                            if ($value instanceof PHPExcel_RichText)
                                                $value = $cell->getValue()->getPlainText();
                                            //对日期格式做特殊处理
                                            if ($cell->getDataType() == PHPExcel_Cell_DataType::TYPE_NUMERIC) {
                                                $cellstyleformat = $cell->getStyle()->getNumberFormat();
                                                $formatcode = $cellstyleformat->getFormatCode();
                                                if (preg_match('/^(\[\$[A-Z]*-[0-9A-F]*\])*[hmsdy]/i', $formatcode)) {
                                                    $value = gmdate("Y-m-d", PHPExcel_Shared_Date::ExcelToPHP($value));
                                                } else {
                                                    $value = PHPExcel_Style_NumberFormat::toFormattedString($value, $formatcode);
                                                }
                                            }
                                            $temp[$columnIndex] = $value;
                                        }
                                        $bodyData[$rowIndex - 2] = $temp;
                                    }
                                    //合并列头和数据
                                    $result[$sheetName] = array_merge(array($headData), $bodyData);
                                }
                            }
                        }
                    } else {
                        throw new Exception('导入的Excel的Sheet数少于模板要求，请使用界面提供下载的Excel模板。');
                    }
                }
            } catch (Exception $e) {
                throw $e;
            }
        }
        return $result;
    }

    public function importCalValue($templateMaxColumn, $limitedMaxRowCount, $limitedMaxSheetCount, $fileName = null, $begin_row = 1, $sheet_index = 1) {
        $sheetData = array();
        if ($fileName != null && $fileName != "") {
            $no_excel_error_msg = '导入的文件不是xls文件，或文件已损坏，请确认后重试。';
            $objReader = new PHPExcel_Reader_Excel2007();
            try {
                if (!$objReader->canRead($fileName)) {
                    $objReader = new PHPExcel_Reader_Excel5();
                    if (!$objReader->canRead($fileName)) {
                        throw new Exception($no_excel_error_msg);
                    }
                }
                $objExcel = $objReader->load($fileName);
            } catch (Exception $e) {
                throw new Exception($no_excel_error_msg);
            }
            try {
                if ($objExcel != null) {
                    $sheetCount = $objExcel->getSheetCount();
                    if ($sheetCount >= 1) {
                        if ($sheetCount <= $limitedMaxSheetCount && $sheetCount > $sheet_index) {
                            $rtn = array();
                            $sheetObj = $objExcel->getSheet($sheet_index);
                            if ($sheetObj != null) {
                                $sheetName = $sheetObj->getTitle();
                                $highestRow = $sheetObj->getHighestRow();
                                if ($highestRow >= 2) {
                                    for ($rowIndex = $begin_row; $rowIndex <= $highestRow; $rowIndex++) {
                                        for ($columnIndex = 0; $columnIndex < $templateMaxColumn; $columnIndex++) {
                                            $sheetData[$rowIndex - $begin_row][$columnIndex] = $sheetObj->getCellByColumnAndRow($columnIndex, $rowIndex)->getCalculatedValue();
                                        }
                                    }
                                }
                            }
                        } else {
                            throw new Exception('导入的Excel的Sheet数超过模板要求，请使用界面提供下载的Excel模板，第一个Sheet为帮助内容，数据从第二个Sheet开始。');
                        }
                    } else {
                        throw new Exception('导入的Excel的Sheet数少于模板要求，请使用界面提供下载的Excel模板，第一个Sheet为帮助内容，数据从第二个Sheet开始。');
                    }
                }
            } catch (Exception $e) {
                throw $e;
            }
        }
        return $sheetData;
    }

}