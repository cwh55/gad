<?php

/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2016/12/2
 * Time: 8:27
 */
require_once('PHPExcel.php');

class ExportExcel
{
    //导出Excel
    function exportList($userList, $getKeys, $_totaltitle, $fileName)
    {
        date_default_timezone_set('Asia/Shanghai');
        //定义此数组存储excel列标
        $_totalmark = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
            'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK', 'AL',
            'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV', 'AW', 'AX');

        //截取与字段数目等值的一段列标数组
        for ($i = 0; $i < count($getKeys); $i++) {
            $columnmark[$i] = $_totalmark[$i];
        }
        //组装成 列标=>字段名 的数据结构。
        $fieldmap = array_combine($columnmark, $getKeys);
        $objExcel = new PHPExcel();
        $objActSheet = $objExcel->getActiveSheet(0);
        //error_reporting(E_ALL);
        //使用cache_towincache方式，单元格对象会保存在Wincache中，只在内存中保存索引
        $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_to_wincache;
        $cacheSettings = array('cacheTime' => 600
        );
        PHPExcel_Settings::setCacheStorageMethod($cacheMethod, $cacheSettings);

        //第一行插入title，设置居中
        for ($i = 1; $i <= count($userList); $i++) {
            foreach ($fieldmap as $key => $value) {
                $objActSheet->setCellValue($key . '1', $_totaltitle[$value]);//列值
                $objActSheet->getColumnDimension($key)->setWidth(15);//宽度
                $objActSheet->getStyle($key . '1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $objActSheet->getStyle($key . '1')->getFont()->setBold(true);

                if ($value == 'game_type') {
                    $info = $userList[$i - 1]['game_type'];
                    if ($info == 1) {
                        $userList[$i - 1]['game_type'] = "动作";
                    } else if ($info == 2) {
                        $userList[$i - 1]['game_type'] = "竞技";
                    } else if ($info == 3) {
                        $userList[$i - 1]['game_type'] = "策略";
                    } else if ($info == 4) {
                        $userList[$i - 1]['game_type'] = "冒险";
                    } else if ($info == 5) {
                        $userList[$i - 1]['game_type'] = "休闲";
                    } else if ($info == 6) {
                        $userList[$i - 1]['game_type'] = "益智";
                    } else if ($info == 7) {
                        $userList[$i - 1]['game_type'] = "竞速";
                    } else if ($info == 8) {
                        $userList[$i - 1]['game_type'] = "格斗";
                    } else if ($info == 9) {
                        $userList[$i - 1]['game_type'] = "射击";
                    } else if ($info == 10) {
                        $userList[$i - 1]['game_type'] = "角色扮演";
                    }
                }

                if ($value == 'game_os') {
                    $info = $userList[$i - 1]['game_os'];
                    if ($info == 1) {
                        $userList[$i - 1]['game_os'] = "手机游戏";
                    } else if ($info == 2) {
                        $userList[$i - 1]['game_os'] = "PC游戏";
                    } else if ($info == 3) {
                        $userList[$i - 1]['game_os'] = "网页游戏";
                    } else if ($info == 4) {
                        $userList[$i - 1]['game_os'] = "VR游戏";
                    }
                }

                if ($value == 'status') {
                    $info = $userList[$i - 1]['status'];
                    if ($info == 0) {
                        $userList[$i - 1]['status'] = "已通过";
                    } else if ($info == 1) {
                        $userList[$i - 1]['status'] = "待审核";
                    } else if ($info == 2) {
                        $userList[$i - 1]['status'] = "已驳回";
                    }
                }

                if ($value == 'city_id') {
                    $info = $userList[$i - 1]['city_id'];
                    if ($info == 11111) {
                        $userList[$i - 1]['city_id'] = "专家活动";
                    } else {
                        $info = $userList[$i - 1]['city']["name"];
                        $userList[$i - 1]['city_id'] = $info;
                    }
                }

                if ($value == 'type') {
                    $info = $userList[$i - 1]['type'];
                    if ($info == 1) {
                        $userList[$i - 1]['type'] = "宣讲";
                    } else if ($info == 2) {
                        $userList[$i - 1]['type'] = "观众";
                    }
                }

                if ($value == 'group_type') {
                    $info = $userList[$i - 1]['group_type'];
                    if ($info == 1) {
                        $userList[$i - 1]['group_type'] = "个人";
                    } else if ($info == 2) {
                        $userList[$i - 1]['group_type'] = "团队";
                    }
                }

                if ($value == 'hatch_status') {
                    $info = $userList[$i - 1]['hatch_status'];
                    if ($info == 0) {
                        $userList[$i - 1]['hatch_status'] = "未扶持";
                    } else if ($info == 1) {
                        $userList[$i - 1]['hatch_status'] = "扶持中";
                    }else if ($info == 2) {
                        $userList[$i - 1]['hatch_status'] = "已扶持";
                    }
                }


                if ($value == 'created_at') {
                    $objActSheet->setCellValue($key . ($i + 1), date('Y-m-d H:i:s', strtotime($userList[$i - 1][$value])));
                } else {
                    $objActSheet->setCellValue($key . ($i + 1), $userList[$i - 1][$value]);
                }

                $objActSheet->getStyle($key . ($i + 1))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
            }
        }

        header('Content-Type: application/vnd.ms-excel;charset=UTF-8');
        $name = $fileName . "_" . date('Ymdhis') . "_Excel.xls";
        header('Content-Disposition: attachment;filename=' . $name);
        header('Cache-Control: max-age=0');
        $objWriter = PHPExcel_IOFactory::createWriter($objExcel, 'Excel5');
        $objWriter->save('php://output');
        exit;
    }

}