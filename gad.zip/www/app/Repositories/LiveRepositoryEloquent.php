<?php

namespace App\Repositories;

use App\Gad\Midas;
use Auth;
use App\Entities\Live;
use App\Validators\LiveValidator;
use App\Repositories\LiveRepository;
use Gate;
use Illuminate\Container\Container as Application;
use Prettus\Repository\Criteria\RequestCriteria;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Repository\Traits\CacheableRepository;
use Request;

/**
 * Class LiveRepositoryEloquent
 * @package namespace App\Repositories;
 */
class LiveRepositoryEloquent extends BaseRepository implements LiveRepository
{
    //use CacheableRepository;

    protected $sign;
    protected $order;

    public function __construct(Application $app, LiveSignRepositoryEloquent $sign, LiveOrderRepositoryEloquent $order)
    {
        parent::__construct($app);

        $this->sign = $sign;
        $this->order = $order;
    }

    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Live::class;
    }

    /**
     * Boot up the repository, pushing criteria
     */
    public function boot()
    {
        $this->pushCriteria(app(RequestCriteria::class));
    }

    public function getAllList($limit = 10)
    {
        $page = Request::get('page', 1);
        $offset = ($page - 1) * $limit;

        $this->with('teachers.user');
        $this->model->where('rowstatus', 0)->limit($limit)->offset($offset)->orderBy('begin_time', 'desc');

        return $this->all();
    }

    //修改状态-by cwh
    public function updateLive($liveRepository,$request,$id)
    {
        return $liveRepository->update($request, $id);
    }

    public function getByUser($signRepository, $user, $limit = 10)
    {
        $liveId = $signRepository->findWhere(['user_id' => $user->UserId], ['live_id'])->pluck('live_id');
        $page = Request::get('page', 1);
        $offset = ($page - 1) * $limit;

        $this->with('teachers');
        $this->model->whereIn('id', $liveId->all())->limit($limit)->offset($offset)->orderBy('begin_time', 'desc');

        return $this->all();
    }

    public function getDetail($id, $count = 6)
    {
        return $this->with(['teachers', $count == 6 ? 'newest6students' : 'newest8students'])->find($id);
    }

    public function buy($live, $user, $type = 'mobile')
    {
        if ($live->price == 0) {
            $this->sign->addUser($this, $live, $user);

            return ['code' => 0, 'buy' => 'free'];
        }

        $price = $live->price * 10;
        $goods = [
            'payitem' => $live->id.'*'.$price.'*1',
            'goodsmeta' => str_limit(trim($live->name), 60).'*'.str_limit(trim($live->name), 60),
            'goodsurl' => 'https://gad.qpic.cn/assets/web/img/live/goods.jpg',
            'amt' => $price
        ];

        $result = $type === 'mobile' ? Midas::mBuyGoods($goods) : Midas::buyGoods($goods);
        if ($result['code'] == 0) {
            $this->order->create(['live_id' => $live->id, 'user_id' => $user->UserId, 'amt' => $price, 'token' => $result['buy']['token']]);
        }

        return $result;
    }

    public function access($signRepository, $live, $user)
    {
        if (Gate::allows('access', $live)) {
            return true;
        }

        if ($user->roles->contains(2)) {
            $signRepository->addAdmin($live->id, $user);

            return true;
        }

        return false;
    }

    public function checkMidasSig($params)
    {
        $midas = config('midas');
        $path = app()->isLocal() ? '/cb.php' : '/live/ship';

        return Midas::checkSig('get', $path, $params, $midas['app_secret'].'&');
    }
}
