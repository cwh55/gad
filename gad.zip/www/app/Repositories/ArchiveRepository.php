<?php

namespace App\Repositories;

use App\Entities\Archive;
use App\Entities\Tag;
use App\Presenters\CommunityPresenter;
use App\Repositories\PictureRepository;
use DB;
use Illuminate\Database\Eloquent\Collection;
use Rinvex\Repository\Repositories\EloquentRepository;

class ArchiveRepository extends EloquentRepository
{
    protected $repositoryId = 'rinvex.repository.archive';
    protected $cacheLifetime = 0;

    protected $tagRepository;
    protected $answerRepository;

    public function __construct(TagRepository $tagRepository, AnswerRepository $answerRepository)
    {
        $this->tagRepository = $tagRepository;
        $this->answerRepository = $answerRepository;
    }

    public function getList($class_id = null, $channel_id = null, $page = 0, $pageSize = 20, $orderType = 'hot', $tag = 'hot')
    {
        if ($tag === 'hot') {
            $this->where([['status', '=', 0], ['is_hot', '=', 1]]);
        } else {
            $this->where([['status', '=', 0]]);
        }
        if($class_id > 0){
            $this->where('class_id', '=', intval($class_id));
        }
        if($channel_id > 0){
            $this->where('channel_id', '=', intval($channel_id));
        }

        $this->with(['user']);
        $this->orderBy($orderType == 'hot' ? 'hot_score' : 'sort_time', 'desc');
        $list = $this->offset($page * $pageSize)->limit($pageSize)->findAll();

        return $list;
    }

    /**
     * @param $tag_name
     * @param null $classId
     * @param null $page
     * @param int $pageSize
     * @param string $orderBy
     * @param bool|true $includeIsTop
     * @return array|mixed
     */
    public function getListByTagName($tag_name, $classId = null, $page = null, $pageSize = 20, $orderBy = 'hot',$includeIsTop=true, $tag_channel='') {
        $tag = $this->tagRepository->findBy('name',$tag_name);
        if($tag == null){
            return [];
        }
        $param = compact('classId', 'pageSize', 'page', 'orderBy');

        return $this->executeCallback(get_called_class(), __FUNCTION__, $param, function () use ($tag, $classId, $page, $orderBy, $pageSize,$includeIsTop, $tag_channel) {
            $archives = $tag->archives();
            $archives->with('user', 'firstPictures');
            if ($classId) {
                $archives->where('class_id', $classId);
            }
            $archives->where('status',0);
            //去掉置顶为了和置顶排重
            if (!$includeIsTop) {
                $archives->where('is_top',0);
            }

            $tag_channel_arr = array(
                'plan' => 1,
                'art' => 2,
                'program' => 3,
                'vr' => 4,
                'audio' => 5,
                'project' => 6,
                'yunying' => 7,
            );
            if($orderBy == 'hot') {
                if(isset($tag_channel_arr[$tag_channel])) {
                    $skey = 'score'.$tag_channel_arr[$tag_channel];
                    $archives->orderBy($skey, 'desc');
                };
                $archives->orderBy('hot_score', 'desc');
            } else {
                if(isset($tag_channel_arr[$tag_channel])) {
                    $archives->where('channel_id', $tag_channel_arr[$tag_channel]);
                };
                $archives->orderBy('sort_time', 'desc')->orderBy('created_at', 'desc');
            }
            $list = $archives->offset($page * $pageSize)->limit($pageSize)->get();

            return $list;
        });
    }

    //获得一个随机数组
    private function getRandomArray($size = 5){
        $arr = [];
        for($i=0;$i<$size;$i++){
            $arr[] = $i;
        }
        for($i=0;$i<$size;$i++){
            $r = round(rand(0, $size-1));
            $temp = $arr[$i];
            $arr[$i] = $arr[$r];
            $arr[$r] = $temp;
        }
        return $arr;
    }

    //随机获取最近的5篇文章，但排除id等于exclusive_id的
    public function getRecentByUser($user_id, $exclusive_id = 0, $class_id = 1){
        $all = $this->with(['user'])->where([['status', '=', 0], ['user_id', '=', $user_id], ['class_id', '=', $class_id]])->orderBy('id', 'desc')->limit(10)->findAll();
        $list = array();
        foreach($all as $a){
            if($a->id != $exclusive_id){
                $list[] = $a;
                if(count($list)>=5){
                    break;
                }
            }
        }
        shuffle($list);
        return $list;
    }

    public function findByTag(Tag $tag, $perPage = null, $page = null)
    {
        return $this->executeCallback(get_called_class(), __FUNCTION__, array_merge(['id' => $tag->id], compact('perPage', 'page')), function () use ($tag, $perPage, $page) {
            return $tag->archives()->paginate($perPage, ['*'], 'page', $page);
        });
    }

    public function captchaCache($archive_type, $type)
    {
        if (\Auth::user()) {
            $key = 'user::community::' . $type . $archive_type . '::save::' . \Auth::user()->UserId . '::' . date('Y-m-d');
            $data = \Redis::get($key);
            $dataArr = ['total' => 1, 'time' => time()];
            if ($data) {
                $dataArr = json_decode($data, true);
                $dataArr['total'] = $dataArr['total'] + 1;
                $dataArr['time'] = time();
            }
            \Redis::setex($key, 86400, json_encode($dataArr));
        }
    }


    //删除文档标签
    public function removeTags($archive){
        $tags = $archive->tags();
        $archive->tags()->detach();
        // 更新标签文档数
        $tags->each(function ($tag) use($archive) {
            $this->tagRepository->updateArchiveCount($tag, $archive);
        });
    }

    /**
     * 给文档添加标签，更新标签文档数
     *
     * @param Archive $archive
     * @param $tags
     */
    public function addTags(Archive $archive, Collection $tags)
    {
        $tags->each(function ($tag) {
            $tag->relate_type = 0;
        });

        // 给各父级添加间接关联
        foreach ($tags as $tag) {
            foreach ([0, $tag->p1, $tag->p2, $tag->p3, $tag->p4] as $lvl => $tagId) {
                if ($tagId AND !$tags->contains($tagId)) {
                    if ($parentTag = $this->tagRepository->find($tagId)) {
                        $parentTag->relate_type = 1;
                        $tags->add($parentTag);
                    }
                }
            }
        }

        $detach = $archive->tags->diff($tags);
        if (!$detach->isEmpty()) {
            $archive->tags()->detach($detach);
        }

        $pivot = [];
        $tags->each(function ($tag) use($archive, &$pivot) {
            if (!$archive->tags->contains($tag)) {
                $pivot[$tag->id] = ['relate_type' => $tag->relate_type, 'lvl' => $tag->lvl];
            }
        });

        $archive->tags()->attach($pivot);

        // 更新标签文档数
        $tags->each(function ($tag) use($archive) {
            $this->tagRepository->updateArchiveCount($tag, $archive);
        });
    }

    /**
     * 获取热门
     * @param int $classId
     * @param int $page
     * @param int $pageSize
     * @param string $orderBy
     * @return \Illuminate\Contracts\Pagination\Paginator
     */
    public function getHots($classId = 0, $page =0, $pageSize =20, $orderBy = 'hot')
    {
        $this->where('status',0)->where('is_hot',1);

        //过滤文档类型
        if ($classId >0) {
            $this->where('class_id',$classId);
        }
        $this->where('sort_time', '>', strtotime('-9 month'));
        //排序映射
        $orderMap =[
            'hot'=>['hot_score','desc'],
            'new'=>['sort_time','desc']
        ];
        $this->with(['user']);
        //置顶

        $this->orderBy($orderMap[$orderBy][0],$orderMap[$orderBy][1]);
        $archives = $this->simplePaginate($pageSize,['*'],'p',$page);
        //根据不同的文档类型拆分
        $res = $this->formatArchives($archives);
        $res->hasMorePage = $archives->hasMorePages();
        return $res;
    }


    /**
     * 获取置顶
     * @param int $classId
     * @param string $orderBy
     * @return ArchiveRepository
     */
    public function getTopArchiveByTag($tag)
    {
        $tag = $this->tagRepository->findBy('name',$tag);
        if($tag == null){
            return collect([]);
        }
        $archives = $tag->archives();
        $archives->with('user');
        $archives = $archives->where('is_top',1)->get();

        //根据不同的文档类型拆分
        $res = $this->formatArchives($archives);
        return $res;
    }

    /**
     * 格式化数据
     * @param $archives
     * @return static
     */
    public function formatArchives($archives)
    {
        $presenter = new CommunityPresenter();
        if (is_array($archives)) {
            $archives = collect($archives);
        }
        return $archives->map(function($item) use($presenter) {
            $tmp = new \stdClass();
            $tmp->avatar = $item->user->getAvatar();
            $tmp->id = $item->id;
            $tmp->channel_id = $item->channel_id;
            $tmp->class_id = $item->class_id;
            $tmp->title = $item->title;
            $tmp->description = $item->description;
            $tmp->cover = $item->cover;
            $tmp->user_id = $item->user_id;
            $tmp->user_name = $item->user->NickName;
            $tmp->is_video = $item->is_video;
            $tmp->is_top = $item->is_top;
            $tmp->is_hot = $item->is_hot;
            $tmp->total = $item->total;
            $tmp->created_at = $item->created_at;
            $tmp->extra = $item->extra;
            $tmp->tag = $item->tag;
            $tmp->tags = $item->tag !="" ? explode(',', $item->tag):[];
            $tmp->comment_count = $item->comment_count;
            $tmp->like_count = $item->like_count;
            $tmp->view_count = $item->view_count;
            $tmp->favorite_count = $item->favorite_count;
            $tmp->format_comment_count = $presenter->formatNumber($item->comment_count);
            $tmp->format_like_count = $presenter->formatNumber($item->like_count);
            $tmp->format_view_count = $presenter->formatNumber($item->view_count);
            $tmp->format_favorite_count = $presenter->formatNumber($item->favorite_count);
            $tmp->publish_time = $item->publish_time;
            $tmp->user_type = $item->user->type;
            $tmp->meishu_type = ($item->class_id == 2 && $item->firstPictures) ? $item->firstPictures->source_type : '';
            return $tmp;
        });
    }

    /**
     * 根据用户标签拉去热门
     * @param $userId
     * @param int $classId
     * @param int $page
     * @param int $pageSize
     * @param string $orderBy
     */
    public function getHotByUserTag($userId,$classId = 0, $page =0, $pageSize =20, $orderBy = 'hot')
    {

    }

    /**
     * 获取我的
     * @param $myId
     * @param int $classId
     * @param int $page
     * @param int $pageSize
     * @param string $orderBy
     * @return \Illuminate\Contracts\Pagination\Paginator
     */
    public function getMy($myId, $classId = 0, $page = 0, $pageSize = 20, $orderBy = 'hot')
    {

        $this->where('status',0);
        //过滤文档类型
        if ($classId >0) {
            $this->where('class_id',$classId);
        }

        //排序映射
        $orderMap =[
            'hot'=>['hot_score','desc'],
            'new'=>['id','desc']
        ];
        $this->with(['user']);
        $this->orderBy($orderMap[$orderBy][0],$orderMap[$orderBy][1]);
        $archives = $this->simplePaginate($pageSize,['*'],'p',$page);


        return $archives;
    }

    public function getChannelList($channelId,$classId,$page =0, $pageSize =20, $orderBy = 'hot')
    {
        $this->where('status',0)->where('channel_id',$channelId);

        //过滤文档类型
        if ($classId >0) {
            $this->where('class_id',$classId);
        }
        //排序映射
        $orderMap =[
            'hot'=>['hot_score','desc'],
            'new'=>['id','desc']
        ];
        $this->with(['user']);
        $this->orderBy($orderMap[$orderBy][0],$orderMap[$orderBy][1]);
        $archives = $this->simplePaginate($pageSize,['*'],'p',$page);
        //根据不同的文档类型拆分
        $archives->map(function($item){
            $item->avatar = $item->user->getAvatar();
            switch ($item->class_id) {
                case Archive::TYPE_WORKS:
                    if (is_string($item->extra)) {
                        $item->pictures = \GuzzleHttp\json_decode($item->extra);
                    }
                    break;
                case Archive::TYPE_QUESTION:
                    if (is_string($item->extra)) {
                        $item->answer = \GuzzleHttp\json_decode($item->extra);
                    }
                    break;
            }
            $item->tags = explode(',',$item->tag);
        });
        return $archives;
    }

    //增加访问次数
    public function addVisitCount($id, $pid = 0, PictureRepository $picture = null){
        $detail = $this->find($id);
        if ($detail) {
            $detail->increment('view_count',1);
        }
        if ($pid) {
            $pdetail = $picture->find($pid);
            if ($pdetail) {
                $pdetail->increment('view_count',1);
            }
        }
    }

    //根据classId拉取相关文档
    public function getRelatedArchivesByClassId($archive, $class_id, $order_by, $per_page)
    {
        $tags = $this->getArchiveTags($archive);
        if(!$tags || !isset($tags[0])){
            return new Collection();
        }
        $archives = $tags[0]->archives();
        $archives->where('status', '=', 0)->where('class_id','=',$class_id)->where('archive_id','<>',$archive->id);
        if ($order_by) {
           $archives->orderBy($order_by, 'desc');
        }

        return $archives->simplePaginate($per_page, ['*'], 'page', 1);
    }

    //根据classId拉取相关作品，这里不容易改成至拉取资源的
    public function getRelatedAtlasByClassId($archive, $class_id, $order_by, $per_page, $needCover)
    {
        $tags = $this->getArchiveTags($archive);
        if(!$tags || !isset($tags[0])){
            return new Collection();
        }
        $archives = $tags[0]->archives();
        if ($needCover) {
            $archives->where('cover', '!=', '');
        }
        $archives->where('status', '=', 0)->where('class_id','=',$class_id)->where('archive_id','<>',$archive->id);
        if ($order_by) {
            $archives->orderBy($order_by, 'desc');
        }

        return $archives->simplePaginate($per_page, ['*'], 'page', 1);
    }

    public function updateExtra($archive){
        if($archive->class_id != 3 && $archive->class_id != 4){
            return;
        }
        if($archive->is_hot == 1 && $archive->hot_aid != 0) {
            return;
        }
        $answer = $this->answerRepository->getLikeAnswer($archive->id,'like_count');
        if($answer){
            $answer->answer = strip_tags($answer->answer);
        }
        $this->update($archive->id, ['extra' => $answer->toArray(), 'sort_time' => strtotime($answer->created_at)]);
    }

    public function getArchiveTags(Archive $archive)
    {
        return $this->executeCallback(get_called_class(), __FUNCTION__, ['id' => $archive->id], function () use ($archive) {
            return $archive->tags;
        });
    }

    /**
     * 获取文档的相关文档
     *
     * @param Archive $archive
     * @param int $page
     * @param string $orderBy
     * @param int $perPage
     * @return Collection
     */
    public function getRelatedArchives(Archive $archive, $page = 1, $orderBy = 'hot_score', $perPage = 10)
    {
        $param = ['id' => $archive->id, 'page' => $page, 'orderBy' => $orderBy, 'perPage' => $perPage];
        $tag = $archive->tags->first();
        if (!$tag) {
            return new Collection();
        }

        return $this->executeCallback(get_called_class(), __FUNCTION__, $param, function () use ($tag, $page, $orderBy, $perPage, $param) {
            $archives = $tag->archives();
            $archives->with('user');
            $archives->where([['status', 0], ['archive_id', '!=', $param['id']]]);
            if ($orderBy) {
                $archives->orderBy($orderBy, 'desc');
            }

            return $archives->skip(($page - 1) * $perPage)->take($perPage + 1)->get();
        });
    }

    //获取我发表的内容数
    public function getMyArchiveCount($myId)
    {
        return $this->where('user_id',$myId)
            ->where('status','=',0)
            ->findAll(['id'])->count();
    }

    public function getMyLikeCount($myId)
    {
        return  $this->where('user_id',$myId)
            ->findAll(['like_count'])->sum('like_count');
    }
    
    public function getRejectNotice($userId){
        return \Redis::connection()->get('gad:community:rejectNotice:' . $userId);
    }
    
    public function setRejectNotice($userId, $value = 1){
        if($value === null){
            \Redis::connection()->del('gad:community:rejectNotice:' . $userId);
        }else{
            \Redis::connection()->set('gad:community:rejectNotice:' . $userId, $value);
        }
    }
    
    public function getDraftCount($userId){
        $rejectNotice = $this->getRejectNotice($userId);
        $count = $this->where('user_id', $userId)->whereIn('status', [1,2,3])->findAll(['id'])->count();
        return compact('rejectNotice', 'count');
    }
}
