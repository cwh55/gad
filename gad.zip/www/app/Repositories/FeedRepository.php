<?php

namespace App\Repositories;

use App\Entities\Feed;
use App\Presenters\CommunityPresenter;
use DB;
use Illuminate\Database\Eloquent\Collection;
use Rinvex\Repository\Repositories\EloquentRepository;
use App\Repositories\FollowRepository;
use Auth;

class FeedRepository extends EloquentRepository
{
    protected $repositoryId = 'rinvex.repository.feed';
    protected $cacheLifetime = 0;

    public function __construct(FollowRepository $followRepository)
    {
        $this->followRepository = $followRepository;
    }

    /**
     * 获取我的
     * @param $myId
     * @param int $page
     * @param int $pageSize
     * @param string $orderBy
     * @return \Illuminate\Contracts\Pagination\Paginator
     */
    public function getMyFeeds($user_id, $page = 1, $pageSize = 20, $orderBy = 'new')
    {
        return DB::table('gad_feeds as a')
            ->join('gad_follows as f', 'a.creator', '=', 'f.follow_user')
            ->join('User as u', 'a.user_id', '=', 'u.UserId')
            ->select('a.*', 'u.NickName', 'u.Avatar', 'u.type as user_type', 'u.breif')
            ->where('f.user_id', '=', $user_id)
            ->where('a.status', '=', 0)
            ->where('f.status', '=', 0)
            ->whereNull('a.deleted_at')
            ->whereIn('a.action_id', [41, 42, 43, 44, 51, 52])
            ->orderBy('a.sort_time', 'DESC')
            ->offset(($page - 1) * $pageSize)
            ->limit($pageSize)
            ->get();
    }

    public function updateFeed($favorite, $status)
    {
        $arr = explode('\\', $favorite->model_type);
        if(isset($arr[2])) {
            switch ($arr[2]) {
                case 'Archive':
                    // 收藏文章
                    $data = $this->getArchiveContent($favorite, 31);
                    break;
                case 'Picture':
                    // 收藏作品
                    $data = $this->getPictureContent($favorite, 32);
                    break;
                case 'Question':
                    // 收藏问题
                    $data = $this->getQuestionContent($favorite, 33);
                    break;
            }
            $this->generateFeeds($data,$status);
        }
    }

    public function getArchiveContent($object, $action_id)
    {
        $data = array();
        $archive = $object->favModel;
        if(!empty($archive)) {
            if(!empty($archive) && isset($archive->class_id)) {
                if ($archive->class_id == 1) {
                    $action_id = 31;
                } else if ($archive->class_id == 2) {
                    $action_id = 32;
                } else if ($archive->class_id == 3) {
                    $action_id = 33;
                } else if ($archive->class_id == 4) {
                    $action_id = 34;
                }
            }
            $data = array(
                'archive_id' => $archive->id,
                'class_id' => $archive->class_id,
                'action_id' => $action_id,
                'title' => stripslashes($archive->title),
                'description' => stripslashes($archive->description),
                'cover' => $archive->cover,
                'tag' => $archive->tag,
                'user_id' => $archive->user_id,
                'user_name' => stripslashes($archive->user_name),
                'creator' => $object->user_id,
                'comment_count' => $archive->comment_count,
                'like_count' => $archive->like_count,
                'favorite_count' => $archive->favorite_count,
                'view_count' => $archive->view_count,
                'is_video' => $archive->is_video,
                'answer_id' => 0,
                'total' => $archive->total,
                'extra' => $archive->extra,
                'sort_time' => strtotime($object->created_at),
                'created_at' => $object->created_at,
                'updated_at' => $object->updated_at,
            );
        }
        return $data;
    }

    public function getQuestionContent($object, $action_id)
    {
        $archive = $object->favModel;
        $data = array();
        if (!empty($archive)) {
            if ($action_id == 23) {
                if ($archive->class_id == 4) {
                    $action_id = 24;
                }
            }
            if ($action_id == 33) {
                if ($archive->class_id == 4) {
                    $action_id = 34;
                }
            }
            $data = array(
                'archive_id' => $archive->id,
                'class_id' => $archive->class_id,
                'action_id' => $action_id,
                'title' => stripslashes($archive->title),
                'description' => stripslashes($archive->description),
                'cover' => $archive->cover,
                'tag' => $archive->tag,
                'user_id' => $archive->user_id,
                'user_name' => stripslashes($archive->user_name),
                'creator' => $object->user_id,
                'comment_count' => $archive->comment_count,
                'like_count' => $archive->like_count,
                'favorite_count' => $archive->favorite_count,
                'view_count' => $archive->view_count,
                'is_video' => $archive->is_video,
                'answer_id' => 0,
                'total' => $archive->total,
                'extra' => $archive->extra,
                'sort_time' => strtotime($object->created_at),
                'created_at' => $object->created_at,
                'updated_at' => $object->updated_at,
            );
        }
        return $data;
    }

    public function getPictureContent($object, $action_id)
    {
        $data = array();
        $picture = DB::table('gad_pictures as p')
            ->join('gad_archives as a', 'a.id', '=', 'p.archive_id')
            ->select('p.*', 'a.title', 'a.extra')
            ->where('p.id', '=', $object->model_id)
            ->where('p.status', '=', 0)
            ->whereNull('p.deleted_at')
            ->first();
        if (!empty($picture)) {
            $extra[] = $picture;
            $data = array(
                'archive_id' => $picture->archive_id,
                'class_id' => 2,
                'action_id' => $action_id,
                'title' => stripslashes($picture->title),
                'description' => '',
                'cover' => $picture->url,
                'tag' => '',
                'user_id' => $picture->user_id,
                'user_name' => stripslashes($picture->user_name),
                'creator' => $object->user_id,
                'comment_count' => $picture->comment_count,
                'like_count' => $picture->like_count,
                'favorite_count' => $picture->favorite_count,
                'view_count' => $picture->view_count,
                'is_video' => 0,
                'answer_id' => 0,
                'total' => 0,
                'extra' => json_decode($picture->extra,true),
                'sort_time' => strtotime($object->created_at),
                'created_at' => $object->created_at,
                'updated_at' => $object->updated_at,
            );
        }
        return $data;
    }

    public function generateFeeds($data,$status)
    {
        if (!empty($data)) {
            $res = $this->exists($data);
            if (!empty($res)) {
                if ($status == 0 && !$res->trashed()) {
                    $res->delete();
                } else if ($status == 1 && !$res->trashed()) {
                    $res->restore();
                }
            } else {
                if ($status == 1) {
                    $this->create($data);
                }
            }
        }
    }

    public function exists($data)
    {
        return Feed::withTrashed()
            ->select('id')
            ->where('archive_id', '=', $data['archive_id'])
            ->where('class_id', '=', $data['class_id'])
            ->where('action_id', '=', $data['action_id'])
            ->where('user_id', '=', $data['user_id'])
            ->where('creator', '=', $data['creator'])
            ->where('answer_id', '=', $data['answer_id'])
            ->first();
    }

    public function getUserActionCount($user_id, $class_id = 0, $action_ids = [])
    {
        $sql = DB::table('gad_feeds as a')
            ->join('User as u', 'a.user_id', '=', 'u.UserId')
            ->select('a.*', 'u.NickName as nickName', 'u.Avatar as avatar', 'u.breif', 'u.type')
            ->where('a.creator', '=', $user_id)
            ->whereNull('a.deleted_at')
            ->where(function ($query) use ($class_id) {
                $query->where('a.status', '=', 0);
                $query->orWhere('a.status', '=', 2);
            })
            ->whereNotIn('action_id', [45, 46, 47, 61]);//暂时过滤评论和live的

        if ($class_id != 0)
            $sql = $sql->where('class_id', '=', $class_id);

        if (count($action_ids) > 0)
            $sql = $sql->whereIn('action_id', $action_ids);

        $res = $sql->count();

        return $res;
    }

    //获取我的动态
    public function getUserActions($user_id, $class_id=0 , $action_ids = [], $page = 1, $pageSize = 20)
    {
        $sql = DB::table('gad_feeds as a')
            ->join('User as u', 'a.user_id', '=', 'u.UserId')
            ->select('a.*', 'u.NickName as nickName', 'u.Avatar as avatar', 'u.breif', 'u.type')
            ->where('a.creator', '=', $user_id)
            ->whereNull('a.deleted_at')
            ->where(function($query) use ($class_id) {
                $query->where('a.status', '=', 0);
                $query->orWhere('a.status', '=', 2);
            })
            ->whereNotIn('action_id',[45,46,47,61]);//暂时过滤评论和live的

        if ($class_id != 0)
            $sql = $sql->where('class_id','=', $class_id);

        if (count($action_ids) > 0)
            $sql = $sql->whereIn('action_id', $action_ids);
        else {
            if(!Auth::check() || Auth::user()['UserId'] != $user_id) {
                // 非客人态有过滤
                //【日志】下只保留【发表了日志】模块
                //【问答】下只保留【提问】、【回答】模块
                //【作品】下只保留【发表了作品】模块
                $sql = $sql->whereIn('action_id', [41,42,43,44,51]);
            }
        }

        $res =  $sql->orderBy('a.sort_time', 'DESC')
            ->offset(($page - 1) * $pageSize)
            ->limit($pageSize)
            ->get();

        $urlMap = array(
            1 => 'article',
            2 => 'gallery',
            3 => 'question',
            4 => 'topic',
        );

        foreach($res as $item) {
            if ($item->extra) {
                $item->extra = json_decode($item->extra, true);
            }
            if (in_array($item->class_id ,[1,2,3,4])) {
                $item->url = sprintf('/%s/detail/%d', $urlMap[$item->class_id], $item->archive_id);
            }
        }

        return $res;
    }


    public function getMy1($page = 0, $pageSize = 20, $orderBy = 'new')
    {
        return $this->followRepository->with(['feeds'])->where('user_id','=', Auth::user()->UserId)->findAll();
    }
}
