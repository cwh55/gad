<?php

namespace App\Repositories;

use App\Entities\Archive;
use App\Entities\Tag;
use App\Repositories\CommentRepository;
use App\Repositories\TagRepository;
use App\Repositories\OperationRepository;
use DB;
use Rinvex\Repository\Repositories\EloquentRepository;
use Auth;

class PictureRepository extends EloquentRepository
{
    protected $repositoryId = 'rinvex.repository.picture';
    protected $cacheLifetime = 0;
    protected $model = 'App\Entities\Picture';

    public function getList($type = 2, $channel_id = 0, $order = 'hot', $page = 0, $pageSize = 20, $tag = 'hot')
    {
        $this->where('type', '=', intval($type))->where('status', '=', 0);
        if ($tag == 'hot') {
            $this->where('is_hot', '=', 1);
        }
        if ($channel_id > 0) {
            $this->where('channel_id', '=', intval($channel_id));
        }
        if (!$pageSize) {
            $pageSize = 20;
        }
        if ($order == 'hot') {
            $this->orderBy('hot_score', 'desc');
        } else {
            $this->orderBy('id', 'desc');
        }
        if (Auth::user()) {
            $list = $this->with(['user', 'mylike'])->offset($page * $pageSize)->limit($pageSize)->findAll();
        } else {
            $list = $this->with(['user'])->offset($page * $pageSize)->limit($pageSize)->findAll();
        }
        $commentre = new CommentRepository();
        for ($i = 0; $i< count($list); $i++) {
           if ($type == 2) {    //点评时需要寻找导师回答
               $comments = $commentre->with(['user'])
                   ->where('model_id', '=', $list[$i]->id)
                   ->where('model_type', '=', 'App\Entities\Picture')
                   ->orderBy('created_at', 'desc')
                   ->findAll();
               foreach ($comments as $comment) {
                   if ($comment->user->TutorStatus == 2) {
                       $comment->comment = strip_tags($comment->comment);
                       $list[$i]->tutoranswer = $comment;
                       break;
                   }
               }
            }
            if ($list[$i]->user) {
                $list[$i]->avatar = $list[$i]->user->getAvatar();
            } else {
                $list[$i]->avatar = 'http://gad.qpic.cn/assets/v2/web/img/global/default_headpic.jpg';
            }
        }
        return $list;
    }

    public function savePictures($data, $ids, $status)
    {
        $piclist = $data['piclist'];
        $type = intval($data['type']);
        $id = intval($data['id']);
        $results = array();
        foreach ($piclist as $picture) {
            if (in_array($picture['id'], $ids)) {
                if ($picture['status'] == -1) {
                    $this->delete($picture['id']);
                } else {
                    $result = $this->update($picture['id'], ['type' => $type, 'url' => $picture['url'],
                        'content' => $picture['content'], 'status' =>$status, 'sort' => $picture['sort'],
                        'publish_time' => date("Y-m-d H:i:s"), 'width' => $picture['width'],
                        'height' => $picture['height']]);
                    if ($result[0]) {
                        //按照前端传过来的顺序，返回数组的顺序是对的。
                        array_push($results, array('id' => $result[1]->id, 'url' => $result[1]->url));
                    } else {
                        return 0;
                    }
                }
            } else {
                if ($picture['status'] == -1) {
                    continue;
                }
                $result = $this->create([
                    'archive_id' => $id,
                    'channel_id' => 15,
                    'type' => $type,
                    'user_id' => Auth::user()['UserId'],
                    'user_name' => Auth::user()['NickName'],
                    'url' => $picture['url'],
                    'content' => $picture['content'],
                    'sort' => $picture['sort'],
                    'status' => $status,
                    'publish_time' => date("Y-m-d H:i:s"),
                    'width' => $picture['width'],
                    'height' => $picture['height']
                ]);
                if ($result[0]) {
                    array_push($results, array('id' => $result[1]->id, 'url' => $result[1]->url));
                } else {
                    return 0;
                }
            }
        }
        return $results;
    }

    public function savePicturesNew($data, $ids, $status)
    {
        $piclist = $data['piclist'];
        $type = intval($data['atlas']['type']);
        $id = intval($data['id']);
        $results = array();
        foreach ($piclist as $picture) {
            if (in_array($picture['id'], $ids)) {
                if ($picture['status'] == -1) {
                    $this->delete($picture['id']);
                } else {
                    $params = [
                        'type' => $type,
                        'url' => $picture['url'],
                        'content' => $picture['content'],
                        'status' =>$status,
                        'sort' => $picture['sort'],
                        'publish_time' => date("Y-m-d H:i:s"),
                        'width' => $picture['width'],
                        'height' => $picture['height'],
                        'source_type' => $picture['source_type'],
                        'videourl' => $picture['videourl']
                    ];
                    $result = $this->update($picture['id'], $params);
                    if ($result[0]) {
                        //按照前端传过来的顺序，返回数组的顺序是对的。
                        array_push($results, array('id' => $result[1]->id, 'url' => $result[1]->url));
                    } else {
                        return 0;
                    }
                }
            } else {
                if ($picture['status'] == -1) {
                    continue;
                }
                $result = $this->create([
                    'archive_id' => $id,
                    'channel_id' => 15,
                    'type' => $type,
                    'user_id' => Auth::user()['UserId'],
                    'user_name' => Auth::user()['NickName'],
                    'url' => $picture['url'],
                    'content' => $picture['content'],
                    'sort' => $picture['sort'],
                    'status' => $status,
                    'publish_time' => date("Y-m-d H:i:s"),
                    'width' => $picture['width'],
                    'height' => $picture['height'],
                    'source_type' => $picture['source_type'],
                    'videourl' => $picture['videourl']
                ]);
                if ($result[0]) {
                    array_push($results, array('id' => $result[1]->id, 'url' => $result[1]->url));
                } else {
                    return 0;
                }
            }
        }
        return $results;
    }

    public function getSubTags()
    {
        return [0=>'全部类型', 10498 => '美术新手', 10476 => '原画', 10506 => '3D', 10559 => 'UI', 10548 => '特效',
            10552 => '技术美术', 10530=>'动画'];
    }

    public function findByTag(TagRepository $tagRepository, Tag $tag, $page = null, $orderBy = 'hot', $perPage = 24, $isHot = 'hot', $type = 0)
    {
        $params = ['class_id' => Archive::TYPE_WORKS];
        if ($isHot == 'hot') {
            $params['is_hot'] = 1;
        }
        $archivesId = $tagRepository->getArchivesId($tag, $params);
        $this->whereIn('archive_id', $archivesId);
        if ($type != 0) {
            $this->where('type', $type);
        }
        $this->with(['user']);
        $this->orderBy($orderBy == 'hot' ? 'hot_score' : 'id', 'desc');

        return $this->simplePaginate($perPage);
    }

    public function getChunk($items, $column = 4)
    {
        $result = array_fill(0, $column, []);
        foreach ($items as $key => $item) {
            $i = $key % $column;
            $result[$i][] = $item;
        }

        return $result;
    }

    public function getCountByArchive(array $ids)
    {
        return $this->executeCallback(get_called_class(), __FUNCTION__, ['ids' => $ids], function () use ($ids) {
            return $this->prepareQuery($this->createModel())->whereIn('archive_id', $ids)->count();
        });
    }

    public function getTagRelatedArchives($tagId = 0 ,$page = 0, $pageSize = 20, $orderBy = 'is_hot')
    {
        if($tagId == 0){
            $archives = Archive::where('class_id',2);
        } else {
            $tag = new TagRepository;
            $archives = $tag->findBy('id',$tagId)->archives()->where('class_id', 2);
        }
        $params = compact('archives','page','pageSize','orderBy');
        return $this->executeCallback(get_called_class(), __FUNCTION__,$params, function () use ($archives, $page, $pageSize ,$orderBy) {
            // 查询图集
            $archives->with('user');
            $archives->with('firstPictures');
            $archives = $archives->where('status',0);
            if($orderBy == 'is_hot') {
                $archives = $archives->where(['is_hot' => 1])->orderBy('sort_time', 'desc');
            } else if($orderBy == 'hot'){
                $archives = $archives->orderBy('hot_score','desc');
            } else {
                $archives = $archives->orderBy('sort_time', 'desc')->orderBy('created_at', 'desc');
            }

            return $archives->offset($page * $pageSize)->limit($pageSize)->get();

        });
    }

    public function getTagRelatedArchivesV2 ($tagId = 0 ,$page = 0, $pageSize = 20, $orderBy = 'is_hot') {
        $archives = DB::table('gad_archives')
            ->join('gad_atlas', 'gad_archives.id', '=', 'gad_atlas.archive_id');
        if ($tagId != 0) {
            $archives->join('gad_archive_tags', 'gad_archives.id', '=', 'gad_archive_tags.archive_id')
            ->where('gad_archive_tags.tag_id', '=', $tagId);
        }
        $archives->where('gad_archives.class_id', '=', 2)->where('gad_archives.status', '=', 0)->where('gad_atlas.type', '=', 1)
        ->whereNull('gad_archives.deleted_at');

        if($orderBy == 'is_hot') {
            $archives->where('gad_archives.is_hot', '=', 1)->orderBy('gad_archives.sort_time', 'desc');
        } else if($orderBy == 'hot'){
            $archives->orderBy('gad_archives.hot_score','desc');
        } else {
            $archives->orderBy('gad_archives.sort_time', 'desc')->orderBy('gad_archives.created_at', 'desc');
        }
        $result = $archives->select('gad_archives.id')->skip($page * $pageSize)
            ->take($pageSize)
            ->get();
        $ids = array_column(json_decode(json_encode($result),true), 'id');
        $query = Archive::with('user', 'firstPictures')->whereIn('id', $ids);
        $query->orderBy('is_top','desc');
        if($orderBy == 'is_hot') {
            $query->where('is_hot', '=', 1)->orderBy('sort_time', 'desc');
        } else if($orderBy == 'hot'){
            $query->orderBy('hot_score','desc');
        } else {
            $query->orderBy('sort_time', 'desc')->orderBy('created_at', 'desc');
        }
        $archivesList = $query->get();
        return $archivesList;
    }


    public function  getPicBanner()
    {
        $op = new OperationRepository;
        return $op ->getBanners(15);
    }
}

