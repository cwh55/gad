<?php

namespace App\Repositories;

use App\Entities\Answer;
use Rinvex\Repository\Repositories\EloquentRepository;
use Gate;

/**
 * Interface AnswerRepository
 * @package namespace App\Repositories;
 */
class AnswerRepository extends EloquentRepository
{

    protected $repositoryId = 'revinx.repository.answer';
    protected $cacheLifetime = 0;
    //

    public function getLikeAnswer($archive_id, $order_by)
    {
        $param = ['archiveId' => $archive_id, 'orderBy' => $order_by];

        return $this->executeCallback(get_called_class(), __FUNCTION__, $param, function () use ($archive_id, $order_by) {
            $res = Answer::with(['user'])->where('archive_id', '=', $archive_id)->orderBy($order_by, 'desc')->orderBy('answer_count', 'desc')->orderBy('id', 'desc')->limit(1)->get();
            $data = collect([]);
            if ($res && isset($res[0])) {
                $data = $res[0];
                $data->avatar = 'http://gad.qpic.cn/assets/v2/web/img/global/default_headpic.jpg';
                if ($data->user) {
                    $data->avatar = $data->user->getAvatar();
                    $data->type = $data->user->type;
                }
                //$data->likeuser = $like->firstLike('App\\Entities\\Answer',$data->id,1);
            }

            return $data;
        });
    }

    public function getListByAnswer($id, $user_id, $pageSize = 20, $orderBy = 'hot', $page = 1)
    {
        $param = ['id' => $id, 'userId' => $user_id, 'orderBy' => $orderBy, 'page' => $page, 'perPage' => $pageSize];

        return $this->executeCallback(get_called_class(), __FUNCTION__, $param, function () use ($id, $user_id, $page, $orderBy, $pageSize) {
            $data = [];
            $res = Answer::with(['user', 'like'])->where('answer_id', '=', $id)->where('status', '=', 0);

            if ($orderBy == 'hot') {
                $res = $res->orderBy('rank', 'desc')->orderBy('like_count', 'desc')->orderBy('created_at', 'desc');
            } else {
                $res = $res->orderBy('created_at', 'asc')->orderBy('like_count', 'desc');
            }
            $total = $res->count();

            $offset = 0;
            if ($page > 1) {
                $offset = ($page - 2) * $pageSize + 3;
            }
            $res = $res->offset($offset)->limit($pageSize);

            $data['data'] = $res->get();
            $data['total'] = $total;

            if ($data) {
                foreach ($data['data'] as &$val) {
                    $val->like = $val->like->where('user_id', $user_id)->toArray();
                    $val->like = array_values($val->like);
                    $val->likefav = isset($val->like[0]) ? $val->like[0] : [];

                    $val->pushState = false;

                    $val->hasPermit = Gate::allows('edit',$val);

                    $val->avatar = 'http://gad.qpic.cn/assets/v2/web/img/global/default_headpic.jpg';
                    $val->profession = '';
                    if ($val->user) {
                        $val->profession = '';//$val->user->Profession;
                        $val->avatar = $val->user->getAvatar();
                    }
                }
            }

            return $data;
        });
    }

    public function getListByQuestion($id, $user_id, $pageSize = 20, $orderBy = 'hot')
    {
        $param = ['id' => $id, 'userId' => $user_id, 'orderBy' => $orderBy, 'perPage' => $pageSize];

        return $this->executeCallback(get_called_class(), __FUNCTION__, $param, function () use ($id, $user_id, $orderBy, $pageSize) {
            $data = [];
            $res = Answer::with(['user', 'like'])->where('archive_id', '=', $id)->where('status', '=', 0);

            if ($orderBy == 'hot') {
                $data = $res->orderBy('rank', 'desc')->orderBy('like_count', 'desc')->paginate($pageSize);
            } else {
                $data = $res->orderBy('created_at', 'desc')->orderBy('like_count', 'desc')->paginate($pageSize);
            }

            if ($data) {
                foreach ($data as &$val) {

                    $val->like = $val->like->where('user_id', $user_id)->toArray();
                    $val->like = array_values($val->like);
                    $val->likefav = isset($val->like[0]) ? $val->like[0] : [];

                    $val->textShow = false;
                    $val->pushState = false;

                    $val->hasPermit = Gate::allows('edit',$val);

                    $val->avatar = $val->user->getAvatar();
                    $val->loading = false;
                    $val->replyList = ['current_page' => 0, 'per_page' => 3, 'data' => [], 'pushState' => false, 'first' => false];
                    //$val->answerList = $this->getListByAnswer($val->id, $user_id, $pageSize, $orderBy);
                }
            }

            return $data;
        });
    }

    public function getMyLikeCount($myId)
    {
        return $this->where('user_id', $myId)
            ->findAll(['like_count'])->sum('like_count');
    }

    public function getMyAnswerCount($myId)
    {
        return $this->where('user_id', $myId)
            ->findAll(['id'])->count();
    }
}
