<?php

namespace App\Repositories;

use App\Entities\Archive;
use App\Entities\Tag;
use App\Repositories\PictureRepository;
use Illuminate\Database\Eloquent\Collection;
use Rinvex\Repository\Repositories\EloquentRepository;

class TagRepository extends EloquentRepository
{
    protected $repositoryId = 'rinvex.repository.tag';
    protected $cacheLifetime = 0;

    public static $tagMap = [
        'plan' => '游戏策划',
        'art' => '游戏美术',
        'vr' => 'VR&AR',
        'program' => '游戏开发',
        'audio' => '游戏音频',
        'project' => '项目管理',
        'yunying' => '游戏运营',
        'test' => '游戏测试'
    ];

    /**
     * 获取标签对应的文档
     *
     * @param Tag $tag
     * @param array $where
     * @param null $page
     * @param string $orderBy
     * @param null $perPage
     * @return Collection
     */
    public function getArchiveList(Tag $tag, $where = [], $page = null, $orderBy = 'hot', $perPage = 20)
    {
        $param = array_merge(['id' => $tag->id], compact('where', 'perPage', 'page', 'orderBy'));

        return $this->executeCallback(get_called_class(), __FUNCTION__, $param, function () use ($tag, $where, $orderBy, $perPage) {
            $archives = $tag->archives();
            $archives->with('user');
            foreach ($where as $key => $value) {
                $archives->where($key, $value);
            }
            $archives->orderBy($orderBy == 'hot' ? 'hot_score' : 'id', 'desc');

            return $archives->simplePaginate($perPage);
        });
    }

    /**
     * 获取标签对应所有文档的id
     *
     * @param Tag $tag
     * @param array $where
     * @return Collection
     */
    public function getArchivesId(Tag $tag, $where = [])
    {
        $param = ['id' => $tag->id, 'where' => $where];

        return $this->executeCallback(get_called_class(), __FUNCTION__, $param, function () use ($tag, $where) {
            $archives = $tag->archives();
            foreach ($where as $key => $value) {
                $archives->where($key, $value);
            }

            return $archives->get(['gad_archives.id'])->pluck('id');
        });
    }

    /**
     * 磨坊3D标签文章接口
     *
     * @param Tag $tag
     * @param null $page
     * @param int $perPage
     * @return mixed
     */
    public function getArchiveListForMofang(Tag $tag, $page = null, $perPage = 50)
    {
        $param = ['api' => 'mofang', 'tagId' => $tag->id, 'page' => $page, 'perPage' => $perPage];

        return $this->executeCallback(get_called_class(), __FUNCTION__, $param, function () use ($tag, $perPage, $page) {
            $archives = $tag->archives();
            $archives->with('user', 'article');
            $archives->where('class_id', Archive::TYPE_ARTICLE);
            $archives->orderBy('id', 'desc');

            return $archives->paginate($perPage, ['gad_archives.id', 'title', 'description', 'cover', 'tag',
                'publish_time', 'user_id'], 'page', $page);
        });
    }

    /**
     * 获取某标签的相关标签
     *
     * @param Tag $tag
     * @param int $count
     * @return \Illuminate\Support\Collection
     */
    public function getRelateTags(Tag $tag, $count = 6)
    {
        // 若为一级标签，直接取热门标签
        if (!$tag->p) {
            return $this->getHotTags($count);
        }

        $tags = $this->getSiblingTags($tag, 4);
        if ($tag->lvl == 4) {
            $parents = $this->findWhereIn(['id', [$tag->p3, $tag->p2]]);
            $tags = $tags->merge($parents);
        } elseif ($tag->lvl == 3) {
            $parents = $this->findWhereIn(['id', [$tag->p2, $tag->p1]]);
            $tags = $tags->merge($parents);
        } elseif ($tag->lvl == 2) {
            $tags->add($this->find($tag->p1));
        }

        // 不够数用热门标签填充
        if ($tags->count() < 6) {
            $padding = $this->getHotTags($count - $tags->count());
            $tags = $tags->merge($padding);
        }

        return $tags->unique('id');
    }

    /**
     * 获取某标签的兄弟标签
     *
     * @param $tag
     * @param $count
     * @return \Illuminate\Support\Collection|mixed
     */
    public function getSiblingTags($tag, $count)
    {
        $siblings = $this->findWhere(['p', '=', $tag->p]);
        $siblings = $siblings->reject(function ($item) use($tag) {
            return $tag->id == $item->id;
        });

        if ($siblings->count() >= $count) {
            $random = $siblings->random($count);
            if ($random instanceof Tag) {
                $random = new Collection([$random]);
            }

            return $random;
        }

        // 递归获取父级元素兄弟节点
        $parent = $this->find($tag->p);
        $parentSiblings = $this->getSiblingTags($parent, $count - $siblings->count());
        $siblings = $siblings->merge($parentSiblings);

        return $siblings;
    }

    /**
     * 获取热门标签
     *
     * @param int $limit
     * @return \Illuminate\Support\Collection
     */
    public function getHotTags($tag = '', $limit = 20)
    {
        $map = [
            'plan' => '10001',
            'art' => '10396',
            'vr' => '10877',
            'program' => '10591',
            'audio' => '11102',
            'project' => '11104',
            'yunying' => '10168'
        ];
        $model = $this->where('is_hot', 1);
        if($tag && isset($map[$tag])){
            $model = $this->where('p1', $map[$tag]);
        }
        return $model->limit($limit)->orderBy('lvl')->findAll(['id', 'name']);
    }

    /**
     * 从标题和内容中获取标签
     *
     * @param $title
     * @param $content
     * @return Collection
     */
    public function findFromTitleContent($title, $content)
    {
        $tags = $this->findAll();
        $tagMatched = [];
        $tagScore = ['title' => [], 'content' => []];
        foreach ($tags as $tag) {
            $regExp = $this->formatRegExp($tag->alias);
            // 从标题里提取标签
            if ($count = preg_match_all($regExp, $title)) {
                if (!isset($tagMatched[$tag->id])) {
                    $tagMatched[$tag->id] = $tag;
                }
                $tagScore['title'][$tag->id] = $count;
            }

            // 从内容里提取标签
            if ($count = preg_match_all($regExp, $content)) {
                if (!isset($tagMatched[$tag->id])) {
                    $tagMatched[$tag->id] = $tag;
                }
                $tagScore['content'][$tag->id] = $count;
            }
        }

        // 提取标题和内容中重合标签，按照匹配次数由高到低排列
        $intersect = array_intersect_key($tagScore['title'], $tagScore['content']);
        $duplicateTagId = array_sort(array_keys($intersect), function ($key) use($tagScore) {
            return max($tagScore['title'][$key], $tagScore['content'][$key]);
        });

        // 提取标题中去重后的标签，按照匹配次数排列
        $titleTag = array_except($tagScore['title'], $duplicateTagId);
        $titleTagId = array_sort(array_keys($titleTag), function ($key) use($tagScore) {
            return $tagScore['title'][$key];
        });

        // 提取内容中去重后的标签，按照匹配次数排列
        $contentTag = array_except($tagScore['content'], $duplicateTagId);
        $contentTagId = array_sort(array_keys($contentTag), function ($key) use($tagScore) {
            return $tagScore['content'][$key];
        });

        $allTagId = array_merge(array_reverse($duplicateTagId), array_reverse($titleTagId), array_reverse($contentTagId));

        $tags = array_map(function ($key) use($tagMatched) {
            return $tagMatched[$key];
        }, $allTagId);

        return new Collection($tags);
    }

    /**
     * 格式化标签别名为正则表达式，单词添加边界匹配
     *
     * @param $tagAlias
     * @return string
     */
    private function formatRegExp($tagAlias)
    {
        $tagAliasArray = explode('/', $tagAlias);
        $regExp = [];
        foreach ($tagAliasArray as $alias) {
            if (preg_match('#\w+#', $alias)) {
                $regExp[] = '\b'.$alias.'\b';
            } else {
                $regExp[] = $alias;
            }
        }

        return '#'.implode('|', $regExp).'#i';
    }

    /**
     * 更新文档某标签的文档数
     *
     * @param Tag $tag
     * @param Archive $archive
     */
    public function updateArchiveCount(Tag $tag, Archive $archive)
    {
        $archiveClass = array_get(['', 'article', 'work', 'question', 'topic'], $archive->class_id, 'article');
        $countKey = 'archive_'.$archiveClass.'_count';
        $attributes = [
            'archive_all_count' => $this->getArchiveCountByType($tag),
            $countKey => $this->getArchiveCountByType($tag, $archive->class_id)
        ];

        $this->update($tag->id, $attributes);
    }

    /**
     * 获取标签下的文章、问答和作品数量
     *
     * @param Tag $tag
     * @param int $type
     * @return mixed
     */
    public function getArchiveCountByType(Tag $tag, $type = 0)
    {
        if ($type == Archive::TYPE_WORKS) {
            // 作品数量，按照图片图片数量
            $archiveId = $this->getArchivesId($tag, ['class_id' => Archive::TYPE_WORKS]);
            $pictureRepository = app(PictureRepository::class);

            return $pictureRepository->getCountByArchive($archiveId->toArray());

        } else {
            // 文章&问答数量
            $archives = $tag->archives();
            if ($type) {
                $archives->where('class_id', $type);
            }

            return $archives->count();
        }
    }

    /**
     * 旧的内容分类和标签映射
     *
     * @param $typeName
     * @return \Illuminate\Database\Eloquent\Model
     */
    private function getTagFromType($typeName)
    {
        $tagTypeMap = [
            ['tag_name' => '数值策划', 'type_name' => '数值'],
            ['tag_name' => '系统策划', 'type_name' => '系统'],
            ['tag_name' => '系统策划', 'type_name' => '玩法'],
            ['tag_name' => '关卡策划', 'type_name' => '关卡'],
            ['tag_name' => '剧情策划', 'type_name' => '剧情'],
            ['tag_name' => '运营策划', 'type_name' => '运营'],
            ['tag_name' => '职业发展', 'type_name' => '新手'],
            ['tag_name' => '原画', 'type_name' => '原画圈'],
            ['tag_name' => '美术新手', 'type_name' => '美术新手圈'],
            ['tag_name' => '3D建模', 'type_name' => '3D美术圈'],
            ['tag_name' => '美术软件', 'type_name' => '技术美术圈'],
            ['tag_name' => '美术动画', 'type_name' => '游戏动画圈'],
            ['tag_name' => '美术特效', 'type_name' => '游戏特效圈'],
            ['tag_name' => '游戏视觉', 'type_name' => '游戏UI'],
            ['tag_name' => '游戏视觉', 'type_name' => '游戏视觉包装圈'],
            ['tag_name' => 'unity', 'type_name' => 'unity3d圈'],
            ['tag_name' => 'Cocos2dx', 'type_name' => 'cocos2d圈'],
            ['tag_name' => 'HTML', 'type_name' => 'html5圈'],
            ['tag_name' => '虚幻引擎', 'type_name' => '虚幻引擎圈'],
            ['tag_name' => '渲染', 'type_name' => '渲染技术圈'],
            ['tag_name' => '游戏开发', 'type_name' => '测试技术'],
            ['tag_name' => 'VR/AR', 'type_name' => 'Ximmerse'],
            ['tag_name' => '游戏开发', 'type_name' => 'Microsoft'],
            ['tag_name' => '游戏美术', 'type_name' => 'H2 学院'],
            ['tag_name' => '游戏开发', 'type_name' => '白鹭引擎'],
            ['tag_name' => 'VR/AR', 'type_name' => '超维星球孵化器'],
            ['tag_name' => 'VR/AR', 'type_name' => 'HTC-VIVE'],
            ['tag_name' => '游戏开发', 'type_name' => 'UWA优化'],
            ['tag_name' => '游戏美术', 'type_name' => 'FZD Films 朱峰影业'],
            ['tag_name' => '游戏美术', 'type_name' => '泰课在线'],
            ['tag_name' => '游戏开发', 'type_name' => '极客学院'],
            ['tag_name' => '游戏美术', 'type_name' => '光子黑板报'],
            ['tag_name' => '游戏策划', 'type_name' => '游戏陀螺'],
            ['tag_name' => '游戏美术', 'type_name' => '研发部美术中心'],
            ['tag_name' => '游戏开发', 'type_name' => 'LayaAir'],
            ['tag_name' => 'VR/AR', 'type_name' => 'UCCVR'],
            ['tag_name' => '游戏美术', 'type_name' => 'ART+'],
            ['tag_name' => '游戏策划', 'type_name' => '项目管理']
        ];

        $tagType = array_first($tagTypeMap, function ($_, $item) use($typeName) {
            return $item['type_name'] == $typeName;
        });
        $tag = $this->findBy('name', $tagType['tag_name']);

        return $tag;
    }
}

