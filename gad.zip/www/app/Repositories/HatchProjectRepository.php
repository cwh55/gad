<?php

namespace App\Repositories;

use App\Entities\ExpertPlan;
use App\Jobs\SendMail;
use Rinvex\Repository\Repositories\EloquentRepository;
use DB;
use Auth;

class HatchProjectRepository extends EloquentRepository
{
    protected $repositoryId = 'rinvex.repository.hatch.project';
    protected $cacheLifetime = 0;

    public function __construct()
    {
    }

    /*
     * $retunrSensitive默认为false，表示不返回敏感信息
     */
    public function getMyList($where, $page, $pageSize, $returnSensitive = false)
    {
        $param = compact('where', 'page', 'pageSize', 'returnSensitive');
        return $this->executeCallback(get_called_class(), __FUNCTION__, $param, function () use ($where, $page, $pageSize, $returnSensitive) {
            $where = is_array($where) ? $where : [];
            $where[] = ['is_finish', '=', 1];
            $model = $this->createModel();
            $list = $model->where($where)->orderBy('id', 'desc')->offset($page * $pageSize)->limit($pageSize)->get();
            if($returnSensitive){
                foreach($list as $li){
                    $li->setVisible([]);
                }
            }
            return $list;
        });
    }

    /**
     * 推送项目邮件给专家
     */
    public function pushMailToExpert()
    {
        // 获取待发送的项目
        $projectList = $this->where('push_email_status', 2)->findAll();
        if (count($projectList) <= 0) return;
        // 获取需要发送的专家
        // 环境区别
        if (app()->isLocal()){
            $newExpert =   new ExpertPlan();
            $newExpert->email = '24147287@qq.com';
            $newExpert->name = '测试专家';
            $expertList[] = $newExpert;
            $newExpert2 =   new ExpertPlan();
            $newExpert2->email = 'sherry520wang@126.com';
            $newExpert2->name = '测试专家2';
            $expertList[] = $newExpert2;

        }else{
            $expertPlanRepository = new ExpertPlanRepository();
            $expertList = $expertPlanRepository->getNeedMailExpert();
        }

        // 加入 邮件队列
        foreach ($expertList as $expert) {
            $mail = view('email.projectPushMail', array('projectList' => $projectList, 'expert' => $expert))->render();
            $title = 'GAD为你推送本周待点评项目(' . count($projectList) . '个)';
            if ($expert->email) dispatch(new SendMail($expert->email, $title, $mail));
        }
        // 更改推送状态
        foreach ($projectList as $project) {
            $project->update(['push_email_status' => 0]);
        }


        return;
    }

    public function getBlogs($project, $type, $page = 0, $pageSize = 20){
        if(in_array($type, [1, 2, 3, 4])){
            $archiveReposotory = app(ArchiveRepository::class);
            $blogs = $archiveReposotory->with(['user'])->where([['project_id', '=', $project->id], ['class_id', '=', $type], ['status', '=', 0]])->orderBy('id', 'desc')->offset($page * $pageSize)->limit($pageSize)->findAll();
        }else if($type == 'live'){
            $userReposotory = app(UserRepository::class);
            $user = $userReposotory->with(['lives'])->find($project->user_id);
            $blogs = $user->teacherLives()->with('teachers.user')->get();
        }else if($type == 'course'){
            $userReposotory = app(UserRepository::class);
            $user = $userReposotory->with(['teacher.user'])->find($project->user_id);
            $blogs = empty($user->teacher) ? [] : $user->teacher->courses->toArray();
            foreach($blogs as &$b){
                $b['user'] = ['UserId'=>$user->UserId, 'Avatar'=>$user->Avatar, 'NickName'=>$user->NickName,'type'=>$user->type];
            }
        }
        return $blogs;
    }
    
    public function getBlogCount($project){
        $counts = [];
        $archives = DB::table('gad_archives')->select(DB::raw('count(1) as cnt, class_id'))->where([['project_id', '=', $project->id], ['status', '=', 0], ['deleted_at', '=', null]])->groupBy('class_id')->get();
        foreach($archives as $r){
            $counts[$r->class_id] = $r->cnt;
        }
        $userReposotory = app(UserRepository::class);
        $user = $userReposotory->with(['lives', 'teacher'])->find($project->user_id);
        $counts['live'] = empty($user) ? 0 : $user->teacherLives->count();
        $counts['course'] = empty($user->teacher) ? 0 : $user->teacher->courses->count();
        return $counts;
    }
    
    public function getNews($project, $type){
        $userReposotory = app(UserRepository::class);
        $user = $userReposotory->find($project->user_id);
        $user = empty($user) ? [] : $user->toArray();
        $news = array();
        if($type == 'hatch'){
            $gameReposotory = app(\App\Models\Game::class);
            $gamess = $gameReposotory->where([['user_id', '=', $project->user_id], ['reg_step', '=', 5]])->get(['created_at', 'id'])->toArray();
            foreach($gamess as $r){
                $news[] = ['created_at'=>$r['created_at'], 'user'=>$user, 'id'=>$r['id'], 'type'=>$type, 'subtype'=>$type];
            }
        }else if($type == 'team'){
            $teamProjectReposotory = app(ProjectRepository::class);
            $projects = $teamProjectReposotory->where('user_id', $project->user_id)->findAll(['created_at', 'id'])->toArray();
            foreach($projects as $r){
                $news[] = ['created_at'=>$r['created_at'], 'user'=>$user, 'id'=>$r['id'], 'type'=>$type, 'subtype'=>'team_project'];
            }
            $teamResumeReposotory = app(ResumeRepository::class);
            $resumes = $teamResumeReposotory->where('user_id', $project->user_id)->findAll()->toArray();
            foreach($resumes as $r){
                $news[] = ['created_at'=>$r['created_at'], 'user'=>$user, 'id'=>$r['id'], 'type'=>$type, 'subtype'=>'team_resume'];
            }
        }
        usort($news, function($a, $b){
            return $a['created_at'] < $b['created_at'];
        });
        return $news;
    }
    
    public function getNewsCount($project){
        $counts = [];
        $gameReposotory = app(\App\Models\Game::class);
        $counts['hatch'] = $gameReposotory->where([['user_id', '=', $project->user_id], ['reg_step', '=', 5]])->count();
        $teamProjectReposotory = app(\App\Entities\Project::class);
        $projectCount = $teamProjectReposotory->where('user_id',  $project->user_id)->count();
        $teamResumeReposotory = app(\App\Entities\Resume::class);
        $resumeCount = $teamResumeReposotory->where('user_id', $project->user_id)->count();
        $counts['team'] = $projectCount + $resumeCount;
        return $counts;
    }

    public function saveProject($params, $id = 0)
    {
        $id = intval($id);
        //是导入，编辑
        if ($id > 0) {
            $project = $this->find($id);
            //判断权限
            if ($project['user_id'] == Auth::user()['UserId']) {
                $result = $this->update($id, $params);
            } else {
                return false;
            }
        } else {    //新建
            $params['user_id'] = Auth::user()['UserId'];
            $result = $this->create($params);
        }
        if ($result[0]) {
            return $result[1]['id'];
        } else {
            return false;
        }

    }
    
    public function deleteProject($id){
        $project = $this->find($id);
        $dict = [1=>'项目扶持', 2=> '晨星计划', 3=>'大赛', 4=>'组队'];
        if($project->created_from_id){
            $type = isset($dict[$project->created_from]) ? $dict[$project->created_from] : '游戏大赛';
            throw new \Exception("该项目已经被关联到{$type}，无法删除");
        }
        if(app(\App\Models\Game::class)->where('project_id', $id)->count()){
            throw new \Exception('该项目已经关联到项目扶持，无法删除');
        }
        if(app(\App\Entities\Project::class)->where('project_id', $id)->count()){
            throw new \Exception('该项目已经关联到组队，无法删除');
        }
        if(app(\App\Entities\HatchGame::class)->where('project_id', $id)->count()){
            throw new \Exception('该项目已经关联到大赛，无法删除');
        }
        $status = $this->delete($id);
        if(!$status){
            throw new \Exception('删除数据失败');
        }
    }
}
