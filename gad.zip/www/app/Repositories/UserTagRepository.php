<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 2017/6/2
 * Time: 15:06
 */

namespace App\Repositories;

use App\Entities\Archive;
use App\Entities\UserTagTag;
use App\Models\User;
use App\Presenters\CommunityPresenter;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;
use Rinvex\Repository\Repositories\EloquentRepository;

class UserTagRepository extends EloquentRepository
{
    protected $repositoryId = 'rinvex.repository.usertag';
    protected $cacheLifetime = 10;

    /**
     * 根据用户标签拉去热门
     * @param $userId
     * @param int $classId
     * @param int $page
     * @param int $pageSize
     * @param string $orderBy
     */
    public function getHotByUserTag($userId,$classId = 0, $page =0, $pageSize =20, $orderBy = 'hot')
    {
        $tagIds = $this->where('user_id',$userId)->findAll();
        //排序映射
        $orderMap =[
            'hot'=>['hot_score','desc'],
            'new'=>['sort_time','desc']
        ];
        if ($tagIds->count() == 0) {
            return collect([]);
        } else {
            $tagIds = array_column($tagIds->toArray(),'tag_id');
            $archives = DB::table('gad_archives')
                ->join('gad_archive_tags','gad_archives.id','=','gad_archive_tags.archive_id')
                ->join('User','User.UserId','=','gad_archives.user_id')
                ->whereIn('gad_archive_tags.tag_id',$tagIds)
                ->where('gad_archives.is_hot',1)
                ->where('gad_archives.status',0)
                ->where('gad_archives.deleted_at','=', null)
                ->where('gad_archives.sort_time', '>', strtotime('-9 month'));
            if ($classId > 0) {
                $archives->where('gad_archives.class_id',$classId);
            }
            $archives = $archives->orderBy('gad_archives.'.$orderMap[$orderBy][0],'DESC')
                ->offset($page*$pageSize)
                ->limit($pageSize+1)
                ->select('gad_archives.*','User.Avatar','User.NickName','User.type as user_type')
                ->distinct()
                ->get();
            $presenter = new CommunityPresenter();
            foreach ($archives as $archive) {
                $archive->avatar = !$archive->Avatar ? 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg' : $archive->Avatar;
                if ($archive->extra) {
                    $archive->extra = json_decode($archive->extra, true);
                }
                $archive->tags = explode(',', $archive->tag);
                if($archive->class_id == \App\Entities\Archive::TYPE_WORKS || $archive->class_id == \App\Entities\Archive::TYPE_ARTICLE) {
                    $archive->created_at = $archive->publish_time;
                }
                $archive->format_comment_count = $presenter->formatNumber($archive->comment_count);
                $archive->format_like_count = $presenter->formatNumber($archive->like_count);
                $archive->format_view_count = $presenter->formatNumber($archive->view_count);
                $archive->format_favorite_count = $presenter->formatNumber($archive->favorite_count);
                $archive->user_name = $archive->NickName;
                $archive->user_type = $archive->user_type;
            }
            $archives = collect($archives);
            if ($pageSize+1 == $archives->count()) {
                $archives = $archives->splice(0,$pageSize);
                $archives->hasMorePage = true;
            } else {
                $archives->hasMorePage = false;
            }
            return $archives;
        }

    }

}