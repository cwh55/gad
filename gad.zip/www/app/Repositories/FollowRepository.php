<?php

namespace App\Repositories;

use Illuminate\Database\Eloquent\Collection;
use Rinvex\Repository\Repositories\EloquentRepository;
use Auth;
use DB;

/**
 * Interface FollowRepository
 * @package namespace App\Repositories;
 */
class FollowRepository extends EloquentRepository
{
    protected $repositoryId = 'rinvex.repository.follow';
    protected $cacheLifetime = 0;


    /**
     * 获取我的
     * @param $myId
     * @param int $classId
     * @param int $page
     * @param int $pageSize
     * @param string $orderBy
     * @return \Illuminate\Contracts\Pagination\Paginator
     */
    public function getMyNews($myId, $classId = 0, $page = 0, $pageSize = 20, $orderBy = 'hot')
    {
        $this->where('status',0);
        //过滤文档类型
        if ($classId >0) {
            $this->where('class_id', $classId);
        }
        $pageSize = ($pageSize > 20) ? 20 : $pageSize;

        //排序映射
        $orderMap =[
            'hot'=>['hot_score','desc'],
            'new'=>['id','desc']
        ];
        $this->with(['user']);
        $this->orderBy($orderMap[$orderBy][0], $orderMap[$orderBy][1]);
        $archives = $this->simplePaginate($pageSize, ['*'], 'p', $page);

        return $archives;
    }
    
    public function getFans($userId, $attributes = ['*']){
        return $this->where('follow_user', $userId)->where('status', 0)->findAll($attributes);
    }


    /**
     * 获取推荐关注用户
     * @param $myId
     * @param int $page
     * @param int $pageSize
     * @return \Illuminate\Contracts\Pagination\Paginator
     */
    public function getRecommendUser($page = 1, $pageSize = 4)
    {
        if(Auth::check()) {
            return DB::table('gad_follow_users as a')
                ->join('User as u', 'a.user_id', '=', 'u.UserId')
                ->select('a.*', 'u.NickName', 'u.Avatar' ,'u.type')
                ->where('user_id', '!=', Auth::user()->UserId)
                ->whereNotIn('a.user_id', function($query){
                    $query->select('follow_user')->from('gad_follows')->where('status', '=', 0)->where('user_id', '=', Auth::user()->UserId);
                })
                ->simplePaginate($pageSize,['*'],'p',$page);
        }
    }

    //获取我的关注数
    public function getMyFollowCount($myId)
    {
        return $this->where('user_id', $myId)
            ->where('status', 0)
            ->findAll(['id'])->count();
    }

    //获取我的粉丝数
    public function getMyFansCount($myId)
    {
        return $this->where('follow_user', $myId)
            ->where('status', 0)
            ->findAll(['id'])->count();
    }

    public function getFollowStatus($follow_user){
        // 0 未关注 ， 1 已关注 ， 2 互相关注
        if(!Auth::check()){
            return 0;
        };
        $userId = Auth::user()['UserId'];
        $followRes = $this->where('user_id', $userId)
            ->where('follow_user', $follow_user)
            ->where('status', '=', 0)
            ->findAll()->first();
        if($followRes){
            $beFollowRes = $this->where('user_id', $follow_user)
                ->where('follow_user', $userId)
                ->where('status', '=', 0)
                ->findAll()->first();
            if($beFollowRes)
                return 2;
            return 1;
        }else
            return 0;

    }

    //获取用户关注的列表
    public function getUserFollowList($userId,$page = 1,$pageSize = 20)
    {
        $followList = $this->with(['follower', 'follower.expert'])
            ->where('user_id', $userId)
            ->where('status', 0)
            ->paginate($pageSize, ['*'], 'page', $page);
        $followList->map(function($item){
            if ($item->follower) {
                $item->addHidden(['follower.QQNo']);
                $item->breif = $item->follower->breif;
                $item->type = $item->follower->type;
            }
        });

        return $followList;
    }

    //获取粉丝列表,包含相互关注
    public function getUserFansList($userId, $page = 1, $pageSize = 20)
    {
        $fansList = $this->with(['fansUser','fansUser.expert'])
            ->where('follow_user', $userId)
            ->where('status', '!=', 1)
            ->paginate($pageSize, ['*'], 'page', $page);
        $fansList->map(function($item){
            if ($item->fansUser) {
                $item->addHidden(['fansUser.QQNo']);
                $item->breif = $item->fansUser->breif;
                $item->type = $item->fansUser->type;
            }
        });
        return $fansList;
    }

    /**
     * @param $userId
     * @param $followUsers
     * 获取userId 和 followUsers 人员的关注关系
     */
    public function getFollowRelations($userId, $followUsers)
    {
        return $this->where('user_id', $userId)
                    ->whereIn('follow_user', $followUsers)
                    ->where('status', 0)
                    ->findAll();
    }

    public function getFansRelations($userId, $fansUsers)
    {
        return $this->where('follow_user', $userId)
            ->whereIn('user_id', $fansUsers)
            ->where('status', 0)
            ->findAll();
    }
}
