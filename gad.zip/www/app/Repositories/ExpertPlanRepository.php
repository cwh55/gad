<?php

namespace App\Repositories;

use App\Entities\ExpertPlan;
use DB;
use Rinvex\Repository\Repositories\EloquentRepository;
use Rinvex\Repository\Repositories\ExpertPlanCategoryRepository;

/**
 * Interface ExpertPlanRepository
 * @package namespace App\Repositories;
 */
class ExpertPlanRepository extends EloquentRepository
{
    protected $repositoryId = 'rinvex.repository.expertplan';
    protected $cacheLifetime = 0;
    //

    //晨星活动
    const EXPERT_PLANS_ACTIVITY_TYPE = 13;

    /**
     * 获取晨星计划活动
     * @param int $limit 条数
     * @return \Illuminate\Support\Collection
     */
    public static function getExpertPlansActivity($limit = 3)
    {
        $model = new OperationRepository();
        return $model->where('type', '=', self::EXPERT_PLANS_ACTIVITY_TYPE)
            ->where('status', '=', 0)
            ->limit($limit)->orderBy('position', 'desc')
            ->findAll();

    }


    public function getExpertList($perPage,$order = 'sort')
    {
        $this->where('status', '=', 0)->where('creator', '!=', 115);
        if ($order == 'recommend') {
            $this->orderBy('is_recommend', 'desc');
        } else {
            $this->orderBy('sort', 'asc');
        }
        return $this->paginate($perPage, ['*'], 'page');
    }

    /**
     * 获取最大排序
     * @return mixed
     */
    public function getMaxSort()
    {
        $model = $this->createModel();
        return $model->min('sort');
    }

    /**
     * 向上
     * @param $id
     */
    public function upward($id)
    {
        //
        $row1 = $this->find($id);
        $row2 = $this
            ->where('sort', '<', $row1->sort)
            ->orderBy('sort', 'desc')
            ->limit(1)
            ->findAll();
        //更新排序
        $upSort = $row1->sort;
        $row1->sort = $row2[0]->sort;
        $row2[0]->sort = $upSort;
        $row1->save();
        $row2[0]->save();
        return;
    }

    /**
     * 向上
     * @param $id
     */
    public function down($id)
    {
        $row1 = $this->find($id);
        $row2 = $this
            ->where('sort', '>', $row1->sort)
            ->orderBy('sort', 'asc')
            ->limit(1)
            ->findAll();
        //更新排序
        $upSort = $row1->sort;
        $row1->sort = $row2[0]->sort;
        $row2[0]->sort = $upSort;

        $row1->save();
        $row2[0]->save();
        return;

    }


    /**
     * 获取去最大晨星首页 专家配置排序
     * @return mixed
     * @throws \Rinvex\Repository\Exceptions\RepositoryException
     */
    public function getMaxIsRecommend()
    {
        $model = $this->createModel();
        return $model->max('is_recommend');
    }
    /**
     * 晨星首页 专家配置 向上
     * @param $id
     */
    public function upwardHomePage($id)
    {
        //
        $row1 = $this->find($id);


        $row2 = $this
            ->where('is_recommend', '>', $row1->is_recommend)
            ->orderBy('is_recommend', 'asc')
            ->limit(1)
            ->findAll();

        if(!$row2->isEmpty()){
            //更新排序
            $upSort = $row1->is_recommend;
            $row1->is_recommend = $row2[0]->is_recommend;
            $row2[0]->is_recommend = $upSort;
            $row1->save();
            $row2[0]->save();
        }
        return;
    }

    /**
     * 晨星首页 专家配置 向下
     * @param $id
     */
    public function downHomePage($id)
    {
        $row1 = $this->find($id);
        $row2 = $this
            ->where('is_recommend', '<', $row1->is_recommend)
            ->where('is_recommend', '>',0)
            ->orderBy('is_recommend', 'desc')
            ->limit(1)
            ->findAll();
        //更新排序

        if (!$row2->isEmpty() ){
            $upSort = $row1->is_recommend;
            $row1->is_recommend = $row2[0]->is_recommend;
            $row2[0]->is_recommend = $upSort;

            $row1->save();
            $row2[0]->save();
        }

        return;

    }
    /**
     * 获取需要发送的专家
     */
    public function getNeedMailExpert()
    {

        //$expertList = $this->where('wish','like','%'.json_encode('晨星顾问团').'%')->findAll();
        $expertList = $this->findAll();
        foreach ($expertList as $expert) {
            if ( isset($expert->wish) && in_array('晨星评审团', $expert->wish)) {
                $data[] = $expert;
            }
        }
        return $data;
    }

}
