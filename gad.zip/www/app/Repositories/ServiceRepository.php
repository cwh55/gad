<?php

namespace App\Repositories;

use Rinvex\Repository\Repositories\EloquentRepository;


class ServiceRepository extends EloquentRepository
{
    //
    protected $repositoryId = 'rinvex.repository.service';
    protected $cacheLifetime = 0;

    public function __constructor(){

    }

    public function getIP(){

    }

    public function getStatus()
    {
        return [1 => '提交需求', 2 => '建立需求单', 3 => '初审中', 4 => '复审中', 5 => '商务沟通', 6 => '签署协议', 7 => '资料准备', 8 => '版号办理', 9 => '入驻场地', 10 => '需求完成', 11 => '需求单取消'];
    }

    public function format($data,$type = 'apply'){
        $res = [];
        foreach($data as $va) {
            $resData = $va;
            if ($type == 'apply') {
                if ($resData->applyMember && $va->applyMember->name) {
                    $resData->apply_logo = $va->applyMember->logo;
                    $resData->apply_intro = $va->applyMember->intro;
                    $resData->apply_team_num = $va->applyMember->team_num;
                    $resData->apply_province = $va->applyMember->province;
                    $resData->apply_city = $va->applyMember->city;
                    $resData->apply_name = $va->applyMember->name;
                }
                if ($resData->provideMember) {
                    $resData->provide_name = $resData->provideMember->name;
                }
                $resData->str_service_type = $this->getType()[$resData->service_type];
                if ($resData->service) {
                    $resData->service->type = $this->getIpType()[$resData->service->type ? 1 : 0];
                    $resData->str_ip_type = $this->getIpType()[$resData->service->ip_type];
                    $resData->str_ip_style = $this->getIpStyle()[$resData->service->ip_style];
                    $range = [];
                    foreach ($resData->service->ip_range as $rangeVal) {
                        $range[] = $this->getIpRange()[$rangeVal];
                    }
                    $resData->range = $range;
                }

                $status = '';
                $val = $resData->status;
                $status = $this->getStatus()[$val];
                $resData->status_progress = $status;
                $resData->created_str = date('Y-m-d H:i', strtotime($resData->created_at));
                unset($resData->applyMember, $resData->provideMember);
            } else {
                //$resData->str_type = $this->getIpType()[$resData->type];
                $resData->str_service_type = $this->getType()[$resData->service_type];
                $resData->str_ip_type = $this->getIpType()[$resData->ip_type];
                $resData->str_ip_style = $this->getIpStyle()[$resData->ip_style];
                $range = [];
                foreach ($resData->ip_range as $rangeVal) {
                    $range[] = $this->getIpRange()[$rangeVal];
                }
                $resData->str_range = $range;
            }

            $res[] = $resData;
        }
        return $res;
    }

    public function updateService($id, $data){
        $this->update($id, $data);
        return true;
    }

    public function save($data){
        $this->create($data);
        return true;
    }

    public function getType(){
        return [1 => 'Ip', 2 => '版号', 3 => '办公场地', 4 => '投融资', 5 => '发行'];
    }

    public function getIpList($service_type,$service_style,$service_range,$orderBy, $city, $page,$pageSize){
        return $this->getListByType(1,$service_type,$service_style,$service_range,$orderBy,$city,$page,$pageSize);
    }

    public function getIpDetail($id){
        $data = $this->with(['member'])->where('id',$id)->findAll()->first();
        return $data;
    }

    public function getIpRange(){
        return [0 => '全部', 1 => '形象', 2 => '音乐', 3 => '场地', 4 => '电影', 5 => '游戏'];
    }

    public function getIpStyle(){
        return [0 => '全部', 1 => '欧美', 2 => '日韩', 3 => '中国古代', 4 => '中国现代', 5 => '其他'];
    }

    public function getIpType(){
        return [0 => '全部', 1 => '影视', 2 => '动漫', 3 => '小说', 4 => '其他'];
    }

    public function getListByType($type,$service_type,$service_style,$service_range,$orderBy,$city,$page,$pageSize){
        $query = \DB::table('gad_project_services')->join('gad_project_service_members','gad_project_services.service_member_id','=','gad_project_service_members.id')
            ->where('gad_project_services.service_type',$type);
        if($service_type && in_array($service_type,array_keys($this->getIpType()))) {
            $query = $query->where('ip_type', $service_type);
        }
        if($service_style && in_array($service_style,array_keys($this->getIpStyle()))) {
            $query = $query->where('ip_style', $service_style);
        }
        if($service_range) {
            $query = $query->where('ip_range', 'like', '%' . intval($service_range) . '%');
        }
        if($city != '0') {
            $query = $query->where('city', $city);
        }
        $query = $query->where('gad_project_services.is_show',1);
        $query = $query->where('gad_project_services.status',0);
        if($orderBy == 'new'){
            $query = $query->orderBy('gad_project_services.id','desc');
        } else {
            $query = $query->orderBy('view_count','desc');
        }
        $list = $query->select(\DB::raw('gad_project_services.*'),'gad_project_service_members.name as member_name')->paginate($pageSize);//$this->with(['member'])->paginate($pageSize);

        return $list;
    }

}
