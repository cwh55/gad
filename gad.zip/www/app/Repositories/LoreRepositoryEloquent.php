<?php

namespace App\Repositories;

use Auth;
use App\Entities\Lore;
use Gate;
use Illuminate\Container\Container as Application;
use Prettus\Repository\Criteria\RequestCriteria;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Repository\Traits\CacheableRepository;
use Request;
use App\Gad\Midas;

/**
 * Class LiveRepositoryEloquent
 * @package namespace App\Repositories;
 */
class LoreRepositoryEloquent extends BaseRepository implements LoreRepository
{
    //use CacheableRepository;


    public function __construct(
        Application $app ,
        LoreTeacherRepositoryEloquent $loreTeachers ,
        LoreSectionRepositoryEloquent $loreSections,
        ContentClassRepositoryEloquent $contentClass,
        LiveOrderRepositoryEloquent $order
    )
    {
        parent::__construct($app);

        $this->loreTeachers = $loreTeachers;
        $this->loreSections = $loreSections;
        $this->contentClass = $contentClass;
        $this->order = $order;
    }

    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Lore::class;
    }

    /**
     * Boot up the repository, pushing criteria
     */
    public function boot()
    {
        $this->pushCriteria(app(RequestCriteria::class));
    }

    public function getDetail($id)
    {   
        $lore = $this->find($id);
    	$teachers = $this->loreTeachers->findTeachersByString($lore->teachers);
        //拉取推荐的小节或者是最新的4节
        if(empty($lore->related))
            $recommend_sections = $this->contentClass->getNewestContents(4);
        else
            $recommend_sections = $this->contentClass->findContentsByString($lore->related);
        

        $lore->recommend_sections = $recommend_sections;
    	$lore->teachers = $teachers;

        //获取用户学习信息
        if(Auth::check()){
            $learns = $lore->learns->where('user_id',Auth::user()->UserId);
            if($learns->count() == 0)
                $lore->userLearn = '';
            else{
                $lore->userLearn = $learns->first();
            }
        }

        return $lore;
    }

    public function buy($lore, $user, $type = 'mobile')
    {
        if ($lore->price == 0) {
            return ['code' => 0, 'buy' => 'free'];
        }

        $price = $lore->price * 10;
        $goods = [
            'payitem' => $lore->id.'*'.$price.'*1',
            'goodsmeta' => str_limit(trim($lore->title), 60).'*'.str_limit(trim(str_replace(PHP_EOL, '', $lore->intro)), 60),
            'goodsurl' => $lore->pay_pic ? $lore->pay_pic : 'https://gad.qpic.cn/assets/web/img/live/goods.jpg',
            'amt' => $price
        ];

        $result = $type === 'mobile' ? Midas::mBuyGoods($goods) : Midas::buyGoods($goods);
        if ($result['code'] == 0) {
            $this->order->create([
                'obj_id' => $lore->id,
                'obj_type' => 'App\Entities\Lore',
                'user_id' => $user->UserId,
                'amt' => $lore->price,
                'token' => $result['buy']['token']
            ]);

        }

        return $result;
    }

    public function isPayed($loreId) {
        if (!Auth::check()) {
            return false;
        }
        $order = $this->order->findWhere([
            'user_id'=>Auth::user()->UserId,
            'obj_id'=>$loreId,
            'obj_type'=>'App\Entities\Lore',
            'state'=>1
        ])
            ->first();
        return $order ? true :false;
    }

}
?>