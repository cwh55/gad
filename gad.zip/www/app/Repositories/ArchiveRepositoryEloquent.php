<?php

namespace App\Repositories;

use App\Entities\Picture;
use Illuminate\Support\Facades\Cache;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Criteria\RequestCriteria;
use App\Entities\Archive;
use App\Entities\Answer;

/**
 * Class ArchiveRepositoryEloquent
 * @package namespace App\Repositories;
 */
class ArchiveRepositoryEloquent extends BaseRepository implements RepositoryInterface
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Archive::class;
    }


    /**
     * Boot up the repository, pushing criteria
     */
    public function boot()
    {
        $this->pushCriteria(app(RequestCriteria::class));
    }

    //获取社区首页内容库-根据类型(管理端)
    public function getListByType(Array $arr, $pageSize = 30)
    {
        $article_type = $arr["article_type"];

        if ($arr["type"] < 5) {
            $contentlist = $this->model->with('user')->where("gad_archives.class_id", $arr["type"]);
        } else {
            $contentlist = $this->model->onlyTrashed()->with('user'); //回收站只查已删除的数据
        }

        if ($arr["type"] == 1) {
            if ($article_type != -1) {
                $contentlist->whereHas('article', function ($query) use ($article_type) {
                    $query->where('gad_articles.type', $article_type);
                });
            }
        }

        $id = intval($arr["id"]);
        if ($id > 0) {
            $contentlist->where('gad_archives.id', $id);
        }

        $userid = intval($arr['userid']);
        if ($userid > 0) {
            $contentlist->where('gad_archives.user_id', $userid);
        }

        $channel_id = intval($arr['channel_id']);
        if ($channel_id > 0) {
            $contentlist->where('gad_archives.channel_id', $channel_id);
        }

        $user_name = $arr['name'];
        if (!empty($user_name)) {
            $contentlist->whereHas('user', function ($query) use ($user_name) {
                $query->where('User.NickName', 'like', "%$user_name%");
            });
        }

        $qq = $arr['qq'];
        if (!empty($qq)) {
            $contentlist->whereHas('user', function ($query) use ($qq) {
                $query->where('User.QQNo', 'like', "%$qq%");
            });
        }

        $ques = $arr['title'];
        if (!empty($ques)) {
            $contentlist->where('gad_archives.title', 'like', "%" . $ques . "%");
        }

        $status = intval($arr['status']);
        if ($status != -1) {
            $contentlist->where('gad_archives.status', $status);
        }

        $is_hot = intval($arr['is_hot']);
        if ($is_hot != -1) {
            $contentlist->where('gad_archives.is_hot', $is_hot);
        }

        $is_top = intval($arr['is_top']);
        if ($is_top != -1) {
            $contentlist->where('gad_archives.is_top', $is_top);
        }

        $begin_time = $arr['begin_time'];
        $end_time = $arr['end_time'];

        if (!empty($begin_time) && !empty($end_time)) {
            $contentlist->where("created_at", '>=', $begin_time)->where("created_at", '<=', $end_time);
        }

        $picture_type = $arr['picture_type'];
        if (!empty($picture_type)) {
            $ids = Picture::where("type", $picture_type)->select("archive_id")->groupBy("archive_id")->get()->toArray();
            $contentlist->whereIn('id', $ids);
        }

        if ($arr["type"] <= 4) {
            $entry = $contentlist->orderBy('gad_archives.id', 'desc');
        } else {
            $entry = $contentlist->orderBy('gad_archives.deleted_at', 'desc');
        }

        $data = $entry->paginate($pageSize);

        foreach ($data as $key => $item) {
            // $data[$key]["QQNo"] = $item->user->getOriginal('QQNo');
            $data[$key]["QQNo"] = $item->user["QQNo"];
            $data[$key]["isDel"] = $item->getOriginal('deleted_at');
            $data[$key]["sortTime"] = intval($item->getOriginal('sort_time'));
            $data[$key]["publish_time"] = $item->getOriginal('created_at');

            if ($arr["type"] == 4) {
                $answerlist = Answer::where("archive_id", $item->id)->select("id")->get();
                $data[$key]["child_comment_count"] = Answer::whereIn("answer_id", $answerlist)->where("status", 0)->count();
            }
        }

        $host = app()->isLocal() ? 'http://dev.gad.qq.com' : 'http://gad.qq.com';
        return response()->json(['data' => $data, 'msg' => 'success', 'code' => '0', 'hostname' => $host]);
    }


    public function getList($class_id = null, $channel_id = null, $page = 0, $pageSize = 20, $orderType = 'hot')
    {
        $this->applyCriteria();
        $this->applyScope();
        $this->model = $this->model->where('status', '=', 0);
        if ($class_id > 0) {
            $this->model = $this->model->where('class_id', '=', intval($class_id));
        }
        if ($channel_id > 0) {
            $this->model = $this->model->where('channel_id', '=', intval($channel_id));
        }
        if (!$pageSize) {
            $pageSize = 20;
        }
        $list = $this->model->with('user');
        if ($orderType == 'hot') {
            $list = $list->orderBy('hot_score', 'desc');
        } else {
            $list = $list->orderBy('id', 'desc');
        }
        $list = $list->skip($page * $pageSize)->take($pageSize)->get();
        $this->resetModel();
        foreach ($list as $li) {
            if ($li->user) {
                $li->avatar = $li->user->getAvatar();
            } else {
                $li->avatar = 'http://gad.qpic.cn/assets/v2/web/img/global/default_headpic.jpg';
            }
        }
        return $this->parserResult($list);
    }

    //获得一个随机数组
    private function getRandomArray($size = 5)
    {
        $arr = [];
        for ($i = 0; $i < $size; $i++) {
            $arr[] = $i;
        }
        for ($i = 0; $i < $size; $i++) {
            $r = round(rand(0, $size - 1));
            $temp = $arr[$i];
            $arr[$i] = $arr[$r];
            $arr[$r] = $temp;
        }
        return $arr;
    }

    //随机获取最近的5篇文章，但排除id等于exclusive_id的
    public function getRecentByUser($user_id, $exclusive_id = 0)
    {
        $all = $this->model->with('user')->where('status', '=', 0)->where('user_id', '=', $user_id)->orderBy('id', 'desc')->take(10)->get();
        $list = array();
        foreach ($all as $a) {
            if ($a->id != $exclusive_id) {
                $list[] = $a;
                if (count($list) >= 5) {
                    break;
                }
            }
        }
        shuffle($list);
        $this->resetModel();
        return $list;
    }
}
