<?php

namespace App\Gad;

use Exception;
use GuzzleHttp\Client;
use Tencent\CL5\Client as CL5;

class Tgd
{
    /**
     * 根据登录用户信息创建TGD认证token
     *
     * @param $user
     * @return array
     * @throws Exception
     */
    public static function getToken($user)
    {
        $url = sprintf('http://%s/auth/token/generate', static::getHost());
        $client = new Client(['timeout' => 10, 'auth' => ['gad', 'gad666'], 'http_errors' => false]);
        $response = $client->request('GET', $url, [
            'query' => [
                'platformId' => 100003,
                'user' => $user
            ]
        ]);
        if ($response->getStatusCode() != 200) {
            throw new Exception('TGD token接口请求失败：'.$response->getReasonPhrase());
        }
        $body = $response->getBody();
        $result = json_decode($body);
        if ($result === null) {
            throw new Exception('TGD token接口请求返回异常：'.$body);
        }

        return $result;
    }

    /**
     * 获取TGD用户信息
     *
     * @param $id
     * @return mixed
     * @throws Exception
     */
    public static function getUser($id)
    {
        $url = sprintf('http://%s/auth/token/user', static::getHost());
        $client = new Client(['timeout' => 10, 'auth' => ['gad', 'gad666'], 'http_errors' => false]);
        $response = $client->request('GET', $url, [
            'query' => ['id' => $id]
        ]);
        if ($response->getStatusCode() != 200) {
            throw new Exception('TGD拉取用户信息接口请求失败：'.$response->getReasonPhrase());
        }
        $body = $response->getBody();
        $result = json_decode($body);
        if ($result === null) {
            throw new Exception('TGD拉取用户信息接口请求返回异常：'.$body);
        }

        if ($result->code) {
            throw new Exception('TGD拉取用户信息接口：'.$result->message);
        }

        return $result;
    }

    /**
     * 获取TGD server IP
     *
     * @return string
     */
    protected static function getHost()
    {
        $tgd = config('tgd');
        $config = [
            'modId' => $tgd['cl5_mod_Id'],
            'cmdId' => $tgd['cl5_cmd_Id'],
            'default' => ['hostIp' => '10.123.20.93', 'hostPort' => 80]
        ];
        $server = CL5::getRoute($config, app()->isLocal());

        return $server['hostIp'].':'.$server['hostPort'];
    }
}