<?php

namespace App\Gad;

use GuzzleHttp\Client;

class Upload
{
    public static function image($file)
    {
        $client = new Client();
        $response = $client->request('POST', 'http://file.tig.oa.com/mod/GadAo.php', [
            'multipart' => [
                [
                    'name' => 'Filedata',
                    'filename' => $file->getClientOriginalName(),
                    'contents' => fopen($file->getPathname(), 'r')
                ]
            ]
        ]);

        if ($response->getStatusCode() != 200) {
            return ['code' => 1, 'message' => '上传图片时出错'];
        }

        $body = (string) $response->getBody();
        if (starts_with($body, 'http://gameweb-img.qq.com')) {
            return ['code' => 0, 'url' => $body];
        }

        return ['code' => 1, 'message' => strip_tags($body)];
    }

    public static function file($file)
    {
        $client = new Client();
        $response = $client->request('POST', 'http://file.tig.oa.com/mod/FileAo.php', [
            'multipart' => [
                ['name' => 'systemId', 'contents' => 'cfs'],
                ['name' => 'uploader', 'contents' => ''],
                [
                    'name' => 'Filedata',
                    'contents' => fopen($file -> getRealPath(), 'r'),
                    'filename' => $file->getClientOriginalName()
                ]
            ]
        ]);

        if ($response->getStatusCode() != 200) {
            return ['code' => 1, 'message' => '上传文件时出错'];
        }

        $body = (string) $response->getBody();

        return ['code' => 0, 'url' => $body];
    }

    public static function doc2Html($file)
    {
        $client = new Client();
        $response = $client->request('POST','http://office.gad.oa.com/richtext/Doc2htmlV2?1=1&domain=qq.com',[
            'multipart' =>[
                [
                    'name' => 'file',
                    'contents' => fopen($file->getPathname(),'r'),
                    'filename' => $file->getClientOriginalName()
                ]

            ]
        ]);

        if ($response->getStatusCode() != 200) {
            return ['code' => 1,'message' => 'word 导入失败'];
        }

        $body = (string) $response->getBody();
        return ['code' => 0, 'content' => $body];

    }

    /**
     * 上传文件到cos
     * @param $module 业务模块名，如course
     * @param $file
     * @return array|bool|mixed
     */
    public static function uploadQcloudCos($module,$file)
    {
        $filePath = $file ->getPathname();
        $fileName = $file ->getClientOriginalName();
        $result = QcloudApi::upload($module, $fileName,$filePath);
        return $result;
    }

    public static function getPreviewDoc($uploadRet)
    {
        return QcloudApi::getDoc($uploadRet);
    }

    /**
     * 上传图片到优图
     * @param $file
     * @return array
     */
    public static function uploadQcloudImage($file)
    {

        $filePath = $file->getPathname();
        $fileName = $file->getClientOriginalName();
        return QcloudApi::uploadImage($fileName,$filePath);
    }

    public static function  hideFileServer($url)
    {
        $url = str_replace("http://file.tig.oa.com/download/cfs", "server1", $url);
        $url = str_replace("http://file.tig.oa.com", "server3", $url);
        return str_replace("http://office.gad.oa.com/uploads/richtext", "server2", $url);


    }

    public static function  showFileServer($url)
    {
        $url = str_replace("server1", "http://file.tig.oa.com/download/cfs", $url);
        $url = str_replace("server3", "http://file.tig.oa.com", $url);
        return str_replace("server2", "http://office.gad.oa.com/uploads/richtext", $url);
    }

	public static function getFile($url, $fileName=null)
    {
        $fileName = empty($fileName) ? basename($url) : $fileName;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
        $content = curl_exec($ch);
        if (curl_errno($ch)) {
            echo curl_error($ch);
            curl_close($ch);
        } else {
            curl_close($ch);
            //获得文件大小
            $file_size = strlen($content);
            //通知浏览器下载文件
            header("Content-type:application/force-download");
            header("Content-Disposition:attachment;filename=".urlencode($fileName));
            header('Content-Length: '.$file_size);
            exit($content); //输出数据流
        }
    }


}