<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-12-13
 * Time: 上午11:17
 */

namespace App\Gad;

use Auth;

class Tlog
{
    const TLOG_CONFIG_PATH = '/data/www/www.gad.qq.com/app/Gad/GadService.xml';
    const TLOG_CAT = 'GadService';
    const TLOG_ID = 1;
    //表ID
    const TB_DATA_STAT = 1;

    //操作类型,浏览
    const OP_TYPE_READ = 1;
    //操作类型,发表
    const OP_TYPE_PUBLISH = 2;
    //操作类型,评论
    const OP_TYPE_COMMENT = 3;
    //操作类型,回复
    const OP_TYPE_REPLY = 4;
    //操作类型,点赞
    const OP_TYPE_UP = 5;
    //操作类型,收藏
    const OP_TYPE_COLLECT = 6;
    //操作类型,注册
    const OP_TYPE_REGISTER = 7;
    //操作类型，修改
    const OP_TYPE_Edit = 8;

    //日志的资源类型 回复,相对业务独立的字段，在Content ShowType的基础上添加
    //数据库中 Content ShowType '展示类型(1:文章,2:论坛,3:视频,4:微辩论,5:里程碑,6:资源,7:圏子作品,8:圈子点评,9:新游评长评,10:短评,11:游戏解说)',
    //日志独立使用自己的资源类型，Content字段的资源类型从数据库中提取，‘回复’等 不在content showtype中的的此定义
    const  RES_TYPE_ARTICLE = 1;
    const  RES_TYPE_WENDA = 2;
    const  RES_TYPE_COURSE = 3;
    const  RES_TYPE_ARGUE = 4;
    const  RES_TYPE_STONE = 5;
    const  RES_TYPE_RESOURCE = 6;
    const  RES_TYPE_GROUP_RESOURCE = 7;
    const  RES_TYPE_GROUP_RESOURCE_DP = 8;
    const  RES_TYPE_GAME_COMMENT_LONG = 9;
    const  RES_TYPE_GAME_COMMENT_SHORT = 10;
    const  RES_TYPE_GAME_JIE_SHUO = 11;
    //组件
    const RES_TYPE_TOOL = 101;
    //游戏项目
    const RES_TYPE_GAME_PROJECT = 102;
    //线上专题 讲座
    const RES_TYPE_SOLON_JZ = 153;
    //线上专题 培训
    const RES_TYPE_SOLON_PX = 154;
    //线上专题 沙龙
    const RES_TYPE_SOLON_SL = 155;
    //线上专题 会议
    const RES_TYPE_SOLON_HY = 156;
    //线上专题 校园行
    const RES_TYPE_SOLON_XYX = 157;
    //线上专题 大赛
    const RES_TYPE_SOLON_DS = 158;

    //回复
    const RES_TYPE_REPLY = 301;
    //独游坊
    const RES_TYPE_DUYOU = 302;
    //评论
    const RES_TYPE_COMMENT = 303;
    //新游评长评;同ContentShowType
    const RES_TYPE_LONG_GAME_COMMENT = 9;
    //新游评短评
    const RES_TYPE_SHORT_GAME_COMMENT = 10;
    //项目对应worker表
    const RES_TYPE_WORK = 303;
    //大赛
    const RES_TYPE_BIG_MATCH = 304;


    private  $initSuccess =false;
    private  $tLog;
    private  static $_instance =null;

    function __construct() {
        $this->initSuccess = false;
        $this->init();
    }

    function __destruct() {
        if($this->initSuccess) {
            if(extension_loaded('tgamelog') && config('app.server_environment') == 'idc' ){
                try{
                    tlog_fini($this->tLog);
                }catch(Exception $e){

                }
            }

        }
    }

    public static function  getInstance(){
        if(!self::$_instance){
            self::$_instance=new self();
        }
        return self::$_instance;
    }

    //初始化，tlog实例
    private function init($conf_path=null) {

        if(!$conf_path){
            $conf_path = config('app.tlog_config');
        }
        if(!$this->initSuccess) {
            if(extension_loaded('tgamelog') && config('app.server_environment') == 'idc'){
                try{
                    $this->tLog = tlog_init($conf_path);
                }
                catch (Exception $e){

                }
            }
            if($this->tLog) {
                $this->initSuccess = true;
            }
        }
        return $this->initSuccess;
    }

    /**
     * @param $tLogArr 日志数组信息，数组中的顺序要和表的列顺序保持一致
     * @param $cls 表明id
     * @return int
     */
    public function write($tLogArr, $cls) {

        if(!$this->initSuccess || empty($tLogArr)) {
            return -1;
        }
        $logStr = implode('|', $tLogArr);
        try{
            return tlog_info($this->tLog, self::TLOG_CAT, self::TLOG_ID, $cls, $logStr);
        }catch(Exception $e){
            return -1;
        }
    }

    /**
     * 写字符串日志
     * @param $logStr
     * @param $cls
     * @return int
     */
    public function writeStr($logStr,$cls){
        if(!$this->initSuccess || empty($tLogArr)) {
            return -1;
        }
        try{
            return tlog_info($this->tLog, self::TLOG_CAT, self::TLOG_ID, $cls, $logStr);
        }catch(Exception $e){
            return -1;
        }
    }

    /**
     * 列名:dtEventTime|iIsIdc|sSessionId|szUrlDst|szUrlSrc|iVisitMode|iBrowser|iModeId|iGroupId|iSubGroupId|iResourceType|iResourceId|iOpType|sUid|iUid|iUin|szIp|iEventId|sExt
     * @param $log array（ key->value）
     * @return bool
     */
    public function writeTbDataStat($log){
        $cols=[
            'dtEventTime',
            'iIsIdc',
            'sSessionId',
            'szUrlDst',
            'szUrlSrc',
            'iVisitMode',
            'iBrowser',
            'iModeId',
            'iGroupId',
            'iSubGroupId',
            'iResourceId',
            'iResourceType',
            'iOpType',
            'sUid',
            'iUid',
            'iUin',
            'szIp',
            'iEventId',
            'sExt'
        ];
        if(empty($log)){
            return false;
        }
        $baseInfo =$this->getClientInfo();
        $sortLog = [];
        $sortLog[] = 'DataStat';
        foreach($cols as $item){
            if(array_key_exists($item,$log)){
                $sortLog[] = $log[$item];
            }
            else if(array_key_exists($item,$baseInfo)){
                $sortLog[] = $baseInfo[$item];
            }
            else {
                $sortLog[] = '';
            }
        }

        return $this->write($sortLog,self::TB_DATA_STAT);

    }

    /**
     * 主要写入点击数据
     * @param $log
     * @return bool|int
     */
    public function writeTbGadStat($log)
    {
        $cols=[
            'dtEventTime',
            'iIsIdc',
            'sSessionId',
            'szUrlDst',
            'szUrlSrc',
            'iVisitMode',
            'iBrowser',
            'iModeId',
            'iEventId',
            'iObjId',
            'iObjType',
            'sUid',
            'iUid',
            'iUin',
            'szIp',
            'sExt',
            'iGroupId'
        ];
        if(empty($log)){
            return false;
        }
        $baseInfo =$this->getClientInfo();
        $sortLog = [];
        $sortLog[] = 'GadStat';
        foreach($cols as $item){
            if(array_key_exists($item,$log)){
                $sortLog[] = $log[$item];
            }
            else if(array_key_exists($item,$baseInfo) and $baseInfo[$item] != null){
                $sortLog[] = $baseInfo[$item];
            }
            else {
                $sortLog[] = '';
            }
        }

        return $this->write($sortLog,self::TB_DATA_STAT);
    }

    /**
     * 获取访问者的基本信息
     */
    public function getClientInfo(){
        $clientInfo = array();
        //获取浏览器类型
        $clientInfo['iBrowser'] = $this->getBrowserTypeByUserAgent(array_get($_SERVER,'HTTP_USER_AGENT'));
        $clientInfo['szIp'] = array_get($_SERVER,'REMOTE_ADDR');
        //获取sessionid
        $clientInfo['sSessionId'] =array_get($_COOKIE,'gadsid');
        $clientInfo['szUrlDst'] ="http://". array_get($_SERVER,'HTTP_HOST').array_get($_SERVER,'REQUEST_URI');
        $clientInfo['szUrlSrc'] = array_get($_SERVER,'HTTP_REFERER');
        $clientInfo['iIsIdc'] = config('app.server_environment') == 'idc'? 0:1;
        $clientInfo['dtEventTime'] = date('Y-m-d H:i:s');
        $clientInfo['sUid'] = array_get($_COOKIE,'gaduid');
        //当前用户信息
        $user = Auth::user();
        $clientInfo['iUid'] = array_get($user,'UserId',0);
        $clientInfo['iUin'] = array_get($user,'QQNo','');
        $clientInfo['iGroupId'] = 0;
        $clientInfo['iSubGroupId'] = 0;

        return $clientInfo;
    }

    /**
     * 获取浏览器类型
     * @param $userAgent
     * @return int
     */
    public function getBrowserTypeByUserAgent($brower){
        if (preg_match('/Chrome/',$brower)) {
            $bid = 1;
        } elseif (preg_match('/QQBrowser/',$brower)) {
            $bid = 2;
        } elseif (preg_match('/Firefox/',$brower)) {
            $bid = 3;
        } elseif (preg_match('/MSIE\s9\.0/',$brower)) {
            $bid = 4;
        } elseif (preg_match('/MSIE\s8\.0/',$brower)) {
            $bid = 5;
        } elseif (preg_match('/MSIE\s7\.0/',$brower)) {
            $bid = 6;
        } elseif (preg_match('/MSIE\s6\.0/',$brower)) {
            $bid = 7;
        } elseif (preg_match('/MetaSr/',$brower)) {
            $bid = 8;
        } elseif (preg_match('/360SE/',$brower)) {
            $bid = 9;
        } elseif (preg_match('/Opera/',$brower)) {
            $bid = 10;
        } elseif (preg_match('/Safari/',$brower)) {
            $bid = 11;
        } elseif (preg_match('/baidu/',$brower)) {
            $bid = 12;
        } elseif (preg_match('/Maxthon/',$brower)) {
            $bid = 13;
        } elseif (preg_match('/Green/',$brower)) {
            $bid = 14;
        } elseif (preg_match('/TheWorld/',$brower)) {
            $bid = 15;
        } else {
            $bid = 0;
        }
        return $bid;

    }


} 