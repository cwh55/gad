<?php
/**
 * Created by PhpStorm.
 * User: sheltonliu
 * Date: 2016/9/6
 * Time: 14:49
 */

namespace App\Gad;

use GuzzleHttp\Client;

class TofService
{
    //tof 接口签名
    public static function get_sig_header() {
        $appKey = '16658dd8922f46b78dfabdd78504f93d';
        $sysId = '21667';
        $rand = mt_rand(1,999999);
        $time = time();

        $key = substr($sysId . '--------', 0, 8);
        $text = "random{$rand}timestamp{$time}";

        $pad = 8 - (strlen($text) % 8);
        $text = $text . str_repeat(chr($pad), $pad);

        return array(
            'appkey:'. $appKey,
            'random:'. $rand,
            'timestamp:'. $time,
            'signature:'. strtoupper(bin2hex(mcrypt_encrypt(MCRYPT_DES, $key, $text, MCRYPT_MODE_CBC, $key))),
        );
    }

    private static function post($url, $data, $header = array()) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $header,
            CURLOPT_POSTFIELDS => $data
        ));
        return curl_exec($ch);
    }
    //发送短信
    public static function sendSms($receiver,$msg){
        if(empty($receiver) || empty($msg))
            return ['code' => 1, 'message' => '出错'];
        $headers = self::get_sig_header();
        $params = array(
            'MsgInfo' =>$msg,
            'Receiver' => $receiver,
            'Priority' => 1,
            'Sender' => 'gad'
        );
        $idc = config('app.server_environment');
        if ($idc == 'idc') {
            $response = self::post('http://oss.api.tof.oa.com/api/v1/Message/SendSMS',$params,$headers);
        }
        else {
            $response = self::post('http://oss.api.tof.oa.com/api/v1/Message/SendSMS',$params,$headers);
        }
        if ($response) {
            $response = \GuzzleHttp\json_decode($response,true);
        }

        if($response['Ret'] != 0){
            return ['code' => 1, 'message' => '出错'];
        }
        return ['code' => 0,'message' => '成功'];
    }
}