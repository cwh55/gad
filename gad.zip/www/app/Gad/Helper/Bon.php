<?php

namespace App\Gad\Helper;
class Bon {

	protected $child = array();
	
	const START_TAG = 0x02;
	const END_TAG = 0x03;
	const MID_TAG = 0x2;
	
	public function addChild(BonChild $obj)
	{
		$this->child[$obj->getName()] = $obj;
	}
	
	public function getChild($name)
	{
		return $this->child[$name];
	}
	
	public function toArray()
	{
		$obj = array();
		foreach ($this->child as $key => $value) {
			$obj[$key] = $value->getArrayValue();
		}
		return $obj;
	}
	
	/**
	 * 
	 * @param string $package
	 * @return Bon
	 */
	public static function decodeFromPackage($string)
	{
		$packageLength = strlen($string);
		$startTag = self::decodeChar($string);
		$totalLength = self::decodeUInt32($string);
		$reserve = self::decodeReserve($string);
		$midTag = self::decodeUInt32($string);
		$fieldCount = self::decodeUInt32($string);
		$bon = new Bon();
		for($i=0;$i<$fieldCount;$i++)
		{
			$name = self::decodeLVString($string);
			$type = self::decodeChar($string);
			$buffer = self::decodeLVBuffer($string);
			$child = BonChild::decode($name, $type, $buffer);
			$bon->addChild($child);
		}
		return $bon;
	}
	
	public function pack()
	{
		//		头 + 包体 + 0x03
		//		头 = 0x02 + 包长(uint32_t) + 保留8字节 + 0x2(uint32_t) + 字段数(uint32_t)
		//		包体 = 字段 + 字段 + .....
		//		字段 = 字段名长度(uint32_t) + 字段名(字符串'0'结尾) + 字段类型(char) + 字段内容长度(uint32_t) + 字段内容
		
		$body = $this->encodeBody();
		$bodyLength = strlen($body);
		$length = 1 + 4 +8 + 4 + 4 + $bodyLength + 1;
		$all = self::encodeChar(self::START_TAG);
		$all .= self::encodeUINT32($length) . self::encodeReserve() . self::encodeUINT32(self::MID_TAG);
		$all .= self::encodeUINT32(count($this->child));
		$all .= $body;
		$all .= self::encodeChar(self::END_TAG);
		return $all;
	}
	
	
	public function encodeBody()
	{
		//		字段 = 字段名长度(uint32_t) + 字段名(字符串'0'结尾) + 字段类型(char) + 字段内容长度(uint32_t) + 字段内容
		$result = '';
		foreach ($this->child as $obj)
		{
			/**
		 	* @var $obj BonChild
		 	*/
			$ret = self::encodeLVString($obj->getName());
			$ret .= self::encodeChar($obj->getType());
			$encodeValue = $obj->getEncodeValue();
			$ret .= self::encodeUINT32(strlen($encodeValue));
			$ret .= $encodeValue;
			$result.=$ret;
		}
		return $result;
	}
	
	public static function decodeBinary($bin)
	{
		return $bin;
	}
	
	public static function encodeBinary($bin)
	{
		return $bin;
	}
	
    public static function encodeChar($char){
        return pack('c',$char);
    }
    
    public static function encodeReserve()
    {
    	return pack('a8','');
    }
    
	public static function decodeReserve(&$string,$mod=true)
	{
		$len = strlen($string);
		if($len<8)
		{
			throw new Exception("need 8 bytes , $len bytes provide");
		}
		$ret = unpack('a8', $string);
		if($mod){
            $string = substr($string, 8);
        }
        return $ret[1];
	}
    
	public static function decodeChar(&$string,$mod=true){
        $len = strlen($string);
        if($len<1)
        {
            throw new Exception("need 1 bytes , $len bytes provide");
        }
        $ret = unpack('c', $string);
        if($mod){
            $string = substr($string, 1);
        }
        return $ret[1];
    }
    
    public static function encodeObject(Bon $obj)
    {
    	return $obj->pack();
    }
    
    /**
     * @param string $buffer
     * @return Bon
     */
	public static function decodeObject($buffer)
    {
    	return Bon::decodeFromPackage($buffer);
    }
	
	public static function encodeUINT32($int)
	{
		$tmpStr = base_convert($int, 10, 16);
        $len = strlen($tmpStr);
        if($len > 8)
        {
            $tmpStr = substr($tmpStr, -8, 8);
        }else if($len < 8){
            $tmpStr = str_pad($tmpStr, 8,'0',STR_PAD_LEFT);
        }
		$tmpStr = self::changeSide($tmpStr);
        return pack('h8', $tmpStr);
	}
	
	public static function decodeUInt32(&$string,$mod=true)
    {
        $len = strlen($string);
        if($len<4)
        {
            throw new Exception("need 4 bytes , $len bytes provide");
        }
        $aa = unpack('h8', $string);
        if($mod){
            $string = substr($string, 4);
        }
        $tmpStr = self::changeSide($aa[1]);
        return strval(hexdec($tmpStr));
    }
	
	public static function encodeInt32($int){
        $tmpStr = dechex($int);
        $len = strlen($tmpStr);
        if($len > 8)
        {
            $tmpStr = substr($tmpStr, -8, 8);
        }else if($len < 8){
            $tmpStr = str_pad($tmpStr, 8,'0',STR_PAD_LEFT);
        }
		$tmpStr = self::changeSide($tmpStr);
        return pack('h8', $tmpStr);
    }
    
	public static function decodeInt32(&$string,$mod=true)
    {
        $len = strlen($string);
        if($len<4)
        {
            throw new Exception("need 4 bytes , $len bytes provide");
        }
        $aa = unpack('h8', $string);
        if($mod){
            $string = substr($string, 4);
        }
		$tmpStr = self::changeSide($aa[1]);
        $x = hexdec($tmpStr);
        if ($x > (float)2147483647) {
            $x -= (float)"4294967296";
            return intval($x);
        }else{
            return intval($x);
        }
    }
	
	public static function encodeUINT64($int)
	{
		$tmpStr = base_convert($int, 10, 16);
        $len = strlen($tmpStr);
        if($len > 16)
        {
            $tmpStr = substr($tmpStr, -16, 16);
        }else if($len < 16){
            $tmpStr = str_pad($tmpStr, 16,'0',STR_PAD_LEFT);
        }
		$tmpStr = self::changeSide($tmpStr);
        return pack('h16', $tmpStr);
	}
	
	public static function decodeUInt64(&$string,$mod=true)
    {
        $len = strlen($string);
        if($len<8)
        {
            throw new Exception("need 8 bytes , $len bytes provide");
        }
        $aa = unpack('h16', $string);
        if($mod){
            $string = substr($string, 8);
        }
        $tmpStr = self::changeSide($aa[1]);
        return strval(hexdec($tmpStr));
    }
    
    
	public static function encodeLVString($string)
    {
        $length = strlen($string)+1;
        return self::encodeUINT32($length) . pack('a*', $string."\0");
    }
    
    
	public static function decodeLVString(&$string,$mod=true)
    {
        $length = self::decodeUInt32($string);
        $len = strlen($string);
        if($len<$length)
        {
            throw new Exception("need $length bytes , $len bytes provide");
        }
        if($length>0){
            $ret = unpack('C'.$length, $string);
            if($mod){
                $string = substr($string, $length);
            }
            $ret = self::chars2str($ret);
            //去掉\0
            $ret = substr($ret, 0 , $length-1);
            return $ret;
        }
        return '';
    }
    
	public static function encodeString($string)
    {
    	return pack('a*', $string."\0");
    }
    
    public static function decodeString($string)
    {
    	$a = strlen($string);
    	$ret = unpack('a*',$string);
    	$str = $ret[1];
    	return $str;
    }
    
    public static function decodeLVBuffer(&$string,$mod=true)
    {
    	$length = self::decodeUInt32($string);
        $len = strlen($string);
        if($len<$length)
        {
            throw new Exception("need $length bytes , $len bytes provide");
        }
        if($length>0){
            $ret = substr($string, 0, $length);
            if($mod){
                $string = substr($string, $length);
            }
            return $ret;
        }
        return '';
    }
    
	private static function chars2str($array){
        $ret = array();
        foreach ($array as $ele){
            $ret[]= chr($ele);
        }
        return implode('', $ret);
    }
    
    private static function changeSide($str)
    {
    	return strrev($str);
    	/*
    	$tmp = array();
    	$length = strlen($str);
    	for($i=$length-2;$i>=0;$i-=2)
    	{
    		$tmp[]= substr($str, $i ,2);
    	}
    	return implode('', $tmp);
    	*/
    }
	
}

?>
