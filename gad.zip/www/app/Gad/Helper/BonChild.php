<?php

namespace App\Gad\Helper;
class BonChild {
	
        const BYTE_TYPE = 0x01 ;
        const INT32_TYPE = 0x02;
        const UINT32_TYPE = 0x03;
        const INT64_TYPE = 0x04;
        const UINT64_TYPE = 0x05;
        const DOUBLE_TYPE = 0x06;
        const CSTRING_TYPE = 0x07;
        const BINARY_TYPE = 0x08;
        const OBJECT_TYPE =0x09;
        const ARRAY_TYPE = 0x10;
        const NIL_TYPE = 100;
	
	
	protected $name;
	protected $type;
	protected $value;
	
	/**
	 * @return the $name
	 */
	public function getName() {
		return $this->name;
	}

	/**
	 * @return the $type
	 */
	public function getType() {
		return $this->type;
	}

	/**
	 * @return the $value
	 */
	public function getValue() {
		return $this->value;
	}
	
	public function getArrayValue()
	{
		if($this->getType()==self::OBJECT_TYPE)
		{
			return $this->getValue()->toArray();
		}
		return $this->getValue();
	}
	
	public function getEncodeValue()
	{
		$ret = '';
		switch ($this->getType())
		{
			case self::BYTE_TYPE:
				$ret = Bon::encodeChar($this->getValue());
				break;
			case self::INT32_TYPE:
				$ret = Bon::encodeInt32($this->getValue());
				break;
			case self::UINT32_TYPE:
				$ret = Bon::encodeUINT32($this->getValue());
				break;
			case self::UINT64_TYPE:
				$ret = Bon::encodeUINT64($this->getValue());
				break;
			case self::BINARY_TYPE:
				$ret = Bon::encodeBinary($this->getValue());
				break;
			case self::CSTRING_TYPE:
				$ret = Bon::encodeString($this->getValue());
				break;
			case self::OBJECT_TYPE:
				$ret =  Bon::encodeObject($this->getValue());
				break;
		}
		return $ret;
	}

	/**
	 * @param field_type $name
	 */
	public function setName($name) {
		$this->name = $name;
	}

	/**
	 * @param field_type $type
	 */
	public function setType($type) {
		$this->type = $type;
	}

	/**
	 * @param field_type $value
	 */
	public function setValue($value) {
		$this->value = $value;
	}

	public function __construct($name,$type,$value)
	{
		$this->setName($name);
		$this->setType($type);
		$this->setValue($value);
	}
	
	/**
	 * 
	 * @param string $name
	 * @param char $type
	 * @param string $string
	 * @return BonChild
	 */
	public static function decode($name,$type,$string)
	{
		$value = null;
		switch ($type)
		{
			case self::BYTE_TYPE:
				$value = Bon::decodeChar($string,false);
				break;
			case self::INT32_TYPE:
				$value = Bon::decodeInt32($string,false);
				break;
			case self::UINT32_TYPE:
				$value = Bon::decodeUInt32($string,false);
				break;
			case self::UINT64_TYPE:
				$value = Bon::decodeUInt64($string,false);
				break;
			case self::BINARY_TYPE:
				$value = Bon::decodeBinary($string);
				break;
			case self::CSTRING_TYPE:
				$value = Bon::decodeString($string);
				break;
			case self::OBJECT_TYPE:
				$value = Bon::decodeObject($string);
				break;
		}
		return new BonChild($name, $type, $value);
	}

}
?>
