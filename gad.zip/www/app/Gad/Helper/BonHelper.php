<?php

namespace App\Gad\Helper;

use \App\Gad\Helper\Bon, \App\Gad\Helper\BonChild;
use \Tencent\CL5\Client;
class BonHelper{

	var $commBon = null;
	var $iCmd = 4;
	var $iAppID = 1900007;
	var $password = 'otwfpNYarWQn';
	var $username = 'tianxia';

	public function __construct(){
	}

	public function hasBadword($data){
		if(env('SERVER_ENVIRONMENT') == "dev"){
			return false;
		}
		$this->commBon = new Bon();
		$this->commBon->addChild(new BonChild('iCmd', BonChild::INT32_TYPE, $this->iCmd));
		$this->commBon->addChild(new BonChild('uiAppID', BonChild::UINT32_TYPE, $this->iAppID));
		$this->commBon->addChild(new BonChild('strPassword', BonChild::CSTRING_TYPE, $this->password));
		$this->commBon->addChild(new BonChild('strUserName', BonChild::CSTRING_TYPE, $this->username));
		$this->commBon->addChild(new BonChild('uiResAddrType', BonChild::UINT32_TYPE, 1));
		$this->commBon->addChild(new BonChild('uiResPort', BonChild::UINT32_TYPE, 0));
		$this->commBon->addChild(new BonChild('strResAddr', BonChild::CSTRING_TYPE, ''));
		$this->commBon->addChild(new BonChild('uiSendTime', BonChild::UINT32_TYPE, 0));
		$this->commBon->addChild(new BonChild('uiSeq', BonChild::UINT32_TYPE, 0));
		$this->commBon->addChild(new BonChild('uiUserIP', BonChild::UINT32_TYPE, 0));
		$this->commBon->addChild(new BonChild('ullUin', BonChild::UINT64_TYPE, 0));
		$this->commBon->addChild(new BonChild('binAppEcho', BonChild::BINARY_TYPE, 0));

		$idBon = new Bon();
		$idBon->addChild(new BonChild('strContentID', BonChild::CSTRING_TYPE, $data["contentId"]));		$idBon->addChild(new BonChild('strPostID', BonChild::CSTRING_TYPE, 0));
		$idBon->addChild(new BonChild('strUserID', BonChild::CSTRING_TYPE, 0));

		$contentMsgComm = new Bon();
		$contentMsgComm->addChild(new BonChild('uiPostTime', BonChild::UINT32_TYPE, 0));

		$txtBon = new Bon();
		$txtBon->addChild(new BonChild('strTitle', BonChild::CSTRING_TYPE, $data["title"]));
		$txtBon->addChild(new BonChild('strContent', BonChild::CSTRING_TYPE, $data["content"]));
		$txtBon->addChild(new BonChild('strDesc', BonChild::CSTRING_TYPE, $data["desc"]));

		$contentBon = new Bon();
		$contentBon->addChild(new BonChild('MsgComm', BonChild::OBJECT_TYPE, $contentMsgComm));
		$contentBon->addChild(new BonChild('TxtInfo', BonChild::OBJECT_TYPE, $txtBon));

		$reqBon = new Bon();
		$reqBon->addChild(new BonChild('Comm', BonChild::OBJECT_TYPE, $this->commBon));
		$reqBon->addChild(new BonChild('ID', BonChild::OBJECT_TYPE, $idBon));
		$reqBon->addChild(new BonChild('Content', BonChild::OBJECT_TYPE, $contentBon));
		$reqdata = $reqBon->pack();
		$rspdata = "";

		$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		$config = [
			  'modId' => '64040833',
				'cmdId' => '458752',
				'default' => [
					'hostIp' => '10.209.13.100', 'hostPort' => 10006
				]
		];
		$server = Client::getRoute($config, env('SERVER_ENVIRONMENT') == "dev");
	  $res = socket_connect($socket, $server['hostIp'], $server['hostPort']);
		if ($res === false) {
			$msg = 'socket_connect:'.socket_last_error($socket);
			throw new Exception($msg);
		}
		$res = socket_write($socket, $reqdata, strlen($reqdata));
		if ($res === false) {
			$msg = 'socket_write:'.socket_last_error($socket);
			throw new Exception($msg);
		}
		$data = null;
		$data = socket_read($socket, 1212);
		if(!$data) {
			$data = socket_read($socket, 1212);
			if(!$data) {
				$msg = 'socket_read:'.socket_last_error($socket);
				socket_close($socket);
				throw new Exception($msg);
			}
		}
		socket_close($socket);
		try {
			$rspobj = Bon::decodeFromPackage($data);
		} catch (Exception $e) {
			$msg = $e->getMessage();
			throw new Exception($msg);
		}
		$rsparr = $rspobj->toArray();
		if($rsparr["Res"]["uiResultCode"] != 2){
			return true;
		}
		return false;
	}
}
