<?php

namespace App\Gad;

use Cookie;
use Exception;
use GuzzleHttp\Client as HTTPClient;
use GuzzleHttp\Cookie\CookieJar;
use Request;
use Tencent\CL5\Client as CL5;

class Midas
{
    public static function buyGoods($params)
    {
        $path = '/v3/r/pay/buy_goods';
        $method = 'get';
        $midas = config('midas');
        if (!app()->isLocal()) {
            Request::setTrustedProxies([Request::server('REMOTE_ADDR')]);
        }

        if (session('loginType') == 'qq') {
            $midasSession = ['id' => 'uin', 'type' => 'skey'];
            $openId = intval(str_replace('o', '', Cookie::get('uin')));
            $openKey = Cookie::get('skey');
        } else {
            $midasSession = ['id' => 'hy_gameid', 'type' => 'wc_actoken'];
            $openId = session('openId');
            $openKey = session('accessToken');
        }

        $cookie = [
            'session_id' => $midasSession['id'],
            'session_type' => $midasSession['type'],
            'appip' => Request::server('SERVER_ADDR'),
            'org_loc' => $path
        ];

        $default = [
            'openid' => $openId,
            'openkey' => $openKey,
            'appid' => $midas['app_id'],
            'ts' => time(),
            'pf' => 'website',
            'pfkey' => 'pfkey',
            'max_num' => 1,
            'appmode' => 1,
            'userip' => Request::ip(),
            'format' => 'json'
        ];

        $params = array_merge($default, $params);
        $params['sig'] = static::makeSig($method, $path, $params, $midas['app_secret'].'&');
        $host = static::getPcHost();
        $url = $host.$path;
        $res = static::request($method, $url, $params, $cookie);
        if ($res->ret) {
            return ['code' => $res->ret, 'message' => $res->msg];
        }

        $buy = [
            'appid' => $midas['app_id'],
            'openid' => $openId,
            'openkey' => $openKey,
            'session_id' => $midasSession['id'],
            'session_type' => $midasSession['type'],
            'pf' => 'website',
            'token' => $res->token,
            'goodstokenurl' => rawurldecode($res->url_params)
        ];

        if (app()->isLocal()) {
            $buy['sandbox'] = 1;
        }

        return ['code' => 0, 'buy' => $buy];
    }

    public static function mBuyGoods($params)
    {
        $path = '/v3/r/mpay/buy_goods_m';
        $method = 'get';
        $midas = config('midas');
        if (!app()->isLocal()) {
            Request::setTrustedProxies([Request::server('REMOTE_ADDR')]);
        }

        $cookie = [
            'session_id' => 'hy_gameid',
            'session_type' => 'wc_actoken',
            'appip' => Request::server('SERVER_ADDR'),
            'org_loc' => $path
        ];

        $default = [
            'openid' => session('openId'),
            'openkey' => session('accessToken'),
            'appid' => $midas['app_id'],
            'ts' => time(),
            'pf' => 'wechat-2017-html5-live',
            'pfkey' => 'website',
            'zoneid' => 1,
            'max_num' => 1,
            'appmode' => 1,
            'userip' => Request::ip(),
            'format' => 'json'
        ];

        $params = array_merge($default, $params);
        $params['sig'] = static::makeSig($method, $path, $params, $midas['app_secret'].'&');
        $host = static::getMobileHost();
        $url = $host.$path;
        $res = static::request($method, $url, $params, $cookie);
        if ($res->ret) {
            return ['code' => $res->ret, 'message' => $res->msg];
        }

        $buy = [
            'token' => $res->token,
            'params' => $res->url_params,
            'pf' => $params['pf'],
            '_version' => 'v3',
            'sessionid' => 'hy_gameid',
            'sessiontype' => 'wc_actoken',
            'openid' => $params['openid'],
            'openkey' => $params['openkey'],
            'wxAppid2' => config('weixin.app_id')
        ];

        if (app()->isLocal()) {
            $buy['sandbox'] = true;
        }

        return ['code' => 0, 'buy' => $buy];
    }

    public static function makeSig($method, $path, $params, $secret)
    {
        $str = strtoupper($method).'&'.rawurlencode($path).'&';
        ksort($params);
        $query = [];
        foreach ($params as $key => $val) {
            array_push($query, $key.'='.$val);
        }
        $queryString = join('&', $query);
        $queryString = $str.str_replace('~', '%7E', rawurlencode($queryString));

        $sig = hash_hmac('sha1', $queryString, strtr($secret, '-_', '+/'), true);
        $sig = base64_encode($sig);

        return $sig;
    }

    public static function checkSig($method, $path, $params, $secret)
    {
        $sig = array_get($params, 'sig');
        if ($sig == null) {
            return false;
        }

        unset($params['sig']);

        foreach ($params as $key => $value) {
            $params[$key] = self::encodeValue($value);
        }

        $sigNew =  static::makeSig($method, $path, $params, $secret);

        return $sigNew === $sig;
    }

    private static function encodeValue($value)
    {
        $rst = '';
        $len = strlen($value);
        for ($i=0; $i < $len; $i++) {
            $c = $value[$i];
            if (preg_match ('/[a-zA-Z0-9!\(\)*]{1,1}/', $c)) {
                $rst .= $c;
            } else {
                $rst .= ('%'.sprintf('%02X', ord($c)));
            }
        }

        return $rst;
    }

    private static function request($method, $url, $query, $cookie = [])
    {
        $option = ['timeout' => 5, 'http_errors' => false];
        if ($cookie) {
            $option['cookies'] = CookieJar::fromArray($cookie, parse_url($url, PHP_URL_HOST));
        }

        $client = new HTTPClient($option);
        $response = $client->request(strtoupper($method), $url, ['query' => $query]);
        if ($response->getStatusCode() != 200) {
            throw new Exception('MIDAS接口请求失败：'.$response->getReasonPhrase());
        }
        $result = json_decode($response->getBody());
        if ($result === null) {
            throw new Exception('MIDAS接口返回异常：'.$response->getBody());
        }

        return $result;
    }

    private static function getPcHost()
    {
        $config = [
            'modId' => config('midas.pc_goods_cl5_mod_id'),
            'cmdId' => config('midas.pc_goods_cl5_cmd_id'),
            'default' => ['hostIp' => '10.123.6.71', 'hostPort' => 29999]
        ];
        $server = CL5::getRoute($config, app()->isLocal());

        return sprintf('http://%s:%s', $server['hostIp'], $server['hostPort']);
    }

    private static function getMobileHost()
    {
        $config = [
            'modId' => config('midas.m_goods_cl5_mod_id'),
            'cmdId' => config('midas.m_goods_cl5_cmd_id'),
            'default' => ['hostIp' => '10.175.133.101', 'hostPort' => 80]
        ];
        $server = CL5::getRoute($config, app()->isLocal());

        return sprintf('http://%s:%s', $server['hostIp'], $server['hostPort']);
    }
}