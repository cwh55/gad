<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-6-6
 * Time: 下午5:17
 */

namespace App\Gad;

use App\Qcloud\Cos\Cosapi;
use App\Qcloud\Cos\Conf;
use App\Qcloud\UImage\ImageV2;

class QcloudApi {
    //qcloud bucket name
    const APPID='10045137';
    //bucket
    const BUCKET_NAME='gad';
    //bucket下的目录
    const UPLOAD_DIR='gad';
    static $previewMaps=array(
        'doc_preview'=>array('doc','docx','ppt','pptx','xls','xlsx','rtf'),
        'pdf_preview'=>array('pdf'),
        'txt_preview'=>array('txt')
    );

    /**
     * 上传文件
     */
    static public function upload($moduleName,$filenName,$srcPath,$isSlice=true){
        if(file_exists($srcPath)){
            //在qcloud上的地址
            $dir = date('Ymd');
            $dstPath='/'.$moduleName.'/'.$dir.'/'.uniqid().'.'.self::getFileExtension($filenName);
            if($isSlice){
                $uploadRet = Cosapi::upload_slice($srcPath, self::BUCKET_NAME, $dstPath);
            }else{
                $uploadRet = Cosapi::upload($srcPath, self::BUCKET_NAME,$dstPath);
            }
            return $uploadRet;
        }
        return false;
    }

    /**
     *根据上传后返回的地址获取预览地址
     */
    static public function getDoc($uploadRet){
        $previewResult=array(
            'ret'=>0
        );
        if($uploadRet){
            if($uploadRet['httpcode']==200){
                $url=$uploadRet['data']['resource_path'];
                $fileExt=self::getFileExtension($url);
                $cmd='doc_preview';
                if(in_array($fileExt,self::$previewMaps['doc_preview'])){
                    $cmd='doc_preview';
                }else if(in_array($fileExt,self::$previewMaps['pdf_preview'])){
                    $cmd='doc_preview';
                }else if(in_array($fileExt,self::$previewMaps['txt_preview'])){
                    $cmd='txt_preview';
                }
                $previewUrl=sprintf("http://%s-%s.preview.myqcloud.com%s?cmd=%s&page=#page#",
                    self::BUCKET_NAME,
                    self::APPID,
                    $url,
                    $cmd
                );
                $previewResult['url']=$previewUrl;
            }
        }
        else{
            $previewResult['ret']=-1;
            $previewResult['msg']='no valid';
        }

        return $previewResult;
    }

    /**
     * 生成uid，生成唯一文件名
     */
    static private function getUid(){
        return sprintf('%04x%04x%04x%04x%04x%04x%04x%04x',

            // 32 bits for "time_low"
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),

            // 16 bits for "time_mid"
            mt_rand(0, 0xffff),

            // 16 bits for "time_hi_and_version",
            // four most significant bits holds version number 4
            mt_rand(0, 0x0fff) | 0x4000,

            // 16 bits, 8 bits for "clk_seq_hi_res",
            // 8 bits for "clk_seq_low",
            // two most significant bits holds zero and one for variant DCE1.1
            mt_rand(0, 0x3fff) | 0x8000,

            // 48 bits for "node"
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }

    /**
     * 获取文件后缀名
     * @param $srcfile
     * @return string
     */
    static private function getFileExtension($srcfile){
        return substr($srcfile, strrpos($srcfile, '.')+1);

    }

    /**
     * https://www.qcloud.com/doc/product/227/%E7%AD%BE%E5%90%8D%E7%AE%97%E6%B3%95
     * 资源存储的唯一标识，格式为"/appid/bucketname/用户自定义路径或资源名"，并且需要对其中非'/'字符进行urlencode编码
     * 前面主要用于上传和下载文件
     * 当$fileId 为空字符时生成多次有效签名
     * 当指定$fileId 时，过期时间强制设置为0生成单次有效签名
     * @param int $expireTime
     * @param string $fileId
     * @return string
     */
    static public  function getSign($expireTime =100, $fileId='')
    {
        $expireTime = $fileId != ''? 0: $expireTime;
        $signContent = sprintf(
            "a=%s&b=%s&k=%s&e=%s&t=%s&r=%s&f=%s",
            Conf::APPID,
            Conf::BUCKET_NAME,
            Conf::SECRET_ID,
            time() + $expireTime,
            time(),
            rand(),
            $fileId
        );

        return base64_encode(hash_hmac('SHA1', $signContent, Conf::SECRET_KEY, true).$signContent)."\n";

    }

    /**
     * 将图片上传到腾讯云
     * @param $srcPath
     */
    static public function uploadImage($filenName,$srcPath)
    {
        if (file_exists($srcPath)) {
            $imgName=date('Ymd').'/'.uniqid().'.'.self::getFileExtension($filenName);
            $ret = ImageV2::upload($srcPath,'gadimg',$imgName);
            return $ret;
        }

    }

    /**
     *获取缩略图
     * @param $url
     * @param $w （图片宽度，最大或最小宽度）
     * @param $h （图片高度，最大或最小高度）
     * @param int $mode 0，1，2，3，4，5。
     *
     * @return string
     */
    static public function getThumbnailImage($url,$w,$h,$mode=0)
    {
        return sprintf("%s?imageView2/%s/w/%s/h/%s",$url,$mode,$w,$h);

    }


    /**
     *获取裁剪图片
     * @param $url
     * @param $x
     * @param $y
     * @param $w
     * @param $h
     * @return string
     */
    static public function getCropImage($url,$x,$y,$w,$h)
    {
        return sprintf("%s?imageMogr2/crop/!%sx%sa%sa%s",$url,$w,$h,$x,$y);
    }


    /**
     * 获取水印图片
     * @param $url
     * @param string $position
     * @return string
     */
    static public function getWaterMarkImage($url,$position="SouthEast")
    {
        //水印图片
        $waterMark = base64_encode("http://gadimg-10045137.image.myqcloud.com/watermark1465784258");
        return sprintf("%s?watermark/1/image/%s/gravity/%s",$url,$waterMark,$position);

    }

} 