<?php

namespace App\Gad;

use Auth;
use Exception;
use GuzzleHttp\Client;
use Tencent\CL5\Client as CL5;

class Mofang
{

    /**
     * 磨坊登录&创建用户
     *
     * @return mixed
     * @throws Exception
     */
    public static function login()
    {
        if (!Auth::check()) {
            throw new Exception('用户未登陆：', 401);
        }

        $user = Auth::user();
        $loginType = session('loginType');
        $tokenResult = Tgd::getToken([
            'uid' => $loginType == 'qq' ? $user->QQNo : $user->WeixinId,
            'source' => $loginType,
            'nickname' => $user->NickName,
            'head_img_url' => $user->Avatar,
            'reg_ip' => $user->ip
        ]);

        if ($tokenResult->code) {
            return ['code' => 1, 'message' => $tokenResult->message];
        }

        $client = static::getHttpClient();
        $url = sprintf('%s/v1/login', static::getHost());
        $response = $client->request('GET', $url, ['query' => ['token' => $tokenResult->data->token]]);
        if ($response->getStatusCode() != 200) {
            throw new Exception('磨坊登录接口请求失败：'.$response->getReasonPhrase());
        }
        $body = $response->getBody();
        $mfLoginResult = json_decode($body);
        if ($mfLoginResult === null) {
            throw new Exception('磨坊登录接口请求返回异常：'.$body);
        }

        if ($mfLoginResult->code != 0) {
            return ['code' => 1, 'message' => $mfLoginResult->message];
        }

        if (!empty($mfLoginResult->result->lkey)) {
            return $mfLoginResult->result;
        }

        return static::registerUser($mfLoginResult->result->rkey, $user);
    }

    /**
     * 磨坊模型创建
     *
     * @param array $files
     * @param $lKey
     * @return mixed
     * @throws Exception
     */
    public static function makeAsset(Array $files, $lKey)
    {
        $client = static::getHttpClient(['headers' => ['x-api-key' => $lKey]]);
        $url = sprintf('%s/v1/asset/', static::getHost());
        $response = $client->request('POST', $url, [
            'json' => ['files' => $files, 'source' => 2]
        ]);
        if ($response->getStatusCode() != 200) {
            throw new Exception('磨坊模型创建接口请求失败：'.$response->getReasonPhrase());
        }

        $body = $response->getBody();
        $result = json_decode($body);
        if ($result === null) {
            throw new Exception('磨坊模型创建接口请求返回异常：'.$body);
        }

        if ($result->code != 0) {
            throw new Exception($result->message);
        }

        return $result->result;
    }

    /**
     * 获取磨房模型信息
     *
     * @param array $files
     * @param $lKey
     * @return mixed
     * @throws Exception
     */
    public static function getDetail($assetId)
    {
        $client = static::getHttpClient();
        $url = sprintf('%s/v1/asset/%s', static::getHost(), $assetId);
        $response = $client->request('GET', $url);
        if ($response->getStatusCode() != 200) {
            throw new Exception('磨坊模型信息获取接口请求失败：'.$response->getReasonPhrase());
        }

        $body = $response->getBody();
        $result = json_decode($body);
        if ($result === null) {
            throw new Exception('磨坊模型信息获取接口请求返回异常：'.$body);
        }

        if ($result->code != 0) {
            throw new Exception($result->message);
        }

        return $result->result;
    }

    /**
     * 修改模型数据
     *
     * @param $assetId
     * @param $data
     * @param $lKey
     * @return mixed
     * @throws Exception
     */
    public static function updateAsset($assetId, $data, $lKey)
    {
        $client = static::getHttpClient(['headers' => ['x-api-key' => $lKey]]);
        $url = sprintf('%s/v1/asset/%s', static::getHost(), $assetId);
        $response = $client->request('PUT', $url, [
            'json' => $data
        ]);
        if ($response->getStatusCode() != 200) {
            throw new Exception('磨坊模型修改接口请求失败：'.$response->getReasonPhrase());
        }

        $body = $response->getBody();
        $result = json_decode($body);
        if ($result === null) {
            throw new Exception('磨坊模型修改接口请求返回异常：'.$body);
        }

        if ($result->code != 0) {
            throw new Exception($result->message);
        }

        return $result->result;
    }

    /**
     * 磨坊模型转换
     *
     * @param $assetId
     * @param $fbxUrl
     * @param $rKey
     * @return mixed
     * @throws Exception
     */
    public static function convert($assetId, $fbxUrl, $rKey)
    {
        $client = static::getHttpClient(['headers' => ['x-api-key' => $rKey]]);
        $url = sprintf('%s/v1/asset/upload/%s', static::getHost(), $assetId);
        $response = $client->request('POST', $url, [
            'json' => ['fbx_url' => $fbxUrl, 'cos' => true]
        ]);
        if ($response->getStatusCode() != 200) {
            throw new Exception('磨坊模型转换接口请求失败：'.$response->getReasonPhrase());
        }

        $body = $response->getBody();
        $result = json_decode($body);
        if ($result === null) {
            throw new Exception('磨坊模型转换接口请求返回异常：'.$body);
        }

        if ($result->code != 0) {
            throw new Exception($result->message);
        }

        return $result->result;
    }


    /**
     * 磨坊用户信息获取接口
     *
     * @param $id
     * @return mixed
     * @throws Exception
     */
    public static function getAccount($id)
    {
        $client = static::getHttpClient();
        $url = sprintf('%s/v1/account/info/multiget?ids=%s', static::getHost(), $id);
        $response = $client->request('GET', $url);
        if ($response->getStatusCode() != 200) {
            throw new Exception('磨坊用户信息获取接口请求失败：'.$response->getReasonPhrase());
        }

        $body = $response->getBody();
        $result = json_decode($body);
        if ($result === null) {
            throw new Exception('磨坊用户信息信息获取接口请求返回异常：'.$body);
        }

        if ($result->code != 0) {
            throw new Exception($result->message);
        }

        return $result->result[0];
    }

    /**
     * 磨坊注册用户，用户名重复时会自动加随机重试一次
     *
     * @param $rKey
     * @param $user
     * @return mixed
     * @throws Exception
     */
    protected static function registerUser($rKey, $user)
    {
        $nickName = static::filterUserName($user->NickName);
        if ($nickName == '') {
            $nickName = $user->QQNo ? $user->QQNo : 'GAD-'.$user->UserId;
        }

        $result = static::makeAccount($rKey, $nickName);
        if ($result->code == -12) {
            // 用户名重复，添加随机数再注册一次
            $nickName = static::filterUserName($nickName, true);
            $result = static::makeAccount($rKey, $nickName);
        }

        if ($result->code != 0) {
            throw new Exception($result->message);
        }

        return $result->result;
    }

    /**
     * 磨坊用户注册接口
     *
     * @param $rKey
     * @param $nickName
     * @return mixed
     * @throws Exception
     */
    protected static function makeAccount($rKey, $nickName)
    {
        $client = static::getHttpClient();
        $url = sprintf('%s/v1/account/', static::getHost());
        $response = $client->request('POST', $url, [
            'json' => [
                'rkey' => $rKey,
                'nickname' => $nickName,
                'roletype' => 2
            ]
        ]);
        $body = $response->getBody();
        $result = json_decode($body);
        if ($result === null) {
            throw new Exception('磨坊用户注册接口请求返回异常：'.$body);
        }

        return $result;
    }

    /**
     * 过滤用户名，使其符合磨坊的规则：1-30个字符，支持中英文、数字、“_”、减号
     * 可选尾部添加4位随机数
     *
     * @param $name
     * @param bool $suffix
     * @return mixed|string
     */
    protected static function filterUserName($name, $suffix = false)
    {
        $exp = '#[^\x{4e00}-\x{9fa5}\-_a-zA-Z0-9]+#u';
        $name = preg_replace($exp, '', $name);
        if ($suffix) {
            $name = mb_substr($name, 0, 26).rand(1000, 9999);
        } else {
            $name = mb_substr($name, 0, 30);
        }

        return $name;
    }

    /**
     * 获取磨坊主机host
     *
     * @return string
     */
    protected static function getHost()
    {
        if (app()->isLocal()) {
            return 'https://ci.asset.qq.com';
        }

        return 'http://mofang.qq.com';
    }

    /**
     * 获取HTTP客户端实例
     *
     * @param $param
     * @return Client
     */
    protected static function getHttpClient($param = [])
    {
        $config = array_merge(['timeout' => 10, 'http_errors' => false], $param);
        if (app()->environment('production')) {
            $config['proxy'] = [
                'http' => static::getProxy()
            ];
        }

        return new Client($config);
    }

    /**
     * 获取HTTPS代理
     *
     * @return string
     */
    protected static function getProxy()
    {
        $config = [
            'modId' => config('app.https_proxy_cl5_modId'),
            'cmdId' => config('app.https_proxy_cl5_cmdId'),
            'default' => ['hostIp' => '10.213.154.2', 'hostPort' => 8081]
        ];
        $server = CL5::getRoute($config, app()->isLocal());

        return sprintf('tcp://%s:%s', $server['hostIp'], $server['hostPort']);
    }

    public static function getRightType($mtype)
    {
        switch ($mtype) {
            case 'by-nc-nd':
                return 1;
            case 'by-nc-sa':
                return 2;
            case 'by-nc':
                return 3;
            case 'by-nd':
                return 4;
            case 'by-sa':
                return 5;
            case 'by':
                return 6;
            default:
                return 7;
        }
    }
}