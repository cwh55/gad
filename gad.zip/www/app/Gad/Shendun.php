<?php
/**
 * Description of Shendun
 *
 * @author xingsongpan
 * 参照：http://km.oa.com/group/25898/articles/show/307553?kmref=knowledge
 */

namespace App\Gad;

use Auth;

class Shendun {
    const VIEW = 101; //曝光 
    const CLICK = 102; //点击 
    const DOWNLOAD = 103; //下载 
    const READ = 104; //阅读 
    const PLAY = 105; //播放 
    const SHARE = 106; //转发/分享
    const LIKE = 107; //点赞
    const COMMENT = 108; //评论
    const PAY = 109; //支付
    const COLLECT = 110; //收藏
    const SEARCH = 111; //搜索
    const FOLLOW = 112; //关注
    const REPLY = 113; //回复
    const INSTALL = 114; //安装
    const OPEN = 115; //打开
    const CANCEL_COLLECT = 116; //取消收藏
    const ADD_CART = 117; //加入购物车
    const REMOVE_CART = 118; //从购物车删除
    const COLLECT_MALL = 119; //收藏店铺
    const CANCEL_COLLECT_MALL = 120; //收藏店铺
    const CANCEL_FOLLOW = 122; //取消关注
    const BUY = 123; //购买
    const CANCEL_BUY = 124; //取消购买
    
    /**
     * 上报数据
     * @param type $item_id 
     * @param type $item_type
     * @param type $action_id
     * @param type $action_value
     * @param type $optionals
     * @throws \Exception
     */
    public function report($item_id, $item_type, $action_id, $action_value, $optionals = []) {
        $config = config('shendun');
        $user = Auth::User();
        $default = [
            'uid' => $user->UserId, //string,app唯一用户ID
            'imei' => null, //string,设备号 IOS对应IDFA,Android 对应IMEI
            'qq' => $user->QQNo, //int64,qq号
            'wxid' => null, //string,微信号
            'open_id' => $user->WeixinId, //string,微信/qq的openid
            'phone_number' => null, //string,手机号
            'oper_time' => time(), //string,操作时间  操作时间戳	
            //以下为：算法场景信息
            'test_id' => $config['test_id'], //int64,场景ID
            'rule_id' => $config['rule_id'], //int64,算法ID, 用于神盾推荐效果对比，由神盾推荐在线上返回时指定，接入推荐之前，填写0即可	
            'trace_id' => null, //int64,跟踪ID，业务上报时生成，用于跟踪每一次推荐用户产生的所有行为， 举个例子，在一次曝光中，业务生成一个随机的trace_id=123用来标记这次了这次曝光，在这次曝光里面又产生了一次点击行为，这个点击行为的trace_id也使用123，这样就表明了这次点击是从这次曝光产生，不会跟其他的trace_id=456的曝光混淆。	
            //以下为：用户行为信息
            'item_id' => $item_id, //string,物品ID
            'sub_item_id' => null, //string,子物品ID
            'item_type' => $item_type, //string,物品类型
            'action_id' => $action_id, //int64,操作行为ID
            'action_value' => $action_value, //string,操作行为值:操作时长（单位为秒）
            //以下为：上下文信息
            'busi_id' => null, //int64,业务ID
            'page_id' => null, //string,页面ID,区分不同页面；具体数字，如：1001 表示直播首页	
            'module_id' => null, //int64,操作模块ID,如：100102 标识banner	
            'sub_module_id' => null, //int64,操作子模块ID
            'platform' => null, //string,平台,ios：ios平台,android：Android平台,h5：H5
            'device' => null, //string,设备型号,设备型号描述
            'position_id' => null, //string,物品在列表的位置
            'network_type' => null, //string,网络型号,2G：2G网络,3G：3G网络,4G：4G网络,wifi：wifi网络
            'app_version' => null, //string,APP的版本
            'report_source' => null, //int64,上报来源,1安卓终端；2iOS终端；3前端（外部分享页、web)；4后台；5.前端（客户端内）
        ];
        $data = array();
        foreach($default as $k=>$v){
            if(isset($optionals[$k])){
                $default[$k] = $v;
            }
            if($v !== null){
                $data[$k] = $v;
            }
        }
        $clogger = new \CLogger($config['app_id']);
        $ret = $clogger->write_baselog(LT_NORMAL, http_build_query($data), TRUE); //write_baselog($logtype, $data, $dropflag)
        if ($ret != 0) {
            throw new \Exception("ReportDC write err[" . $ret . "] : " . $clogger->get_errmsg());
        }
    }
}