<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-7-20
 * Time: 下午8:05
 */

namespace App\Gad;

use App;
use Tencent\CL5\Client as CL5;
use GuzzleHttp\Client;
use Endroid\QrCode\QrCode;
use Response;

class Func
{
    public static function  getExtensionName ($fileName)
    {
       return pathinfo($fileName,PATHINFO_EXTENSION);
    }

    public static function getPreviewDocs ($attachments)
    {
        $previewDoc = [];
        $attachments = is_array($attachments) ? $attachments : \GuzzleHttp\json_decode($attachments, true);
        foreach ($attachments as $item) {
            if (in_array(self::getExtensionName($item['name']),['ppt','pptx','pdf'])) {
                if(isset($item['url']) && !empty($item['url'])) {
                    $info = explode("newd=", $item['url']);
                    $idInfo = urldecode($info[1]);
                    $url = explode(";", $idInfo);
                    $previewDoc[] = $url;
                }
            }
        }
        return $previewDoc;
    }

	//脏词检查
	public static function hasBadWord($contentId,$content,$desc,$title)
	{
  		$bon = App::make("BonHelper");
  		$data = array("title" => $title, "content" => $content, "desc" => $desc, "contentId" => $contentId);
  		return $bon->hasBadWord($data);
	}

	//生成二维码
	public static function getShare($url,$id){
		$url = url($url,$id);
        $qrCode = new QrCode();
        $response = Response::stream(function () use($qrCode, $url) {
            $qrCode->setText($url)->setSize(125)->setPadding(10)->setErrorCorrection('high')->render();
        }, 200, ['Content-Type' => 'image/png']);

        return $response;
	}

  //img标签alt、title
  public static function imgAltTitle($detail,$alt,$title){
    if(!$detail){
        return '';
    }
    $preg = "/<img.*?src=[\"|\'](.*?)[\"|\'](.*?)>/";
    $img = '<img src="$1" alt="'.$alt.'"title="'.$title.'"$2>';
    $detail = preg_replace($preg,$img,$detail);
    return $detail;
  }

	//获取IP
	public function getIp()
	{
		if(getenv('HTTP_CLIENT_IP')) {
		$onlineip = getenv('HTTP_CLIENT_IP');
		} elseif(getenv('HTTP_X_FORWARDED_FOR')) {
		$onlineip = getenv('HTTP_X_FORWARDED_FOR');
		} elseif(getenv('REMOTE_ADDR')) {
		$onlineip = getenv('REMOTE_ADDR');
		} else {
		$onlineip = $HTTP_SERVER_VARS['REMOTE_ADDR'];
		}
		return $onlineip;
	}

    //获取当前时间距离指定时间间隔的提示
    public static function getPublishTimeTips ($dateTime)
    {

        $timeDiff = time() - strtotime($dateTime) ;
        $hours = $timeDiff / 3600;
        $mins = $timeDiff / 60;
        // 72小时前
        if (($hours - 72) > 0) {
            return date('Y-m-d h:i',strtotime($dateTime));
        }
        // 24 -72 小时内
        if ( (72-$hours) >= 0 && ($hours -24) >= 0) {
            return intval($timeDiff / 86400).'天前';
        }
        // 1-24小时内
        if ( (24 - $hours) > 0 && ($hours -1) >= 0) {
            return intval($timeDiff / 3600). '小时前';
        }
        //5-60分钟内
        if ( (60 - $mins) >0 && ($mins -5) > 0) {
            return intval($timeDiff / 60). '分钟前';
        }

        //1-5分钟内
        return '刚刚';
    }


    /**
     * 系统post接口
     * @return bool
     */
    public static function httpRequest($data, $url='http://msg.gad.qq.com/api', $timeout = 5) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        if ($timeout) {
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        }
        $result = curl_exec($ch);
        $errno   = curl_errno($ch);
        //$errmsg  = curl_error($ch);
        $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return array($errno, $httpCode, $result);
    }

    /**
     * 消息系统调用接口
     * @param SMALLINT $type 消息类型(动态10x/关注20x/系统30x)
     * @param int $user_id  消息所属者id
     * @param int $sender   消息生产者id
     * @param int $obj_id   消息内容id(文章id/问答id/评论id)
     * @param varchar $obj_url  消息链接url
     * @param varchar $obj_content  消息内容
     * @param int $ext_id   附加消息内容id
     * @param varchar $ext_url  附加消息链接
     * @param varchar $ext_content  附加消息内容
     * @return bool
     */
    public static function msgApi($type, $user_id='', $sender='', $obj_id='', $obj_url='', $obj_content='', $ext_id='', $ext_url='', $ext_content='') {
        if(!empty($type) && !empty($user_id) ) {
            $msgArr = array(
                'user_id' => $user_id,
                'type' => $type,
                'sender' => $sender,
                'obj_id' => $obj_id,
                'obj_url' => $obj_url,
                'obj_content' => strip_tags($obj_content),
                'ext_id' => $ext_id,
                'ext_url' => $ext_url,
                'ext_content' => strip_tags($ext_content),
            );

            $msgData = array(
                'system_id' => 'GAD',
                'action' => 'message.insert_message',
                'data' => array('message' => $msgArr),
            );

            $msgCfg = config('msg');
            $config = [
                'modId' => $msgCfg['cl5_mod_Id'],
                'cmdId' => $msgCfg['cl5_cmd_Id'],
                'default' => ['hostIp' => 'msg.gad.qq.com', 'hostPort' => 80]
            ];
            try{
                $server = CL5::getRoute($config, app()->isLocal());
                $url = sprintf('http://%s:%s/api', $server['hostIp'], $server['hostPort']);
            } catch (\Exception $ex) {
                $url = 'http://msg.gad.qq.com/api';
            }

            /*
            $client = new Client(['timeout' => 3]);
            $data = array('json' => $msgData);
            $response = $client->post($url, array(), json_encode($data));
            if ($response->getStatusCode() != 200) {
                throw new Exception('TGD接口请求失败：'.$response->getReasonPhrase());
            }*/

            $result = self::httpRequest(json_encode($msgData), $url);
            $msgResult = json_decode($result[2], true);
            return $msgResult && $msgResult['return'] == 0;
        }

    }

    /**
     * 消息系统调用接口
     * @return bool
     */
    public static function fileApi($access_token, $media_id, $type = 'audio') {
        $msgCfg = config('file');
        $config = [
            'modId' => $msgCfg['cl5_mod_Id'],
            'cmdId' => $msgCfg['cl5_cmd_Id'],
            'default' => ['hostIp' => 'file.gad.qq.com', 'hostPort' => 80]
        ];
        try{
            $server = CL5::getRoute($config, app()->isLocal());
            $url = sprintf('http://%s:%s/api', $server['hostIp'], $server['hostPort']);
        } catch (\Exception $ex) {
            $url = 'http://file.gad.qq.com/api';
        }
        $post = array('action'=>'attachment.get_weixin_file', 'system_id' => 'GAD', 'data'=>array('access_token'=>$access_token, 'media_id'=>$media_id, 'type'=>$type));
        $result = self::httpRequest(json_encode($post), $url);
        $obj = json_decode($result[2], true);
        if(empty($obj)){
            throw new \Exception('文件转存失败：返回为空');
        }elseif($obj['return'] != 0){
            throw new \Exception($obj['details']);
        }else{
            return $obj['data'];
        }
    }

    public static function checkIsPhone ($useragent) {
        return preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4));
    }

    public static function checkIsWeixin ($useragent) {
        return strpos($useragent, 'MicroMessenger') !== false;
    }
}
