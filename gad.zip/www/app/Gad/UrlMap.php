<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 17-3-6
 * Time: 下午2:32
 */

namespace App\Gad;


use App\Entities\Archive;
use App\Entities\ArchiveTag;
use App\Entities\Live;
use App\Entities\Lore;
use App\Entities\LoreSection;
use App\Models\Activity;
use App\Models\Config;
use App\Models\ContentClass;
use App\Models\Course;
use App\Models\Fame;
use App\Models\Lesson;
use App\Models\Question;

class UrlMap
{
    //策划
    const PLAN_ID = 1;
    //美术
    const ART_ID = 2;
    //程序
    const PROGRAME_ID = 3;
    //VR
    const VR_ID = 3595;

    //新社区映射
    static $channelMaps = [
        '1'=>self::PLAN_ID,
        '2'=>self::ART_ID,
        '3'=>self::PROGRAME_ID,
        '4'=>self::VR_ID
        ];

    //首页
    static $INDEX_ID = ['id'=>101, 'label'=>'首页'];

    //圈子
    static $GROUP_ID = ['id'=>102, 'label'=>'圈子'];
    //文章
    static $ARTICLE_ID = ['id'=>1, 'label'=>'文章'];
    //问答
    static $WEN_ID = ['id'=>2, 'label'=>'问答'];
    //分享
    static $COURSE_ID = ['id'=>3, 'label'=>'视频'];
    //直播
    static $ZHI_BO_ID = ['id'=>4,'label'=>'直播'];
    //知识地图
    static $KMAP_ID = ['id'=>5,'label'=>'知识地图'];
    //翻译官
    static $TRANSLATE_ID = ['id'=>6,'label'=>'翻译馆'];
    //项目扶持
    static $HATCH_ID = ['id'=>7,'label'=>'项目扶持'];
    //我问大咖
    static $WENDA_ID = ['id'=>8,'label'=>'我问大咖'];
    //资讯
    static $ZIXUN_ID = ['id'=>9,'lable'=>'资讯'];
    //点评
    static $DINGPING_ID = ['id'=>10,'label'=>'定评'];
    //美术动态
    static $ARTDYNAMIC_ID = ['id'=>11,'label'=>'美术动态'];
    //作品
    static $ART_ID = ['id'=>12,'label'=>'美术作品'];
    //名人堂
    static $FAME_ID = ['id'=>13,'label'=>'名人堂'];
    //独游坊
    static $DUYOUFANG_ID = ['id'=>14,'label'=>'独游坊'];
    //live
    static $LIVE_ID = ['id'=>15,'label'=>'live'];
    //知识体系
    static $LORE_ID = ['id'=>16,'label'=>'知识体系'];
    //组队
    static $TEAM_ID = ['id'=>104, 'label'=>'组队'];
    //活动
    static $ACTIVITY_ID = ['id'=>105, 'label'=>'活动'];
    //组件
    static $COMPONENT_ID = ['id'=>106, 'label'=>'组件'];
    //大赛
    static $MEGAGAME_ID = ['id'=>107, 'label'=>'大赛'];
    //用户中心
    static $USER_ID = ['id'=>108, 'label'=>'用户'];
    //新游评
    static $GAMEREVIEW_ID = ['id'=>109, 'label'=>'新游评'];
    //搜索
    static $SEARCH_ID = ['id'=>110, 'label'=>'搜索'];
    //创建内容
    static $CREATE_ID = ['id'=>111, 'label'=>'创建'];
    //周报
    static $WEEKLY_ID = ['id'=>112, 'label'=>'周报'];
    static $JOIN_WORK_ID = ['id'=>113,'label'=>'扶持作品'];
    //游戏派
    static $GAME_PIE = ['id'=>114,'label'=>'游戏派'];
    //话题
    static $TOPIC = ['id'=>115,'label'=>'话题'];
    //个人中心
    static $USER = ['id'=>116,'label'=>'个人中心'];


    public static function getInstance()
    {
        if(self::$_instance) {
            return self::$_instance;
        }
        self::$_instance = new self();
        return self::$_instance;
    }


    private static $_instance;

    var $channelRule = [
        'plan' => array('id'=>self::PLAN_ID, 'label'=>'策划'),
        'art' => array('id'=>self::ART_ID, 'label'=>'美术'),
        'vr' => array('id'=>self::VR_ID, 'label'=>'VR'),
        'program' => array('id'=>self::PROGRAME_ID, 'label'=>'程序'),
    ];

    var $contentControllers = ['content', 'article'];


    //showtype分类
    var $showTypeRule = [
        '/article/detail' => array('id'=>1, 'label'=>'文章'),
        '/content/wendetail'=>array('id'=>2, 'label'=>'问答'),
        '/content/coursedetail'=>array('id'=>3, 'label'=>'分享'),
        '/content/groupresourcedetail'=>array('id'=>7, 'label'=>'作品'),
        '/content/resourcedetail'=>array('id'=>6, 'label'=>'资源')
    ];

    //模块按照controller分类
    public function moduleRule() {
        return [
            'megagame' => self::$MEGAGAME_ID['id'],
            'activity' => self::$ACTIVITY_ID['id'],
            'tool' => self::$COMPONENT_ID['id'],
            'college' => self::$GROUP_ID['id'],
            'user' => self::$USER_ID['id'],
            'gameforum' => self::$GAMEREVIEW_ID['id'],
            'joins' => self::$TEAM_ID['id'],
            'weekly' =>self::$WEEKLY_ID['id'],
            'lundao'=>self::$ZHI_BO_ID['id'],
            'hatch'=>self::$HATCH_ID['id'],
            'review'=>self::$DINGPING_ID['id'],
            'fame'=>self::$FAME_ID['id'],
            'course'=>self::$ZHI_BO_ID['id'],
            'wenda'=>self::$WENDA_ID['id'],
            'live'=>self::$LIVE_ID['id'],
            'lore'=>self::$LORE_ID['id'],
            'gamepie'=>self::$GAME_PIE['id'],
            'u'=>self::$USER['id'],
            'topic'=>self::$TOPIC['id']
        ];
    }

    //模块action分类
    public function moduleActionRule() {
        return [
            '/content/search' => self::$SEARCH_ID['id'],
            '/art/search' => self::$SEARCH_ID['id'],
            '/article/index' => self::$CREATE_ID['id'],
            '/content/createquestion' => self::$CREATE_ID['id'],
            '/content/editcourse' => self::$CREATE_ID['id'],
            '/content/creategroupresource' => self::$CREATE_ID['id'],
            '/college/index' => self::$GROUP_ID['id'],
            '/college/group' => self::$GROUP_ID['id'],
            '/article/detail' => self::$ARTICLE_ID['id'],
            '/program/wz' => self::$ARTICLE_ID['id'],
            '/program/wen' => self::$WEN_ID['id'],
            '/content/wendetail' => self::$WEN_ID['id'],
            '/program/course' => self::$COURSE_ID['id'],
            '/content/coursedetail' => self::$COURSE_ID['id'],
            '/art/kmap' => self::$KMAP_ID['id'],
            '/vr/translate' => self::$TRANSLATE_ID['id'],
            '/program/translatevie' => self::$TRANSLATE_ID['id'],
            '/program/translate' => self::$TRANSLATE_ID['id'],
            '/program/news' => self::$ZIXUN_ID['id'],
            '/art/artdynamic' => self::$ARTDYNAMIC_ID['id'],
            '/content/groupresourcedetail' => self::$ART_ID['id'],
            '/art/work' => self::$ART_ID['id'],
            '/plan/news' => self::$ZHI_BO_ID['id'],
            '/plan/duyoushow' => self::$DUYOUFANG_ID['id'],
            '/plan/duyoufangdetail' => self::$DUYOUFANG_ID['id'],
            '/plan/game' => self::$GAMEREVIEW_ID['id'],
            '/plan/gameview' => self::$GAMEREVIEW_ID['id']
        ];
    }

    private function urlMapGroupId($tlog,$controller,$action,$objectId,$paramArr)
    {
        switch ($controller) {
            case 'course':
                $course = null;
                if ($action == 'lesson') {
                    $lesson = Lesson::find($objectId);
                    $course = $lesson->course;
                }
                else if (intval($action)) {
                    $course = Course::find($action);
                }
                if ($course) {
                    $tlog['iGroupId'] = $course->first_type_id;
                }
                break;
            case 'lundao':
                if ($action == 'list') {
                    if (array_get($paramArr,'type')) {
                        $tlog['iGroupId'] = array_get($paramArr,'type');
                    }

                } else if ($action == 'detail') {
                    $course = Course::find($objectId);
                    if ($course) {
                        $tlog['iGroupId'] = $course->first_type_id;
                    }
                }
                break;
            case 'fame':
                if ($action == 'detail') {
                    if (intval($objectId)) {
                        $fame = Fame::find($objectId);
                        if ($fame) {
                            $tlog['iGroupId'] = $fame->class;
                        }
                    }
                }
                break;
            case 'wenda':
                if ($action == 'activity') {
                    if (intval($objectId)) {
                        $activity = Activity::find($objectId);
                        if ($activity) {
                            $tlog['iGroupId'] = $activity->module;
                        }
                    }

                } else if ($action == 'detail') {
                    if (intval($objectId)) {
                        $question = Question::find($objectId);
                        if ($question and $question->obj_type == 1) {
                            $activity = Activity::find($question->obj_id);
                            if ($activity) {
                                $tlog['iGroupId'] = $activity->module;
                            }
                        }

                    }
                }
                break;
            case 'lore':
                if (in_array($action,['index','catalog'])) {
                    if (intval($objectId)) {
                        $lore = Lore::find($objectId);
                        if ($lore) {
                            $tlog['iGroupId'] = $lore->type;
                        }
                    }
                } else if ($action == 'detail') {
                    if (intval($objectId)) {
                        $section = LoreSection::find($objectId);
                        if ($section) {
                            $tlog['iGroupId'] = $section->type;
                        }
                    }
                }
                break;
            case 'live':
                if ($action == 'chatroom') {
                    if (intval($objectId)) {
                        $live = Live ::find($objectId);
                        if ($live) {
                            $tlog['iGroupId'] = $live->class;
                        }
                    }
                } else if ($action == 'detail') {
                    if (intval($objectId)) {
                        $live = Live ::find($objectId);
                        if ($live) {
                            $tlog['iGroupId'] = $live->class;
                        }
                    }
                }
                break;
            case 'community':
            case 'article':
            case 'question':
                switch($action) {
                    case 'plan':
                        $tlog['iGroupId'] = self::PLAN_ID;
                        break;
                    case 'art':
                        $tlog['iGroupId'] = self::ART_ID;
                        break;
                    case 'program':
                        $tlog['iGroupId'] = self::PROGRAME_ID;
                        break;
                    case 'vr':
                        $tlog['iGroupId'] = self::VR_ID;
                        break;
                    default:
                        if ($action == 'detail') {
                            $archive = Archive::find($objectId);
                            if ($archive) {
                                $tlog['iGroupId'] = array_get(self::$channelMaps,$archive->channel_id,0);
                            }

                        } else {
                            $tlog['iGroupId'] = 0;
                        }
                }
                break;
            case 'gallery':
                $tlog['iGroupId'] = self::ART_ID;
                break;

        }
        $tlog['iGroupId'] = intval(array_get($tlog,'iGroupId',0));
        return $tlog;
    }
    //入口action
    public function mapTlog($url, $refer = '')
    {

        if(empty($url)) {
            return [];
        }

        //解析url和参数
        $arr = parse_url($url);
        $path = array_get($arr,'path');
        $pathArr = explode('/', $path);
        $params = array_get($arr,'query');
        parse_str($params, $paramArr);

        $tLog = [
            'iOpType'=>1,
            'iGroupId'=>0,
            'iSubGroupId'=>0,
            'iResourceType'=>0,
            'iResourceId'=>0,
            'iModeId'=>0
        ];

        if(!empty($url)) {
            $tLog['szUrlDst'] = $url;
        }
        $tLog['szUrlSrc'] = $refer;
        if (count($pathArr)>=2 and !empty($pathArr[1])) {
            //移动端处理
            if ($pathArr[1] == 'm') {
                $controller = array_get($pathArr,2);
                $action = array_get($pathArr,3);
                $objectId = array_get($pathArr,4,0);
            } else {
                $controller = array_get($pathArr,1);
                $action = array_get($pathArr,2);
                $objectId = array_get($pathArr,3,0);
            }
            //频道子页面
            if (in_array($controller, array_keys($this->channelRule))) {
                $tLog['iGroupId'] = $this->channelRule[$controller]['id'];
            }
            //获取所属圈子
            $tLog = $this->urlMapGroupId($tLog,$controller,$action,$objectId,$paramArr);
            //系统模块解析
            if (in_array($controller, array_keys($this->moduleRule()))) {
                $tLog['iModeId'] = $this->moduleRule()[$controller];
            }
            //系统模块action解析
            if (!empty($controller) && !empty($action)) {
                $conAction = "/$controller/$action";
                if (in_array($conAction,array_keys($this->moduleActionRule()))) {
                    $tLog['iModeId'] = $this->moduleActionRule()[$conAction];
                }
            }

        }
        return $tLog;

    }

} 