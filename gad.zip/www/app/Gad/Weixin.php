<?php

namespace App\Gad;

use GuzzleHttp\Client;
use Illuminate\Support\Str;
use Log;
use Redis;
use RuntimeException;
use Tencent\CL5\Client as CL5;

class Weixin
{
    const ACCESS_TOKEN_KEY = 'weixin:access_token';
    const JSAPI_TICKET_KEY = 'weixin:jsapi_ticket';
    const SUBSCRIBER_KEY = 'weixin:subscriber';
    const SUB_ACCESS_TOKEN_KEY = 'weixin_access_token';
    const SUB_JSAPI_TICKET_KEY = 'weixin:sub_jsapi_ticket';
    const SUB_SUBSCRIBER_KEY = 'weixin:sub_subscriber';

    public static function getAccessToken()
    {
        if ($token = Redis::get(self::ACCESS_TOKEN_KEY)) {
            return $token;
        }

        $query = array(
            'grant_type' => 'client_credential',
            'appid' => config('weixin.app_id'),
            'secret' => config('weixin.app_secret')
        );
        $ret = self::httpGet('/cgi-bin/token', $query);
        if (!isset($ret->access_token)) {
            throw new RuntimeException('获取access_token出错：'.$ret->errmsg);
        }

        if ($token = $ret->access_token) {
            Redis::setex(self::ACCESS_TOKEN_KEY, 7100, $token);
        }

        return $token;
    }

    public static function getSubAccessToken()
    {
        if ($token = Redis::get(self::SUB_ACCESS_TOKEN_KEY)) {
            return $token;
        }

        $query = array(
            'grant_type' => 'client_credential',
            'appid' => config('weixin.sub_app_id'),
            'secret' => config('weixin.sub_app_secret')
        );
        $ret = self::httpGet('/cgi-bin/token', $query);
        if (!isset($ret->access_token)) {
            throw new RuntimeException('获取access_token出错：'.$ret->errmsg);
        }

        if ($token = $ret->access_token) {
            Redis::setex(self::SUB_ACCESS_TOKEN_KEY, 7000, $token);
        }

        return $token;
    }

    public static function getJsApiTicket($isSub = false)
    {
        $key = $isSub ? self::SUB_JSAPI_TICKET_KEY : self::JSAPI_TICKET_KEY;
        if ($ticket = Redis::get($key)) {
            return $ticket;
        }

        $query = array(
            'type' => 'jsapi',
            'access_token' => $isSub ? self::getSubAccessToken() : self::getAccessToken()
        );
        $ret = self::httpGet('/cgi-bin/ticket/getticket', $query);
        if (!isset($ret->ticket)) {
            throw new RuntimeException('获取js_ticket出错：'.$ret->errmsg);
        }

        Redis::setex($key, Redis::ttl($isSub ? self::SUB_ACCESS_TOKEN_KEY : self::ACCESS_TOKEN_KEY), $ret->ticket);

        return $ret->ticket;
    }

    public static function refreshAccessToken($appId, $refreshToken)
    {
        $query = ['appid' => $appId, 'grant_type' => 'refresh_token', 'refresh_token' => $refreshToken];
        $result = self::httpGet('/sns/oauth2/refresh_token', $query);
        if (isset($result->errcode) AND $result->errcode) {
            throw new RuntimeException('刷新微信AccessToken出错：'.$result->errmsg);
        }

        return $result;
    }

    public static function getJsConfig($url, $isSub = false)
    {
        $ticket = self::getJsApiTicket($isSub);
        $nonceStr = self::getRandomStr();
        $timestamp = time();
        $tmpStr = 'jsapi_ticket='.$ticket.'&noncestr='.$nonceStr.'&timestamp='.$timestamp.'&url='.$url;
        $signature = sha1($tmpStr);
        $config = array(
            'debug' => false,
            'appId' => config($isSub ? 'weixin.sub_app_id' : 'weixin.app_id'),
            'timestamp' => $timestamp,
            'nonceStr' => $nonceStr,
            'signature' => $signature,
            'jsApiList' => array('onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareWeibo', 'startRecord', 'stopRecord', 'onVoiceRecordEnd', 'playVoice', 'pauseVoice', 'stopVoice', 'onVoicePlayEnd', 'uploadVoice', 'downloadVoice', 'chooseImage', 'previewImage', 'uploadImage', 'downloadImage', 'translateVoice', 'getNetworkType', 'openLocation', 'getLocation', 'hideOptionMenu', 'showOptionMenu', 'hideMenuItems', 'showMenuItems', 'hideAllNonBaseMenuItem', 'showAllNonBaseMenuItem', 'closeWindow', 'scanQRCode', 'chooseWXPay', 'openProductSpecificView', 'addCard', 'chooseCard', 'openCard')
        );

        return $config;
    }

    public static function getRandomStr($length = 16)
    {
        return strtoupper(Str::random($length));
    }

    public static function redirect($url, $scope = 'snsapi_userinfo', $state = 'user', $isSub = true)
    {
        $query = [
            'appid' => config($isSub ? 'weixin.sub_app_id' : 'weixin.app_id'),
            'redirect_uri' => urldecode($url),
            'response_type' => 'code',
            'scope' => $scope,
            'state' => $state
        ];
        $url = 'https://open.weixin.qq.com/connect/oauth2/authorize?'.http_build_query($query).'#wechat_redirect';

        return $url;
    }

    public static function getUserOpenId($code, $isSub = true)
    {
        $config = config('weixin');
        $appId = $isSub ? $config['sub_app_id'] : $config['app_id'];
        $appSecret = $isSub ? $config['sub_app_secret'] : $config['app_secret'];
        $query = ['appid' => $appId, 'secret' => $appSecret, 'code' => $code, 'grant_type' => 'authorization_code'];
        $result = self::httpGet('/sns/oauth2/access_token', $query);
        if (!isset($result->openid)) {
            throw new RuntimeException('获取用户openId出错：'.$result->errmsg);
        }

        return $result->openid;
    }

    public static function getUserInfoByCode($code, $scope, $isSub = false)
    {
        $appId = config($isSub ? 'weixin.sub_app_id' : 'weixin.app_id');
        $appSecret = config($isSub ? 'weixin.sub_app_secret' : 'weixin.app_secret');
        $query = ['appid' => $appId, 'secret' => $appSecret, 'code' => $code, 'grant_type' => 'authorization_code'];
        $result = self::httpGet('/sns/oauth2/access_token', $query);
        if (!isset($result->openid)) {
            throw new RuntimeException('获取微信用户openId出错：'.$result->errmsg);
        }

        session(['openId' => $result->openid, 'accessToken' => $result->access_token]);
        $user = self::getSnsUserInfo($result->access_token, $result->openid);

        return $user;
    }

    public static function getSnsUserInfo($accessToken, $openid)
    {
        $query = ['access_token' => $accessToken, 'openid' => $openid, 'lang' => 'zh_CN'];
        $result = self::httpGet('/sns/userinfo', $query);
        if (!isset($result->openid)) {
            throw new RuntimeException('获取微信用户信息出错：'.$result->errmsg, $result->errcode);
        }

        return $result;
    }

    public static function getUserInfo($openId, $isSub = true)
    {
        $accessToken = $isSub ? self::getSubAccessToken() : self::getAccessToken();
        $query = ['access_token' => $accessToken, 'openid' => $openId, 'lang' => 'zh_CN'];
        $result = self::httpGet('/cgi-bin/user/info', $query);
        if (!isset($result->openid)) {
            throw new RuntimeException('获取微信用户信息出错：'.$result->errmsg, $result->errcode);
        }

        return $result;
    }

    public static function getTemplateId($templateNo)
    {
        $templateCacheKey = 'gad:weixin:tpl:'.$templateNo;
        $templateId = Redis::get($templateCacheKey);
        if (!$templateId) {
            $accessToken = self::getAccessToken();
            $url = '/cgi-bin/template/api_add_template?access_token='.$accessToken;
            $result = self::httpPost($url, json_encode(['template_id_short' => $templateNo]));
            if (!isset($result->template_id)) {
                throw new RuntimeException('获取微信模版消息ID出错：'.$result->errmsg, $result->errcode);
            }
            $templateId = $result->template_id;
            Redis::set($templateCacheKey, $templateId);
        }

        return $templateId;
    }

    public static function sendTemplateMessage($templateId, $openId, $url, $data, $color = '#327aff')
    {
        $accessToken = self::getAccessToken();
        $param = [
            'touser' => $openId,
            'template_id' => $templateId,
            'url' => $url,
            'topcolor' => $color,
            'data' => [
                'first' => [
                    'value' => array_get($data, 'first'),
                    'color' => $color
                ],
                'keyword1' => [
                    'value' => array_get($data, 'keyword1'),
                    'color' => $color
                ],
                'keyword2' => [
                    'value' => array_get($data, 'keyword2'),
                    'color' => $color
                ],
                'keyword3' => [
                    'value' => array_get($data, 'keyword3'),
                    'color' => $color
                ],
                'keyword4' => [
                    'value' => array_get($data, 'keyword4'),
                    'color' => $color
                ],
                'keyword5' => [
                    'value' => array_get($data, 'keyword5'),
                    'color' => $color
                ],
                'remark' => [
                    'value' => $data['remark'],
                    'color' => $color
                ]
            ]
        ];
        $url = '/cgi-bin/message/template/send?access_token='.$accessToken;
        $result = self::httpPost($url, json_encode($param));
        if (isset($result->msgid)) {
            return $result->msgid;
        }
    }

    /**
     * openId转换，appid需先在wxapi.oa.com绑定
     *
     * @param $appId
     * @param $openId
     * @return mixed
     */
    public static function openId2openId($appId, $openId)
    {
        $cacheKey = 'openId2openId:'.$appId.':'.$openId;
        if ($id = Redis::get($cacheKey)) {
            return $id;
        }

        $config = [
            'modId' => 64048833,
            'cmdId' => 65537,
            'default' => ['hostIp' => '10.123.6.71', 'hostPort' => 12462]
        ];
        $server = CL5::getRoute($config, app()->isLocal());
        $url = sprintf('http://%s:%s/innerapi/acctapi/transid/openid_to_openid?appname=wx_gad', $server['hostIp'], $server['hostPort']);
        $client = new Client(['timeout' => 5]);
        $body = json_encode(['target_appid' => $appId, 'openid_list' => [$openId]]);
        $response = $client->request('POST', $url, ['body' => $body]);
        if ($response->getStatusCode() != 200) {
            throw new RuntimeException('微信内部接口请求失败：'.$response->getReasonPhrase());
        }
        $result = json_decode($response->getBody());
        if ($result === null) {
            throw new RuntimeException('微信内部接口返回异常：'.$result);
        }

        if (isset($result->errcode)) {
            throw new RuntimeException('微信内部接口返回错误：'.$result->errmsg, $result->errcode);
        }

        $list = $result->openid_list[0];
        if ($list->target_openid) {
            Redis::set($cacheKey, $list->target_openid);
        }

        return $list->target_openid;
    }

    public static function commonId2openId($appId, $openId)
    {
        $cacheKey = 'commonId2openId:'.$appId.':'.$openId;
        if ($id = Redis::get($cacheKey)) {
            return $id;
        }

        $config = [
            'modId' => 64048833,
            'cmdId' => 65537,
            'default' => ['hostIp' => '10.123.6.71', 'hostPort' => 12462]
        ];
        $server = CL5::getRoute($config, app()->isLocal());
        $url = sprintf('http://%s:%s/innerapi/acctapi/transid/commid_to_openid?appname=wx_gad', $server['hostIp'], $server['hostPort']);
        $client = new Client(['timeout' => 5]);
        $body = json_encode(['appid' => $appId, 'commid_list' => [$openId]]);
        $response = $client->request('POST', $url, ['body' => $body]);
        if ($response->getStatusCode() != 200) {
            throw new RuntimeException('微信内部接口请求失败：'.$response->getReasonPhrase());
        }
        $result = json_decode($response->getBody());
        if ($result === null) {
            throw new RuntimeException('微信内部接口返回异常：'.$result);
        }

        if (isset($result->errcode)) {
            throw new RuntimeException('微信内部接口返回错误：'.$result->errmsg, $result->errcode);
        }

        $list = $result->data[0];
        if ($list->openid) {
            Redis::set($cacheKey, $list->openid);
        }

        return $list->openid;
    }

    /**
     * 获取公众号所有关注用户
     *
     * @param null $next
     * @return array
     */
    public static function getSubscriber($next = null)
    {
        $allOpenId = [];
        $query = ['access_token' => self::getAccessToken(), 'next_openid' => $next];
        $result = self::httpGet('/cgi-bin/user/get', $query);
        if (!isset($result->total)) {
            throw new RuntimeException('获取微信关注用户出错：'.$result->errmsg, $result->errcode);
        }

        $allOpenId = array_merge($allOpenId, $result->data->openid);
        if ($result->total > $result->count) {
            $rest = self::getSubscriber($result->next_openid);
            $allOpenId = array_merge($allOpenId, $rest);
        }

        return $allOpenId;
    }

    /**
     * 判断是否是关注用户
     *
     * @param $openId
     * @return bool
     */
    public static function isSubscribe($openId)
    {
        return Redis::sIsMember(self::SUBSCRIBER_KEY, $openId);
    }

    private static function httpGet($url, $query = [])
    {
        $client = new Client(['base_uri' => self::getApiHost(), 'timeout' => 5]);
        $query['simple_get_token'] = 1;
        $response = $client->request('GET', $url, ['query' => $query]);
        if ($response->getStatusCode() != 200) {
            throw new RuntimeException('微信公众号接口请求失败：'.$response->getReasonPhrase());
        }
        $result = json_decode($response->getBody());
        if ($result === null) {
            throw new RuntimeException('微信公众号接口返回异常：'.$result, $result->errcode);
        }

        return $result;
    }

    private static function httpPost($url, $data)
    {
        $client = new Client(['base_uri' => self::getApiHost(), 'timeout' => 10]);
        $query['simple_get_token'] = 1;
        $response = $client->request('POST', $url, ['body' => $data]);
        if ($response->getStatusCode() != 200) {
            throw new RuntimeException('微信公众号接口请求失败：'.$response->getReasonPhrase());
        }

        $result = json_decode($response->getBody());
        if ($result === null) {
            throw new RuntimeException('微信公众号接口返回结果非法');
        }

        if (isset($result->errcode) AND $result->errcode) {
            throw new RuntimeException('微信公众号接口返回异常：'.$result->errmsg, $result->errcode);
        }

        return $result;
    }

    private static function getApiHost()
    {
        $config = [
            'modId' => 64028801,
            'cmdId' => 65536,
            'default' => ['hostIp' => '10.123.6.71', 'hostPort' => 12361]
        ];
        $server = CL5::getRoute($config, app()->isLocal());

        return sprintf('http://%s:%s', $server['hostIp'], $server['hostPort']);
    }
}