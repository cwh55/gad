<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-8-4
 * Time: 下午4:34
 */

namespace App\Gad;

use Symfony\Component\DomCrawler\Crawler;
use GuzzleHttp\Client;

class HtmlDom {

    //将富文本中的图片替换为cdn上的图片
    public static function  replaceImgUrlForHtml ($content)
    {
        if (!$content) {
            return null;
        }

        $crawler = New Crawler($content);
        $imageNodes = $crawler->filter('img');
        $isChange = false;
        foreach ($imageNodes as $node) {
            $url = $node->getAttribute('src');
            if ($url) {
                $ext = self::getFileExtension($url);
                $fileName = uniqid();
                if ($ext) {
                    $fileName = $fileName.'.'.$ext;
                }
                $newUrl = sprintf('http://gad.qpic.cn/assets/images/trans/%s',$fileName);
                $node->setAttribute('src',$newUrl);
                self::callCdnRPCService($url,$fileName);
                $isChange = true;
            }

        }

        if ($isChange) {
           //Crawler 会自动在原文上加上p标签。
           return $crawler->filter('p')->first()->html();
        }
        else {
            return $content;
        }
    }

    //根据url获取文件后缀名
    private static function getFileExtension($srcfile)
    {
        return substr($srcfile, strrpos($srcfile, '.')+1);
    }

    //将url的资源上传到cdn
    public static function callCdnRPCService($srcUrl,$file)
    {
        $url = 'http://10.213.154.206/pictrans';
        $client = new Client();
        $response = $client->request('GET', sprintf('%s?address=%s&name=%s',$url,$srcUrl,$file));
        if ($response->getStatusCode() == '') {

        }

        return true;
    }

}