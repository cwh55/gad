<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-5-18
 * Time: 下午4:03
 */

namespace App\Gad;

use GuzzleHttp\Client;

class Html {

    //从富文本获取第一张图片
    public static function getFirstImage($content){
        $matches = array();
        preg_match("/<[i|I][m|M][g|G].*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>/", $content, $matches);
        if(isset($matches[1])) {
            return $matches[1];
        }
        return null;
    }

    //获取用户avatar
    public static function getAvatar($avatar = '') {
    	return empty($avatar) ? 'http://gad.qq.com/forum/img/profile2.jpg':$avatar;
    }

    //拉取中转地址
    public static function getVideoUrl($file = '') {
        $client = new Client();
        $url = 'http://gad.qq.com'.$file;
        
        $response = $client->request('GET', $url, []);

        if ($response->getStatusCode() != 200) {
            return ['code' => 1, 'msg' => '获取视频地址出错'];
        }
        
        $body = (string) $response->getBody();
        return ['code' => 0, 'msg' => $body];
    }

} 

