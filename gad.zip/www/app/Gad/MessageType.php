<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 16-7-20
 * Time: 下午8:05
 */

namespace App\Gad;

class MessageType
{
	const ARTICLE_NEW = 101; //关注者新增文章 
	const ARTICLE_REPLY = 102; //文章被回复 
	const ARTICLE_LIKE = 103; //文章被点赞 
	const COMMENT_REPLY = 104; //评论被回复 
	const COMMENT_LIKE = 105; //评论被点赞 
	const LIVECAST_NEW = 106; //关注者新增直播 
	const LIVECAST_BEGIN = 107; //直播即将开始 
	const PLAYBACK_NEW = 108; //回播提醒 
	const LESSION_NEW = 109; //关注者新增 
	const LESSION_UPDATE = 110; //关注者更新课程 
	const LESSION_ADDFAVORITE = 111; //课程被收藏 
	const LESSION_LIKE = 112; //课程被点赞 
	const QUESTION_REPLY = 113; //问题被回答 
	const QUESTION_LIKE = 114; //问题被点赞
    const QUESTION_NEW = 129;//问题创建
    const TOPIC_NEW = 130;//话题创建
    const TOPIC_REPLY = 132;//话题回答
    const ART_LIKE = 133;//作品点赞
    const TOPIC_LIKE = 134;//话题
    const TOPIC_ANSWER_REPLY = 135;//话题回答被评论
	const QUESTION_ANSWER_REPLY = 115; //回答被评论
	const ANSWER_LIKE = 116; //回答被点赞 
	const ART_INVITE = 117; //美术点评，嘉宾收到邀请点评 
	const ART_REPLY = 118; //美术点评，作品被点评 
	const DAKA_INVITE = 119; //嘉宾收到邀请回答（包括管理端重新指派）
	const DAKA_GUEST_REPLY = 120; //问题被（大咖）回答 
	const DAKA_QUESTION_REPLY = 121; //问题被其他人回答 
	const DAKA_ANSWER_REPLY = 122; //回答被回复 
	const DAKA_ANSWER_LIKE = 123; //回答被点赞 
	const DAKA_ANSWER_ADOPT = 124; //回答者被采纳
	const TEAM_PROJECT_INVITE_RESUME = 125;//项目者邀请开发
	const TEAM_RESUME_ANSWER_PROJECT = 126;//项目者邀请开发
	const TEAM_RESUME_APPLY_PROJECT = 127;//收到申请加入项目
	const TEAM_PROJECT_ANSWER_RESUME = 128;//收到申请加入项目
	const WORK_NEW = 131;//新增作品
	const FOLLOW = 201; //被关注提醒

	const GAME_JOIN_SUCCESS = 301; //报名成功通知 
	const GAME_JOIN_FAIL = 302; //报名失败通知 
	const GAME_SUBMIT_SUCCESS = 303; //提交成功通知 
	const GAME_SUBMIT_FAIL = 304; //提交失败通知 
	const GAME_AWARD = 305; //大赛获奖通知 
	const PROJECT_APPLY_SUCCESS = 306; //项目孵化提交成功 
	const PROJECT_APPLY_FAIL = 307; //项目孵化提交失败 
	const PROJECT_AUDIT_SUCCESS = 308; //项目孵化专家团审核成功 
	const PROJECT_AUDIT_FAIL = 309; //项目孵化专家团审核失败 
	const DAKA_QUESTION_DELETE = 310; //大咖答疑,问题被删除 
	const DAKA_ANSWER_DELETE = 311; //大咖答疑,回答/评论被删除 
	const ARTICLE_DELETE = 312; //文章被删除 
	const COMMENT_DELETE = 313; //文章评论、二级评论被删除 
	const QUESTION_DELETE = 314; //问题被删除 
	const ANSWER_DELETE = 315; //问题回答被删除 
	const ANSWER_COMMENT_DELETE = 316; //问题评论被删除 
	const ART_DELETE = 317; //作品被删除 
	const ART_COMMENT_DELETE = 318; //作品评论、二级评论被删除
	const TEAM_RESUME_ACCEPT = 319; //简历审核通过
	const TEAM_RESUME_REJECT = 320; //简历不通过
	const TEAM_PROJECT_ACCEPT = 321;//项目审核通过
	const TEAM_PROJECT_REJECT = 322;//项目审核不通过
        
    const ARTICLE_ACCEPT = 330;//文章审核通过
	const ARTICLE_REJECT = 331;//文章审核不通过
	const ART_ACCEPT = 332;//作品审核通过
	const ART_REJECT = 333;//作品审核不通过
	const RESOURCE_CONVERT_SUCCESS = 340; //美术资源转换完成
    const DAKA_INVITE_ANSWER = 341;     //大咖，邀请嘉宾回答问题
    const DAKA_REJECT_QUESTION = 342;   //大咖，用户提问审核不通过
} 