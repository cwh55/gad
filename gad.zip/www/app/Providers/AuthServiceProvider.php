<?php

namespace App\Providers;

use App\Entities\Answer;
use App\Entities\Archive;
use App\Entities\Comment;
use App\Entities\Course as Lundao;
use App\Entities\Live;
use App\Entities\Lore;
use App\Entities\Project;
use App\Models\Course;
use App\Models\Lesson;
use App\Policies\AnswerPolicy;
use App\Policies\ArchivePolicy;
use App\Policies\CommentPolicy;
use App\Policies\CoursePolicy;
use App\Policies\LessonPolicy;
use App\Policies\LivePolicy;
use App\Policies\LorePolicy;
use App\Policies\LundaoPolicy;
use App\Policies\TeamProjectPolicy;
use Illuminate\Contracts\Auth\Access\Gate as GateContract;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        Course::class => CoursePolicy::class,
        Lundao::class => LundaoPolicy::class,
        Lesson::class => LessonPolicy::class,
        Live::class => LivePolicy::class,
        Lore::class => LorePolicy::class,
        Archive::class => ArchivePolicy::class,
        Comment::class => CommentPolicy::class,
        Answer::class => AnswerPolicy::class,
        Project::class => TeamProjectPolicy::class
    ];

    /**
     * Register any application authentication / authorization services.
     *
     * @param  \Illuminate\Contracts\Auth\Access\Gate  $gate
     * @return void
     */
    public function boot(GateContract $gate)
    {
        $this->registerPolicies($gate);

        $gate->before(function ($user, $ability) {
            if ($user->roles->contains(2)) {
                return true;
            }
        });
        //修改操作，对象：文章
        $gate->define('update', function ($user, $post) {
            return $user->UserId === $post->user_id;
        });
        //创建操作，对象：文章
        $gate->define('create', function ($user, $post) {
            if ($user->roles->contains(1)) {
                return false;
            }
            return true;
        });
    }
}
