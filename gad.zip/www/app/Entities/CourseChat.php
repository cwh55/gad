<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class CourseChat extends Model implements Transformable
{
    use TransformableTrait, SoftDeletes;

    protected $table = 'course_chat';
    protected $fillable = ['course_id', 'lesson_id', 'user_id', 'nickname', 'content', 'source', 'is_show'];

    public function user()
    {
        return $this->belongsTo('App\Entities\User');
    }

}
