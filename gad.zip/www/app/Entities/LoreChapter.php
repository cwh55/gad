<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;
use Illuminate\Database\Eloquent\SoftDeletes;

class LoreChapter extends Model implements Transformable
{
    use TransformableTrait;
    use SoftDeletes;

    protected $fillable = ['title', 'intro', 'pic', 'type', 'lore_id', 'chapter_no', 'duration', 'creator', 'updater', 'state'];


    public function sections(){
    	return $this->hasMany('App\Entities\LoreSection','chapter_id')->where('state',0)->orderBy('section_no');
    }

    public function lore() {
        return $this->belongsTo('App\Entities\Lore', 'lore_id');
    }
}
