<?php
namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class CityActivity extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['city_id','logo','url','order_no','name'];
    
    protected $table = 'gad_city_activities';
    
}
