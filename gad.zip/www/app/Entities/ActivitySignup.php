<?php

namespace App\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ActivitySignup extends Model
{
    use SoftDeletes;

    protected $fillable = ['user_id', 'activity_id', 'activity_type',
        'name', 'phone', 'email', 'weixin', 'qq',
        'province', 'city', 'address',
        'company', 'job', 'attachment', 'topic',
        'intro', 'type', 'status',
        'team_type', 'team_num',
        'game_name', 'game_intro', 'game_platform', 'game_type',
        'creator', 'created_at', 'updater', 'updated_at', 'deleted_at',
    ];

    protected $hidden = ['updated_at', 'deleted_at'];

    protected $table = 'gad_activity_signups';

    protected $casts = ['attachment' => 'array', 'game_type' => 'array' , 'game_platform' => 'array'];


    public function getTypeAttribute($type)
    {
        switch ($type) {
            case  '0':
                return '观众';
                break;
            case  '1':
                return '演讲嘉宾';
                break;
        }
    }

    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }

    public function activity()
    {
        return $this->belognsTo('App\Entities\Activity', 'activity_id');
    }

}
