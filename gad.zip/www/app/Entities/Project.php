<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Entities\HatchProject;
use Auth;

class Project extends Model implements Transformable
{
    use TransformableTrait, SoftDeletes;

    protected $table = "team_projects";

    protected $fillable = ['title', 'game_name', 'game_type', 'game_state', 'member_count',
        'cover', 'intro', 'video', 'music', 'demo', 'job_types', 'job_cities', 'reason', 'user_id', 'is_show', 'created_at',
        'state', 'updated_at', 'invite_notify', 'apply_notify', 'project_id', 'hatch_status'];

    protected $visible = ['id','title', 'game_name', 'game_type', 'game_state', 'member_count',
        'cover', 'intro', 'video', 'music', 'demo', 'job_types', 'job_cities', 'reason', 'user_id', 'created_at', 'is_show',
        'state', 'invite_notify', 'apply_notify', 'project_id', 'jobs', 'isPublicDemo'];

    protected $casts = [
        'demo' => 'array',
        'video' => 'array',
        'cover' => 'array',
        'music' => 'array'
    ];

    public function jobs()
    {
        return $this->hasMany('App\Entities\ProjectJob');
    }

    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }

    //管理端展示接口人姓名、邮箱、手机号要用到
    public function user_manager()
    {
        return $this->hasOne('App\Models\UserManager', 'UserId', 'user_id');
    }

    public function projectUser()
    {
        return $this->hasOne('App\Entities\ProjectUser','creator','user_id');
    }

    //置顶，管理端用
    public static function setTop($id)
    {
        $question = self::withTrashed()->where('id', '=', $id)->firstOrFail();
        $question->is_top = self::query()->max('is_top') + 1;
        $question->save();
        return $question;
    }

    public function inviteActions()
    {
        return $this->hasMany('App\Entities\TeamAction', 'project_user', 'user_id')->where('action_type', 'invite');
    }

    public function allowAccess()
    {
        if ($this->state == 1) {
            return true;
        } else {
            if (!Auth::check()) {
                return false;
            }
            $user = Auth::user();
            if ($user->UserId == $this->user_id || $user->roles->contains(2)) {
                return true;
            }
            //项目发起人可查看
            $applyAction = $this->inviteActions()->where('project_user', $user->UserId)->first();
            if ($applyAction) {
                return true;
            }
            return false;
        }
    }
    //关联通用项目表中的信息
    public function realPro()
    {
        return $this->hasOne('App\Entities\HatchProject', 'id', 'project_id');
    }
    public function getGameNameAttribute($value)
    {
        return $this->realPro ? $this->realPro->name : $value;
    }
    public function getGameTypeAttribute($value)
    {
        return $this->realPro && count($this->realPro->type) ? $this->realPro->type[0] : $value;
    }
    public function getGameStateAttribute($value)
    {
        return $this->realPro ? $this->realPro->progress : $value;
    }
    public function getMemberCountAttribute($value)
    {
        return $this->realPro ? $this->realPro->team_num : $value;
    }
    public function getCoverAttribute($value)
    {
        return $this->realPro ? $this->realPro->pictures : json_decode($value, true);
    }
    public function getIntroAttribute($value)
    {
        return $this->realPro ? $this->realPro->intro : $value;
    }
    public function getVideoAttribute($value)
    {
        return $this->realPro ? $this->realPro->videos : json_decode($value, true);
    }
    public function getDemoAttribute($value)
    {
        return $this->realPro ? $this->realPro->demo : json_decode($value, true);
    }
    public function getMusicAttribute($value)
    {
        return $this->realPro ? $this->realPro->music : json_decode($value, true);
    }
}
