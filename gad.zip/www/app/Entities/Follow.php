<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Follow extends Model implements Transformable
{
    use TransformableTrait;
    use SoftDeletes;

    protected  $table = "gad_follows";
    protected $fillable = ['user_id','follow_user','status'];

    public function archives()
    {
        return $this->hasMany('App\Entities\Archive', 'user_id', 'follow_user');
    }

    public function feeds()
    {
        return $this->hasMany('App\Entities\Feed', 'creator', 'follow_user')->orderBy('created_at' ,'desc');
    }

    public function follower()
    {
        return $this->hasOne('App\Entities\User','UserId','follow_user');
    }

    public function fansUser()
    {
        return $this->hasOne('App\Entities\User','UserId','user_id');
    }
}
