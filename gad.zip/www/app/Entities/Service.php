<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

/**
 * Class Service
 * 项目扶持-资源对接
 * @package App\Entities
 */
class Service extends Model implements Transformable
{
    use TransformableTrait;
    use SoftDeletes;
    protected $table = 'gad_project_services';
    protected $fillable = ['user_id','service_member_id', 'service_type', 'name', 'logo', 'description', 'ip_style', 'ip_type', 'ip_range', 'online_time', 'progress',
        'status', 'showcase', 'derivatives', 'creator', 'updater', 'reason','is_show',
        'business_type','business_style','business_platform','institutional_type','invest_stage','office_address','office_seat','office_price'
    ];
    protected $casts = [
        'showcase' => 'array',
        'derivatives' => 'array',
        'ip_range' => 'array',
        'is_show'=>'boolean',
        'business_type'=>'array',
        'business_style'=>'array',
        'business_platform'=>'array',
    ];
    /**
     * 服务类型
     * @var array
     */
    public static $serviceType = [
        0 => '开发者',//IP
        1 => 'IP',//IP
        2 => '版号',//版号
        3 => '办公场地',//办公场地
        4 => '投融资',//投融资
        5 => '发行',//发行
    ];

    /**
     * 获取服务所有者
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function member()
    {
        return $this->belongsTo('App\Entities\ServiceMember', 'service_member_id');
    }

    /**
     * 获取该服务需求单
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function serviceOrders()
    {
        return $this->hasMany('App\Entities\ServiceOrder', 'service_id');
    }

}
