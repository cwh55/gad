<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Tag extends Model
{
    use SoftDeletes;

    protected $fillable = ['name', 'alias', 'lvl', 'archive_all_count', 'archive_article_count',
        'archive_work_count', 'archive_question_count', 'archive_topic_count', 'is_hot','is_recommend','description', 'p', 'p1', 'p2', 'p3', 'p4',
        'created_at', 'updated_at', 'deleted_at'];

    protected $table = 'gad_tags';

    public function archives()
    {
        return $this->belongsToMany('App\Entities\Archive', 'gad_archive_tags');
    }

    /**
     * 获取直接父级ID
     * @return int|mixed
     */
    public function getPidAttribute()
    {
        switch ($this->lvl) {
            case 1:
                return $this->p;
                break;
            case 2:
                return $this->p1;
                break;
            case 3:
                return $this->p2;
                break;
            case 4:
                return $this->p3;
                break;
            case 5:
                return $this->p4;
                break;
            default:
                return 0;
                break;
        }


    }

}
