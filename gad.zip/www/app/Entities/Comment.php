<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Comment extends Model implements Transformable
{
    use TransformableTrait;
    use SoftDeletes;

    protected $table = 'gad_comments';
    protected $fillable = ['model_type', 'model_id', 'comment','comment_count', 'user_id', 'user_name', 'at_user', 'at_name', 'like_count', 'creator', 'updator', 'image','status', 'created_at'];

    public function commentable()
    {
        return $this->morphTo('model');
    }

    public function likes()
    {
        return $this->morphMany('App\Entities\Like', 'model');
    }

    public function subcomments()
    {
        return $this->morphMany('App\Entities\Comment', 'model');
    }

    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
}
