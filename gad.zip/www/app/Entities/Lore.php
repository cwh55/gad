<?php

namespace App\Entities;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;
use Auth;

class Lore extends Model implements Transformable
{
    use TransformableTrait;
    use SoftDeletes;

    protected $fillable = ['title', 'type', 'intro', 'intro_pic', 'intro_video', 'features', 'suit_user', 'teachers','logo',
        'label', 'price', 'duration', 'qq', 'weixin_qrcode', 'pay_pic','study_cnt','view_cnt','state','related','creator','updater','qqkey',
        'top_banner','m_top_banner','light_banner','m_light_banner','manual_banner','m_manual_banner','advantage_list','daka_comment_list'];

    // protected $casts = ['duration' => 'datetime'];
    protected $casts = [
        'daka_comment_list' => 'array'
    ];

    public function pays()
    {
        return $this->hasMany('App\Entities\LorePay');
    }
   	
   	public function chapters(){
   		return $this->hasMany('App\Entities\LoreChapter')->where('state',0);
   	}

    public function learns(){
      return $this->hasMany('App\Entities\LoreLearn');
    }

    public function orders(){
        return $this->morphMany('App\Entities\LiveOrder','obj');
    }

    public function incrementPayCount() {
        $this->increment('pay_cnt');
    }

    public function advantages(){
        if ($this->advantage_list) {
            return \GuzzleHttp\json_decode($this->advantage_list);
        }
        return [];
    }

    public function isPayed() {
        if (!Auth::check()) {
            return false;
        }
        $user = Auth::user();
        //管理员不用购买
        if ($user->roles->contains(2)) {
            return true;
        }
        $order = $this->orders()->where([
            'user_id'=> $user->UserId,
            'state'=>1
            ])->first();
        return $order ? true :false;
    }

    public function teachers(){
        $tids = explode(',', str_replace('，', ',', $this->teachers));
        $teachers = DB::table('lore_teachers')->whereIn('id',$tids)->get();
        $teacherStr = "";
        for($i = 0; $i < count($teachers); $i++){
            $teacherStr .= $teachers[$i]->nick.',';
        }
        return trim($teacherStr, ",");
    }

    public function getNewestLore()
    {
        return $this->where(['state' => 0])->orderBy('id', 'desc')->limit(1);
    }
}