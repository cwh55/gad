<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Course extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = [];
    protected $dates = ['deleted_at'];
    protected $appends = ['is_registered', 'is_collected'];

    public function type()
    {
        return $this->belongsTo('App\Models\Type');
    }

    public function lesson()
    {
        return $this->belongsTo('App\Entities\Lesson', 'next_lesson');
    }

    public function user()
    {
        return $this->belongsTo('App\Entities\User');
    }

    public function lessons()
    {
        return $this->hasMany('App\Entities\Lesson');
    }

    public function teachers()
    {
        return $this->belongsToMany('App\Models\Teacher')->withTimestamps();
    }

    public function assistants()
    {
        return $this->belongsToMany('App\Models\Teacher', 'course_assistant')->withTimestamps();
    }

    public function students()
    {
        return $this->belongsToMany('App\Models\User')->withPivot('attend_at')->withTimestamps();
    }

    public function collects()
    {
        return $this->belongsToMany('App\Models\User', 'course_collect')->withTimestamps();
    }

    public function chats()
    {
        return $this->hasMany('App\Entities\CourseChat');
    }

    public function getStudyCountAttribute()
    {
        if ($this->attributes['study_count'] <= 8) {
            return $this->attributes['study_count'];
        }

        $rand = $this->attributes['study_count'] > 5 ? ($this->attributes['study_count'] % 5) : 0;

        return $this->attributes['study_count'] * 5 + $rand;
    }
}
