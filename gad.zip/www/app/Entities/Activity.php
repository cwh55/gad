<?php

namespace App\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Activity extends Model
{
    use SoftDeletes;

    const TYPE_OFFLINE = 1;
    const TYPE_ONLINE = 2;
    const TYPE_GAME = 3;

    protected $fillable = ['type','user_id','name','province','city','address','location','start_time',
        'end_time','signup_limit','banner','live_type','live_setting','guest','description','contact','background_color',
        'is_comment','comment_count','signup_count','status','show_type','show_video','creator','pics','signup_role_setting','signup_setting'];

    protected $hidden = ['updated_at','deleted_at'];

    protected $table = 'gad_activities';
    protected $casts = ['guest' => 'array','show_video' => 'array','is_comment'=>'boolean','show_type'=>'array','signup_setting'=>'array','signup_role_setting'=>'array','location'=>'array'];
    
    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
    
    public function signups()
    {
        return $this->hasMany('App\Entities\ActivitySignup','activity_id');
    }
    
    public function comments()
    {
        return $this->hasMany('App\Entities\ActivityComment', 'activity_id')->paginate(20);
    }
}
