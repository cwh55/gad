<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class LoreLearn extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['lore_id','user_id','section_id','creator','updater'];

}
