<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/8/25
 * Time: 7:36
 */

namespace App\Entities;
use Illuminate\Database\Eloquent\Model;

class Reply extends Model
{
    protected $table = "Reply";
    protected $fillable = ['ReplyId','ReplyType', 'ReplyObject', 'HtmlDetail', 'UpCount', 'RowStatus', 'Created', 'Creator', 'Modified', 'Modifier'];

    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'Creator');
    }



}