<?php
namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class CityPlace extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['city_id','logo_type','logo','company','address','url','order_no'];
    
    protected $table = 'gad_city_places';
    
}
