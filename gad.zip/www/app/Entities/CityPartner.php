<?php
namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class CityPartner extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['city_id','name','logo','url','order_no'];
    
    protected $table = 'gad_city_partners';
    
}
