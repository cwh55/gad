<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Answer extends Model implements Transformable
{
    use TransformableTrait;

    protected $table = 'gad_answers';

    protected $fillable = ['user_name', 'user_id', 'cover', 'archive_id', 'answer_id', 'answer', 'vip', 'rank', 'adopt', 'like_count', 'unlike_count', 'answer_count', 'at_user', 'at_name', 'status', 'is_topic', 'project_id'];

    public function user()
    {
        return $this->belongsTo('App\Entities\User', 'user_id', 'UserId');
    }

    public function like()
    {
        return $this->morphMany('App\Entities\Like', 'model');
    }

    public function panswer()
    {
        return $this->belongsTo('App\Entities\Answer', 'answer_id', 'id');
    }

    public function question()
    {
        return $this->belongsTo('App\Entities\Archive', 'archive_id', 'id');
    }

    public function user_manager()
    {
        return $this->belongsTo('App\Models\UserManager', 'user_id', 'UserId');
    }

}
