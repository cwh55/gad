<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2018/1/23
 * Time: 2:55
 */

namespace App\Entities;
use Illuminate\Database\Eloquent\Model;

class WendaActivity extends Model
{
    protected $fillable = ['title', 'banner', 'starttime', 'endtime', 'module', 'info', 'status','mobilebanner','bullet','partner','bg_color'];
    //protected $hidden = ['updated_at','created_at'];
    protected $table = 'activities';
    protected $casts = ['partner' => 'array', 'bullet' => 'array'];
}