<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Question extends Model implements Transformable
{
    use TransformableTrait;

    protected $table = 'gad_questions';

    protected $fillable = ['archive_id','rank','source','obj_type','obj_id','to_user','status','updater','content','is_topic','activity_status','activity_rank','activity_to_user','activity_is_answer'];
    protected $casts = ['activity_to_user' => 'array'];
}
