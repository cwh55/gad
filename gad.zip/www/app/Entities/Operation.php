<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Operation extends Model implements Transformable
{
    use TransformableTrait;
    protected $table = 'gad_operations';
    protected $fillable = ['channel_id', 'type', 'model_id', 'position', 'cover', 'title', 'url', 'status', 'user_id','starttime','endtime','extra'];


    /**
     * 获取大咖详细信息
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'model_id');
    }

    public function tag()
    {
        return $this->hasOne('App\Entities\Tag', 'id', 'model_id');
    }

    public function archive()
    {
        return $this->hasOne('App\Entities\Archive', 'id', 'model_id');
    }

    /**
     * 删除
     *
     * @return $this
     */
    public function delete()
    {
        $this->status = -1;
        $this->save();
        return $this;
    }


}
