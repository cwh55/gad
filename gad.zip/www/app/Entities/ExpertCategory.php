<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class ExpertCategory extends Model
{
    public function experts(){
        return $this->belongsToMany('App\Entities\ExpertPlan', 'expert_plan_categories')->where('status', '=', 0);
    }
}
