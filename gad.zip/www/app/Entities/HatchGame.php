<?php

namespace App\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class HatchGame extends Model
{
    use SoftDeletes;

    protected $fillable = ['project_id','game_id','user_id','step','status'];

    protected $table = 'gad_hatch_games';
    
    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
    
    public function project()
    {
        return $this->belongsTo('App\Entities\HatchProject');
    }
}
