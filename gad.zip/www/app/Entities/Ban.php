<?php
namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Ban extends Model
{
    use SoftDeletes;

    const TYPE_USER = 'user';
    const TYPE_IP = 'ip';
    const DURATION_7DAYS = '7days';
    const DURATION_1MONTH = '1month';
    const DURATION_FOREVER = 'forever';

    protected $table = 'gad_bans';
    protected $fillable = ['type', 'duration', 'expire', 'user_id', 'ip', 'reason', 'creator'];

    public function user()
    {
        return $this->belongsTo('App\Entities\User');
    }
}