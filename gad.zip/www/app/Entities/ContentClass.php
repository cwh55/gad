<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class ContentClass extends Model implements Transformable
{
    use TransformableTrait;

    protected $table = "ContentClass";

    protected $fillable = [];

    public function content(){
    	return $this->hasOne('App\Entities\Content','ContentId','ContentId');
    }

}
