<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;
use Auth;

class Atlas extends Model implements Transformable
{
    use TransformableTrait;

    protected $table = "gad_atlas";

    protected $fillable = ['archive_id', 'rights', 'attachments', 'type', 'from_type', 'modelface_count',
        'modelpoint_count', 'download_able', 'download_url', 'match_qq', 'city'];

    protected $casts = ['attachments' => 'array'];
}
