<?php

namespace App\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Archive extends Model
{
    use SoftDeletes;

    const TYPE_ARTICLE = 1;
    const TYPE_WORKS = 2;
    const TYPE_QUESTION = 3;
    const TYPE_TOPIC = 4;
    const TYPE_COMMENT = 5;

    protected $fillable = ['channel_id','class_id','title','description','cover','tag','comment_count','updater',
        'user_id','user_name','creator','is_video','is_hot','is_top','ccid','hot_aid','status','total','deleted_at','extra','sort_time','publish_time','project_id','reject_reason','from_activity'];

    protected $hidden = ['channel_id','hot_score','score1','score2','score3','score4','score5','score6','score7',
        'ccid','sort_time','deleted_at'];

    protected $table = 'gad_archives';
    protected $casts = ['extra' => 'array'];
    
    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
    
    public function article()
    {
        return $this->hasOne('App\Entities\Article');
    }
    
    public function tags()
    {
        return $this->belongsToMany('App\Entities\Tag', 'gad_archive_tags')->withTimestamps();
    }

    public function pictures()
    {
        return $this->hasMany('App\Entities\Picture', 'archive_id', 'id')->orderBy('sort' ,'asc');
    }

	public function atlas()
    {
        return $this->hasOne('App\Entities\Atlas', 'archive_id', 'id');
    }
    public function firstPictures()
    {
        return $this->hasOne('App\Entities\Picture', 'archive_id', 'id')->orderBy('sort' ,'asc');
    }

    public function question()
    {
      return $this->hasOne('App\Entities\Question');
    }

    public function getCreatedAtAttribute()
    {
        $value = $this->class_id == static::TYPE_ARTICLE || $this->class_id == static::TYPE_WORKS ? $this->attributes['publish_time'] :
            $this->attributes['created_at'];

        return $value;
    }
}
