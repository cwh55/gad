<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class LiveOrder extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['user_id', 'live_id','obj_id','obj_type', 'openid', 'payitem', 'amt', 'token', 'billno', 'cftid',
        'paychannel', 'paychannelsubid', 'state'];

    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }

    public function live()
    {
        return $this->belongsTo('App\Entities\Live', 'live_id');
    }

    public function obj()
    {
        return $this->morphTo();
    }

    //管理端用
    public function lores(){
        return $this->hasOne('App\Entities\Lore','id','obj_id');
    }

}
