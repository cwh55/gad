<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;
use Illuminate\Database\Eloquent\SoftDeletes;

class LoreSection extends Model implements Transformable
{
    use TransformableTrait;
    use SoftDeletes;


    protected $fillable = ['title','type','duration','lore_id','chapter_id','section_no','label',
        'section_type','html_detail','video','view_cnt','comment_cnt','teacher_id','creator','updater', 'state','attachments'];

    protected $casts = [  'attachments' => 'array'];


    public function teacher() {
        return $this->belongsTo('App\Entities\LoreTeacher', 'teacher_id');
    }

    public function lore() {
        return $this->belongsTo('App\Entities\Lore', 'lore_id');
    }

    public function chapter() {
        return $this->belongsTo('App\Entities\LoreChapter', 'chapter_id');
    }
    public function relateSections()  {
        return $this->chapter->sections->sortBy('section_no');
        $chapters = $this->lore->chapters()->where(['state'=>0])->get();
        $chapters = $chapters->sortBy('chapter_no');
        $sections = [];
        foreach($chapters as $chapter) {
            $temp=$chapter->sections()
                ->where(['state'=>0])
                ->get()
                ->sortBy('section_no')
                ->map(function($item)use($chapter){
                    $item->chapter_no = $chapter->chapter_no;
                    return $item;
                })->toArray();
            $sections = array_merge($sections,$temp);
        }
        $map = [];
        $index = 0;
        foreach($sections as $section) {
            $map[$section['id']] = $index;
            $index++;
        }
        if(count($map)>0) {
            $curIndex = $map[$this->id];
            $maxIndex = count($sections) -1;
            //小节数小于8时全部显示
            $sections = collect($sections);
            if ($maxIndex < 7) {
                $ret=[];
                foreach($sections as $item) {
                    if($item['id'] != $this->id) {
                        array_push($ret,$item);
                    }
                }

                return $ret;
            }
            //当前小结为第一小结，取后6节
            if($curIndex == 0) {
                return $sections->splice(1,6);
            }
            //后面不足5节取前三后三
            elseif($curIndex + 5 > $maxIndex) {
                $preSection = clone $sections;
                $preSection = $preSection->splice($curIndex-3,3);
                $lastSection = $sections->splice($curIndex+1,3);
                return $preSection->merge($lastSection);

            }
            else {
                //取前一后五
                $preSection = clone $sections;
                $preSection = $preSection->splice($curIndex-1,1);
                $lastSection = $sections->splice($curIndex+1,5);
                return $preSection->merge($lastSection);
            }
        }
        else {
            return [];
        }
    }
    public function isFree() {
        if (in_array($this->section_type,[1,3])) {
            return true;
        }

        return false;
    }

    public function tags() {

    }

    public function allowAccess()
    {
        //1，3为免费章节类型
        return in_array($this->section_type,[1,3]) || $this->lore->isPayed();
    }

}
