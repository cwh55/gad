<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class GamePaiCode extends Model
{
    use SoftDeletes;

    protected $fillable = ['game_pai_id','game_pai_type','user_id','code','delete_at'];
    protected $table = 'gad_gamepai_code';
    protected $casts = ['extra' => 'array'];
    
    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
    
    public function gamePai()
    {
        return $this->belongsTo('App\Entities\GamePai');
    }
}
