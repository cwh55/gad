<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class GamePaiSignup extends Model
{
    use SoftDeletes;

    protected $fillable = ['game_pai_type','game_pai_id','user_id','user_name','qq','tel','company','game_type','game_desc','deleted_at'];
    protected $table = 'gad_gamepai_signup';
    
    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
    
    public function gamePai()
    {
        return $this->belongsTo('App\Entities\GamePai');
    }
}
