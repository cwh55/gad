<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;
use Illuminate\Database\Eloquent\SoftDeletes;

class TeamAction extends Model implements Transformable
{
    use TransformableTrait, SoftDeletes;

    const STATE_UNTREATED = 0;
    const STATE_ACCEPT = 1;
    const STATE_REJECT = 2;

    protected $table = "team_actions";

    protected $fillable = ['resume_id','resume_user','project_id','project_user','action_type','message','state','creator'];

    public function resume()
    {
        return $this->hasOne('App\Entities\Resume','id','resume_id');
    }

    public function project()
    {
        return $this->hasOne('App\Entities\Project','id','project_id');
    }

}
