<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

/**
 * Class ServiceMember
 * 项目扶持-资源对接
 * @package App\Entities
 */
class ServiceMember extends Model implements Transformable
{
    use TransformableTrait;
    use  SoftDeletes;
    protected $table = 'gad_project_service_members';

    protected $fillable = ['user_id', 'service_member_type', 'name', 'logo', 'province', 'city', 'intro', 'contacts', 'id_card', 'phone', 'type', 'address', 'business_license',
        'email', 'weixin', 'creator', 'status', 'created_at', 'updater', 'updated_at', 'deleted_at', 'reason','team_num','business_type','business_style','business_platform','institutional_type','invest_stage'
    ];
    protected $casts = [
        'business_type'=>'array',
        'business_style'=>'array',
        'business_platform'=>'array',
    ];

    /**
     * 获取所有服务
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function services()
    {
        return $this->hasMany('App\Entities\Service', 'service_member_id');
    }

    /**
     * 获取该成员申请的服务需求单
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function applyServiceOrders()
    {
        return $this->hasMany('App\Entities\ServiceOrder', 'apply_member_id');
    }

}
