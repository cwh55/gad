<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Draft extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['class_id','user_id','content'];

    protected $table = 'gad_drafts';
    
    protected $casts = [
        'content' => 'object'
    ];
}
