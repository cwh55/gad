<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class ExpertPlan extends Model
{
    use SoftDeletes;
    protected $fillable = ['name','avatar','job','description','company','profession','user_id','account','meeting','wish','phone','email','status','recommend','from_group','from_class','good_at','sort','step','is_recommend','fame_url'];
    protected $casts = ['account' => 'array','meeting' => 'array','wish' => 'array'];

    public function category()
    {
        return $this->belongsToMany('App\Entities\ExpertCategory','expert_plan_categories','expert_plan_id','expert_category_id');
    }
}
