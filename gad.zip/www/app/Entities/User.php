<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class User extends Model implements Transformable
{
    use TransformableTrait;

    public $timestamps = false;
    protected $table = 'User';
    protected $primaryKey = 'UserId';
    protected $fillable = ['UserId','QQNo', 'WeixinId', 'NickName','RealName', 'Avatar','RowStatus', 'tgd_uid', 'ip', 'Created', 'Modified'];
    protected $visible = ['UserId', 'NickName', 'Avatar', 'TutorStatus','type'];

    /**
     * Extract and cache all the mutated attributes of a class.
     *
     * @param  string  $class
     * @return void
     */
    public static function cacheMutatedAttributes($class)
    {
        $mutatedAttributes = ['Avatar'];

        // Here we will extract all of the mutated attributes so that we can quickly
        // spin through them after we export models to their array form, which we
        // need to be fast. This'll let us know the attributes that can mutate.
        if (preg_match_all('/(?<=^|;)get([^;]+?)Attribute(;|$)/', implode(';', get_class_methods($class)), $matches)) {
            foreach ($matches[1] as $match) {
                if (static::$snakeAttributes) {
                    $match = Str::snake($match);
                }

                $mutatedAttributes[] = lcfirst($match);
            }
        }

        static::$mutatorCache[$class] = $mutatedAttributes;
    }

    public function setRememberToken($value)
    {
        //
    }

    public function courses()
    {
        return $this->belongsToMany('App\Models\Course')->withTimestamps();
    }

    public function lives()
    {
        return $this->belongsToMany('App\Entities\Live', 'live_signs');
    }

    public function roles()
    {
        return $this->belongsToMany('App\Models\Role', 'User_Role', 'userId', 'roleId')->withPivot('resourceType', 'resourceId');
    }

    //是否为星辰专家
    public function expert()
    {
        return $this->hasOne('App\Entities\ExpertPlan','user_id','UserId')->where('status',0)->select(['user_id']);
    }

    /**
     * 通过用户QQ号码查找用户。
     *
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeQq($query, $qq)
    {
        return $query->where('QQNo', 'LIKE', '%'.$qq)->take(6);
    }

    public function teacher()
    {
        return $this->hasOne('App\Models\Teacher');
    }

    public function creator_course()
    {
        return $this->hasMany('App\Models\Course')->orderBy('id', 'DESC');
    }

    public function isCourseTeacher(Course $course)
    {
        if ($course->teachers->contains('user_id', $this->UserId)) {
            return true;
        }

        if ($course->assistants->contains('user_id', $this->UserId)) {
            return true;
        }

        return false;
    }

    public function getAvatarAttribute($avater)
    {
        if (!$avater) {
            return 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg';
        }

        if (starts_with($avater, '/')) {
            return 'http://gad.qq.com'.$avater;
        }

        return $avater;
    }

    public function getFullAvatarAttribute()
    {
        $default = 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg';
        if (!$this->Avatar) {
            return $default;
        }

        if (starts_with($this->Avatar, '/')) {
            return 'http://gad.qq.com'.$this->Avatar;
        }

        return $this->Avatar;
    }

    //
    public function getCoverAttribute()
    {
        $coverList = [
            'http://gad.qpic.cn/assets/v2/web/img/community/people/cover/1.jpg',
            'http://gad.qpic.cn/assets/v2/web/img/community/people/cover/2.jpg',
            'http://gad.qpic.cn/assets/v2/web/img/community/people/cover/3.jpg'
        ];
        if (!$this->attributes['cover']) {
            $index = rand(0,2);
            return $coverList[$index];
        }
        return $this->attributes['cover'];
    }

    public function getAgeCnAttribute()
    {
        switch($this->attributes['Age']){
            case '-20':
                return '20岁以下';
            case '20-25':
                return '20-25岁';
            case '26-30':
                return '26-30岁';
            case '31-35':
                return '31-35岁';
            case '36-':
                return '36岁以上';
            default:
                return '';
        }
    }

    public function getSexCnAttribute()
    {
        switch($this->attributes['Sex'])
        {
            case 'boy':
                return '男';
            case 'girl':
                return '女';
            default:
                return '';
        }
    }

    public function getSourceAttribute()
    {
        return $this->attributes['QQNo'] ? 'qq' : 'weixin';
    }

    public function canPermit($perm){
        return !is_null($perm) && $this->checkPermit($perm);
    }

    public function permit($perm,$arr){
        return !is_null($perm) && $this->checkPermit($perm,$arr);
    }

    public function checkPermit($perm, $arr = array()){
        $permitArr = is_array($perm) ? $perm : [$perm];
        $permits = $this->roles->load('permissions')->toArray();
        $haspermit = $this->getAllPermitsByAllRoles($permits,$permitArr, $arr);
        $permitsToo = User::find(111111)->roles->load('permissions')->toArray();
        $haspermitToo = $this->getAllPermitsByAllRoles($permitsToo,$permitArr, $arr);
        return $haspermit || $haspermitToo;
    }

    public function getAvatar()
    {
        $default = 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg';
        if (!$this->Avatar) {
            return $default;
        }

        if (starts_with($this->Avatar, '/')) {
            return 'http://gad.qq.com'.$this->Avatar;
        }

        return $this->Avatar;
    }

    public function getAllPermitsByAllRoles($permits, $permArr,$arr){
        $permitArr = [];
        if($this->checkBlack($permits)){
            return false;
        }
        foreach($permits as $role){
            $p = $role['pivot'];
            if($p['resourceType'] == 'function'){
                if(method_exists($this, $p['resourceId'])){
                    $bool = $this->$p['resourceId']($arr);
                    if($bool){
                        $permitArr = array_map(
                            "strtolower", array_unique(array_flatten(array_map(function($permit){
                                return $permit["name"];
                            }, $role["permissions"])))
                        );
                        $bool = count(array_intersect($permitArr, $permArr));
                        if($bool){
                            return $bool;
                        }
                    }
                }
            } else {
                $permitArr = array_map(
                    "strtolower", array_unique(array_flatten(array_map(function($permit){
                        return $permit["name"];
                    }, $role["permissions"])))
                );
                $bool = count(array_intersect($permitArr, $permArr));
                if($bool){
                    return $bool;
                }
            }
        }
        return false;
    }

    public function checkBlack($permit){
        foreach($permit as $p){
            if($p['name'] == "blackuser"){
                return true;
            };
        }
        return false;
    }

    public function checkUser($param){
        if($this->UserId){
            return true;
        }
        return false;
    }

    public function checkArtilAuthor($param){
        if(isset($param['user_id'])){
            return $this->UserId == $param["user_id"];
        }
        return false;
    }

    public function checkCourse($param){
        if(!isset($param['courseId'])){
            return false;
        }
    }

    //返回用户id，如果为空，表示未登录，需要redirect(Weixin::redirect($request->url(), 'snsapi_userinfo', 'user', true));
    //如果为-1，表示需要注册，redirect(Weixin::redirect($request->url(), 'snsapi_base', 'base', true));
    public static function checkWxLogin($code = '', $state = 'base') {
        $user_id = session('weixin_user_id');
        if ($code) {
            //如果传入code，会尝试去拉取最新用户信息，如果拉取失败，则返回他上次登录的id
            try{
                $user_info = $state == 'base' ? (array)Weixin::getUserInfoByCode($code, 'base', true) : (array)Weixin::getUserInfoByCode($code, 'user', true);
            } catch (\Exception $ex) {
                return $user_id;
            }
            $user = User::where('WeixinId', $user_info['unionid'])->first();
            if (empty($user) && $state == 'base') {
                //未注册，且未获取到用户昵称等信息，则进行下一次跳转
                return -1;
            } else {
                if (empty($user)) {
                    //未注册，已获取到用户昵称等信息
                    $user = new User();
                    $user->WeixinId = $user_info['unionid'];
                    $user->NickName = isset($user_info['nickname']) ? $user_info['nickname'] : '';
                    $user->Avatar = isset($user_info['headimgurl']) ? $user_info['headimgurl'] : '';
                    $user->Created = date("Y-m-d H:i:s");
                    $user->Creator = 1111;
                    $user->save();
                }
                Auth::loginUsingId($user->UserId);
                $user_id = $user->UserId;
                session(['weixin_user_id' => $user->UserId]);
            }
        }
        return $user_id;
    }

    public static function getUserByIds($ids)
    {
        return User::whereIn('UserId',$ids)
            ->where('RowStatus',0)
            ->get();
    }
    
    public function teacherLives()
    {
        return $this->belongsToMany('App\Entities\Live', 'live_signs')->where('type', 1);
    }
}
