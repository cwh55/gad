<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class GamePai extends Model
{
    use SoftDeletes;

    protected $fillable = ['logo','banner','title','sub_title','date','phase','is_show_video','section_video','is_show_text','section_text','is_show_project','section_project','is_show_comment','section_comment','program','deleted_at','sms_code','download','hint','view_count','like_count','fav_count','comment_count','cover','recommend_cover','status','banner_color','related'];

    protected $table = 'gad_gamepais';
    protected $casts = [  'is_show_text' => 'boolean',
        'is_show_video' => 'boolean',
        'is_show_project' => 'boolean',
        'is_show_comment' => 'boolean',
        'section_video' => 'array',
        'section_text' => 'array',
        'section_project' => 'array',
        'section_comment' => 'array',
        'program' => 'array',
        'download' => 'array',
        'related' => 'array'
    ];
}
