<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Article extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['archive_id','content_type','content','content_md','attachments','type','deleted_at','source','draft_content','draft_content_md'];
    
    protected $table = 'gad_articles';
    
    protected $casts = ['attachments' => 'array'];
}
