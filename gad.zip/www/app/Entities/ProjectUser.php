<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use Auth;

class ProjectUser extends Model implements Transformable
{
    use TransformableTrait, SoftDeletes;

    protected $table = "team_project_users";

    protected $fillable = [ 'title', 'phone', 'weixin','mail', 'creator'];

}
