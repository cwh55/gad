<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 2017/6/2
 * Time: 14:56
 */

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;


class IndependGame extends Model
{
    protected $table = 'tbIndependGame';
    protected $primaryKey = 'iId';
}