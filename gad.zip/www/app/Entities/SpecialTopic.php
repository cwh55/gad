<?php

namespace App\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class SpecialTopic extends Model
{
    use SoftDeletes;

    protected $fillable = ['logo', 'banner', 'game_name', 'game_description', 'game_url',  'recommend_picture', 'recommend_text',
        'ad', 'content','title','question_topic', 'view_count', 'like_count', 'favorite_count', 'status', 'creator', 'created_at', 'updater', 'is_show_ad', 'is_show_top_ad', 'more_topics', 'topic_pic', 'question_title',

    ];

    protected $table = 'gad_special_topics';
    protected $casts = [
        'recommend_picture' => 'array',
        'recommend_text' => 'array',
        'ad' => 'array',
        'content' => 'array',
        'question_topic' => 'array',
        'more_topics' => 'array',
        'is_show_top_ad' => 'boolean',
        'is_show_ad' => 'boolean',
    ];

    public function user()
    {

        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
}
