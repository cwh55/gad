<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class FollowUser extends Model implements Transformable
{
    use TransformableTrait;

    protected $table = "gad_follow_users";

    protected $fillable = ['user_id', 'introduction'];

    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
}
