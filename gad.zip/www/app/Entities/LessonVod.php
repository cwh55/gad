<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class LessonVod extends Model implements Transformable
{
    use TransformableTrait;

    protected $table = 'lesson_vod';
    protected $fillable = ['course_id', 'lesson_id', 'file_id', 'sort', 'vid', 'title', 'img_url', 'duration', 'status'];

}
