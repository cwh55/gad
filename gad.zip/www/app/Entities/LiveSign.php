<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class LiveSign extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['live_id', 'user_id', 'type', 'nickname', 'avatar', 'description', 'midas_billno',
        'creator', 'updater'];
    
    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }
}
