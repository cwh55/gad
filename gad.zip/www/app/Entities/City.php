<?php
/**
 * Created by PhpStorm.
 * User: v_whuachen
 * Date: 2017/8/8
 * Time: 8:24
 */

namespace App\Entities;
use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use Auth;

class City extends Model implements Transformable
{
    use TransformableTrait;
    use SoftDeletes;

    protected $table="gad_cities";
    protected $fillable = [ 'name', 'icon', 'url', 'is_new', 'owner_name', 'owner_email', 'owner_phone', 'background_img','qq_group','qq_group_key','signup_end_time'];

}