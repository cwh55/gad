<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 2017/6/2
 * Time: 14:56
 */

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class UserTag extends Model
{
    protected $table = 'gad_user_tags';

    protected $fillable = ['tag_id','user_id','lvl','source','created_at','updated_at'];

    public function archives()
    {
        return $this->belongsToMany('App\Entities\Archive', 'gad_archive_tags');
    }
}