<?php

namespace App\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Live extends Model implements Transformable
{
    use TransformableTrait;
    use SoftDeletes;

    protected $fillable = ['name', 'description', 'begin_time', 'end_time', 'class', 'tags', 'sign_num', 'sign_count',
        'price', 'state', 'rowstatus', 'tips', 'weixin_tips', 'creator', 'updater'];
    protected $casts = ['begin_time' => 'datetime', 'end_time' => 'datetime'];

    public function signs()
    {
        return $this->hasMany('App\Entities\LiveSign');
    }

    public function teachers()
    {
        return $this->hasMany('App\Entities\LiveSign')->where(['type' => 1]);
    }

    public function admins()
    {
        return $this->hasMany('App\Entities\LiveSign')->where(['type' => 2]);
    }

    public function students()
    {
        return $this->hasMany('App\Entities\LiveSign')->where(['type' => 3])->orderBy('id','desc');
    }

    public function newest6students()
    {
        return $this->hasMany('App\Entities\LiveSign')->where(['type' => 3])->orderBy('id' ,'desc')->limit(6);
    }

    public function newest8students()
    {
        return $this->hasMany('App\Entities\LiveSign')->where(['type' => 3])->orderBy('id' ,'desc')->limit(8);
    }

    public function getSignCountAttribute()
    {
        if ($this->attributes['sign_count'] <= 8) {
            return $this->attributes['sign_count'];
        }

        $rand = $this->attributes['sign_count'] > 5 ? ($this->attributes['sign_count'] % 5) : 0;

        return $this->attributes['sign_count'] * 5 + $rand;
    }
}
