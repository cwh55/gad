<?php
namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class CityProject extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['city_id','project_id','name','description','logo','url','order_no'];
    
    protected $table = 'gad_city_projects';
    
}
