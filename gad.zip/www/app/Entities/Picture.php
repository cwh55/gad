<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;
use Auth;

class Picture extends Model implements Transformable
{
    use TransformableTrait, SoftDeletes;

    protected $table = "gad_pictures";

    protected $fillable = ['archive_id', 'channel_id', 'type', 'user_id', 'user_name', 'url', 'content',
        'comment_count', 'like_count', 'favorite_count', 'view_count', 'sort', 'status', 'hot_score', 'publish_time',
        'width', 'height', 'source_type', 'mofang_id', 'videourl'];

    protected $hidden = ['hot_score', 'deleted_at'];

    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
    public function archive()
    {
        return $this->hasOne('App\Entities\Archive', 'id', 'archive_id');
    }
    public function mylike()
    {
        return $this->hasMany('App\Entities\Like', 'model_id', 'id')->where('model_type', 'App\Entities\Picture')
            ->where('user_id', Auth::user()['UserId']);
    }
}
