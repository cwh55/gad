<?php

namespace App\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class HatchProjectStructure extends Model
{

    protected $fillable = ['user_id','logo','title','description','name','banner','button_name','button_intro',
        'button_url','type','end_time','start_time','url','game_id'];

    protected $hidden = ['created_at'];

    protected $table = 'gad_project_structures';
    
    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
    
    public function project()
    {
        return $this->hasOne('App\Entities\HatchProject','structure_id');
    }
}
