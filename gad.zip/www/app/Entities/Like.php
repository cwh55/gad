<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Traits\TransformableTrait;

class Like extends Model implements Transformable
{
    use TransformableTrait;

    use SoftDeletes;

    protected $table = 'gad_likes';

    protected $fillable = ['model_type','model_id','user_id','status'];

    public function likeModel(){
      return $this->morphTo('model');
    }

    public function user(){
      return $this->belongsTo('App\Entities\User','user_id','UserId');
    }

}
