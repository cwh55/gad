<?php

namespace App\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Vote extends Model
{
    protected $fillable = [
        'project_id',//所属的对象id
        'date',//对象类型(0个人/1机构)
        'user_id',//报名用户id
    ];

    protected $hidden = ['deleted_at'];

    protected $table = 'gad_project_votes';
    
    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
    
    public function project()
    {
        return $this->belongsTo('App\Entities\HatchProject');
    }
}
