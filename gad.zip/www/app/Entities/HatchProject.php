<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;
use Illuminate\Database\Eloquent\SoftDeletes;

class HatchProject extends Model implements Transformable
{
    use TransformableTrait, SoftDeletes;

    protected $table = "gad_projects";

    protected $fillable = ["user_id","created_from","is_public","name","logo","type","progress","team_num","pictures",
        "intro","platform","demo","videos","ppt","team_type","team_business_license","team_name","team_logo","team_province",
        "team_city","team_intro","team_contacts","team_id_card","team_phone","team_email","team_weixin","comment_count","view_count",
        "like_count","favorite_count","vote_count","download_count","updater",'created_from_id','structure_id','other_attachment',
        "push_email_status","is_public_demo",'music','expert_comment_count','is_finish','hatch_status','rank','progress_explan'];

    protected $casts = ['type' => 'array', 'pictures'=>'array', 'platform'=>'array', 'demo' => 'array', 'videos' => 'array',
        'ppt'=>'array', 'other_attachment'=>'array','is_public_demo'=>'boolean','music'=>'array','progress_explan'=>'array'];

    protected $visible = ['id','structure_id','user_id','created_from','is_public','name','logo','type','progress','team_num',
        'pictures','intro','platform','videos','ppt','music','team_name','team_logo','team_intro','created_at','push_email_status',
        'is_public_demo','expert_comment_count','hatch_status','rank','progress_explan'];

    public function game() {
        return $this->hasOne('App\Entities\HatchGame','project_id');
    }

    public function oldgame() {
        return $this->hasOne('App\Models\Game', 'project_id');
    }

    public function structure() {
        return $this->belongsTo('App\Entities\HatchProjectStructure','structure_id');
    }
}