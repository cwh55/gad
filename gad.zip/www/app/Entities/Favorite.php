<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Traits\TransformableTrait;

class Favorite extends Model implements Transformable
{
    use TransformableTrait;

    use SoftDeletes;

    protected $table = 'gad_favorites';

    protected $fillable = ['model_type','model_id','user_id'];

    public function user(){
      return $this->belongsTo('App\Models\User','user_id','UserId');
    }

    public function favModel(){
      return $this->morphTo('model');
    }

}
