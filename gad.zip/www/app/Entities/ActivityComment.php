<?php

namespace App\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ActivityComment extends Model
{
    use SoftDeletes;

    const TYPE_OFFLINE = 1;
    const TYPE_ONLINE = 2;
    const TYPE_QUESTION = 3;
    const TYPE_TOPIC = 4;
    const TYPE_COMMENT = 5;

    protected $fillable = ['user_id','comment','comment_count','like_count','activity_id','activity_type','status'];

    protected $hidden = ['channel_id','hot_score','score1','score2','score3','score4','score5','score6','score7','ccid','sort_time','deleted_at'];

    protected $table = 'gad_activity_comments';
    protected $casts = [];
    
    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
    
    public function activity()
    {
        return $this->belongsTo('App\Entities\Activity','activity_id');
    }
    
    public function tags()
    {
        return $this->belongsToMany('App\Entities\Tag', 'gad_archive_tags')->withTimestamps();
    }

    public function pictures()
    {
        return $this->hasMany('App\Entities\Picture', 'archive_id', 'id')->orderBy('sort' ,'asc');
    }

    public function question()
    {
      return $this->hasOne('App\Entities\Question');
    }
}
