<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 2017/7/12
 * Time: 15:54
 */

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use Auth;

class Resume extends Model implements Transformable
{
    use TransformableTrait, SoftDeletes;

    protected $table = "team_resumes";

    protected $fillable = [
        'real_name','photo', 'gender', 'birthday', 'education', 'province', 'city', 'phone', 'email', 'career_state',
        'career_type', 'work_date', 'intent_city', 'work_type', 'intro', 'skill', 'jobs', 'works_pictures',
        'works_videos', 'works_audios', 'works_zips', 'works_remarks', 'github', 'zhihu', 'site', 'other',
        'user_id', 'step', 'reason','state','is_show'
    ];
    protected  $appends = ['workTypes','intentCities','nickname','ageofwork','nickphoto','completed','age'];


    protected $casts = [
        'skill' => 'array',
        'jobs' => 'array',
        'works_pictures' => 'array',
        'works_videos' => 'array',
        'works_audios' => 'array',
        'works_zips' => 'array'
    ];

    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }

    public function applyActions()
    {
        return $this->hasMany('App\Entities\TeamAction', 'resume_user', 'user_id')->where('action_type', 'apply');
    }

    public function inviteActions()
    {
        return $this->hasMany('App\Entities\TeamAction', 'resume_id', 'id')->where('action_type', 'invite');
    }

    public function getIntentCitiesAttribute()
    {
        return explode(',',$this->intent_city);
    }

    public function getWorkTypesAttribute()
    {
        return explode(',',$this->work_type);
    }
    public function getAgeAttribute()
    {
        list($by,$bm,$bd)=explode('-',$this->birthday);
        $cm=date('n');
        $cd=date('j');
        $age=date('Y')-$by-1;
        if ($cm>$bm || $cm==$bm && $cd >= $bd) $age++;
        return $age;
    }

    public function getAgeOfWorkAttribute()
    {
        list($by,$bm,$bd)=explode('-',$this->work_date);
        $cm=date('n');
        $cd=date('j');
        $age=date('Y')-$by-1;
        if ($by =='0000') {
            return 0;
        }
        if ($cm>$bm || $cm==$bm && $cd>$bd) $age++;
        return $age>0?$age:0;
    }

    public function getIsAcceptInviteAttribute()
    {
        if (!Auth::check()) {
            return false;
        }  else {
            $action = $this->inviteActions()->where('project_user',Auth::user()->UserId)->first();
            if ($action and $action->state == 1) {
                return true;
            } else {
                return false;
            }
        }
    }

    public function allowAccess()
    {
        if ($this->state == 1) {
            return true;
        } else {
            if (!Auth::check()) {
                return false;
            }
            $user = Auth::user();
            if ($user->UserId == $this->user_id || $user->roles->contains(2)) {
                return true;
            }
            //项目发起人可查看
            $applyAction = $this->applyActions()->where('project_user', $user->UserId)->first();
            if ($applyAction) {
                return true;
            }
            return false;
        }
    }

    public function getPhotoAttribute()
    {
        if (!$this->attributes['photo']) {
            return 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg';
        }
        return $this->attributes['photo'];
    }

    public function getNickNameAttribute()
    {
        if ($this->gender == '男') {
           return  mb_substr($this->real_name,0,1).'先生';
        }
        return  mb_substr($this->real_name,0,1).'女士';
    }

    public function getNickPhotoAttribute()
    {
        return 'http://gad.qpic.cn/assets/web/img/global/default_headpic.jpg';
    }

    //简历完成度
    public function getCompletedAttribute()
    {
        $completed = 5;
        if ($this->real_name !='') {
            $completed +=5;
        }
        if ($this->gender !='') {
            $completed +=5;
        }
        if ($this->photo !='') {
            $completed +=5;
        }
        if ($this->education !='') {
            $completed +=5;
        }
        if ($this->city !='') {
            $completed +=5;
        }
        if ($this->career_type !='') {
            $completed +=5;
        }
        if ($this->work_date !='') {
            $completed +=5;
        }
        if (count($this->intent_city) >0) {
            $completed +=5;
        }
        if (count($this->work_type) >0) {
            $completed +=5;
        }
        if (count($this->skill) >0) {
            $completed +=5;
        }
        if ($this->intro != '') {
            $completed +=5;
        }
        if (count($this->jobs) > 0) {
            $completed +=5;
        }
        if (
            count($this->works_pictures) > 0
            or count($this->works_videos) > 0
            or count($this->works_audios) > 0
            or count($this->works_zips) > 0
        ) {
            $completed +=5;
        }

        if ($this->phone != '') {
            $completed +=5;
        }
        if ($this->email != '') {
            $completed +=5;
        }
        if ($this->github != '') {
            $completed +=5;
        }
        if ($this->zhihu != '') {
            $completed +=5;
        }
        if ($this->site != '') {
            $completed +=5;
        }
        if ($this->other != '') {
            $completed +=5;
        }

        return $completed;

    }

    //
    public function getCompletedStepsAttribute()
    {
        $completedSteps = [
            'baseInfo' => true,
            'careerInfo' => false,
            'introInfo' => false,
            'jobInfo' => false,
            'worksInfo' => false,
            'snsInfo' => false
        ];
        if ($this->career_type != '') {
            $completedSteps['careerInfo'] = true;
        }
        if ($this->intro != '') {
            $completedSteps['introInfo'] = true;
        }
        if (count($this->jobs) > 0) {
            $completedSteps['jobInfo'] = true;
        }
        if (
            count($this->works_pictures) > 0
            or count($this->works_videos) > 0
            or count($this->works_audios) > 0
            or count($this->works_zips) > 0
        ) {
            $completedSteps['worksInfo'] = true;
        }

        if (
            $this->github != ''
            or $this->zhihu != ''
            or $this->site != ''
            or $this->other != ''
        ) {
            $completedSteps['snsInfo'] = true;
        }

        return $completedSteps;

    }


    //置顶，管理端用
    public static function setTop($id)
    {
        $question = self::withTrashed()->where('id', '=', $id)->firstOrFail();
        $question->is_top = self::query()->max('is_top') + 1;
        $question->save();
        return $question;
    }


}