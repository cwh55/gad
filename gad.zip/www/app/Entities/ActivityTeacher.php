<?php

namespace App\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ActivityTeacher extends Model
{
    use SoftDeletes;

    protected $fillable = ['channel_id','class_id'];

    protected $table = 'gad_archives';
    protected $casts = ['extra' => 'array'];
    
    public function user()
    {
        return $this->hasOne('App\Entities\User', 'UserId', 'user_id');
    }
}
