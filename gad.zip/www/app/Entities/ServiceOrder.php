<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

/**
 * Class ServiceOrder
 * 项目扶持-资源对接
 * @package App\Entities
 */
class ServiceOrder extends Model implements Transformable
{
    use TransformableTrait;
    use SoftDeletes;
    protected $table = 'gad_project_service_orders';

    protected $fillable = ['apply_member_id', 'provide_member_id', 'service_id', 'service_type', 'cooperation_intention',
        'attachment', 'status', 'created_at', 'updater', 'updated_at', 'deleted_at', 'reason','user_id','remark','extra'
    ];

    protected $casts = [
        'attachment'=>'array',
        'extra' => 'array'
    ];
    /**
     * 状态
     * @var array
     */
    public static $statusList = [
        1 => '提交需求',
        2 => '需求单建立',
        3 => '初审中',
        4 => '复审中',
        5 => '商务沟通',
        6 => '签署协议',
        7 => '资料准备',
        8 => '版号办理',
        9 => '入驻场地',
        10 => '需求完成',
        11 => '需求单取消',
    ];

    /**
     * 服务类型对应状态
     * @var array
     */
    public static $typeStatus = [
        1 => [1, 2, 6, 10],//IP
        2 => [1, 2, 6, 7, 8, 10],//版号
        3 => [1, 2, 6, 9, 10],//办公场地
        4 => [1, 2, 6, 10],//投融资
        5 => [1, 2, 3, 4, 5, 10],//发行
    ];

    /**
     * 获取服务详情
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function service()
    {
        return $this->belongsTo('App\Entities\Service', 'service_id');
    }

    /**
     * 获取服务申请方
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function applyMember()
    {
        return $this->belongsTo('App\Entities\ServiceMember', 'apply_member_id');
    }

    /**
     * 获取服务提供方
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function provideMember()
    {
        return $this->belongsTo('App\Entities\ServiceMember', 'provide_member_id');
    }



}
