<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Feed extends Model
{
    use SoftDeletes;

    protected $fillable = ['class_id','title','description','cover','tag','user_id','user_name','creator','comment_count','like_count','favorite_count','view_count','action_id','answer_id','sort_time','archive_id','is_video','status','total','deleted_at','extra'];
    protected $table = 'gad_feeds';
    protected $casts = ['extra' => 'array'];
    
}
