<?php
/**
 * Created by PhpStorm.
 * User: xiaolinwang
 * Date: 2017/6/2
 * Time: 15:46
 */

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ArchiveTag extends Model
{
    protected $table = 'gad_archive_tags';

    protected $fillable = ['tag_id','user_id','lvl','source','created_at','updated_at'];

    public function archive()
    {
        return $this->hasOne('App\Entities\Archive', 'archive_id');
    }

}