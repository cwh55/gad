<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;


class CityStation extends Model implements Transformable
{
    use TransformableTrait;
    use SoftDeletes;

    protected $fillable = ['city_id', 'type', 'group_type', 'user_id', 'name', 'position', 'qq', 'mobile', 'corp', 'members',
        'status', 'game_name', 'game_os', 'game_type', 'description', 'game_att','created_at','updated_at','deleted_at'];
    
    protected $casts = ['game_att' => 'array'];

    public function users()
    {
      return $this->belongsTo('App\Models\User','user_id');
    }

    public function city()
    {
        return $this->belongsTo('App\Entities\City','city_id');
    }

}
