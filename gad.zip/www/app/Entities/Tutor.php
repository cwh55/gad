<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: ShouKun Liu  |  Email:24147287@qq.com  | Time:2017/7/13 10:56
// +----------------------------------------------------------------------
// | TITLE: 晨星专家
// +----------------------------------------------------------------------

namespace App\Entities;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Tutor extends Model
{

    use SoftDeletes;

    protected $table = "gad_tutors";

    protected $fillable = [
        'year_month','url','avatar','dim','name','description','detail','summary','rank','creator',
        'created_at', 'updated_at', 'deleted_at'];
}