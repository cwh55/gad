<?php

namespace App\Policies;

use App\Entities\Live;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class LivePolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function before($user, $ability)
    {
        // 角色为管理员有所有权限
        if ($user->roles->contains(2)) {
            //return true;
        }
    }

    public function teacher(User $user, Live $live)
    {
        return $live->teachers()->where('live_signs.user_id', $user->UserId)->exists();
    }

    public function admin(User $user, Live $live)
    {
        return $live->admins()->where('live_signs.user_id', $user->UserId)->exists();
    }

    public function access(User $user, Live $live)
    {
        return $live->signs()->where('live_signs.user_id', $user->UserId)->exists();
    }
}
