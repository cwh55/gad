<?php

namespace App\Policies;

use App\Models\User;
use App\Entities\Lore;
use Illuminate\Auth\Access\HandlesAuthorization;

class LorePolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function access(User $user, Lore $lore)
    {
        //免费课程或者该用户已付费
        return $lore->price == 0 || $lore->isPayed();
    }

    public function accessdraft(User $user)
    {
       return $user->roles->contains(2);
    }
}
