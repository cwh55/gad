<?php

namespace App\Policies;

use App\Entities\Project;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class TeamProjectPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * 前置判断，管理员有一切权限
     *
     * @param $user
     * @param $ability
     * @return bool
     */
    public function before($user, $ability)
    {
        // 角色为管理员有所有权限
        if ($user->roles->contains(2)) {
            return true;
        }
    }

    /**
     * 项目创建权限校验
     *
     * @param User $user
     * @param Project $project
     * @return bool
     */
    public function create(User $user, Project $project)
    {
        // 黑名单用户无法创建项目
        return !$user->roles->contains(1);
    }

    /**
     * 项目查看权限校验
     *
     * @param User $user
     * @param Project $project
     * @return bool
     */
    public function access(User $user, Project $project)
    {
        return $project->user_id == $user->UserId;
    }

    /**
     * 项目编辑权限校验
     *
     * @param User $user
     * @param Project $project
     * @return bool
     */
    public function edit(User $user, Project $project)
    {
        return $this->access($user, $project);
    }

    /**
     * 项目删除权限校验
     *
     * @param User $user
     * @param Project $project
     * @return mixed
     */
    public function delete(User $user, Project $project)
    {
        return $this->access($user, $project);
    }
}
