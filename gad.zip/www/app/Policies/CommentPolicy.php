<?php

namespace App\Policies;

use App\Entities\Comment;
use App\Models\User;
use App\Repositories\BanRepository;
use Illuminate\Auth\Access\HandlesAuthorization;

class CommentPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * 前置判断，管理员有一切权限
     *
     * @param $user
     * @param $ability
     * @return bool
     */
    public function before($user, $ability)
    {
        // 角色为管理员有所有权限
        if ($user->roles->contains(2)) {
            return true;
        }
    }

    /**
     * 发表权限校验
     *
     * @param User $user
     * @param Comment $comment
     * @return bool
     */
    public function create(User $user, Comment $comment)
    {
        $banRepository = app(BanRepository::class);

        return !$banRepository->isBaned($user);
    }

    /**
     * 编辑权限校验
     *
     * @param User $user
     * @param Comment $comment
     * @return bool
     */
    public function edit(User $user, Comment $comment)
    {
        // 发表者自身可以编辑
        if ($comment->user_id == $user->UserId) {
            return true;
        }

        return false;
    }

    public function delete(User $user, Comment $comment)
    {
        return $this->edit($user, $comment);
    }
}
