<?php

namespace App\Policies;

use App\Entities\Archive;
use App\Models\User;
use App\Repositories\BanRepository;
use Illuminate\Auth\Access\HandlesAuthorization;

class ArchivePolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * 前置判断，管理员有一切权限
     *
     * @param $user
     * @param $ability
     * @return bool
     */
    public function before($user, $ability)
    {
        // 角色为管理员有所有权限
        if ($user->roles->contains(2)) {
            return true;
        }
    }

    /**
     * 文档创建权限校验
     *
     * @param User $user
     * @param Archive $archive
     * @return bool
     */
    public function create(User $user, Archive $archive)
    {
        $banRepository = app(BanRepository::class);

        return !$banRepository->isBaned($user);
    }

    /**
     * 编辑权限校验
     *
     * @param User $user
     * @param Archive $archive
     * @return bool
     */
    public function edit(User $user, Archive $archive)
    {
        // 发表者自身可以编辑
        if ($archive->user_id == $user->UserId) {
            return true;
        }

        return false;
    }

    /**
     * 回复和评论权限校验
     *
     * @param User $user
     * @param Archive $archive
     * @return bool
     */
    public function reply(User $user, Archive $archive)
    {
        return $this->create($user, $archive);
    }

    /**
     * 免审核权限校验
     *
     * @param User $user
     * @param Archive $archive
     * @return mixed
     */
    public function verify(User $user, Archive $archive)
    {
        // 社区白名单用户免审核
        return $user->roles->contains(11);
    }
}
