<?php

namespace App\Policies;

use App\Models\Course;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class CoursePolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function before($user, $ability)
    {
        // 角色为管理员有所有权限
        if ($user->roles->contains(2)) {
            return true;
        }
    }

    public function create(User $user, Course $course)
    {
        // 角色为直播白名单，未失效的老师可以创建分享
        return $user->roles->contains(10) AND $user->teacher->status == 0;
    }

    public function edit(User $user, Course $course)
    {
        if ($course->user_id == $user->UserId) {
            return true;
        }
        
        if ($course->teachers->contains('user_id', $user->UserId)) {
            return true;
        }

        if ($course->assistants->contains('user_id', $user->UserId)) {
            return true;
        }

        return false;
    }

    public function learn(User $user, Course $course)
    {
        if ($course->hasStudent($user)) {
            return true;
        }

        return $this->edit($user, $course);
    }
}
