<?php

namespace App\Policies;

use App\Models\Lesson;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class LessonPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function before($user, $ability)
    {
        // 角色为管理员有所有权限
        if ($user->roles->contains(2)) {
            return true;
        }
    }

    public function create(User $user, Lesson $lesson)
    {
        $course = $lesson->course;
        if ($course->user_id == $user->UserId) {
            return true;
        }

        if ($course->teachers->contains('user_id', $user->UserId)) {
            return true;
        }

        if ($course->assistants->contains('user_id', $user->UserId)) {
            return true;
        }

        return false;
    }

    public function update(User $user, Lesson $lesson)
    {
        return $this->create($user, $lesson);
    }

    public function show(User $user, Lesson $lesson)
    {
        $course = $lesson->course;
        if ($course->hasStudent($user)) {
            return true;
        }

        return $this->update($user, $lesson);
    }
}
