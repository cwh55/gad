<?php

namespace App\Jobs;

use App\Jobs\Job;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Tof;

class SendMail extends Job implements ShouldQueue
{
    use InteractsWithQueue, SerializesModels;

    protected $to;
    protected $title;
    protected $content;
    protected $cc;

    /**
     * 发送邮件任务
     *
     * SendMail constructor.
     * @param $to
     * @param $title
     * @param $content
     * @param string $cc
     */
    public function __construct($to, $title, $content, $cc = '')
    {
        $this->to = $to;
        $this->title = $title;
        $this->content = $content;
        $this->cc = $cc;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        Tof::service('message')->sendEmail('gad@tencent.com', $this->to, $this->title, $this->content, $this->cc);
    }
}
