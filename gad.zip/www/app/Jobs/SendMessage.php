<?php

namespace App\Jobs;

use App\Jobs\Job;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Tof;

class SendMessage extends Job implements ShouldQueue
{
    use InteractsWithQueue, SerializesModels;

    protected $type, $user_id, $sender, $obj_id, $obj_url, $obj_content, $ext_id, $ext_url, $ext_content;

    /**
     * 消息系统调用接口
     * @param SMALLINT $type 消息类型(动态10x/关注20x/系统30x)
     * @param int $user_id  消息所属者id
     * @param int $sender   消息生产者id
     * @param int $obj_id   消息内容id(文章id/问答id/评论id)
     * @param varchar $obj_url  消息链接url
     * @param varchar $obj_content  消息内容
     * @param int $ext_id   附加消息内容id
     * @param varchar $ext_url  附加消息链接
     * @param varchar $ext_content  附加消息内容
     * @return bool
     */
    public function __construct($type, $user_id=array(), $sender=0, $obj_id=0, $obj_url='', $obj_content='', $ext_id=0, $ext_url='', $ext_content='')
    {
        $this->type = $type;
        $this->user_id = !is_array($user_id) ? [$user_id] : $user_id;
        $this->sender = $sender;
        $this->obj_id = $obj_id;
        $this->obj_url = preg_replace('#^http://www.gad.oa.com/#', 'http://gad.qq.com/', $obj_url);
        $this->obj_content = $obj_content;
        $this->ext_id = $ext_id;
        $this->ext_url = $ext_url;
        $this->ext_content = $ext_content;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        foreach($this->user_id as $user_id){
            if(!\App\Gad\Func::msgApi($this->type, $user_id, $this->sender, $this->obj_id, $this->obj_url, $this->obj_content, $this->ext_id, $this->ext_url, $this->ext_content)){
                throw new \Exception('站内消息接口调用失败');
            }
        }
    }
}
