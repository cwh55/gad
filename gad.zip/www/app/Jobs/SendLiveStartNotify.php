<?php

namespace App\Jobs;

use App\Entities\Live;
use App\Models\User;
use App\Gad\Weixin;
use App\Jobs\Job;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendLiveStartNotify extends Job implements ShouldQueue
{
    use InteractsWithQueue, SerializesModels;

    /**
     * @var Live
     */
    protected $live;

    /**
     * @var User
     */
    protected $user;

    /**
     * SendCourseStartNotify constructor.
     * @param Live $live
     * @param User $user
     */
    public function __construct(Live $live, User $user)
    {
        $this->live = $live;
        $this->user = $user;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $weixin = config('weixin');
        $templateId = $weixin['tpl_msg_id']['course_start'];
        $openId = Weixin::commonId2openId($weixin['app_id'], $this->user->WeixinId);
        $data = [
            'first' => $this->user->NickName.'同学，您报名的Live马上就要开始了',
            'keyword1' => $this->live->name,
            'keyword2' => $this->live->begin_time->toDateTimeString(),
            'keyword3' => '腾讯游戏开发者平台Live问答',
            'remark' => '还有5分钟就开始了，点击进入！'
        ];
        $url = sprintf('http://%s/m/live/detail/%s', app()->isLocal() ? 'dev.m.gad.qq.com' : 'm.gad.qq.com', $this->live->id);

        try {
            Weixin::sendTemplateMessage($templateId, $openId, $url, $data);
        } catch (\Exception $e) {
            if ($e->getCode() != 43004) {
                throw $e;
            }
        }
    }
}
