<?php

namespace App\Jobs;

use App\Gad\Weixin;
use App\Jobs\Job;
use App\Models\Course;
use App\Models\User;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Log;

class SendCourseRegisteredNotify extends Job implements ShouldQueue
{
    use InteractsWithQueue, SerializesModels;

    /**
     * @var Course
     */
    protected $course;

    /**
     * @var User
     */
    protected $user;

    /**
     * SendCourseRegisteredNotify constructor.
     * @param Course $course
     * @param User $user
     */
    public function __construct(Course $course, User $user)
    {
        $this->course = $course;
        $this->user = $user;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $weixin = config('weixin');
        $templateId = $weixin['tpl_msg_id']['course_register'];
        $openId = Weixin::commonId2openId($weixin['app_id'], $this->user->WeixinId);
        $lesson = $this->course->lesson;
        $data = [
            'first' => '恭喜'.$this->user->NickName.'同学，您已成功报名以下直播',
            'keyword1' => $this->course->title,
            'keyword2' => sprintf('%s %s-%s', $lesson->begin_date, $lesson->begin_time, $lesson->end_time),
            'remark' => '请准时来观看哦！'
        ];
        $url = sprintf('http://%s/course/detail.html?id=%s', app()->isLocal() ? 'dev.m.gad.qq.com' : 'm.gad.qq.com', $this->course->id);
        try {
            Weixin::sendTemplateMessage($templateId, $openId, $url, $data);
        } catch (\Exception $e) {
            if ($e->getCode() != 43004) {
                throw $e;
            }
        }

    }
}
