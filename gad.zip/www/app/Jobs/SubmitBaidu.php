<?php

namespace App\Jobs;

use App\Jobs\Job;
use Illuminate\Queue\SerializesModels;
use App\Exceptions\GadException;
use GuzzleHttp\Client;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Tencent\CL5\Client as CL5;

class SubmitBaidu extends Job implements ShouldQueue
{
    use InteractsWithQueue, SerializesModels;

    /**
     * @var string
     */
    public $queue = 'community';

    /**
     * @var string
     */
    protected $url;

    /**
     * SubmitBaidu constructor.
     *
     * @param $url
     */
    public function __construct($url)
    {
        $this->url = $url;
    }

    /**
     * 执行提交URL到百度
     *
     * @throws GadException
     */
    public function handle()
    {
        $baiduApi = 'http://data.zz.baidu.com/urls?site=gad.qq.com&token=yzfoLu5CNawlRtGp';
        $client = new Client([
            'timeout' => 10,
            'headers' => ['Content-Type' => 'text/plain'],
            'proxy' => ['http' => $this->getProxy()],
            'http_errors' => false
        ]);

        $response = $client->post($baiduApi, ['body' => $this->url]);
        $body = $response->getBody();
        $result = json_decode($body);
        if ($result === null) {
            throw new GadException('百度提交接口返回异常：%s', $body);
        }

        if (empty($result->success)) {
            if ($error = data_get($result, 'error')) {
                throw new GadException('百度提交接口出错：[%d] %s', $error, data_get($result, 'message'));
            }

            throw new GadException('百度提交接口出错：[%s] URL错误', $this->url);
        }
    }

    /**
     * 获取HTTP代理
     *
     * @return string
     */
    protected function getProxy()
    {
        $config = [
            'modId' => config('app.https_proxy_cl5_modId'),
            'cmdId' => config('app.https_proxy_cl5_cmdId'),
            'default' => ['hostIp' => '10.213.154.2', 'hostPort' => 8080]
        ];
        $server = CL5::getRoute($config, app()->environment('production') === false);

        return sprintf('tcp://%s:%s', $server['hostIp'], $server['hostPort']);
    }
}
