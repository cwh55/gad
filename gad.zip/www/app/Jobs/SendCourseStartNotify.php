<?php

namespace App\Jobs;

use App\Gad\Weixin;
use App\Jobs\Job;
use App\Models\Course;
use App\Models\User;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendCourseStartNotify extends Job implements ShouldQueue
{
    use InteractsWithQueue, SerializesModels;

    /**
     * @var Course
     */
    protected $course;

    /**
     * @var User
     */
    protected $user;

    /**
     * SendCourseStartNotify constructor.
     * @param Course $course
     * @param User $user
     */
    public function __construct(Course $course, User $user)
    {
        $this->course = $course;
        $this->user = $user;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $weixin = config('weixin');
        $templateId = $weixin['tpl_msg_id']['course_start'];
        $openId = Weixin::commonId2openId($weixin['app_id'], $this->user->WeixinId);
        $lesson = $this->course->lesson;
        $data = [
            'first' => $this->user->NickName.'同学，您报名的直播马上就要开始了',
            'keyword1' => $this->course->title,
            'keyword2' => sprintf('%s %s-%s', $lesson->begin_date, $lesson->begin_time, $lesson->end_time),
            'keyword3' => '腾讯游戏开发者平台',
            'remark' => '还有5分钟就开始了，点击进入！'
        ];
        $url = sprintf('http://%s/course/detail.html?id=%s', app()->isLocal() ? 'dev.m.gad.qq.com' : 'm.gad.qq.com', $this->course->id);
        Weixin::sendTemplateMessage($templateId, $openId, $url, $data);
    }
}
