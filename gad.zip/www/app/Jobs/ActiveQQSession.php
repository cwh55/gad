<?php

namespace App\Jobs;

use App\Jobs\Job;
use Cache;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Tencent\Ptlogin\Ptlogin;

class ActiveQQSession extends Job implements ShouldQueue
{
    use InteractsWithQueue, SerializesModels;

    public $delay = 2940;

    protected $uin;
    protected $skey;
    protected $sessionId;
    protected $loginTime;

    /**
     * ActiveQQSession constructor.
     *
     * @param $uin
     * @param $skey
     * @param $sessionId
     * @param $loginTime
     */
    public function __construct($uin, $skey, $sessionId, $loginTime)
    {
        $this->uin = $uin;
        $this->skey = $skey;
        $this->sessionId = $sessionId;
        $this->loginTime = $loginTime;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {


        // 续期超时，QQ登录态最多续期2天
        $expire = $this->loginTime + 172800;
        if (time() > $expire) {
            return;
        }

        // 会话关联的会话已失效，无需续期
        if (!Cache::get($this->sessionId)) {
            return;
        }

        if (Ptlogin::check($this->uin, $this->skey)) {
            $job = new static($this->uin, $this->skey, $this->sessionId, $this->loginTime);
            dispatch($job);
        }
    }
}
