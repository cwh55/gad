<?php

namespace App\Jobs;

use App\Gad\Weixin;
use App\Jobs\Job;
use Cache;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class ActiveWeixinSession extends Job implements ShouldQueue
{
    use InteractsWithQueue, SerializesModels;

    public $delay = 7140;

    protected $appId;
    protected $refreshToken;
    protected $sessionId;
    protected $loginTime;

    /**
     * ActiveWeixinSession constructor.
     * 
     * @param $appId
     * @param $refreshToken
     * @param $sessionId
     * @param $loginTime
     */
    public function __construct($appId, $refreshToken, $sessionId, $loginTime)
    {
        $this->appId = $appId;
        $this->refreshToken = $refreshToken;
        $this->sessionId = $sessionId;
        $this->loginTime = $loginTime;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        // 续期超时，微信AccessToken最多续期2天（微信侧最多可以续30天）
        $expire = $this->loginTime + 172800;
        if (time() > $expire) {
            return;
        }

        // 会话关联的会话已失效，无需续期
        if (!Cache::get($this->sessionId)) {
            return;
        }

        try {
            $result = Weixin::refreshAccessToken($this->appId, $this->refreshToken);
            if (!empty($result->refresh_token)) {
                $job = new static($this->appId, $this->refreshToken, $this->sessionId, $this->loginTime);
                dispatch($job);
            }
        } catch (\Exception $e) {
            // ignore
        }
    }
}
