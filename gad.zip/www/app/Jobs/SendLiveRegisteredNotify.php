<?php

namespace App\Jobs;

use App\Gad\Weixin;
use App\Jobs\Job;
use App\Entities\Live;
use App\Models\User;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Log;

class SendLiveRegisteredNotify extends Job implements ShouldQueue
{
    use InteractsWithQueue, SerializesModels;

    /**
     * @var Course
     */
    protected $live;

    /**
     * @var User
     */
    protected $user;

    /**
     * SendLiveRegisteredNotify constructor.
     * @param Live $live
     * @param User $user
     */
    public function __construct(Live $live, User $user)
    {
        $this->live = $live;
        $this->user = $user;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        if($this->user->WeixinId) {
            $weixin = config('weixin');
            $templateId = $weixin['tpl_msg_id']['course_register'];
            $openId = Weixin::commonId2openId($weixin['app_id'], $this->user->WeixinId);
            //$lesson = $this->course->lesson;
            $data = [
                'first' => '恭喜' . $this->user->NickName . '同学，您已成功报名以下Live',
                'keyword1' => $this->live->name,
                'keyword2' => sprintf('%s-%s', $this->live->begin_time, $this->live->end_time),
                'remark' => '请准时来参与哦！'
            ];
            $url = sprintf('http://%s/m/live/detail/%s', app()->isLocal() ? 'dev.m.gad.qq.com' : 'm.gad.qq.com', $this->live->id);
            try {
                Weixin::sendTemplateMessage($templateId, $openId, $url, $data);
            } catch (\Exception $e) {
                if ($e->getCode() != 43004) {
                    throw $e;
                }
            }
        }
        /*
        else if($this->user->QQNo) {
            $tipsInfo = array(
                '128Char' => "http://gad.qq.com/live/detail/{$this->live->id}",
                'NickName' => $this->user->NickName,
                '64Char' => "《{this->user->$name}》",
                'Time' => date('Y-m-d H:i'),
                'qq' => $this->user->QQNo,
            );

        }*/

    }
}
