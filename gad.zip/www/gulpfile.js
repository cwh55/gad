var $ = require('gulp-load-plugins')();
var gulp = require('gulp');

//压缩js
gulp.task('minijs', function () {
    return gulp.src('public/assets/**/*.js', {base: './'})
        .pipe($.plumber({
            errorHandler: function (error) {
              $.util.log(error.toString());
            }
        }))
        .pipe($.uglify({mangle: false}))
        .pipe(gulp.dest('./dist'));
});
//压缩css
gulp.task('minicss', function () {
    return gulp.src('public/assets/**/*.css', {base: './'})
        .pipe($.plumber({
            errorHandler: function (error) {
              $.util.log(error.toString());
            }
        }))
        .pipe($.minifyCss({
            restructure: false
        }))
        .pipe(gulp.dest('./dist'));
});

//版本管理，js和css引用地址后加上md5
gulp.task('rev', function(){
    gulp.src('resources/**/*.php', {base: './'})
        .pipe($.replace('href="http://gad.qpic.cn', 'flag="gulp-replace" href="/public'))
        .pipe($.replace('src="http://gad.qpic.cn', 'flag="gulp-replace" src="/public'))
        .pipe($.revAppend())
        .pipe($.replace('flag="gulp-replace" href="/public', 'href="http://gad.qpic.cn'))
        .pipe($.replace('flag="gulp-replace" src="/public', 'src="http://gad.qpic.cn'))
        .pipe(gulp.dest('./dist'));
});

gulp.task('default', ['minijs', 'minicss', 'rev']);