<?php

return [
    'app_id' => env('WX_APP_ID'),
    'app_secret' => env('WX_APP_SECRET'),
    'sub_app_id' => env('WX_SUB_APP_ID'),
    'sub_app_secret' => env('WX_SUB_APP_SECRET'),
    'tpl_msg_id' => [
        'course_register' => env('WX_TPL_MSG_COURSE_REG'),
        'course_start' => env('WX_TPL_MSG_COURSE_START')
    ]
];