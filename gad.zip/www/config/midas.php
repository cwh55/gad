<?php

return [
    'app_id' => env('MIDAS_APP_ID'),
    'app_secret' => env('MIDAS_APP_SECRET'),
    'pc_goods_cl5_mod_id' => env('MIDAS_PC_GOODS_CL5_MODID'),
    'pc_goods_cl5_cmd_id' => env('MIDAS_PC_GOODS_CL5_CMDID'),
    'm_goods_cl5_mod_id' => env('MIDAS_M_GOODS_CL5_MODID'),
    'm_goods_cl5_cmd_id' => env('MIDAS_M_GOODS_CL5_CMDID')
];