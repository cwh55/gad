<?php

return [
    'url' => env('TGD_URL'),
    'cl5_mod_Id' => env('TGD_CL5_MODID'),
    'cl5_cmd_Id' => env('TGD_CL5_CMDID'),
    'id' => env('TGD_PLATFORM_ID'),
    'secret' => env('TGD_SECRET'),
    'wx_app_id' => env('TGD_WX_APP_ID'),
];