<?php

return [
    'SecretId' => env('QCLOUD_SECRET_ID'),
    'SecretKey' => env('QCLOUD_SECRET_KEY'),
    'RequestMethod'  => 'GET',
    'DefaultRegion'  => 'gz'
];