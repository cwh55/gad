<?php

return [
    'cl5_mod_Id' => env('MSG_CL5_MODID'),
    'cl5_cmd_Id' => env('MSG_CL5_CMDID'),
];