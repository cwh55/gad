<?php

return [
    'cl5_mod_Id' => env('FILE_CL5_MODID'),
    'cl5_cmd_Id' => env('FILE_CL5_CMDID'),
];