<?php

return [
    'app_id' => env('PTLOGIN_APP_ID', 1600000714),
    'daid' => env('PTLOGIN_DAID', 0),
    'pskey' => env('PTLOGIN_PSKEY', false),
    'dev_host' => env('PTLOGIN_DEV_HOST', '10.125.36.22'),
    'dev_port' => env('PTLOGIN_DEV_PORT', 58000)
];