define(['jquery', 'lodash', 'socket.io'], function ($, _, io) {
    function IMClient(url) {
        this.socket = io(url);
    }

    IMClient.prototype.onLogin = function (cb) {
        this.socket.on('login', cb);
    };

    IMClient.prototype.onMessage = function (cb) {
        this.socket.on('message', cb);
    };

    IMClient.prototype.send = function (message) {
        this.socket.emit('message', message);
    };

    IMClient.prototype.online = function (cb) {
        this.socket.on('online', cb);
    };

    IMClient.prototype.ban = function (userId) {
        this.socket.emit('ban', userId);
    };

    IMClient.prototype.onBaned = function (cb) {
        this.socket.on('ban', cb);
    };

    IMClient.prototype.release = function (userId) {
        this.socket.emit('release', userId);
    };

    IMClient.prototype.onReleased = function (cb) {
        this.socket.on('release', cb);
    };

    IMClient.prototype.silent = function (state) {
        this.socket.emit('silent', state);
    };

    IMClient.prototype.onSilent = function (cb) {
        this.socket.on('silent', cb);
    };

    IMClient.prototype.onNotify = function (cb) {
        this.socket.on('notify', cb);
    };

    var ImgIputHandler={
        emojis:[
            {faceName:"微笑",facePath:"http://gad.qpic.cn/assets/images/face/0.gif"},
            {faceName:"撇嘴",facePath:"http://gad.qpic.cn/assets/images/face/1.gif"},
            {faceName:"色",facePath:"http://gad.qpic.cn/assets/images/face/2.gif"},
            {faceName:"发呆",facePath:"http://gad.qpic.cn/assets/images/face/3.gif"},
            {faceName:"得意",facePath:"http://gad.qpic.cn/assets/images/face/4.gif"},
            {faceName:"流泪",facePath:"http://gad.qpic.cn/assets/images/face/5.gif"},
            {faceName:"害羞",facePath:"http://gad.qpic.cn/assets/images/face/6.gif"},
            {faceName:"闭嘴",facePath:"http://gad.qpic.cn/assets/images/face/7.gif"},
            {faceName:"大哭",facePath:"http://gad.qpic.cn/assets/images/face/8.gif"},
            {faceName:"尴尬",facePath:"http://gad.qpic.cn/assets/images/face/9.gif"},
            {faceName:"发怒",facePath:"http://gad.qpic.cn/assets/images/face/10.gif"},
            {faceName:"调皮",facePath:"http://gad.qpic.cn/assets/images/face/11.gif"},
            {faceName:"龇牙",facePath:"http://gad.qpic.cn/assets/images/face/12.gif"},
            {faceName:"惊讶",facePath:"http://gad.qpic.cn/assets/images/face/13.gif"},
            {faceName:"难过",facePath:"http://gad.qpic.cn/assets/images/face/14.gif"},
            {faceName:"酷",facePath:"http://gad.qpic.cn/assets/images/face/15.gif"},
            {faceName:"冷汗",facePath:"http://gad.qpic.cn/assets/images/face/16.gif"},
            {faceName:"抓狂",facePath:"http://gad.qpic.cn/assets/images/face/17.gif"},
            {faceName:"吐",facePath:"http://gad.qpic.cn/assets/images/face/18.gif"},
            {faceName:"偷笑",facePath:"http://gad.qpic.cn/assets/images/face/19.gif"},
            {faceName:"可爱",facePath:"http://gad.qpic.cn/assets/images/face/20.gif"},
            {faceName:"白眼",facePath:"http://gad.qpic.cn/assets/images/face/21.gif"},
            {faceName:"傲慢",facePath:"http://gad.qpic.cn/assets/images/face/22.gif"},
            {faceName:"饥饿",facePath:"http://gad.qpic.cn/assets/images/face/23.gif"},
            {faceName:"困",facePath:"http://gad.qpic.cn/assets/images/face/24.gif"},
            {faceName:"惊恐",facePath:"http://gad.qpic.cn/assets/images/face/25.gif"},
            {faceName:"流汗",facePath:"http://gad.qpic.cn/assets/images/face/26.gif"},
            {faceName:"憨笑",facePath:"http://gad.qpic.cn/assets/images/face/27.gif"},
            {faceName:"大兵",facePath:"http://gad.qpic.cn/assets/images/face/28.gif"},
            {faceName:"奋斗",facePath:"http://gad.qpic.cn/assets/images/face/29.gif"},
            {faceName:"咒骂",facePath:"http://gad.qpic.cn/assets/images/face/30.gif"},
            {faceName:"疑问",facePath:"http://gad.qpic.cn/assets/images/face/31.gif"},
            {faceName:"嘘",facePath:"http://gad.qpic.cn/assets/images/face/32.gif"},
            {faceName:"晕",facePath:"http://gad.qpic.cn/assets/images/face/33.gif"},
            {faceName:"折磨",facePath:"http://gad.qpic.cn/assets/images/face/34.gif"},
            {faceName:"衰",facePath:"http://gad.qpic.cn/assets/images/face/35.gif"},
            {faceName:"骷髅",facePath:"http://gad.qpic.cn/assets/images/face/36.gif"},
            {faceName:"敲打",facePath:"http://gad.qpic.cn/assets/images/face/37.gif"},
            {faceName:"再见",facePath:"http://gad.qpic.cn/assets/images/face/38.gif"},
            {faceName:"擦汗",facePath:"http://gad.qpic.cn/assets/images/face/39.gif"},
            {faceName:"抠鼻",facePath:"http://gad.qpic.cn/assets/images/face/40.gif"},
            {faceName:"鼓掌",facePath:"http://gad.qpic.cn/assets/images/face/41.gif"},
            {faceName:"糗大了",facePath:"http://gad.qpic.cn/assets/images/face/42.gif"},
            {faceName:"坏笑",facePath:"http://gad.qpic.cn/assets/images/face/43.gif"},
            {faceName:"左哼哼",facePath:"http://gad.qpic.cn/assets/images/face/44.gif"},
            {faceName:"右哼哼",facePath:"http://gad.qpic.cn/assets/images/face/45.gif"},
            {faceName:"哈欠",facePath:"http://gad.qpic.cn/assets/images/face/46.gif"},
            {faceName:"鄙视",facePath:"http://gad.qpic.cn/assets/images/face/47.gif"},
            {faceName:"委屈",facePath:"http://gad.qpic.cn/assets/images/face/48.gif"},
            {faceName:"快哭了",facePath:"http://gad.qpic.cn/assets/images/face/49.gif"},
            {faceName:"阴险",facePath:"http://gad.qpic.cn/assets/images/face/50.gif"},
            {faceName:"亲亲",facePath:"http://gad.qpic.cn/assets/images/face/51.gif"},
            {faceName:"吓",facePath:"http://gad.qpic.cn/assets/images/face/52.gif"},
            {faceName:"可怜",facePath:"http://gad.qpic.cn/assets/images/face/53.gif"},
            {faceName:"菜刀",facePath:"http://gad.qpic.cn/assets/images/face/54.gif"},
            {faceName:"西瓜",facePath:"http://gad.qpic.cn/assets/images/face/55.gif"},
            {faceName:"啤酒",facePath:"http://gad.qpic.cn/assets/images/face/56.gif"},
            {faceName:"篮球",facePath:"http://gad.qpic.cn/assets/images/face/57.gif"},
            {faceName:"乒乓",facePath:"http://gad.qpic.cn/assets/images/face/58.gif"},
            {faceName:"拥抱",facePath:"http://gad.qpic.cn/assets/images/face/59.gif"},
            {faceName:"握手",facePath:"http://gad.qpic.cn/assets/images/face/60.gif"},
            {faceName:"睡觉",facePath:"http://gad.qpic.cn/assets/images/face/61.gif"},
            {faceName:"饭",facePath:"http://gad.qpic.cn/assets/images/face/62.png"},
            {faceName:"猪头",facePath:"http://gad.qpic.cn/assets/images/face/63.png"},
            {faceName:"玫瑰",facePath:"http://gad.qpic.cn/assets/images/face/64.png"},
            {faceName:"凋谢",facePath:"http://gad.qpic.cn/assets/images/face/65.png"},
            {faceName:"爱心",facePath:"http://gad.qpic.cn/assets/images/face/66.png"},
            {faceName:"闪电",facePath:"http://gad.qpic.cn/assets/images/face/67.png"},
            {faceName:"炸弹",facePath:"http://gad.qpic.cn/assets/images/face/68.png"},
            {faceName:"月亮",facePath:"http://gad.qpic.cn/assets/images/face/69.png"},
            {faceName:"太阳",facePath:"http://gad.qpic.cn/assets/images/face/70.png"},
            {faceName:"礼物",facePath:"http://gad.qpic.cn/assets/images/face/71.png"},
            {faceName:"OK",facePath:"http://gad.qpic.cn/assets/images/face/72.png"},
            {faceName:"飞吻",facePath:"http://gad.qpic.cn/assets/images/face/73.png"},
            {faceName:"发抖",facePath:"http://gad.qpic.cn/assets/images/face/74.png"}
        ],
        Init:function(){
            var isShowImg=false;
            $(".expression-btn").click(function(){
                if(isShowImg==false){
                    isShowImg=true;
                    $(this).prev().animate({top:"-111px"},300);
                    if($(".faceDiv").children().length==0){
                        for(var i=0;i<ImgIputHandler.emojis.length;i++){
                            $(".faceDiv").append("<img title=\""+ImgIputHandler.emojis[i].faceName+"\" src=\""+ImgIputHandler.emojis[i].facePath+"\" />");
                        }
                        $(".faceDiv>img").click(function(){
                            isShowImg=false;
                            $(this).parent().parent().animate({top:"140px"},300);
                            ImgIputHandler.insertAtCursor($("#input_msg")[0],"["+$(this).attr("title")+"]");
                        });
                    }
                }else{
                    isShowImg=false;
                    $(this).prev().animate({top:"134px"},300);
                }
            });
        },
        insertAtCursor:function(myField, myValue) {
            if (document.selection) {
                myField.focus();
                sel = document.selection.createRange();
                sel.text = myValue;
                sel.select();

            } else if (myField.selectionStart || myField.selectionStart == "0") {
                var startPos = myField.selectionStart;
                var endPos = myField.selectionEnd;
                var restoreTop = myField.scrollTop;
                myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length);
                if (restoreTop > 0) {
                    myField.scrollTop = restoreTop;
                }
                myField.focus();
                myField.selectionStart = startPos + myValue.length;
                myField.selectionEnd = startPos + myValue.length;

            } else {
                myField.value += myValue;
                myField.focus();
            }
        },
        render: function (content) {
            var self = this;

            return content.replace(/\[(.*?)\]/g, function (match, value) {
                for (i = 0; i < self.emojis.length; i++) {
                    if (value === self.emojis[i].faceName) {
                        return '<img src='+self.emojis[i].facePath+'>';
                    }
                }
            });
        }
    };

    var messageTpl = '<div class="comments-list-item"><div class="comments-inner clearfix"><img src="<%- user.Avatar %>" alt=""><p><% if (user.role != \'user\') { %><span class="name manager-name"><%- user.NickName %>（<%- user.roleName %>）：</span><% } else { %><span class="name"><%- user.NickName %>：</span><% } %><%- content %></p></div><% if (auth.role != \'user\' && user.role == \'user\') { %><div class="keep-silence-btn"><a href="javascript:;" data-userid="<%- user.UserId %>" data-nickname="<%- user.NickName %>" data-avatar="<%- user.Avatar %>">禁言</a></div><% } %></div>';
    var banedListTpl = '<% _.forEach(users, function(user) { %><div class="user-list-item" id="ban-user-<%- user.userid %>"><a class="user-name jinyan"><img src="<%- user.avatar %>"><span><%- user.nickname %></span></a><a class="jinyan-set" data-userid="<%- user.userid %>">解禁</a></div><% }); %>';
    var notifyTpl = '<div class="comments-list-item"><div class="comments-inner clearfix"><p style="color:<%- color %>;">系统：<%- content %></p></div></div>';
    var messageView = _.template(messageTpl);
    var bandListView = _.template(banedListTpl);
    var notifyView = _.template(notifyTpl);
    var messageRender = function (message) {
        var html = messageView(message);

        return ImgIputHandler.render(html);
    };
    var banedListRender = function (users) {
        return bandListView({users: users});
    };
    var notifyRender = function (content, color) {
        return notifyView({content: content, color: color});
    };

    var messageList = $('#message-list');
    var banedList = $('.user-manage-list');

    return {
        init: function (lesson) {
            var url = 'http://api.gad.qq.com/chat?id=' + lesson.id;
            im = new IMClient(url);
            im.onLogin(function (user) {
                im.user = user;
            });

            im.onMessage(function (message) {
                var messageHeight = messageList.outerHeight();
                var messageElement = messageList.get(0);
                var totalHeight = messageElement.scrollHeight;
                var scrollTop = messageList.scrollTop();

                message.auth = im.user;
                var html = messageRender(message);
                messageList.append(html);
                if (totalHeight == (scrollTop + messageHeight)) {
                    messageList.scrollTop(messageElement.scrollHeight);
                }
            });

            im.online(function (online) {
                $('#online-user-count').text('在线人数：' + online);
            });

            im.onNotify(function (notify) {
                console.log(notify);

                var messageHeight = messageList.outerHeight();
                var messageElement = messageList.get(0);
                var totalHeight = messageElement.scrollHeight;
                var scrollTop = messageList.scrollTop();
                var html = notifyRender(notify.message, 'red');
                messageList.append(html);
                if (totalHeight == (scrollTop + messageHeight)) {
                    messageList.scrollTop(messageElement.scrollHeight);
                }
            });

            im.onBaned(function (users) {
                if (im.user.role != 'user' && $('#ban-user-')) {
                    var html = banedListRender(users);
                    banedList.append(html);
                }
            });

            im.onReleased(function (userId) {
                $('#ban-user-' + userId).remove();
            });

            var silentCheckbox = $('.user-set :checkbox');
            im.onSilent(function (state) {
                silentCheckbox.get(0).checked = state;
            });

            silentCheckbox.click(function (e) {
                im.silent($(this).is(':checked'));
            });

            var input = $('#input_msg');
            $('#send_msg').click(function() {
                if (input.val()) {
                    im.send(input.val());
                    input.val('');
                }
            });

            messageList.on('click', '.keep-silence-btn > a', function(e) {
                var ele = $(e.target);
                var user = {
                    userid: ele.data('userid'),
                    nickname: ele.data('nickname'),
                    avatar: ele.data('avatar')
                };
                im.ban(user);
            });

            ImgIputHandler.Init();

            banedList.on('click', '.jinyan-set', function(e) {
                var uid = $(e.target).data('userid');
                im.release(uid);
            });
        }
    };
});
