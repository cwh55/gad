define(['jquery', 'lodash', 'angular', 'moment', 'moment-zh-cn', 'bootstrap', 'ng-file-upload', 'angular-datetimepicker', 'angular-date-time-input', 'app/service'], function ($, _, angular, moment) {
    var app = angular.module('gad.course', ['ngFileUpload', 'ui.bootstrap.datetimepicker', 'ui.dateTimeInput', 'gad.course.service']);
    var course = {};
    app.controller('CourseInfoController', ['$scope', 'Course', 'Lesson', 'Upload', function ($scope, Course, Lesson, Upload) {
        var _modal = {
            isOpened: false,
            messages: [],
            show: function () {
                this.isOpened = true;
            },
            close: function () {
                this.messages = [];
                this.isOpened = false;
            }
        };
        $scope.modal = {
            lesson: angular.copy(_modal),
            info: angular.copy(_modal)
        };

        $scope.timeOptions = ['09:00', '09:15', '09:30', '09:45', '10:00', '10:15', '10:30', '10:45', '11:00', '11:15',
            '11:30', '11:45', '12:00', '12:15', '12:30', '12:45', '13:00', '13:15', '13:30', '13:45', '14:00',
            '14:15', '14:30', '14:45', '15:00', '15:15', '15:30', '15:45', '16:00', '16:15', '16:30', '16:45',
            '17:00', '17:15', '17:30', '17:45', '18:00', '18:15', '18:30', '18:45', '19:00', '19:15', '19:30',
            '19:45', '20:00', '20:15', '20:30', '20:45', '21:00', '21:15', '21:30', '21:45', '22:00',
            '22:15', '22:30', '22:45', '23:00'];

        $scope.release = function () {
            if (confirm('您确定发布该分享吗？')) {
                Course.release(course).success(function (res) {
                    if (res.code) {
                        $scope.modal.info.type = 'fail';
                        $scope.modal.info.messages.push(res.message ? res.message : '发布分享时出错');
                        $scope.modal.info.show();
                    } else {
                        location.reload();
                    }
                }).error(function (res) {
                    $scope.modal.info.type = 'fail';
                    $scope.modal.info.messages.push(res.message ? res.message : '发布分享时出错');
                    $scope.modal.info.show();
                });
            }
        };

        $scope.delete = function () {
            if (confirm('您确定删除该分享吗？')) {
                Course.remove(course).success(function (res) {
                    if (res.code == 0) {
                        location.href = '/user/creator';
                        return;
                    }

                    $scope.modal.info.type = 'fail';
                    $scope.modal.info.messages.push(res.message ? res.message : '删除分享时出错');
                    $scope.modal.info.show();
                }).error(function (res) {
                    $scope.modal.info.type = 'fail';
                    $scope.modal.info.messages.push(res.message ? res.message : '删除分享时出错');
                    $scope.modal.info.show();
                });
            }
        };
        
        $scope.editLesson = function (id) {
            $scope.lesson = {attachment: []};
            if (id) {
                Lesson.find(id).success(function (res) {
                    $scope.lesson = res;
                });
            }

            $scope.modal.lesson.show();
        };
        
        $scope.removeLesson = function (id) {
            if (confirm('您确定删除该分享吗？'))　{
                Lesson.remove(id).success(function (res) {
                    if (res.code == '0') {
                        location.reload();
                    } else {
                        $scope.modal.info.type = 'fail';
                        $scope.modal.info.messages.push(res.message);
                        $scope.modal.info.show();
                    }
                }).error(function (res) {
                    $scope.modal.info.type = 'fail';
                    $scope.modal.info.messages.push(res.message ? res.message : '删除分享时出错');
                    $scope.modal.info.show();
                });
            }
        };

        $scope.uploadFile = function (files) {
            _.forEach(files, function (_file) {
                var attachment = {name: _file.name, state: 'uploading', progress: '0%'};
                $scope.lesson.attachment.push(attachment);
                Upload.upload({
                    url: '/course/lesson/uploadAttachment',
                    data: {
                        file: _file,
                        _token: $('meta[name="csrf-token"]').attr('content')
                    }
                }).then(function (res) {
                    if (res.data.code) {
                        alert(res.data.message);
                        return;
                    }

                    attachment.url = res.data.url;
                    attachment.state = 'uploaded';
                }, function (res) {
                    attachment.state = 'error';
                    alert('附件上传出错');
                }, function (evt) {
                    attachment.progress = parseInt(100 * evt.loaded / evt.total) + '%';
                });
            });
        };
        $scope.changeTime = function (field) {
            if (field == 'begin_time') {
                if ($scope.lesson.end_time && $scope.lesson.begin_time > $scope.lesson.end_time) {
                    $scope.lesson.begin_time = '';
                }
            } else {
                if ($scope.lesson.begin_time && $scope.lesson.begin_time > $scope.lesson.end_time) {
                    $scope.lesson.end_time = '';
                }
            }
        };

        $scope.deleteAttachment = function (attachment, index) {
            if (confirm('您确定要删除附件[' + attachment.name + ']？')) {
                $scope.lesson.attachment.splice(index, 1);
            }
        };

        $scope.saveLesson = function () {
            _.forEach($scope.lesson.attachment, function (attachment) {
                _.unset(attachment, 'state');
                _.unset(attachment, 'progress');
            });

            $scope.lesson.attachment = _.filter($scope.lesson.attachment, function (attachment) {
                return attachment.url != '';
            });

            $scope.lesson.course_id = course.id;
            $scope.lesson.begin_date = moment($scope.lesson.begin_date).format('YYYY-MM-DD');
            Lesson.save($scope.lesson).success(function (res) {
                location.href = '/course/info/' + res.course_id;
            }).error(function (res) {
                $scope.modal.info.type = 'fail';
                angular.forEach(res, function (messages, field) {
                    angular.forEach(messages, function (message) {
                        $scope.modal.info.messages.push(message);
                    });
                });
                if ($scope.modal.info.messages.length == 0) {
                    $scope.modal.info.messages.push('保存分享出错');
                }
                $scope.modal.info.show();
            });
        };
    }]);

    app.directive('ngMaxwidth', function () {
        var castStrWidth = function (str) {
            var len = str.length;
            var width = 0;
            var i = 0;
            for (; i < len; i++) {
                if (str.charCodeAt(i) > 256) {
                    width++;
                } else {
                    width += 0.5;
                }
            }

            return width;
        };

        return {
            restrict: 'A',
            require: '?ngModel',
            link: function(scope, elm, attr, ctrl) {
                if (!ctrl) return;

                var maxwidth = -1;
                attr.$observe('ngMaxwidth', function(value) {
                    var intVal = parseInt(value, 10);
                    maxwidth = isNaN(intVal) ? -1 : intVal;
                    ctrl.$validate();
                });
                ctrl.$validators.maxwidth = function(modelValue, viewValue) {
                    return (maxwidth < 0) || ctrl.$isEmpty(viewValue) || (castStrWidth(viewValue) <= maxwidth);
                };
            }
        };
    });

    return {
        init: function (course_id) {
            course.id = course_id;
            angular.bootstrap(document, ['gad.course']);
        }
    };
});
