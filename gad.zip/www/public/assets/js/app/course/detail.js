define(['jquery', 'angular', 'angular-route', 'angular-cookies', 'app/service'], function ($, angular) {
    var app = angular.module('gad.course', ['ngRoute', 'ngCookies', 'gad.course.service']);
    var course = {};
    app.controller('CourseDetailController', ['$scope', '$interval', '$cookies', 'Course', 'WxPay', function ($scope, $interval, $cookies, Course, WxPay) {
        $scope.course = course;
        $scope.timer = null;
        $scope.state = '';
        $scope.isAgree = true;
        $scope.buy = function () {
            if ($cookies.get('isLogined') != '1') {
                return gad.login();
            }

            $scope.state = 'pay';
            if (!$scope.timer) {
                $scope.checkPayResult();
            }
        };

        $scope.register = function () {
            if ($cookies.get('isLogined') != '1') {
                return gad.login();
            }

            $scope.state = 'register';
        };

        var isRegistering = false;
        $scope.confirmRegister = function () {
            if ($cookies.get('isLogined') != '1') {
                return gad.login();
            }

            if (isRegistering) {
                return false;
            }

            isRegistering = true;
            Course.register($scope.course).success(function (res) {
                if (res && res.result) {
                    $scope.state = 'registered';
                    $scope.course.is_registered = true;
                }
            });
        };

        $scope.checkPayResult = function () {
            $scope.timer = $interval(function () {
                WxPay.checkPayResult($scope.course.id).success(function (res) {
                    if (res && res.result) {
                        $interval.cancel($scope.timer);
                        $scope.state = 'registered';
                        $scope.course.is_registered = true;
                    }
                }).error(function (res) {
                    $interval.cancel($scope.timer);
                });
            }, 2000);
        };

        $scope.agree = function () {
            $('.code-agree input:checkbox').click();
        };

        $scope.close = function () {
            $scope.state = '';
            if ($scope.timer) {
                $interval.cancel($scope.timer);
            }
        };

        $scope.enter = function ($event) {
            if ($cookies.get('isLogined') != '1') {
                $event.preventDefault();
                return gad.login();
            }

            if (!$scope.course.is_registered) {
                if ($scope.course.state == 'new' || $scope.course.cost > 0) {
                    $event.preventDefault();
                    $scope.state = $scope.course.cost > 0 ? 'pay' : 'register';
                }
            }
        };

        $scope.$on('$destroy', function() {
            $interval.cancel($scope.timer);
        });
    }]);

    app.directive('collectCourse', ['$cookies', 'Course', function ($cookies, Course) {
        return {
            restrict: 'A',
            link: function ($scope, $element, $attrs) {
                var isCollected = $attrs.collectCourse == '1';
                $element.click(function ($event) {
                    if ($cookies.get('isLogined') != '1') {
                        $event.preventDefault();
                        return gad.login();
                    }

                    if (isCollected) {
                        Course.collect(course, 'cancel').success(function (res) {
                            isCollected = false;
                            $element.removeClass('collected').text('收藏');
                        }).error(function (res) {
                            alert('取消收藏分享出错');
                        });
                    } else {
                        Course.collect(course, 'add').success(function (res) {
                            isCollected = true;
                            $element.addClass('collected').text('已收藏');
                        }).error(function (res) {
                            alert('收藏分享出错');
                        });
                    }
                });
            }
        };
    }]);

    $(function () {
        $('#course-tab a').click(function () {
            var tabContent = '#course-' + $(this).attr('rel');
            $(this).parent('li').addClass('active').siblings().removeClass('active');
            $(tabContent).addClass('active').siblings().removeClass('active');
        });
    });

    return {
        init: function (_course) {
            course = _course;
            angular.bootstrap(document, ['gad.course']);
        }
    };
});
