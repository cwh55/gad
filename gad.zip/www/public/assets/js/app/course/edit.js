define(['jquery', 'angular', 'lodash', 'angular-sanitize', 'ui-select', 'ng-file-upload', 'tig-editor', 'app/service'], function ($, angular, _) {
    var app = angular.module('gad.course', ['ngSanitize', 'ngFileUpload', 'ui.select', 'gad.course.service']);
    var types = [];
    var course = {title: '', thumbnail: '', record: '0', summary: '', desc: '', cs_uin: '', cs_name: '',
        qq_qun: '', qq_qun_name: '', teachers: [], assistants: []};

    app.controller('CreateCourseCtrl', ['$scope', 'Upload', 'Teacher', 'Course', function ($scope, Upload, Teacher, Course) {
        $scope.course = course;
        $scope.types = types;
        $scope.selected = {teachers: course.teachers};
        $scope.teachers = [];
        $scope.assistants = [];

        var thumbnailBox = $('.create-thumbnail-img');
        if ($scope.course.thumbnail) {
            thumbnailBox.css('background-image', 'url(' + $scope.course.thumbnail + ')');
        }

        $scope.uploadThumb = function (file) {
            if (!file) {
                return;
            }

            thumbnailBox.addClass('img-uploading');
            Upload.upload({
                url: '/course/uploadImage',
                data: {
                    file: file,
                    _token: $('meta[name="csrf-token"]').attr('content')
                }
            }).then(function (res) {
                if (res.data.code) {
                    var message = res.data.message == 'ERROR_PHOTO_COMPRESS' ? '图片格式错误' : '图片上传出错';
                    thumbnailBox.removeClass('img-uploading')
                    alert(message);
                    return;
                }

                $scope.course.thumbnail = res.data.data.downloadUrl;
                thumbnailBox.removeClass('img-uploading').css('background-image', 'url(' + $scope.course.thumbnail + ')');
            }, function (res) {
                thumbnailBox.removeClass('img-uploading');
                alert('图片上传出错');
            });
        };

        $scope.changeTarget = function () {
            $scope.course.target = $scope.course.target && $scope.course.target.replace(';', '；').replace('；', '；');
        };

        $scope.addTeacher = function () {
            $scope.course.teachers.push({});
        };

        $scope.removeTeacher = function (index, teacher) {
            if (confirm('您确定删除该老师吗？')) {
                $scope.course.teachers.splice(index, 1);
            }
        };

        $scope.teacherSelected = function (item, model, index) {
            $scope.selected.teachers[index] = item;
        };

        $scope.addAssistant = function () {
            $scope.course.assistants.push({});
        };

        $scope.removeAssistant = function (index, assistant) {
            if (!assistant.id || confirm('您确定删除该助教吗？')) {
                $scope.course.assistants.splice(index, 1);
            }
        };

        $scope.modal = {
            isOpened: false,
            messages: [],
            show: function () {
                this.isOpened = true;
            },
            close: function () {
                this.isOpened = false;
                this.messages = [];
            }
        };

        $scope.saveCourse = function () {
            var valid = true;
            if (!$scope.course.thumbnail) {
                valid = false;
                $scope.modal.messages.push('缩略图未上传');
            }

            var editor = TIG.editor.getInstance('course-desc');
            if (editor.isEmpty()) {
                valid = false;
                $scope.modal.messages.push('课程预览未填写');
            } else {
                $scope.course.desc = editor.html();
            }

            if ($scope.course.teachers.length == 0) {
                valid = false;
                $scope.modal.messages.push('老师信息未添加');
            }

            if ($scope.course.assistants.length == 0) {
                valid = false;
                $scope.modal.messages.push('助教信息未添加');
            }

            if (!valid) {
                return $scope.modal.show();
            }

            Course.save($scope.course).success(function (res) {
                location.href = '/course/info/' + res.id;
            }).error(function (res) {
                if (res.code == 422) {
                    angular.forEach(res.message, function (messages, field) {
                        angular.forEach(messages, function (message) {
                            $scope.modal.messages.push(message);
                        });
                    });
                } else {
                    $scope.modal.messages.push(res.message ? res.message : '系统错误，请联系管理员');
                }

                if ($scope.modal.messages.length) {
                    $scope.modal.show();
                }
            });
        };

        $scope.refreshTeacher = function (qq) {
            return Teacher.getTeacher(qq).then(function (res) {
                $scope.teachers = res.data;
            });
        };

        $scope.refreshAssistant = function (qq) {
            return Teacher.getAssistant(qq).then(function (res) {
                $scope.assistants = res.data;
            });
        };

        $scope.refreshTeacher();
        $scope.refreshAssistant();
    }]);

    app.filter('firstType', function () {
        return function (types, topTypeId) {
            var select = _.find(types, {id: topTypeId});
            if (!select) {
                return [];
            }

            return select.subs;
        }
    });

    app.directive('ngMaxwidth', function () {
        var castStrWidth = function (str) {
            var len = str.length;
            var width = 0;
            var i = 0;
            for (; i < len; i++) {
                if (str.charCodeAt(i) > 256) {
                    width++;
                } else {
                    width += 0.5;
                }
            }

            return width;
        };

        return {
            restrict: 'A',
            require: '?ngModel',
            link: function(scope, elm, attr, ctrl) {
                if (!ctrl) return;

                var maxwidth = -1;
                attr.$observe('ngMaxwidth', function(value) {
                    var intVal = parseInt(value, 10);
                    maxwidth = isNaN(intVal) ? -1 : intVal;
                    ctrl.$validate();
                });
                ctrl.$validators.maxwidth = function(modelValue, viewValue) {
                    return (maxwidth < 0) || ctrl.$isEmpty(viewValue) || (castStrWidth(viewValue) <= maxwidth);
                };
            }
        };
    });

    return {
        init: function (_types, _course) {
            types = _types;
            if (_course) {
                course = _course;
            }

            TIG.editor({
                id: 'course-desc',
                height: 300,
                value: course.desc,
                showRelativePath: false,
                imageUploadPath: '/course/editorUploadImage',
                buttons: ['bold', 'italic', 'underline', 'font', 'size', 'color', 'insertorderedlist',
                    'insertunorderedlist', 'justify', 'link', 'table', 'image', 'source', 'fullscreen']
            });

            angular.bootstrap(document, ['gad.course']);
        }
    };
});
