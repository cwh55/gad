define(['jquery', 'angular', 'moment', 'app/course/im', 'app/service'], function ($, angular, moment, im) {
    var app = angular.module('gad.course', ['gad.course.service']);
    var lesson = {};
    var isTeacher = false;
    var isManager = false;
    var player;
    var start_lvb_player = function () {
        var playerEle = $('#live_video_player');
        player = new qcVideo.Player('live_video_player', {
            channel_id: lesson.lvb_channel_id,
            app_id: '1252093452',
            width: playerEle.width(),
            height: playerEle.height(),
            WMode: /MSIE/.test(navigator.userAgent) ? 'opaque' : 'window',
            volume: 1
        });

        $(window).resize(function () {
            player.resize(playerEle.width(), playerEle.height());
        });
    };

    app.controller('LessonController', ['$scope', '$interval', 'Course', function ($scope, $interval, Course) {
        $scope.lesson = lesson;
        $scope.isTeacher = isTeacher;
        $scope.isManager = isManager;
        $scope.isLiving = lesson.state == 'living';
        var begin_time = lesson.begin_date + ' ' + lesson.begin_time;
        var countdown = function (time) {
            var duration = moment.duration(moment(time).diff(moment()));

            return {
                d: duration.days(),
                h: duration.hours(),
                m: duration.minutes(),
                s: duration.seconds()
            };
        };

        var timeTick = function () {
            if (moment().isBefore(begin_time)) {
                $scope.countdown = countdown(begin_time);
            } else {
                $scope.timer && $interval.cancel($scope.timer);
                location.reload();
            }
        };

        if (lesson.state == 'new' && moment().isBefore(begin_time)) {
            $scope.countdown = countdown(begin_time);
            $scope.timer = $interval(timeTick, 1000);
        }

        $scope.currentTab = lesson.state == 'living' ? 'im' : 'info';
        $scope.isTeacherMode = isTeacher && lesson.state == 'living' ? true : false;
        $scope.tab = function (tab) {
            $scope.currentTab = tab;
        };

        $scope.switchMode = function () {
            $scope.isTeacherMode = !$scope.isTeacherMode;
            if ($scope.isTeacherMode && player) {
                player = null;
                $('#live_video_player').empty();
            } else {
                setTimeout(start_lvb_player, 100);
            }
        };

        $scope.video = {index: 1, current: {}};
        $scope.play = function (video) {
            var playerEle = $('#live_video_player');
            var option = {
                app_id: '1252093452',
                file_id: video.file_id,
                auto_play: 1,
                width: playerEle.width(),
                height: playerEle.height(),
                WMode: /MSIE/.test(navigator.userAgent) ? 'opaque' : 'window'
            };
            $scope.video.current = video;
            angular.forEach($scope.lesson.videos, function (_video, index) {
                if (_video == video) {
                    $scope.video.index = index + 1;
                }
            });

            if (player) {
                player.changeVideo(option);
            } else {
                player = new qcVideo.Player('live_video_player', option, {
                    playStatus: function (status) {
                        // 播放完成后自动进入下一段
                        if (status == 'playEnd') {
                            if ($scope.video.index == $scope.lesson.videos.length) {
                                $scope.play($scope.lesson.videos[0]);
                            } else {
                                $scope.play($scope.lesson.videos[$scope.video.index]);
                            }
                            $scope.$apply();
                        }
                    }
                });
                $(window).resize(function () {
                    player.resize(playerEle.width(), playerEle.height());
                });
            }
        };

        if ($scope.lesson.vod == '2' && $scope.lesson.videos.length) {
            $scope.play($scope.lesson.videos[0]);
        }
    }]);

    app.directive('collectCourse', ['Course', function (Course) {
        return function (scope, elm, attrs) {
            var isCollected = attrs.collectCourse == '1';
            elm.click(function () {
                if (isCollected) {
                    Course.collect({id: lesson.course_id}, 'cancel').success(function (res) {
                        isCollected = false;
                        elm.removeClass('collected').find('span').text('收藏');
                    }).error(function (res) {
                        alert('取消收藏分享出错');
                    });
                } else {
                    Course.collect({id: lesson.course_id}, 'add').success(function (res) {
                        isCollected = true;
                        elm.addClass('collected').find('span').text('已收藏');
                    }).error(function (res) {
                        alert('收藏分享出错');
                    });
                }
            });
        };
    }]);

    $(function () {
        $('.side-operate').click(function () {
            var _left = $('.live-side').position().left;
            if (_left == 0) {
                $('.live-side').animate({left: -310}, 300, 'swing', function () {
                    $('.side-operate').addClass('side-close');
                });
            } else {
                $('.live-side').animate({left: 0}, 300, 'swing', function () {
                    $('.side-operate').removeClass('side-close');
                });
            }
        });
    });

    return {
        init: function (data, cost, _isManager, _isTeacher, _videos) {
            lesson = data;
            lesson.videos = _videos;
            isManager = _isManager;
            isTeacher = _isTeacher;
            if (lesson.state == 'living') {
                if (!isTeacher) {
                    start_lvb_player();
                }

                im.init(lesson);
            }

            angular.bootstrap(document, ['gad.course']);
        }
    };
});
