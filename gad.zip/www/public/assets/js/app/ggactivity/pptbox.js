define(['zepto', 'vue', 'fastclick'], function($, Vue, FastClick) {

	var pptbox = {
		workid: 0,
		pagesize: 0,
		urltpl: '',
		init: function(id) {
			pptbox.workid = id;
			$.get('/api/getworkdetail/'+id, {}, function(data) {
				pptbox.pagesize = data.data.pptPageSize;
				pptbox.urltpl = data.data.pptUrltpl.replace('#page#', '');

				new Vue({
					el: '#pptbox',
					data: {
						pagesize: parseInt(pptbox.pagesize),
						imgtpl: pptbox.urltpl
					}
				});

				var swiper = new Swiper('.swiper-container', {
			        prevButton: '.swiper-button-prev',
			        nextButton: '.swiper-button-next',
			        loop: true,
			        onSlideChangeStart: function(swiper){
						//延迟加载
						var cuImg = $(".swiper-slide-active img");
						$(cuImg).attr('src',$(cuImg).data('url'));
					}
			    });
				swiper.slideTo(data.data.pptPageSize, 100, function() {
					
				});
				
			    require(['zepto', 'lazyload'], function($) {
                    $(".lazy").lazyload({
                        effect: "fadeIn"
                    });
                });
			}, 'json');
			
		}
	}

	return pptbox;
})