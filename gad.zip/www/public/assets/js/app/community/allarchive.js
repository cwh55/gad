/**
 * Created by xiaolinwang on 17-5-17.
 */
define(['jquery','vue','vue-resource','popup','app/community/community','common/vue-component/archive-li'],function($,Vue,VueResource,popup){
    Vue.use(VueResource);
    Vue.http.interceptors.push(function(request, next) {
        next(function(response) {
            if (response.status == 401) {
                gad.login();
            }
        });
    });

     Vue.component('all-archive',{
        template:'<div class="feeds-wrap">\
                     <ul class="uarticle uarticle-feeds">\
                     <template v-for="item in archives">\
                       <li class="uarticle-item" v-if="ads[$index] != undefined"><ads  :ad="ads[$index]"></ads></li>\
                       <li class="uarticle-item" v-if="item.class_id == 1" ><article-tpl :archive="item"></article-tpl></li>\
                       <li class="uarticle-item" v-if="item.class_id == 2"><art-tpl  :item="item"></art-tpl></li>\
                       <li class="uarticle-item" v-if="item.class_id == 3"><question-tpl :item="item"></question-tpl></li>\
                       <li class="uarticle-item" v-if="item.class_id == 4"><question-tpl :item="item"></question-tpl></li>\
                     </template>\
                     </ul>\
                     </div>\
                 <div class="m-dlmore {{showLoad}} dlmore-home" >\
                    <span class="dlmore-loading gico-loading loading-20">加载中</span>\
                    <span class="dlmore-nomore">没有更多消息</span>\
                </div>\
                ',
        props:['tag','isHide','orderBy','page','classId','initHasmore'],
        data:function(){
            return {
                pageSize:20,
                archives:[],
                ads:[],
                showLoad:'',
                hasMore:true,
                requestStatus:true
            }
        },
        ready:function(){
          var _that = this;
          // _that.getList();
          if(this.initHasmore)
              $(document).scroll(function(){
                   if($(document).scrollTop()+$(window).height() > $(document).height() - 100){
                       if (_that.hasMore) {
                           _that.getList();
                       }
                   }
              });
        },
        methods:{
            getList:function(){
                if (this.requestStatus) {
                    this.showLoad = 'dl-loading';
                    this.requestStatus = false;
                    this.$http.get('/community/'+this.tag+'/'+this.orderBy,{
                        params:{
                            p:this.page,
                            ps:this.pageSize,
                            ob:this.orderBy,
                            cid:this.classId,
                            tag:this.tag
                        }
                    })
                        .then(function(res){
                            this.showLoad = '';
                            this.requestStatus = true;
                            if (res.data.code == 0) {
                                this.hasMore = res.data.hasMore;
                                if (res.data.hasMore) {
                                    this.page = parseInt(this.page)+1;
                                    this.showLoad = '';
                                } else {
                                    this.showLoad = 'dl-nomore';
                                    this.$emit('nomoremsg');
                                }
                                res.data.archives.map(function(item){
                                    switch (item.class_id) {
                                        case 1:
                                            item.shareUrl ='http://'+location.hostname+'/article/detail/'+item.id;
                                            item.shareQrcode = 'http://'+location.hostname+'/article/detail/'+item.id;
                                            item.created_at = item.publish_time;
                                            break;
                                        case 2:
                                            item.shareUrl = 'http://'+location.hostname+'/gallery/detail/'+item.id;
                                            item.shareQrcode = 'http://'+location.hostname+'/gallery/detail/'+item.id;
                                            break;
                                        case 3:
                                            item.answer = item.extra;
                                            item.shareUrl ='http://'+location.hostname+ '/question/detail/'+item.id;
                                            item.shareQrcode ='http://'+location.hostname+ '/question/detail/'+item.id;
                                            break;
                                    }

                                });
                                this.archives = this.archives.concat(res.data.archives);
                                var that = this;
                                if(res.data.ads)
                                    res.data.ads.map(function(item){
                                        that.ads[item.position-that.pageSize-1] = item;
                                    });
                            }
                        },function(){
                            this.requestStatus = true;
                        });
                }

            }
        }
    });

})