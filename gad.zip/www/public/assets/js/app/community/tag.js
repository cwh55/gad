/**
 * 使用样例
 * 注：需引入样式：<link rel="stylesheet" href="http://gad.qpic.cn/assets/js/lib/typeahead/typeahead.css" />
 * <tag :tags="['美术','策划']" 或者:tags="'美术,策划'" :maxtag="6(选填)" :inputid="'tags-input(选填)'"></tag>
 */
define(['vue', 'jquery', 'bloodhound', 'bootstrap-tagsinput', 'typeahead'],function(Vue, $, Bloodhound){
    Vue.component('tag',{
        /*template:'<ul class="articletit-tags f-clearfix">\
                    <li class="tags-item" v-for="tag in tags"><a class="m-label" target="_blank" href="javascript:;">{{tag}}<span class="ico-del-1"></span></a></li>\
                    <li class="tags-item"><label class="tags-input"><i class="gico-search"></i><input id="tags-input" class="form-tags" type="text" placeholder="添加标签"></label>\
                        <div class="select-wrap"></div>\
                    </li>\
                    <li class="tags-item"><span class="long-tips">标签（{{tags.length}}/{{maxtag}}）</span>\</li></ul>',*/
        template: '<div class="tagsinput-wrap"><input :id="inputid" class="form-tags" type="text" placeholder="添加标签"><span class="tt-long-tips">标签（{{tags.length}}/{{maxtag}}）</span></div>',
        props: {
            tags: {type: [Array, String], default: function(){
                return [];
            }},
            classid: {type: Number, default: 1},
            maxtag: {type: Number, default: 6},
            inputid: {type: String, default: 'tags-input'}
        }, 
        ready: function(){
            if(typeof this.tags === "string"){
                this.tags = this.tags.trim();
                this.tags = this.tags ? this.tags.split(',') : [];
            }
            var _this = this;
            var tags = new Bloodhound({
                datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
                queryTokenizer: Bloodhound.tokenizers.whitespace,
                remote: {
                    url: '/article/tags/'+this.classid+'/%QUERY',
                    wildcard: '%QUERY'
                }
            });
            tags.initialize();
            var tInputs = $('#'+this.inputid).val(this.tags).on('itemAdded itemRemoved', function(event) {
                _this.tags = this.value ? this.value.split(',') : [];
                if($(this).data('tagsinput')){
                    var tt = $(this).data('tagsinput').input().data('ttTypeahead');
                    if(event.type == 'itemRemoved' && _this.tags.length==0){
                        $('.tt-dataset-intro').show();
                        tt.minLength = 0;
                    }else if(event.type == 'itemAdded' && _this.tags.length>=1){
                        $('.tt-dataset-intro').hide();
                        tt.minLength = 1;
                    }
                    _this.tags.length>=6 ? $('.tt-input,.twitter-typeahead').hide() : $('.tt-input,.twitter-typeahead').show();
                }
            }).tagsinput({
                maxTags: this.maxtag,
                confirmKeys: [],
                typeaheadjs: [
                    {
                        hint: true,
                        highlight: true,
                        minLength: 0
                    },
                    {
                        name: 'tags',
                        displayKey: 'name',
                        valueKey: 'name',
                        limit: 100,
                        source: tags.ttAdapter(),
                        templates: {
                            header: '<div class="typeahead-item tt-dataset-intro">推荐标签</div>',
                            empty: '<div class="empty-message">无匹配标签</div>',
                            suggestion: function(item){
                                return '<div class="typeahead-item">'+item.alias+'</div>'
                            }
                        }
                    }
                ]
            });
            tInputs[0].$element.trigger($.Event('itemAdded'));
        }
    });
});