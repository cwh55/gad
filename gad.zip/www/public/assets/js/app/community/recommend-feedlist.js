define(['jquery','vue','vue-resource','popup'],function($,Vue,VueResource,popup){
	Vue.use(VueResource);
	var recomList = Vue.component('recommend-feedlist',{
	    template:'<div class="nofollow" id="js-feedList" v-show="listShow">\
			        <!-- <div class="nofollow-tab">已关注用户</div> -->\
			        <!--\
			            交互说明：\
			            默认不展示\
			            新内容推荐 | show-news\
			            刷新中 | show-loading\
			            刷新结束推荐 | show-end\
			        -->\
			        <div class="intronews show-news" v-show="recomListCnt >0 && showAll" v-cloak>\
			            <span class="intronews-btn"><a class="link" href="javascript:;" @click="reload()">新关注{{recomListCnt}}个用户，点击查看~</a>\
			            <!-- <span class="intronews-loading gico-loading loading-20">刷新中</span> -->\
			            <!-- <span class="intronews-endtips">为您新增6篇推荐内容</span> -->\
			        </div>\
			        <div class="nofollow-tips" v-show="recomListCnt == 0 && showAll" >\
			            <div class="tips-title">您暂未关注用户或其未更新动态</div>\
			            <div class="tips-cnt">在这里可以看到您关注的用户动态，立即关注精彩内容吧</div>\
			        </div>\
		    		<div class="intro f-clearfix">\
		                <h3 class="intro-title">推荐关注</h3><div class="intro-other"><a class="cychange" href="javascript:;" @click="getList()">换一批<i class="cychange-ico cyico-change"></i></a></div>\
		            </div>\
		            <ul class="author">\
		                <li class="author-item" v-for="item in items">\
		                    <div class="author-info">\
		                   		<a class="link" href="http://gad.qq.com/user?id={{item.userId}}" target="_blank">\
		                   			<span class="userpic g-badge">\
		                   				<img class="f-circle" width="52" height="52" :src="item.avatar" alt="{{item.nickName}}">\
								 		<i v-if="item.type == 1" class="gicos-bluev-shadow-s"></i>\
    	                        		<i v-if="item.type == 2" class="gicos-redv-shadow-s"></i>\
		                   			</span>\
		                   		</a>\
		                   		<span class="userinfo"><a class="link" href="http://gad.qq.com/user?id={{item.userId}}" target="_blank"><span class="userinfo-name">{{item.nickName}}</span></a><span class="userinfo-slogan">{{item.title}}</span></span></div>\
		                    <ul class="author-artlink">\
		                        <li class="artlink-item" v-for="li in item.archives"><a class="link" href="{{li.url}}" target="_blank">{{li.title?li.title:"暂无"}}</a></li>\
		                    </ul>\
		                    <!--交互说明：\
		                        1、show-add | 未关注，展示关注按钮\
		                        2、show-done | 已关注，展示已关注按钮（mousehover：出现取消关注）\
		                        3、show-mutual | 已关注，相互关注按钮（mousehover：出现取消关注）\
		                    -->\
		                    <div class="opt-line {{btnStatus[item.isFollowed]}}">\
		                        <button class="follow-btn btn-add" type="button" @click="follow(item)"><span class="cyico-add-2" ><!--添加--></span>关注</button>\
		                        <button class="follow-btn btn-done" type="button" @click="unFollow(item)"><span class="cyico-done" ><!--完全--></span>已关注</button>\
		                        <button class="follow-btn btn-mutual" type="button" @click="unFollow(item)"><span class="cyico-mutual" ><!--相互--></span>互相关注</button>\
		                        <button class="follow-btn btn-cancle" type="button" @click="unFollow(item)"><span class="cyico-cancle" "><!--取消关注--></span>取消关注</button>\
		                    </div>\
		                </li>\
		            </ul>\
		            <div class="m-dlmore  dlmore-home dl-loading"  v-show="loading">\
		                 <span class="dlmore-loading gico-loading loading-20">加载中</span>\
		            </div>\
		         </div>',
	    data:function(){
	        return {
	            hasMore:true,
	            loading:false,
				followactionloading:false,
	            recomListCnt:0,
	            items:[],
	            status:{
	                p:0,
	                ps:4
	            },
	            btnStatus:['show-add','show-done','show-mutual']
	        }
	    },
	    props:{
	    	showAll:{
	    		type:Boolean,
	    		default:function () {
					return true;
                }
	    	},
			listShow:{
	    		type:Boolean,
				default:function () {
					return true;
                }
			}
	    },
		watch:{
            listShow:function (newV,oldV) {
            	//改变量只有一次变化的状态
            	//若变量发生改变则请求
				this.getList();
            }
		},
	    ready:function(){
	    	//初始化不存在关注人状态则请求
			var that = this;
	    	if(that.listShow)
	    		that.getList();

	    },
	    methods:{
	        getList:function(){
	            var that = this;

	            if(that.loading)
	            	return;

	            if(!this.hasMore)
	                that.status.p = 0;

	            that.loading = true;
	            that.$http.get('/follow/feeds?p='+(++that.status.p)+'&ps='+that.status.ps).then(function(res){
	                if(res.data.code == 0){
	                    that.loading = false;
	                    that.hasMore = res.data.hasMore;
	                    that.items = res.data.users;
	                }
	            });
	        },
	        follow:function(item){
	            var that = this;
	            //提升用户体验
				if(that.followactionloading){
					popup.showLoading('操作过于频繁，请稍后重试..')
					setTimeout(function () {
						popup.hideLoading();
                    },1000);
					return;
				}
				that.followactionloading = true;
	            var tempFollow = item.isFollowed;
	            item.isFollowed = 1;
	            that.$http.post('/follow/index',{
	                followuser:item.userId,
	                act:'follow',
	                _token: $('[name="csrf-token"]').attr('content')
	            }).then(function(res){
	                if(res.data.code == 0){
	                    that.recomListCnt++;
						item.isFollowed = res.data.status;
	                   item.isFollowed = res.data.status;
	                }else{
	                    item.isFollowed = tempFollow;
	                }
                    that.followactionloading = false;
	            },function(res){
	            	item.isFollowed = tempFollow;
	            	that.followactionloading = false;
                    popup.showLoading('系统错误，请稍后重试..')
                    setTimeout(function () {
                        popup.hideLoading();
                    },1000);
	            })

	        },
	        unFollow:function(item){
	            var 
	                tempFollow = item.isFollowed
	                ,that = this
	            ;
                if(that.followactionloading){
                    popup.showLoading('操作过于频繁，请稍后重试..')
                    setTimeout(function () {
                        popup.hideLoading();
                    },1000);
                    return;
                }
                that.followactionloading = true;
	            item.isFollowed = 0;
	            that.$http.post('/follow/index',{
	                followuser:item.userId,
	                act:'cancel',
	                _token: $('[name="csrf-token"]').attr('content')
	            }).then(function(res){
	                if(res.data.code == 0){
	                   if(that.recomListCnt == 0)
	                   	return;
	                   that.recomListCnt--;

	                }else{
	                    item.isFollowed = tempFollow;
	                }
	                that.followactionloading = false;
	            },function(res){
	            	item.isFollowed = tempFollow;
	            	that.followactionloading = false;
                    popup.showLoading('系统错误，请稍后重试..')
                    setTimeout(function () {
                        popup.hideLoading();
                    },1000);
	            })
	        },
	        reload:function(){
	            location.reload();
	        }
	    }
	});

})