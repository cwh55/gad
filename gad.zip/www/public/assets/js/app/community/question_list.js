define(['vue', 'jquery', 'app/community/share'], function(Vue, $, share) {
    var vue = new Vue({
        el: '#feed-div',
        data: {
            list: [],
            page: 1,
            pageSize: 20,
            orderType: 'new',
            tagName: '',
            controller: 'question',
            isLoading: false,
            noMoreData: false,
            token: $('meta[name="csrf-token"]').attr('content'),
        },
        methods: {
            loading: function (channel_id) {
                if (this.noMoreData || this.isLoading) {
                    return;
                }
                this.isLoading = true;
                var url = '/' + this.controller + '/list';
                if (this.tagName) {
                    url = url + '/' + this.tagName;
                }
                $.ajax({
                    url: url, type: 'get', headers: {'X-CSRF-TOKEN': this.token}, data: {
                        channel_id: channel_id, page: 0,
                        pageSize: this.pageSize, orderType: this.orderType
                    }, dataType: 'json', success: function (recv) {
                        if (recv.code == 0) {
                            vue.isLoading = false;
                            vue.noMoreData = recv.data.length < vue.pageSize;
                        } else {
                            //alert('获取列表失败：'+recv.msg);
                        }
                        vue.isLoading = false;
                    }, error: function () {
                        //alert('获取列表失败');
                    }
                });
            },
            getFeedList: function (channel_id) {
                if (vue.noMoreData || vue.isLoading) {
                    return;
                }
                vue.isLoading = true;
                var url = '/' + this.controller + '/list';
                if (vue.tagName) {
                    url = url + '/' + vue.tagName;
                }
                $.ajax({
                    url: url, type: 'get', headers: {'X-CSRF-TOKEN': vue.token}, data: {
                        channel_id: channel_id, page: vue.page,
                        pageSize: vue.pageSize, orderType: vue.orderType
                    }, dataType: 'json', success: function (recv) {
                        if (recv.code == 0) {
                            vue.page++;
                            vue.list = vue.list.concat(recv.data);
                            vue.isLoading = false;
                            vue.noMoreData = recv.data.length < vue.pageSize;
                        } else {
                            //alert('获取列表失败：'+recv.msg);
                        }
                    }, error: function () {
                        //alert('获取列表失败');
                    }
                });
            },
            formatTime: function (time) {
                /* 时间标记规则；
                 1小时内：显示 XX分钟前
                 1天内：显示 XX小时前
                 3天内：显示 X天前
                 超过3天：显示日期  2017-3-17
                 */
                var $t0 = new Date(time).valueOf();
                var $t = (new Date().valueOf() - $t0) / 1000;
                if ($t < 3600) {
                    return Math.round($t / 60) + '分钟前';
                } else if ($t < 24 * 3600) {
                    return Math.round($t / 3600) + '小时前';
                } else if ($t < 3 * 24 * 3600) {
                    return Math.round($t / 24 / 3600) + '天前';
                } else {
                    return time.substr(0, 10);
                }
            },
            showTags: function (tags) {
                if (!tags) {
                    return '';
                }
                var arr = tags.split(',');
                var html = [];
                for (var i = 0; i < arr.length; i++) {
                    html.push('<a class="m-label umetadata-label" target="_blank" href="' + encodeURI('/tag/name/' + arr[i]) + '">' + arr[i] + '</a>');
                }
                return html.join('');
            },
            reply: function (at_user) {
                if (!tags) {
                    return '';
                }
                var arr = tags.split(',');
                var html = [];
                for (var i = 0; i < arr.length; i++) {
                    html.push('<a class="m-label umetadata-label" target="_blank" href="javascript:;">' + arr[i] + '</a>');
                }
                return html.join('');
            }
        }
    });
    $(window).scroll(function() {
        var sHeight = document.documentElement.scrollTop || document.body.scrollTop;
        var wHeight = document.documentElement.offsetHeight;
        var dHeight = document.documentElement.scrollHeight;
        if (dHeight - (sHeight + wHeight) < 50) {
            vue.getFeedList();
        }
    });
    return list = {
        vue: vue
    }
});
