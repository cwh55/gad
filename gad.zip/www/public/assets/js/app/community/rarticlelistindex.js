define(['app/community/list','app/community/question','app/community/common', 'app/community/gallery/layoutrindex'],
    function(list,question,common, layout){
    return {
        init: function (isLogin, tagName, auth) {
            layout.init(auth);
            list.init(tagName);
            if(isLogin){
                question.init(0,'','','','topic');
                question.init(0,'','','','question');
            }
            common.init(isLogin);
        }
    } 
});