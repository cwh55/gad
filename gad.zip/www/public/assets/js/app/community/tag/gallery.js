define(['vue', 'vue-resource'], function (Vue, VueResource) {

    Vue.use(VueResource);
    Vue.http.interceptors.push(function(request, next) {
        next(function(response) {
            if (response.status == 401) {
                gad.login();
            }
        });
    });

    Vue.component('archive-picture', {
        template: '#tpl-picture',
        props: ['pictures']
    });

    return {
        init: function (tag, category, sort) {
            vm = new Vue({
                el: '#tag-archive-list',
                ready: function () {
                    var self = this;
                    $(window).scroll(function() {
                        var sHeight = document.documentElement.scrollTop || document.body.scrollTop;
                        var wHeight = document.documentElement.offsetHeight;
                        var dHeight = document.documentElement.scrollHeight;
                        if (dHeight - (sHeight + wHeight) < 100) {
                            if (!self.isLoading && !self.isEnd) {
                                self.load();
                            }
                        }
                    });
                },

                data: {
                    pictures: [[], [], [], []],
                    page: 2,
                    isLoading: false,
                    loadStatus: '',
                    isEnd: false
                },
                methods: {
                    load: function (page) {
                        this.isLoading = true;
                        this.loadStatus = 'loading';
                        this.$http.get('/tag/' + category + '/' + encodeURIComponent(tag.name) + '/' + sort, {
                            params: {
                                page: this.page
                            }
                        }).then(function (res) {
                            this.isLoading = false;
                            for (var i = 0; i < res.body.data.length; i++) {
                                var column = i % 4;
                                this.pictures[column].push(res.body.data[i]);
                            }

                            if (res.body.data.length < res.body.per_page) {
                                this.loadStatus = 'nomore';
                                this.isEnd = true;
                            } else {
                                this.loadStatus = '';
                                this.page++;
                            }
                        });
                    }
                }
            });
        }
    };
});
