define(['vue', 'vue-resource'], function (Vue, VueResource) {

    Vue.use(VueResource);
    Vue.http.interceptors.push(function(request, next) {
        next(function(response) {
            if (response.status == 401) {
                gad.login();
            }
        });
    });

    Vue.component('archive-article', {
        template: '#tpl-article',
        props: ['archive']
    });

    Vue.component('archive-gallery', {
        template: '#tpl-gallery',
        props: ['archive']
    });

    Vue.component('archive-question', {
        template: '#tpl-question',
        props: ['archive']
    });

    return {
        init: function (tag, category, sort) {
            vm = new Vue({
                el: '#tag-archive-list',
                ready: function () {
                    var self = this;
                    $(window).scroll(function() {
                        var sHeight = document.documentElement.scrollTop || document.body.scrollTop;
                        var wHeight = document.documentElement.offsetHeight;
                        var dHeight = document.documentElement.scrollHeight;
                        if (dHeight - (sHeight + wHeight) < 100) {
                            if (!self.isLoading && !self.isEnd) {
                                self.load();
                            }
                        }
                    });
                },

                data: {
                    archives: [],
                    page: 2,
                    isLoading: false,
                    loadStatus: '',
                    isEnd: false
                },
                methods: {
                    getArchiveComponent: function (archive) {
                        var archiveType = ['', 'article', 'gallery', 'question'];

                        return 'archive-' + archiveType[archive.class_id];
                    },
                    load: function (page) {
                        this.isLoading = true;
                        this.loadStatus = 'loading';

                        var url = '/tag/' + (category == 'all' ? '' : category + '/') + encodeURI(tag.name) + (sort == 'hot' ? '' : '/' + sort);
                        this.$http.get(url, {
                            params: {
                                page: this.page
                            }
                        }).then(function (res) {
                            this.isLoading = false;
                            this.archives = this.archives.concat(res.body.data);
                            if (res.body.data.length < res.body.per_page) {
                                this.loadStatus = 'nomore';
                                this.isEnd = true;
                            } else {
                                this.loadStatus = '';
                                this.page++;
                            }
                        });
                    }
                }
            });
        }
    };
});
