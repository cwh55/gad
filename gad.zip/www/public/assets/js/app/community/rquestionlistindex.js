define(['app/community/question_list','app/community/question','vue','app/community/recommendfollow','app/community/common', 'app/community/gallery/layoutrindex'], 
    function (list,question,Vue,recommendfollow,common, layout) {
    return {
        init: function (order, tagname, isLogin, auth) {
            layout.init(auth);
            list.vue.orderType = order;
            list.vue.tagName = tagname;
            list.vue.controller='question';
            list.vue.loading();
            if(isLogin){
                question.init(0,'','','','topic');
                question.init(0,'','','','question');
            }
            //new Vue({el:'#js-recommend-follow'});
            common.init(isLogin);
        }
    }
});