define(['jquery', 'vue', 'app/community/community', 'popup', 'moment', 'tig-editor-v2', 'app/community/tag', 'app/hatch/project_list','app/community/captcha'], function ($, Vue, community, popup, moment, TIG) {
    Vue.filter('time-format', function (value) {
        if(value==undefined) {
            return '';
        }
        var time = moment(value, "YYYY-MM-DD hh:mm:ss").unix();
        var passhours = (new Date().getTime()/1000 - time)/60/60;
        if (passhours > 24) {
            return value.substring(0, 10);
        }else if (1 < passhours && passhours < 24) {
            return parseInt(passhours) + "小时前";
        }else if (parseInt(passhours * 60)) {
            return parseInt(passhours * 60) + "分钟前";
        }else {
            return "刚刚";
        }
        return value;
    });
    Vue.filter('view-format', function(value) {
        var str = ''+value;
        value = parseInt(value);
        if(value >= 10000) {
            var pre = parseInt(value / 10000);
            var sub = parseInt(value % 10000 / 1000);
            str = sub == 0 ? pre + 'w' : pre + '.' + sub + 'w';
        } else if(value >= 1000) {
            var pre = parseInt(value / 1000);
            var sub = parseInt(value % 1000 / 100);
            str = sub == 0 ? pre + 'k' : pre + '.' +sub + 'k';
        }
        return str;
    });
    Vue.component('v-question', {
        template: '<div class="publishpop publishpop-{{question}} publishpop-{{controller}} m-mask f-hide" >\
        <div class="publishpop-wrap mask-inner">\
        <div class="publishpop-head"><h3 class="publishpop-title">发表</h3><a class="publishpop-close" href="javascript:;" v-on:click="close()"><i class="gicos-close-1"></i></a></div>\
            <div class="m-form publishpop-main">\
			    <div class="articletit">\
			    	<div class="articletit-textarea">\
                        <textarea class="moretext g-scrollbar" placeholder="写下{{controllerName}}" autofocus>{{title}}</textarea>\
                        <span class="moretext-place f-abs-hide"></span>\
                        <span class="errortips f-hide">标题已超出<span class="num">3</span>个字</span>\
                    </div>\
                    <div class="question-hint" v-if="controller!=\'topic\'">\
                        <p class="hint-title">如何快速获得回答？</p>\
                        <ol class="hint-list">\
                            <li class="hint-item">\
                                <span class="hint-num">1.</span>\
                                <p class="hint-text">问题尽量清晰完整</p>\
                            </li>\
                            <li class="hint-item">\
                                <span class="hint-num">2.</span>\
                                <p class="hint-text">在描述处对问题进行详细补充，如有代码则贴上<br>更多提问帮助，点击 <a class="hint-link" href="http://gad.qq.com/article/detail/37633" target="_blank">《“靠谱”提问手册》</a></p>\
                            </li>\
                        </ol>\
                    </div>\
                    <div class="wendainput">\
                        <h4>{{controllerName}}描述（可选）<span class="error-tips">{{errText}}</span></h4>\
                        <div class="m-tigeditor">\
                            <textarea class="tigeditor-textarea" id="{{controller}}_answer" name="desc" data-markdown="content_md"></textarea>\
                        </div>\
                    </div>\
                    <div class="articletit-tags">\
                      <h4>{{controllerName}}标签</h4>\
                      <ul class="articletit-tags-wrap f-clearfix">\
                      <tag :tags="tag" :inputid="controller_input" :classid="classid"></tag>\
                      </ul>\
                    </div>\
                </div>\
                <project-push :id="projectId" @projectselect="projectSelect"></project-push>\
                <div class="btngroups"><button class="m-btn-primary wenda-btn" v-bind:class="{inactive:publishStatus}" type="button" v-on:click="submitQuestion()">{{btnText}}</button><button class="m-btn-secondary wenda-btn" type="button" v-on:click="close()">取消</button></div>\
            </div>\
        </div>\
        </div>\
        <v-captcha v-ref:captcha v-on:save="submitQuestion"></v-captcha>',
        props: ['id', 'tag', 'detail', 'title', 'errText', 'controller', 'projectId','question'],
        ready: function () {
            var _that = this;
            this.controllerName = '问题';
            if (this.controller == 'topic') {
                this.controllerName = '话题';
            }
            $(".moretext").bind("input",function(){
                var inputStr = $(this).val().replace(/\r|\n/g,"");
                $(this).parent().find(".moretext-place").html(inputStr.replace(/\s/g,"&nbsp;"));
                _that.title = inputStr;
                if(inputStr.length > 0){
                    $(this).parent().find(".moretext-place").css("width",520);
                    $(this).height($(this).parent().find(".moretext-place").height());
                }
                else{
                    $(this).height(45);
                }
                if(inputStr.length > 50){
                    $(this).parent().find(".errortips").removeClass("f-hide");
                    $(this).parent().find(".errortips .num").text(inputStr.length - 50);
                }
                else{
                    $(".errortips").addClass("f-hide");
                }
            });
        },
        data: function () {
            return {
                publishStatus: false,
                btnText: '发表',
                classid: 3,
                num: 0,
                editor: '',
                controllerName: '',
                controller_input: 'tags-input_' + this.controller
            }
        },
        methods: {
            login: function () {
                gad.login();
            },
            charLen: function () {
                var editor_value = community.strip_tags(this.editor.html());
                return editor_value.length;
            },
            focus: function () {
                if (!this.isLogin) {
                    gad.login();
                    return;
                }
                if (this.charLen() > 0) {
                    this.publishStatus = true;
                } else {
                    this.publishStatus = false;
                }
                if (this.charLen() > 5000) {
                    this.num = this.charLen() - 5000;
                } else {
                    this.num = 0;
                }
            },
            blur: function () {
                if (this.isMultiLine()) {
                    this.textClass = "status-morecol focus-out";
                }
            },
            projectSelect: function (Id) {
                this.projectId = Id;
            },
            close: function () {
                $('.publishpop-' + this.controller + '').addClass('f-hide');
				$("body").css({
					"overflow-y":""
				});
            },
            submitQuestion: function (captcha) {
                this.editor = TIG.editor.getInstance(this.controller + '_answer');
                if (this.title.length <= 0 || this.title.length > 300) {
                    popup.showPopup('warn', '提示', '请输入标题或标题字数太多!');
                    return;
                }
                if (this.charLen() > 10000) {
                    popup.showPopup('warn', '', '输入的描述超过字数');
                    return;
                }
                var _that = this;
                if (this.publishStatus === false) {
                    this.publishStatus = true;
                    this.btnText = '发表中...';
                    var div = $('<div>').hide().appendTo('body');
                    div.html(this.editor.html());
                    $('img:not(.emoticon)[src]', div).attr('title', this.title).attr('alt', this.title); //图片（非表情）加上title和alt(SEO)
                    var content = div.html();
                    div.remove();
                    var question_id = '';
                    if (this.id > 0) {
                        question_id = '/' + this.id;
                    }
                    var data = {
                        id: this.id,
                        title: this.title,
                        content: content,
                        projectId: this.projectId,
                        tag: $('#tags-input_' + _that.controller).val(),
                        captcha: captcha,
                        _token: $('[name="csrf-token"]').attr('content')
                    };
                    this.$http.post('/' + _that.controller + '/question' + question_id, data)
                        .then(function (res) {
                            if (res.data.code == 0) {
                                location.href = '/' + _that.controller + '/detail/' + res.data.data.archive.id;
                            } else if (res.data.code == 10001) {
                                //$(".publishpop").addClass("f-hide");
                                _that.$refs.captcha.showCode(true, false);
                            } else if (res.data.code == 10002) {
                                //$(".publishpop").addClass("f-hide");
                                _that.$refs.captcha.showCode(true, true);
                            } else {
                                popup.showPopup('warn', '提示', res.data.message);
                            }
                            this.publishStatus = false;
                            this.btnText = '发表';
                        }, function (res) {
                            this.publishStatus = false;
                            this.btnText = '发表';
                            if (res.data.message) {
                                popup.showPopup('warn', '提示', res.data.message instanceof Object ? '请填写正确的标题' : res.data.message);
                            } else {
                                popup.showPopup('warn', '提示', 'Token验证失败，请重新登录后再操作');
                            }
                        });
                }
            }
        }
    });

    return {
        init: function(id,title,tag,content,controller,projectId){
            var vue = new Vue({
                el: '#'+controller+'_publish',
                data: {
                    id: id,
                    title: title,
                    tag: tag,
                    content: content,
                    errText: '',
                    controller: controller,
                    projectId: projectId,
                    _token: $('meta[name="csrf-token"]').attr('content'),
                },
                methods: {
                    delAnswer : function (answerList, reply, id){
                        var data = {};
                        data.type = 'del';
                        data.id = id;
                        data._token = $('meta[name=csrf-token]').attr('content');

                        if(id > 0){
                            var _that = this;
                            popup.showPopup(1,'提示','您确定要删除吗?', function(){
                                _that.$http.post('/'+_that.controller+'/answer/'+id,data).then(function(res){
                                    var ret = res.data;
                                    if(ret.code == 0){
                                        answerList.answerList.data.$remove(reply);
                                        answerList.answer_count = answer.answer_count - 1;
                                    } else {
                                        popup.showPopup(1,'提示',data.message);
                                    }
                                });
                            });
                        }
                    },
                    textShow: function(answer,type){
                        if(type != '' && this.answerData != ''){
                            answer.answer = this.answerData;
                            this.answerData = '';
                        }
                        answer.textShow = !answer.textShow;
                    },
                    changedata: function(data){
                        this.answerData = data;
                    },
                    updateAnswer: function(data){
                        this.dataList.answerList.data.splice(this.index,0,data);
                        this.dataList.answer_count = this.dataList.answer_count + 1;
                    }
                },
                computed: {
                    showLogin: function(){
                        return { 'show-replynew-apply': this.isLogin }
                    },
                    favstatus: function(){
                        return { 'item-on': this.favId > 0 }
                    }
                },
                ready: function(){
                    var tig_id = this.controller+'_answer';
                    var _that = this;
                    setTimeout(function() {
                        TIG.editor({
                            id: tig_id,
                            height: 200,
                            width: 520,
                            value: _that.content,
                            showRelativePath: false,
                            docToHtmlPath: '/course/doc2Html',
                            imageUploadPath: '/article/editorUploadImage',
                            wrapperClass: 'tig-image-center',
                            buttons: ['bold', 'italic', 'h2', 'blockquote', 'insertorderedlist',
                                'insertunorderedlist', 'emoticons', 'addsource', 'link', 'table', 'image', 'video']
                        });
                        $('#editor-' + tig_id).on('contentchange.editor.tfl', function (res) {
                            var editor = TIG.editor.getInstance(vue.controller+'_answer');
                            var editor_value = community.strip_tags(editor.html());
                            var length = editor_value.length;
                            if (length > 10000) {
                                _that.errText = '限1万字，已超出' + (length - 10000) + '字';
                            } else {
                                _that.errText = '';
                            }
                        });
                    },100);

                    $('.ask-ucommpraise_update a').on('click', function(){
						$("body").height($(window).height()).css({
							"overflow-y":"hidden"
						});
                        $('.publishpop-'+vue.controller).removeClass('f-hide');
                    });
                    $('.ask-ucommpraise_del a').on('click', function(){
                        var data = {};
                        data.type = 'del';
                        data.id = id;
                        data.title = 'del';
                        data._token = $('meta[name=csrf-token]').attr('content');
                        if(id > 0){
                            popup.showPopup(1,'提示','您确定要删除吗?', function(){
                                vue.$http.post('/'+vue.controller+'/question/'+id,data).then(function(res){
                                    var ret = res.data;
                                    if(ret.code == 0){
                                        location.href = '/'+vue.controller;
                                    } else {
                                        popup.showPopup(1,'提示',ret.message);
                                    }
                                });
                            });
                        }
                    });
                }
            })
        }
    }
})
