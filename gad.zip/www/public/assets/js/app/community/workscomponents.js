define(['jquery', 'vue', 'vue-resource', 'app/community/community', 'popup'],function($, Vue, VueResource, community, popup){
    Vue.use(VueResource);
    /*  图集弹窗组件
    调用示例：<works-detail :atlas-end="atlasEnd" :current-li-no="currentLiNo" :is-login="'{{Auth::check()}}'" :avatar="'{{Auth::check()?Auth::user()->getAvatar():''}}'"></works-detail>
        atlasEnd: 当前图集是不是瀑布流中最后一个图集
        currentLiNo：当前图集序号，为0时，切换图集左箭头不显示
        isLogin：是否登录，评论组件要用
        avatar: 当前用户头像，评论组件要用*/
    /*需要父组件或所在vue实例处理的事件：
    'change-altas': 切换图集，更新外部状态，并广播返回getDetail方法
     */
    Vue.component('worksDetail',{
        template:   '<div class="works-detail m-mask js_worksdetail {{altasPopClass}}" v-cloak>\
                        <span class="btn-close" @click="hideDetail"></span>\
                        <div class="bg-close" @click="hideDetail"></div>\
                        <div class="mask-inner">\
                            <div class="wkcirclebtn f-clearfix">\
                                <a href="javascript:;" class="wkcirclebtn-item isprev {{preAtlasClass}}" @click="changeAtlas(0)">\
                                    <div class="wkcirclebtn-mask"></div>\
                                    <span class="wkcirclebtn-ico"></span>\
                                </a>\
                                <a href="javascript:;" class="wkcirclebtn-item isnext {{nextAtlasClass}}" @click="changeAtlas(1)">\
                                    <div class="wkcirclebtn-mask"></div>\
                                    <span class="wkcirclebtn-ico"></span>\
                                </a>\
                            </div>\
                            <div class="main f-clearfix js_atlasdetail">\
                                <div class="detail-wrap">\
                                    <div class="m-breadcrumb detail-breadcrumb">\
                                        <a class="breadcrumb-item" href="/resource/list">美术资源库</a>\
                                        <span class="breadcrumb-spilt">&gt;</span>\
                                        <a class="breadcrumb-item" href="/gallery">习作点评</a>\
                                        <span class="breadcrumb-spilt">&gt;</span>\
                                        <span class="breadcrumb-item">{{atlas.title}}</span>\
                                    </div>\
                                    <div class="detail-head">\
                                        <h1 class="detail-tit">{{atlas.title}}</h1>\
                                        <div class="detail-data">\
                                            <span class="name-wrap">\
                                                <span class="name">{{atlas.user?atlas.user.NickName:""}}</span>\
                                                <i v-if="atlas.user && atlas.user.type == 1" class="gicos-bluev-s"></i>\
                                                <i v-if="atlas.user && atlas.user.type == 2" class="gicos-redv-s"></i>\
                                            </span>\
                                            <span class="time">{{atlas.publish_time| date-format}}</span>\
                                            <span class="browse">{{atlas.view_count | large-number}}次浏览</span>\
                                            <span class="ucommpraise opt-enter" v-if="editright">\
                                                <a class="ucommpraise-item">\
                                                    <i class="ucommpraise-ico cyico-del-s"></i>\
                                                    <span class="item-txt" @click="deleteAltas(atlas.id)">删除</span>\
                                                </a>\
                                                <a class="ucommpraise-item" href="/gallery/edit/{{atlas.id}}">\
                                                    <i class="ucommpraise-ico cyico-edit-s"></i>\
                                                    <span class="item-txt">修改</span>\
                                                </a>\
                                            </span>\
                                        </div>\
                                        <div class="detail-label">\
                                            <a class="m-label" target="_blank" :href="\'/tag/\'+encodeURIComponent(onetag)" v-for="onetag in atlas.tag" track-by="$index">{{onetag}}</a>\
                                        </div>\
                                        <div class="works-quickopt">\
                                            <div class="comment f-fl">\
                                                <span class="comment-num">{{picture.comment_count}}评论</span>\
                                                <a class="comment-link" href="javascript:;" @click="gotoReply"><i class="cyico-commt"></i></a>\
                                            </div>\
                                            <share :share-style="share.type" :url="share.url" :title="share.url" :qrcode="share.rcode" :desc="atlas.description" :classname="share.class"></share>\
                                        </div>\
                                    </div>\
                                    <div class="works-wrap">\
                                        <div class="works-hd">\
                                            <div class="works-cont g-imgpreview">\
                                                <img :src="picture.url" @click="enlarge" width="{{curimgwidth}}" height="{{curimgheight}}">\
                                                <p class="intro tigskin">\
                                                    {{{picture.content}}}\
                                                </p>\
                                            </div>\
                                        </div>\
                                        <div class="works-bd">\
                                            <div class="interflow work-interflow" v-if="qqgroup">\
                                                <div class="interflow-ewm">\
                                                    <img class="ewm-img" :src="qqgroup.url" width="72" height="72">\
                                                    <div class="ewm-info">\
                                                        <p class="ewm-intro">想免费获取内部独家PPT资料库？\
                                                            观看行业大牛直播？</p>\
                                                        <em class="ewm-tips">立即扫码加群</em>\
                                                    </div>\
                                                </div>\
                                                <div class="interflow-group">\
                                                    <a href="//shang.qq.com/wpa/qunwpa?idkey={{qqgroup.cover}}" target="_blank" class="clearfix">\
                                                        <i class="group-bigico"></i>\
                                                        <div class="group-info">\
                                                            <span class="tips">点击加入</span>\
                                                            <h5 class="group-tit">腾讯GAD游戏开发行业精英群</h5>\
                                                            <em class="group-number">{{qqgroup.model_id}}</em>\
                                                        </div>\
                                                    </a>\
                                                </div>\
                                            </div>\
                                            <v-likeandfav model-type="Picture" :model-id="picture.id" :like-id="myLike && myLike.id ? myLike.id : 0" :like-count="picture.like_count" :like-status="myLike ? myLike.status : 0" :fav-id="myFavorite && myFavorite.id ? myFavorite.id : 0" :fav-count=" picture.favorite_count"></v-likeandfav>\
                                        </div>\
                                        <div class="works-ft">\
                                            <div class="detail-commit"  id="replylist">\
                                                <comment-list :obj-id="picture.id" :obj-type="comment.type" :is-dian-ping="picture.type" :is-login="isLogin" :avatar="avatar"  :user-type="userType" need-pic="1"></comment-list>\
                                            </div>\
                                        </div>\
                                    </div>\
                                </div>\
                                <div class="detail-side">\
                                    <div class="fixarea">\
                                        <div class="side-author">\
                                            <div class="card">\
                                                <div class="card-thumb f-clearfix">\
                                                    <a class="userhead" href="http://gad.qq.com/user?id={{atlas.user.UserId}}" target="_blank">\
                                                        <img class="f-circle" :src="atlas.user.Avatar" width="44" height="44">\
                                                        <i v-if="atlas.user.type == 1" class="badge"><span class="gicos-bluev"></span></i>\
                                                        <i v-if="atlas.user.type == 2" class="badge"><span class="gicos-redv"></span></i>\
                                                    </a>\
                                                    <a class="card-title f-hide-col-1" href="http://gad.qq.com/user?id={{atlas.user.UserId}}" target="_blank">\
                                                        {{atlas.user.NickName}}\
                                                    </a>\
                                                    <follow :follow-user="atlas.user.UserId" :is-followed="myFollow" :style-class="m-btn-small"></follow>\
                                                </div>\
                                                <div class="card-desc">{{atlas.user.Summary}}</div>\
                                            </div>\
                                        </div>\
                                        <div class="side-author side-artwork">\
                                            <div class="artwork-list f-clearfix js_waterfallwrap">\
                                                <side-atlas :piclist="atlas.pictures" :picid="picture.id"></side-atlas>\
                                            </div>\
                                        </div>\
                                        <div class="side-wechat">\
                                            <p class="wechat-tit">腾讯GAD公众号</p>\
                                            <img class="wechat-ewm" src="http://gad.qpic.cn/assets/web/img/community/gad_code.png" width="149" height="149">\
                                        </div>\
                                        <div class="side-backup">\
                                            <div class="m-side status-side-gotop" id="go-innertop" style="display: none;">\
                                                <a class="m-side-ico m-ico-gotop"  @click="backToTop">返回顶部</a>\
                                            </div>\
                                        </div>\
                                    </div>\
                                </div>\
                            </div>\
                            <!--作品浏览-->\
                            <div class="works-browsing m-mask js_picturepop {{picPopClass}}" v-cloak>\
                                <div class="mask-inner">\
                                    <div class="wkcirclebtn f-clearfix">\
                                        <a href="javascript:;" class="wkcirclebtn-item isprev {{prePicClass}}" @click="changePicture(-1)">\
                                            <div class="wkcirclebtn-mask"></div>\
                                            <span class="wkcirclebtn-ico"></span>\
                                        </a>\
                                        <a href="javascript:;" class="wkcirclebtn-item isnext {{nextPicClass}}" @click="changePicture(1)">\
                                            <div class="wkcirclebtn-mask"></div>\
                                            <span class="wkcirclebtn-ico"></span>\
                                        </a>\
                                    </div>\
                                    <a href="javascript:;" class="close-btn" @click="closePicture"></a>\
                                    <div class="browsing-content">\
                                        <img class="js_imgpop" load="centrePicture" src="http://lorempixel.com/1064/1569/">\
                                    </div>\
                                </div>\
                            </div>\
                        </div>\
                    </div>',
        props: ['atlasEnd', 'currentLiNo', 'isLogin', 'avatar' , 'userType'],
        data: function () {
            return {
                showDetail: false,
                atlas: {created_at:'',user:{}, pictures:[]},  //下面的都是详情页弹窗的属性，ajax返回的
                picture: {id:0},
                myLike: {},
                myFavorite: {},
                myFollow: 0,
                qqgroup: null,
                editright: false,       //受否有权限编辑详情弹窗
                currentPicNo: 0,        //当前图片在图集中的序号
                imgno:0,                //所放大图片的序号
                showPop: false,          //是否显示图片放大弹窗
                firsturl: '/gallery',    //打开弹窗前的url
                curimgwidth: 0,          //当前图片占位宽
                curimgheight: 0          //当前图片占位高
            }
        },
        ready: function () {
            var _that = this;
            //监听后退事件
            window.addEventListener("popstate", function() {
                var duans = window.location.href.split('/');
                if(isNaN(duans[duans.length-1])){  //返回到列表页。
                    _that.showDetail = false;
                    _that.setOverFlow(1,0,0);
                }else{
                    _that.getDetail(duans[duans.length-2], duans[duans.length-1]);
                }
            });
        },
        watch: {
            atlas: function () {
                //计算当前图片在图集中的序号
                for (var i = 0; i < this.atlas.pictures.length; i++) {
                    if (this.atlas.pictures[i].id == this.picture.id) {
                        this.currentPicNo = i;
                        break;
                    }
                }
                var ratio = this.atlas.pictures[this.currentPicNo].width / 847;
                if (ratio > 1) {
                    this.curimgwidth = 847;
                    this.curimgheight = this.atlas.pictures[this.currentPicNo].height / ratio;
                } else {
                    this.curimgwidth = this.atlas.pictures[this.currentPicNo].width;
                    this.curimgheight = this.atlas.pictures[this.currentPicNo].height;
                }
            }
        },
        computed: {
            share: function () {
                return {
                    type: 'bigshare',
                    url: 'http://' + location.host + '/gallery/detail/' + this.atlas.id + '/' + this.picture.id,
                    title: this.atlas.title+'——GAD腾讯游戏开发者平台',
                    rcode: 'http://' + location.host + '/gallery/detail/' + this.atlas.id + '/' + this.picture.id,
                    class: 'works-share'
                }
            },
            comment: function () {
                return {
                    type: 'App\\Entities\\Picture'
                }
            },
            preAtlasClass: function () {
                return !this.currentLiNo||this.showPop ? "f-hide": "";
            },
            nextAtlasClass: function () {
                return this.atlasEnd||this.showPop ? "f-hide": "";
            },
            prePicClass: function () {
                return !this.imgno ? "f-hide" : "";
            },
            nextPicClass: function () {
                return this.atlas.pictures && (this.imgno == this.atlas.pictures.length-1) ? "f-hide" : "";
            },
            picPopClass: function () {
                return !this.showPop ? "f-hide" : "";
            },
            altasPopClass: function () {
                return !this.showDetail ? "f-hide" : "";
            }
        },
        methods: {
            //获取图集详情，更改url并弹出弹窗，不支持pushState就新开窗口
            getDetail: function(aid, id, historyflag, flowflag){
                if(history.pushState){
                    var duans = window.location.href.split('/');
                    if(isNaN(duans[duans.length-1])){  //记录为第一个页面
                        this.firsturl = window.location.href;
                    }
                    if(historyflag){
                        history.pushState({}, '', '/gallery/detail/'+aid+'/'+id);
                    }
                    this.$http.get('/gallery/detail/'+aid+'/'+id, {}).then(function (res) {
                        var response = res.data;
                        if(response.code == 0){
                            this.$http.post('/api/addviewcnt');
                            this.atlas = response.data.atlas;
                            this.atlas.tag = this.atlas.tag.split(',');
                            this.picture = response.data.picture;
                            this.myLike = response.data.myLike;
                            this.myFollow = response.data.myFollow;
                            this.myFavorite = response.data.myFavorite;
                            this.editright = response.data.editright;
                            this.qqgroup = response.data.QQGroup;
                            this.showDetail = true;
                            if(flowflag){
                                this.setOverFlow(0,1,0);
                                $("#go-top").hide();
                            }
                            $(".js_worksdetail").scroll(function(){
                                $('#go-innertop')[$(this).scrollTop() > document.body.clientHeight ? 'fadeIn' : 'fadeOut']();
                            });
                            //左右侧悬浮自动置顶
                            community.autoFixTop({scrollTop:119,fixTop:66,popflag:true,mainWidth:1180,outHeight:-1,objgroup:$(".detail-side .fixarea")});
                        }else{
                            popup.showPopup('warn','提示','数据拉取失败!');
                        }
                    });
                }else{
                    window.location.href = '/gallery/detail/'+aid+'/'+id;
                }
            },
            changeAtlas: function (direction) {
                this.$dispatch('change-altas', direction);
            },
            deleteAltas: function (id) {
                var _that = this;
                popup.showPopup('ok','提示','确定要删除么？', function(){
                    _that.$http.post('/gallery/delete-atlas', {id:id, _token:$('meta[name="csrf-token"]').attr('content')}).then(function (res) {
                        var response = res.data;
                        if(response.code == 0){
                            popup.showPopup('ok','提示',response.msg, function(){
                                window.location.href = '/gallery';
                            });
                        }else{
                            popup.showPopup('warn','提示',response.msg);
                        }
                    });
                });
            },
            gotoReply: function () {
                document.getElementById("replylist").scrollIntoView(true);
            },
            enlarge: function () {
                this.showPop = true;
                this.imgno = this.currentPicNo;
                this.setOverFlow(0,0,1);
                var imgSrc = this.atlas.pictures[this.imgno].url.split('?')[0];
                $(".js_imgpop").attr('src', imgSrc);
            },
            backToTop: function () {
                $(".js_worksdetail").scrollTop(0);
            },
            closePicture: function(){
                this.showPop = false;
                this.setOverFlow(0,1,0);
                $('#go-innertop').hide();
            },
            hideDetail: function(){
                this.showDetail = false;
                history.pushState({}, '', this.firsturl);
                this.setOverFlow(1,0,0);
            },
            back: function(){
                history.go(-1);
            },
            setOverFlow: function(body, detail, picture){       //改变当前观察窗口为可滚动，其余不可滚动。
                if (body) {
                    $("body").css("overflow","");
                } else {
                    $("body").css("overflow","hidden");
                }
                if (detail) {
                    $(".js_worksdetail").css("overflow","auto");
                } else {
                    $(".js_worksdetail").css("overflow","hidden");
                }
                if (picture) {
                    $(".js_picturepop").css("overflow","auto");
                } else {
                    $(".js_picturepop").css("overflow","hidden");
                }
            },
            centrePicture: function(){      //图片小于屏幕，使其居中。此方法由重构童鞋提供。
                if($(".browsing-content img").height() < ($(window).height()-40)){
                    $(".browsing-content img").addClass("f-abs-center");
                }else{
                    $(".browsing-content img").removeClass("f-abs-center");
                }
            },
            changePicture: function(direction){
                this.imgno += direction;
                var imgsrc = this.atlas.pictures[this.imgno].url.split('?')[0];
                $(".js_imgpop").attr('src', imgsrc);
            }
        },
        events: {
            'get-pic-detail': function (aid, id, historyflag, flowflag) {
                this.getDetail(aid, id, historyflag, flowflag);
            },
            'change-picture': function (aid, pid) {
                this.picture.url = '';
                history.pushState({}, '', '/gallery/detail/'+aid+'/'+pid);
                this.getDetail(aid, pid, true);
                this.setOverFlow(0,1,0);
            },
        }
    })

    /*  图集弹窗\详情页 左侧导航瀑布流组件
    调用示例：<side-atlas :piclist="atlas.pictures" :picid="picture.id"></side-atlas>
        piclist: 图集的图片列表
        picid: 当前图片id*/
    /*需要父组件或所在vue实例处理的事件：
    'change-picture': 切换图片，请求数据或者跳转
    'side-ready': 侧边初始化完成，需要则处理
     */
    
    Vue.component('sideAtlas',{
        template:   '<div class="artwork-waterfall">\
                        <div class="list-1">\
                            <a class="artwork {{item.curclass}}" href="javascript:;" v-for="item in leftlist" track-by="$index" @click="changePic(item.archive_id, item.id)">\
                                <img :src="item.url" width="{{item.swidth}}" height="{{item.sheight}}">\
                                <span class="artwork-mask"></span>\
                            </a>\
                        </div>\
                        <div class="list-2">\
                            <a class="artwork {{item.curclass}}" href="javascript:;"  v-for="item in rightlist" track-by="$index" @click="changePic(item.archive_id, item.id)">\
                                <img :src="item.url" width="{{item.swidth}}" height="{{item.sheight}}">\
                                <span class="artwork-mask"></span>\
                            </a>\
                        </div>\
                    </div>',
        props: ['piclist', 'picid'],
        data: function () {
            return {
                leftlist: [],
                rightlist: [],
                leftheight: 0,
                rightheight: 0
            };
        },
        watch: {
            piclist: function () {
                this.init();         
            }
        },
        ready: function () {
            this.init();
        },
        methods: {
            changePic: function (aid, pid) {
                this.$dispatch('change-picture', aid, pid);
            },
            clearData: function () {
                this.rightheight = 0;
                this.leftheight = 0;
                this.rightlist = [];
                this.leftlist = [];
            },
            init: function () {
                this.clearData();
                var curHeight = 0;
                var curImgNo = 0;
                var imglist = [];
                for (var i = 0; i < this.piclist.length; i++) {
                    imglist.push(this.piclist[i].url);
                    var ratio = this.piclist[i].width/115;
                    if(ratio > 1) {
                        this.piclist[i].swidth = 115;
                        this.piclist[i].sheight = this.piclist[i].height/ratio;
                    }
                    this.piclist[i].url += '?imageView2/2/w/115';
                    //设置当前图片class
                    if (this.piclist[i].id == this.picid) {
                        this.piclist[i].curclass = "cur js_curimg";
                        curHeight = this.leftheight <= this.rightheight ? this.leftheight : this.rightheight;
                        curImgNo = i;
                    } else {
                        this.piclist[i].curclass = "";
                    }
                    if (this.leftheight <= this.rightheight) {
                        this.leftlist.push(this.piclist[i]);
                        this.leftheight += this.piclist[i].sheight + 10;
                    } else {
                        this.rightlist.push(this.piclist[i]);
                        this.rightheight += this.piclist[i].sheight + 10;
                    }
                }
                this.$nextTick(function () {
                    $(".js_waterfallwrap").scrollTop(curHeight);
                    this.$dispatch('side-ready', curImgNo, imglist);
                })
            }
        }
    });

    /*瀑布流图片组件
    调用示例：<pic-works v-for="works in workslist4" :content="works"></works>
        content: 当前图片信息*/
    /*需要父组件或所在vue实例处理的事件：
    'picture-detail': 需要广播getDetail事件到弹窗组件，打开图集弹窗
     */
    Vue.component('picWorks',{
        template:'<li class="list-item">\
                    <a class="item-link js_liimg" id="liimg{{content.lino}}" :data-liid="content.lino" :data-aid="content.archive_id" :data-id="content.id" @click="openAtlas($event)" href="javascript:;">\
                        <div class="item-img show-uwokpraise-more">\
                            <img :src="content.url" class="js_image" width="{{swidth}}" height="{{sheight}}">\
                            <div class="uwokpraise">\
                                <span class="uwokpraise-item" href="javascript:;">\
                                    <i class="uwokpraise-ico {{likestyle}}" @click="like($event)"></i><!--cyico-like-s-red-->\
                                    <span class="item-num">{{content.like_count | large-number}}</span>\
                                </span>\
                                <span class="uwokpraise-item" href="javascript:;">\
                                    <i class="uwokpraise-ico cyico-commt-s-white"></i>\
                                    <span class="item-num">{{content.comment_count | large-number}}</span>\
                                </span>\
                            </div>\
                            <i class="tips cyico-gif" v-show="judgePicType(content.url)"></i>\
                        </div>\
                    </a>\
                    <h3 class="item-tit f-hide-col-1">{{{content.content}}}</h3>\
                    <div class="item-info">\
                        <a href="http://gad.qq.com/user?id={{content.user_id}}" target="_blank">\
                            <img class="info-img f-circle" :src="content.avatar" width="30" height="30">\
                            <em class="info-name f-hide-col-1">{{content.user_name}}</em>\
                            <span class="badge" v-if="content.user.type == 1"><i class="gicos-bluev-s"></i></span>\
                            <span class="badge" v-if="content.user.type == 2"><i class="gicos-redv-s"></i></span>\
                        </a>\
                        <span class="info-time">{{content.created_at | date-format}}</span>\
                    </div>\
                    <div class="item-comment {{tutorstyle}} js_commenttype">\
                        <p class="tit">晨星专家点评</p>\
                        <p class="intro">\
                        <span class="name f-hide-col-1">{{tutoranswer.user_name}}</span>\
                        <span class="badge" v-if="content.tutoranswer.user.type == 1"><i class="gicos-bluev-s"></i></span>\
                        <span class="badge" v-if="content.tutoranswer.user.type == 2"><i class="gicos-redv-s"></i></span>\
                        <i>：</i>{{tutoranswer.comment}}</p>\
                        <div class="opt-line">\
                            <div class="opt-down"><span class="gicos-arrow-down"></span></div>\
                            <div class="opt-up"><span class="gicos-arrow-up"></span></div>\
                        </div>\
                    </div>\
                </li>',
        props:['content'],
        data: function () {
                return {
                    likestyle: false,
                    liking: false,
                    tutorstyle: 'f-hide',
                    tutoranswer: {},
                    swidth: 0,
                    sheight: 0
                }
        },
        ready: function() {
            this.content.url += '?imageView2/2/w/275';
            if(this.content.mylike && this.content.mylike.length && this.content.mylike[0].status == 1){
                this.likestyle = 'cyico-like-s-red';
            }else{
                this.likestyle = 'cyico-like-s-white';
            };
            if (this.content.tutoranswer) {
                this.tutorstyle = '';
                this.tutoranswer = this.content.tutoranswer;
            }
            //计算图片在列表中的宽和高
            var ratio = this.content.width / 275;
            if (ratio > 1) {
                this.swidth = 275;
                this.sheight = this.content.height / ratio;
            } else {
                this.swidth = this.content.width;
                this.sheight = this.content.height;
            }
        },
        methods: {
            openAtlas: function(item){
                this.$dispatch('picture-detail', this.content.lino);
                item.preventDefault();
            },
            judgePicType: function(url){
                var patrn = /.gif/;
                return url && patrn.test(url);
            },
            like: function(item){
                if(this.liking) return;
                this.liking = true;
                item.cancelBubble = true;
                var data = {};
                data.model_type = 'Picture';
                data.model_id = this.content.id;
                data._token = $('meta[name=csrf-token]').attr('content');
                if(this.content.mylike && this.content.mylike.length){
                    data.status = this.content.mylike[0].status == 1 ? 0 : 1;
                    this.$http.post('/nlike/edit/'+this.content.mylike[0].id, data).then(function(res){
                        var ret = res.data;
                        this.liking = false;
                        if(ret.code == 0){
                            if(this.likestyle == 'cyico-like-s-white'){
                                this.likestyle = 'cyico-like-s-red';
                                this.content.like_count++;
                                this.content.mylike[0].status = 1;
                            }else{
                                this.likestyle = 'cyico-like-s-white';
                                this.content.like_count--;
                                this.content.mylike[0].status = 0;
                            }
                        } else {
                            popup.showPopup(1,'提示',data.message);
                        }
                    });
                } else {
                    data.status = 1;
                    this.$http.post('/nlike/create',data).then(function(res){
                        var ret = res.data;
                        this.liking = false;
                        if(ret.code == 0){
                            this.content.mylike = [];
                            this.content.mylike.push({
                                'id': ret.data.id,
                                'status': 1
                            })
                            this.likestyle = 'cyico-like-s-red';
                            this.content.like_count++;
                        } else {
                            popup.showPopup(1,'提示',ret.message);
                        }
                    })
                }
            }
        }
    });
})