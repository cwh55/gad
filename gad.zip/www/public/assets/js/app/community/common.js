define(['jquery','app/community/community'], function($, autofixtop) {
  !function(){

      $(".follow-btn").click(function() {
          $(this).text("已关注").addClass("disabled");
      });

      $(".js-test-1").click(function() {
          $(".pmain").attr("class", "pmain").addClass("p-all");
      });
      $(".js-test-6").click(function() {
          $(".pmain").attr("class", "pmain").addClass("p-article");
      });
      $(".js-test-2").click(function() {
          $(".pmain").attr("class", "pmain").addClass("p-wenda");
      });
      $(".js-test-3").click(function() {
          $(".pmain").attr("class", "pmain").addClass("p-works");
      });
      $(".js-intronews-btn .link").click(function() {
          $(".intronews").attr("class", "intronews").addClass("show-loading");
          setTimeout(function() {
              $(".intronews").attr("class", "intronews").addClass("show-end");
          }, 1000);
      })
      $(".follow-btn").click(function() {
          $(this).text("已关注").addClass("disabled");
      });

      $(".js-test-4").click(function() {
          $(".works-opera .tab-item").removeClass("cur");
          $(this).addClass("cur");
          $(".works-list").removeClass("show-works-main");
      });
      $(".js-test-5").click(function() {
          $(".works-opera .tab-item").removeClass("cur");
          $(this).addClass("cur");
          $(".works-list").addClass("show-works-main");
      });

      $("#new-archive-btn").click(function() {
          $(".publishpop-enter").removeClass("f-hide");
      });

      $(".topic_up .sortlab-item, .topic_up .tab-item, .topic_down .sortlab-item, .topic_down .tab-item").click(function(){
          var week = $(this).data('week');
          var up = $(this).data('up');
          var topic = $(this).data('topic');
          if(week != "") {
              up = $(".topic_"+topic).data("up");
              $(".topic_" + topic + " .sortlab-item").removeClass("cur");
              $(this).addClass("cur");
              $(".topic_"+topic).data('week',week);
          } else {
              week = $(".topic_" + topic).data("week");
              $(".topic_" + topic + " .tab-item").removeClass("item-on");
              $(this).addClass("item-on");
              $('.topic_' + topic).data('up', up);
          }
          $(".topic_"+topic+" .topic-list").hide();
          $(".topic_"+topic+" .topic-list_"+week+"_"+up).show();
      })
      $(".topic .topic-list").hide();
      $(".topic .topic-list_week_up").show();

  }();
  //ie中placeholder不可用。
  if(navigator.appVersion.indexOf("MSIE 9")>=0 || navigator.appVersion.indexOf("MSIE 8")>=0){
	$('textarea[placeholder], input[placeholder]').each(function(){
		var placeholder = $(this).attr('placeholder');
		$(this).click(function(){
			if($(this).val() == placeholder){
				$(this).val('');
			}
		});
		$(this).blur(function(){
			var element = $(this);
			setTimeout(function(){
				if(!element.val()){
					element.val(placeholder);
				}
			}, 100);
		}).trigger('blur');
	});
  }
    //滚动到相关推荐的位置，左右侧内容相继消失
    $(window).ready(function(){
        autofixtop.autoFixTop({scrollTop:119,fixTop:30,mainWidth:1180,outHeight:-1,objgroup:$(".pswitch .fixarea")});
        autofixtop.autoFixTop({scrollTop:$('.pmain-side .fixarea-b'),fixTop:30,mainWidth:1180,outHeight:-1,objgroup:$('.pmain-side .fixarea')});
    });;
    return {
        init: function(isLogin){
             $("#publish-question").click(function() {
                if(!isLogin){
                    gad.login();
                    localStorage.loginPopup = 'publish-question';
                    return;
                }
                $('#question_publish').removeClass('f-hide');
                $(".publishpop-enter").addClass("f-hide");
                $(".publishpop-wenda").removeClass("f-hide");
                $(".publishpop-wenda .articletit-textarea").focus();
				$("body").height($(window).height()).css({
					"overflow-y":"hidden"
				});
            });

            $("#publish-topic").click(function() {
                if(!isLogin){
                    gad.login();
                    localStorage.loginPopup = 'publish-topic';
                    return;
                }
                $('#topic_publish').removeClass('f-hide');
                $(".publishpop-enter").addClass("f-hide");
                $(".publishpop-topic").removeClass("f-hide");
                $(".publishpop-topic .articletit-textarea").focus();
				$("body").height($(window).height()).css({
					"overflow-y":"hidden"
				});
            });
            
            if(isLogin && localStorage.loginPopup){
                $('#'+localStorage.loginPopup).click();
                localStorage.removeItem('loginPopup');
            }
        }
    }
});
