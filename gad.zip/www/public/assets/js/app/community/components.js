define(['jquery','vue'],function($,Vue){
    /*  调用示例：<more-loading :status="status"></more-loading>
        status有以下状态：  空 不展示
                            goto 加载按钮
                            loading 加载中
                            nomore 没有更多数据*/
    Vue.component('moreLoading',{
        template:   '<div class="m-dlmore" :class="\'dl-\'+status">\
                        <a class="dlmore-btnsec" href="javascript:;">查看更多回复<span class="dlmore-ico gicos-arrow-down"></span></a>\
                        <span class="dlmore-loading gico-loading loading-20">加载中</span>\
                        <span class="dlmore-nomore">没有更多消息</span>\
                    </div>',
        props:['status']
    });
    //时间过滤器
    Vue.filter('date-format', function (value) {
        if (!value) {
            return '';
        }
        var time = moment(value, "YYYY-MM-DD hh:mm:ss").unix();
        var passhours = (new Date().getTime()/1000 - time)/60/60;
        if (passhours > 72) {
            return value.substring(0, 10);
        }else if (24 <= passhours && passhours <= 72) {
            return parseInt(passhours/24) + "天前";
        }else if (1 < passhours && passhours < 24) {
            return parseInt(passhours) + "小时前";
        }else if (parseInt(passhours * 60)) {
            return parseInt(passhours * 60) + "分钟前";
        }else {
            return "刚刚";
        }
    });
    //千、万过滤器
    Vue.filter('large-number', function (value) {
        var str = ''+value;
        value = parseInt(value);
        if(value >= 10000) {
          var pre = parseInt(value / 10000);
          var sub = parseInt(value % 10000 / 1000);
          str = sub == 0 ? pre + 'w' : pre + '.' + sub + 'w';
        } else if(value > 1000) {
          var pre = parseInt(value / 1000);
          var sub = parseInt(value % 1000 / 100);
          str = sub == 0 ? pre + 'k' : pre + '.' +sub + 'k';
        }
        return str;
    });
})