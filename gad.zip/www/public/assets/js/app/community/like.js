
/*
* @Author: dick@tecent.com
* @Date:   2017-02-23 10:40:02l
* @Last Modified by:   jumorzhulorlo
* @Last Modified time: 2017-02-27 15:39:07
*/

define(['jquery', 'vue', 'vue-resource', 'popup'], function ($, Vue, VueResource, popup) {
  Vue.use(VueResource);

  Vue.filter('view-format', function(value) {
      var str = ''+value;
      value = parseInt(value);
      if(value >= 10000) {
          var pre = parseInt(value / 10000);
          var sub = parseInt(value % 10000 / 1000);
          str = sub == 0 ? pre + 'w' : pre + '.' + sub + 'w';
      } else if(value >= 1000) {
          var pre = parseInt(value / 1000);
          var sub = parseInt(value % 1000 / 100);
          str = sub == 0 ? pre + 'k' : pre + '.' +sub + 'k';
      }
      return str;
  });
  Vue.component('v-likeandfav', {
      template: '<div class="m-collect">\
      <a class="collect-item item-like" v-bind:class="likestatus" href="javascript:;" v-on:click="like">\
          <i class="collect-ico gicos-like-blue"></i>\
          <i class="collect-ico gicos-like-white"></i>\
          <span class="collect-num">{{likeCount|view-format}}</span>\
      </a>\
      <a class="collect-item item-favor" v-bind:class="favstatus" href="javascript:;" v-on:click="fav">\
          <i class="collect-ico gicos-favor-blue"></i>\
          <i class="collect-ico gicos-favor-white"></i>\
          <span class="collect-num">{{favCount|view-format}}</span>\
      </a>\
      </div>\
      ',
      props: {
          modelType: {type: String},
          modelId: {type: Number},
          likeId: {type: Number},
          favId: {type: Number},
          likeCount: {type: Number},
          favCount: {type: Number},
          likeStatus: {type: Number}
      },
      methods: {
          like: function () {
              var data = {};
              data.model_type = this.modelType;
              data.model_id = this.modelId;
              data._token = $('meta[name=csrf-token]').attr('content');
              if(this.like_status == true){
                  return ;
              }
              this.like_status = true;

              if (this.likeId > 0) {
                  data.status = this.likeStatus == 1 ? 0 : 1;
                  this.$http.post('/nlike/edit/' + this.likeId, data).then(function (res) {
                      var ret = res.data;
                      if (ret.code == 0) {
                          if (this.likeStatus == 1) {
                              this.likeCount = this.likeCount - 1;
                              this.likeStatus = 0;
                          } else {
                              this.likeCount = this.likeCount + 1;
                              this.likeStatus = 1;
                          }
                          //popup.showPopup(1,'提示','操作成功');
                      } else {
                          popup.showPopup(1, '提示', data.message);
                      }
                      this.like_status = false;
                  });
              } else if (this.likeId <= 0) {
                  data.status = 1;
                  this.$http.post('/nlike/create', data).then(function (res) {
                      var ret = res.data;
                      if (ret.code == 0) {
                          this.likeCount = this.likeCount + 1;
                          this.likeId = ret.data.id;
                          this.likeStatus = 1;
                          //popup.showPopup(1,'提示','点赞成功');
                      } else {
                          popup.showPopup(1, '提示', ret.message);
                      }
                      this.like_status = false;
                  })
              }
          },
          fav: function () {
              var data = {};
              data.model_type = this.modelType;
              data.model_id = this.modelId;
              data._token = $('meta[name=csrf-token]').attr('content');
              if (this.fav_status == true) {
                  return;
              }
              this.fav_status = true;

              if (this.favId > 0) {
                  this.$http.post('/nfavorite/edit/' + this.favId, data).then(function (res) {
                      var ret = res.data;
                      if (ret.code == 0) {
                          this.favCount = this.favCount - 1;
                          this.favId = 0;
                          //popup.showPopup(1,'提示','操作成功');
                      } else {
                          popup.showPopup(1, '提示', ret.message);
                      }
                      this.fav_status = false;
                  });
              } else {
                  this.$http.post('/nfavorite/create', data).then(function (res) {
                      var ret = res.data;
                      if (ret.code == 0) {
                          this.favCount = this.favCount + 1;
                          this.favId = ret.data.id;
                          //popup.showPopup(1,'提示','收藏成功');
                      } else {
                          popup.showPopup(1, '提示', ret.message);
                      }
                      this.fav_status = false;
                  })
              }
          }
      },
      data: function () {
          return {like_status: false, fav_status: false}
      },
      computed: {
          likestatus: function () {
              return {
                  'item-on': this.likeStatus == 1,
              }
          },
          favstatus: function () {
              return {
                  'item-on': this.favId > 0,
              }
          }
      }
  })
    Vue.component('v-unlike', {
        template: '<div class="m-praise">\
      <div class="praise-item item-like" v-bind:class="likestatus" v-on:click="like(1)">\
          <div class="praise-ico"><i class="praise-utriangle-t"></i>\
          </div>\
          <span class="praise-like-num">{{likeCount|view-format}}</span>\
      </div>\
      <div class="praise-item item-notlike" v-bind:class="favstatus" v-on:click="like(2)">\
          <div class="praise-ico"><i class="praise-utriangle-b"></i></div>\
      </div>\
      </div>\
      ',
        props: {
            modelType: {
                type: String
            }, modelId: {
                type: Number
            }, likeId: {
                type: Number
            }, likeCount: {
                type: Number
            }, likeStatus: {
                type: Number
            }
        },
        methods: {
            like: function (status) {
                var data = {};
                data.model_type = this.modelType;
                data.model_id = this.modelId;
                data._token = $('meta[name=csrf-token]').attr('content');
                if (this.like_status == true) {
                    return;
                }
                this.like_status = true;

                if (this.likeId > 0) {
                    data.status = status == this.likeStatus ? 0 : status;
                    this.$http.post('/nlike/edit/' + this.likeId, data).then(function (res) {
                        var ret = res.data;
                        if (ret.code == 0) {
                            if (this.likeStatus == 1) {
                                this.likeCount = this.likeCount>0 ? this.likeCount - 1 : 0;
                            } else if (data.status == 1) {
                                this.likeCount = this.likeCount + 1;
                            }
                            this.likeStatus = data.status;
                            //popup.showPopup(1,'提示','操作成功');
                        } else {
                            popup.showPopup(1, '提示', ret.message);
                        }
                        this.like_status = false;
                    });
                } else {
                    data.status = status != 1 ? 2 : 1;
                    this.$http.post('/nlike/create', data).then(function (res) {
                        var ret = res.data;
                        if (ret.code == 0) {
                            if (data.status == 1) {
                                this.likeCount = this.likeCount + 1;
                            }
                            this.likeId = ret.data.id;
                            this.likeStatus = data.status;
                            //popup.showPopup(1,'提示','点赞成功');
                        } else {
                            popup.showPopup(1, '提示', ret.message);
                        }
                        this.like_status = false;
                    })
                }
            }

        },
        data: function () {
            return {like_status: false}
        },
        computed: {
            likestatus: function () {
                return {
                    'isactive': this.likeStatus == 1,
                }
            },
            favstatus: function () {
                return {
                    'isactive': this.likeStatus == 2,
                }
            }
        }
    })
    Vue.component('v-like',{
        template: '<a class="ucommpraise-item">\
        <i class="ucommpraise-ico cyico-like-s-gray" v-bind:class="likestatus" v-on:click="like()"></i>\
            <span class="item-txt">{{likeCount|view-format}}</span>\
            </a>\
            ',
        props: {
          modelType: { type:String },
          modelId: { type:Number },
          likeId: { type:Number },
          likeCount: { type:Number },
          likeStatus: { type:Number }
        },
        methods: {
            like: function () {
                var data = {};
                data.model_type = this.modelType;
                data.model_id = this.modelId;
                data._token = $('meta[name=csrf-token]').attr('content');
                data.status = 1 == this.likeStatus ? 0 : 1;
                if(this.like_status == true){
                    return;
                }
                this.like_status = true;
                this.$http.post('/nlike/create', data).then(function (res) {
                    var ret = res.data;
                    if (ret.code == 0) {
                        if (this.likeStatus == 1) {
                            this.likeCount > 0 ? this.likeCount = this.likeCount - 1 : 0;
                        } else {
                            this.likeCount = this.likeCount + 1;
                        }
                        this.likeStatus = data.status;
                        //popup.showPopup(1,'提示','点赞成功');
                    } else {
                        popup.showPopup(1, '提示', ret.message);
                    }
                    this.like_status = false;
                })
            }
        },
        data: function () {
            return { like_status : false }
        },
        computed: {
            likestatus: function () {
                return {
                    'isactive': this.likeStatus == 1,
                }
            }
        }
    })
    Vue.component('v-fav',{
        template: '<button class="m-btn-secondary" v-bind:class="{cancled:favId>0,\'f-fr\':className==0,\'btnbox-follow\':className>0}" type="button" v-on:click="fav()"><i class="ans-ico-star-white"></i><i class="ans-ico-star"></i>{{favId > 0 ? "已关注" : "关注"}}\
            (<span>{{ favCount|view-format }}</span>)\
        </button>\
            ',
        props: {
          modelType: { type:String },
          modelId: { type:Number },
          favId: { type:Number },
          favCount: { type:Number },
          className: {type:String,default:0}
        },
        methods: {
            fav: function () {
                var data = {};
                data.model_type = this.modelType;
                data.model_id = this.modelId;
                data._token = $('meta[name=csrf-token]').attr('content');
                if (this.fav_status == true) {
                    return;
                }
                this.fav_status = true;
                if (this.favId > 0) {
                    this.$http.post('/nfavorite/edit/' + this.favId, data).then(function (res) {
                        var ret = res.data;
                        if (ret.code == 0) {
                            if (this.favCount > 0) {
                                this.favCount = this.favCount - 1;
                            }
                            this.favId = 0;
                            this.$emit("updatefav", this.favCount, this.favId);
                            //popup.showPopup(1,'提示','点赞成功');
                        } else {
                            popup.showPopup(1, '提示', ret.message);
                        }
                        this.fav_status = false;
                    })
                } else {
                    this.$http.post('/nfavorite/create', data).then(function (res) {
                        var ret = res.data;
                        if (ret.code == 0) {
                            this.favCount = this.favCount + 1;
                            this.favId = ret.data.id;
                            this.$emit("updatefav", this.favCount, this.favId);
                            //popup.showPopup(1,'提示','收藏成功');
                        } else {
                            popup.showPopup(1, '提示', ret.message);
                        }
                        this.fav_status = false;
                    })
                }
            }
        },
        data : function() {
            return {fav_status: false}
        },
        ready: function() {
        },
        computed: {
            likestatus: function() {
                return {
                    'isactive': this.likeStatus == 1,
                }
            }
        }
    })
  Vue.component('v-special-likeandfav', {
      template: '<div class="banner-btngroup">\
      <button class="btngroup btn-save" v-bind:class="favstatus" href="javascript:;" v-on:click="fav">\
          收藏 {{favCount|view-format}}<span class="ico ico-save"></span>\
      </button>\
      <button class="btngroup btn-like" v-bind:class="likestatus" href="javascript:;" v-on:click="like">\
          觉得有用 {{likeCount|view-format}}<span class="ico ico-like"></span>\
      </button>\
      </div>\
      ',
      props: {
          modelType: {type: String},
          modelId: {type: Number},
          likeId: {type: Number},
          favId: {type: Number},
          likeCount: {type: Number},
          favCount: {type: Number},
          likeStatus: {type: Number},
		  login: {type:Number}
      },
      methods: {
          like: function () {
			  if(this.login == 0){
				  return gad.login();
			  }
              var data = {};
              data.model_type = this.modelType;
              data.model_id = this.modelId;
              data._token = $('meta[name=csrf-token]').attr('content');
              if(this.like_status == true){
                  return ;
              }
              this.like_status = true;

              if (this.likeId > 0) {
                  data.status = this.likeStatus == 1 ? 0 : 1;
				  if (this.likeStatus == 1 && this.likeCount > 0) {
					  this.likeCount = this.likeCount - 1;
                      this.likeStatus = 0;
				  } else if(this.likeStatus == 0){
					  this.likeCount = this.likeCount + 1;
                      this.likeStatus = 1;
				  }
                  this.$http.post('/nlike/edit/' + this.likeId, data).then(function (res) {
                      var ret = res.data;
                      if (ret.code == 0) {
                          //popup.showPopup(1,'提示','操作成功');
                      } else {
                          if (this.likeStatus == 0) {
							  this.likeCount = this.likeCount + 1;
                              this.likeStatus = 1;
                          } else {
                              this.likeCount = this.likeCount - 1;
                              this.likeStatus = 0;
                          }
                          popup.showPopup(1, '提示', data.message);
                      }
                      this.like_status = false;
                  });
              } else if (this.likeId <= 0) {
                  data.status = 1;
                  this.likeCount = this.likeCount + 1;
                  this.likeStatus = 1;
                  this.$http.post('/nlike/create', data).then(function (res) {
                      var ret = res.data;
                      if (ret.code == 0) {
                          this.likeId = ret.data.id;
                          //popup.showPopup(1,'提示','点赞成功');
                      } else {
                          this.likeStatus = 0;
                          this.likeCount = this.likeCount - 1;
                          popup.showPopup(1, '提示', ret.message);
                      }
                      this.like_status = false;
                  })
              }
          },
          fav: function () {
			  if(this.login == 0){
				  return gad.login();
			  }
              var data = {};
              data.model_type = this.modelType;
              data.model_id = this.modelId;
              data._token = $('meta[name=csrf-token]').attr('content');
              if (this.fav_status == true) {
                  return;
              }
              this.fav_status = true;

              if (this.favId > 0) {
				  var fId = this.favId;
                  if (this.favCount > 0) {
					this.favCount = this.favCount - 1;
                    this.favId = 0;
				  }
                  this.$http.post('/nfavorite/edit/' + fId, data).then(function (res) {
                      var ret = res.data;
                      if (ret.code == 0) {
                          //popup.showPopup(1,'提示','操作成功');
                      } else {
						  this.favCount = this.favCount + 1;
                          this.favId = fId;
                          popup.showPopup(1, '提示', ret.message);
                      }
                      this.fav_status = false;
                  });
              } else {
				  this.favCount = this.favCount + 1;
                  this.favId = 1;
                  this.$http.post('/nfavorite/create', data).then(function (res) {
                      var ret = res.data;
                      if (ret.code == 0) {
                          this.favId = ret.data.id;
                          //popup.showPopup(1,'提示','收藏成功');
                      } else {
                          this.favId = 0;
						  this.favCount = this.favCount - 1;
                          popup.showPopup(1, '提示', ret.message);
                      }
                      this.fav_status = false;
                  })
              }
          }
      },
      data: function () {
          return {like_status: false, fav_status: false}
      },
      computed: {
          likestatus: function () {
              return {
                  'active': this.likeStatus == 1,
              }
          },
          favstatus: function () {
              return {
                  'active': this.favId > 0,
              }
          }
      }
  })
})
