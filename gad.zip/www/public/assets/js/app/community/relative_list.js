define(['vue', 'vue-resource'], function (Vue, VueResource) {

    Vue.use(VueResource);
    Vue.component('archive-article', {
        template: '#tpl-article',
        props: ['archive']
    });

    Vue.component('archive-gallery', {
        template: '#tpl-gallery',
        props: ['archive']
    });

    Vue.component('archive-question', {
        template: '#tpl-question',
        props: ['archive']
    });
    
    Vue.component('archive-topic', {
        template: '#tpl-topic',
        props: ['archive']
    });

    return {
        init: function (id, topic) {
            var vm = new Vue({
                el: '#relative-list',
                ready: function () {
                    var self = this;
                    $(window).scroll(function() {
                        var sHeight = document.documentElement.scrollTop || document.body.scrollTop;
                        var wHeight = document.documentElement.offsetHeight;
                        var dHeight = document.documentElement.scrollHeight;
                        if (dHeight - (sHeight + wHeight) < 100) {
                            if (!self.isLoading && !self.isEnd) {
                                self.load();
                            }
                        }
                    });
                },

                data: {
                    archives: [],
                    page: 2,
                    pageSize: 10,
                    orderBy: 'hot_score',
                    tagName: '',
                    isLoading: false,
                    loadStatus: '',
                    isEnd: false
                },
                methods: {
                    getArchiveComponent: function (archive) {
                        var archiveType = ['', 'article', 'gallery', 'question', 'topic'];

                        return 'archive-' + archiveType[archive.class_id];
                    },
                    load: function (tagName) {
                        var clearUp = false;
                        if(tagName !== undefined && tagName != this.tagName){
                            this.tagName = tagName;
                            clearUp = true;
                            this.page = 1;
                            this.loadStatus = '';
                            $('#relative-list-ul > li').remove();
                            this.isEnd = false;
                        }
                        this.isLoading = true;
                        this.loadStatus = 'loading';
                        this.$http.get('/article/related-archives', {
                            params: {
                                id: id,
                                page: vm.page,
                                pageSize: vm.pageSize,
                                orderBy: vm.orderBy,
                                tagName: topic && !vm.tagName ? 'plan' : encodeURI(vm.tagName)
                            }
                        }).then(function (res) {
                            this.isLoading = false;
                            if (!this.isEnd) {
                                this.archives = clearUp ? res.body.data : this.archives.concat(res.body.data);
                            }

                            if (res.body.data.length < vm.pageSize) {
                                this.loadStatus = 'nomore';
                                this.isEnd = true;
                            } else {
                                this.loadStatus = '';
                                this.page++;
                            }
                        });
                    }
                }
            });
        }
    };
});
