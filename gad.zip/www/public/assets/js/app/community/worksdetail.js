define(['jquery', 'vue', 'tig-editor-v2', 'popup', 'vue-resource', 'app/community/relative_list', 'app/community/community', 'app/community/tag', 'app/community/like', 
    'app/community/comment', 'app/community/follow', 'pan_upload', 'app/community/workscomponents'], function($, Vue, TIG, popup, VueResource, relative_list, community) {
    Vue.use(VueResource);

    var largeH_r = $('.detail-related').offset().top - $('.detail-side .fixarea').height();
    var largeH_l = $('.detail-related').offset().top - $('.detail-comshare .fixarea').height();
    var relatedTop = $('.detail-related').offset().top;
    //左右侧悬浮自动置顶
    community.autoFixTop({scrollTop:119,fixTop:30,mainWidth:1180,outHeight:largeH_r,objgroup:$(".detail-side .fixarea")});
    community.autoFixTop({scrollTop:119,fixTop:30,mainWidth:1180,outHeight:largeH_l,objgroup:$('.detail-comshare .fixarea')});
    community.autoFixTop({scrollTop:$('.detail-related'),fixTop:30,mainWidth:1180,outHeight:-1,objgroup:$('.detail-related .fixarea')});
    
    //滚动到相关推荐的位置，右侧内容消失
    var largeH = $(".detail-head").height() + $(".works-wrap").height() + $(".detail-commit").height() + 119 +30 - 600;
    $(window).on("scroll",function(){
        var top = $(this).scrollTop();
        if(top > largeH){
            $(".detail-side").fadeOut();
        }
        else{
            $(".detail-side").fadeIn();
        }
    });

    return {
        init: function (id, pictures) {
            relative_list.init(id,false);
            var vm = new Vue({
                el: '#app',
                ready: function(){
                },
                data:{
                    showPop: false,
                    imglist: [],
                    imgno: 0,            //放大图片序号
                    currentimgno: 0     //详情页图片在图集中的序号
                },
                computed: {
                    isLastImg: function(){
                        return this.imgno == this.imglist.length-1;
                    }
                },
                methods: {
                    initvm: function (index, imglist) {
                        this.currentimgno = index;
                        this.imglist = imglist;
                    },
                    enlarge: function(item){
                        this.imgno = this.currentimgno;
                        this.showPop = true;
                        $("body").css("overflow","hidden");
                        var imgSrc = this.imglist[this.currentimgno].split('?')[0];
                        $(".js_imgpop").attr('src', imgSrc);
                    },
                    changePicture: function(direction){
                        this.imgno += direction;
                        $(".js_imgpop").attr('src', this.imglist[this.imgno].split('?')[0]);
                    },
                    clickPicture: function(aid, id, item){
                        history.pushState({pid:id}, '', '/gallery/detail/'+aid+'/'+id);
                        $(".js_imgmask", $(".js_waterfall")).removeClass('f-hide');
                        $(".js_imgmask", $(item.target).parent()).addClass('f-hide');
                        $(".js_imgpop").attr('src', this.imglist[this.imgno]);
                    },
                    closePop: function(){
                        this.showPop = false;
                        $("body").css("overflow","");
                    },
                    back: function(){
                        history.go(-1);
                    },
                    centrePicture: function(){
                        if($(".browsing-content img").height() < ($(window).height()-40)){
                            $(".browsing-content img").addClass("f-abs-center");
                        }else{
                            $(".browsing-content img").removeClass("f-abs-center");
                        }
                    },
                    deleteAltas: function (id, delType) {
                        var _that = this;
						var url = delType == '1' ? '/game/picture-delete' : '/gallery/delete-atlas';
                        popup.showPopup('ok','提示','确定要删除么？', function(){
                            _that.$http.post(url, {id:id, _token:$('meta[name="csrf-token"]').attr('content')}).then(function (res) {
                                var response = res.data;
                                if(response.code == 0){
                                    popup.showPopup('ok','提示',response.msg, function(){
                                        location.href = '/gallery';
                                    });
                                }else{
                                    popup.showPopup('warn','提示',response.msg);
                                }
                            });
                        }); 
                    }
                },
                events: {
                    'side-ready': function (index, imglist) {
                        this.initvm(index, imglist);
                    },
                    'change-picture': function (aid, pid) {
                        console.log(aid);
                        location.href = "/gallery/detail/" + aid + "/" + pid;
                    }
                }
            });
        }
    };
});