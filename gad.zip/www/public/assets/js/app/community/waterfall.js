define(['jquery','vue','vue-resource','popup', 'moment'],function($,Vue,VueResource,popup,moment){
	Vue.use(VueResource);
    
	Vue.component('picWorks',{
        template:'<li class="list-item">\
                    <a class="item-link js_liimg" id="liimg{{content.lino}}" :data-liid="content.lino" :data-aid="content.archive_id" :data-id="content.id" @click="openAtlas($event)">\
                        <div class="item-img show-uwokpraise-more">\
                            <img :src="content.url" class="js_image">\
                            <div class="uwokpraise">\
                                <span class="uwokpraise-item" href="javascript:;">\
                                    <i class="uwokpraise-ico {{likestyle}}" @click="like($event)"></i><!--cyico-like-s-red-->\
                                    <span class="item-num">{{content.like_count | large-number}}</span>\
                                </span>\
                                <span class="uwokpraise-item" href="javascript:;">\
                                    <i class="uwokpraise-ico cyico-commt-s-white"></i>\
                                    <span class="item-num">{{content.comment_count | large-number}}</span>\
                                </span>\
                            </div>\
                            <i class="tips cyico-gif" v-show="judgePicType(content.url)"></i>\
                        </div>\
                    </a>\
                    <h3 class="item-tit f-hide-col-1">{{{content.content}}}</h3>\
                    <div class="item-info">\
                        <a href="http://gad.qq.com/user?id={{content.user_id}}" target="_blank">\
                            <img class="info-img f-circle" :src="content.avatar" width="30" height="30">\
                            <em class="info-name f-hide-col-1">{{content.user_name}}</em>\
                        </a>\
                        <span class="info-time">{{content.created_at | date-format}}</span>\
                    </div>\
                    <div class="item-comment {{tutorstyle}} js_commenttype">\
                        <p class="tit">晨星专家点评</p>\
                        <p class="intro">\
                        <span class="name f-hide-col-1">{{tutoranswer.user_name}}</span>\
                        <i>：</i>{{tutoranswer.comment}}</p>\
                        <div class="opt-line">\
                            <div class="opt-down"><span class="gicos-arrow-down"></span></div>\
                            <div class="opt-up"><span class="gicos-arrow-up"></span></div>\
                        </div>\
                    </div>\
                </li>',
        props:['content'],
        data: function () {
                return {
                    likestyle: false,
                    liking: false,
                    tutorstyle: 'f-hide',
                    tutoranswer: {}
                }
        },
        ready: function(){
            this.content.url += '?imageView2/2/w/250';
            if(this.content.mylike && this.content.mylike.length && this.content.mylike[0].status == 1){
                this.likestyle = 'cyico-like-s-red';
            }else{
                this.likestyle = 'cyico-like-s-white';
            };
            if (this.content.tutoranswer) {
                this.tutorstyle = '';
                this.tutoranswer = this.content.tutoranswer;
            }
        },
        methods: {
            openAtlas: function(item){
                this.$dispatch('picture-detail', this.content.lino);
                item.preventDefault();
            },
            judgePicType: function(url){
                var patrn = /.gif/;
                return url && patrn.test(url);
            },
            like: function(item){
                if(this.liking) return;
                this.liking = true;
                item.cancelBubble = true;
                var data = {};
                data.model_type = 'Picture';
                data.model_id = this.content.id;
                data._token = $('meta[name=csrf-token]').attr('content');
                if(this.content.mylike && this.content.mylike.length){
                    data.status = this.content.mylike[0].status == 1 ? 0 : 1;
                    this.$http.post('/nlike/edit/'+this.content.mylike[0].id, data).then(function(res){
                        var ret = res.data;
                        this.liking = false;
                        if(ret.code == 0){
                            if(this.likestyle == 'cyico-like-s-white'){
                                this.likestyle = 'cyico-like-s-red';
                                this.content.like_count++;
                                this.content.mylike[0].status = 1;
                            }else{
                                this.likestyle = 'cyico-like-s-white';
                                this.content.like_count--;
                                this.content.mylike[0].status = 0;
                            }
                        } else {
                            popup.showPopup(1,'提示',data.message);
                        }
                    });
                } else {
                    data.status = 1;
                    this.$http.post('/nlike/create',data).then(function(res){
                        var ret = res.data;
                        this.liking = false;
                        if(ret.code == 0){
                            this.content.mylike = [];
                            this.content.mylike.push({
                                'id': ret.data.id,
                                'status': 1
                            })
                            this.likestyle = 'cyico-like-s-red';
                            this.content.like_count++;
                        } else {
                            popup.showPopup(1,'提示',ret.message);
                        }
                    })
                }
            }
        }
    });
})