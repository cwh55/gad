/**
 * Created by xiaolinwang on 17-5-16.
 */
define(['vue','vue-resource','popup','app/community/follow'],function(Vue,VueResource,popup,_){
    Vue.use(VueResource);
    Vue.component('recommend-follow',{
        template:'<div class="siderow follow {{nodata ? \'f-hide\' : \'\'}}">\
                    <div class="siderow-title">\
                        <h3>推荐关注</h3>\
                        <div class="siderow-other">\
                        <a class="cychange {{hasMore ? \'\' : \'f-hide\'}}" href="javascript:;" @click="change">换一批<i class="cychange-ico cyico-change"></i></a>\
                        </div>\
                    </div>\
                    <div class="siderow-cnt">\
                        <ul class="follow-list">\
                            <li class="follow-item" v-for="item in userList">\
                            <a class="link" href="http://gad.qq.com/user?id={{item.userId}}" target="_blank">\
                            <span class="userpic g-badge">\
                                <img class="f-circle" width="52" height="52" :src="item.avatar" alt="{{item.nickName}}">\
                                <i v-if="item.type == 1" class="gicos-bluev-shadow-s"></i>\
                                 <i v-if="item.type == 2" class="gicos-redv-shadow-s"></i>\
                            </span>\
                            <span class="userinfo"><span class="userinfo-name">{{item.nickName}}</span>\
                            <span class="userinfo-slogan">{{item.title}}</span>\
                            </span>\
                            </a>\
                            <follow :follow-user="item.userId" :is-followed="item.isFollowed"></follow>\
                            </li>\
                         </ul>\
                    </div>\
                    <div class="m-dlmore {{showClass}} dlmore-home">\
                     <span class="dlmore-loading gico-loading loading-20">加载中</span>\
                    </div>\
                  </div>',
        data:function(){
            return {
                index:1,
                pageSize:3,
                maxCount:3,
                userList:[],
                ruleOut:[],
                nodata: false,
                hasMore: false,
                showClass:'dl-loading'
            }
        },
        ready:function(){
            this.getRecommend();
        },
        methods:{
            getRecommend:function(){
                this.$http.get(
                    '/follow/recommend',
                    {
                        params:{
                            p:this.index,
                            ps:this.pageSize
                        }
                    }
                ).then(function(res){
                    if (res.data.code == 0) {
                        this.userList = res.data.users;
                        this.ruleOut = this.ruleOut.concat(res.data.users);
                        this.showClass = '';
                        if (this.index == this.maxCount) {
                            this.index = 1;
                        } else {
                            if (res.data.hasMore) {
                                this.index += 1;
                            } else {
                                this.index = 1;
                            }
                        }
                        this.nodata = false;
                        if(res.data.hasMore) {
                            this.nodata = false;
                            this.hasMore = true;
                        } else {
                            this.nodata = res.data.users.length <= 2;
                            this.hasMore = false;
                        }
                    }
                    this.showClass = '';
                },function(){
                    this.showClass = '';
                });
            },
            change:function(){
                this.getRecommend();
            }
        }
    });

})