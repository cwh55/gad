define(['app/gad','vue','app/community/question','app/community/community','app/community/common', 'app/community/gallery/layoutrindex',
  'app/community/recommendfollow', 'app/community/allarchive'],
    function(gad,Vue,question,community,common,layout){
      return {
        init: function (isLogin, auth) {
          layout.init(auth);
          if(isLogin){
              question.init(0,'','','','question');
              question.init(0,'','','','topic');
          }
          new Vue({
              el: '#js-recommend-follow'
          });
          new Vue({
              el: '#js-all-list',
              data: {
                  showDirect: false
              },
              ready: function () {
                  this.showDirect = (new Date().getFullYear()=='2017')&&!(document.cookie.indexOf('resource_show_direct=1')>=0);
                  if (this.showDirect) {
                      $("body").css("overflow","hidden");
                  }
              },
              methods: {
                  closeDirect: function () {
                      this.showDirect = false;
                      var expires = new Date();
                      expires.setMonth(expires.getMonth() + 12);
                      document.cookie = 'resource_show_direct=1;expires=' + expires.toGMTString();
                      $("body").css("overflow","");
                  },
                  goToSee: function () {
                      this.closeDirect();
                      location.href = '/resource/list';
                  }
              }
          });
          common.init(isLogin);
        }
      }
});