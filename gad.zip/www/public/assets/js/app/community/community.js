define(['jquery', 'moment', 'imgzoomnew', 'imgzoom','common/vue-interceptor','common/vue-component/community'], function ($, moment, imgzoomnew) {
    /*
        @author: tinnocui
        @param:
            scrollTop 检测滚动条距离顶部的最小距离
            fixTop 悬浮的距离顶部的距离
            mainWidth 主页面最小宽度
            objgroup 悬浮对象组
            outHeight 消失高度，无则填任意负数
    */
    function autoFixTop(eles) {
		var toTop;
		var fixTop;
		if ((typeof eles.scrollTop) == "object") {
			toTop = eles.scrollTop.offset().top;
		} else {
			toTop = eles.scrollTop;
		}
		var winWidth = document.body.clientWidth;
		var winHeight = document.body.clientHeight;
		var mainWidth = eles.mainWidth;
		var elementH = 0; //对象高度
		var objgroup = eles.objgroup;
		objgroup.each(function() {
			var obj = $(this);
			//如对象的高度和悬浮的距离顶部的距离 大于 屏幕高度，则不作动态悬浮
			$(window).on("scroll", function() {
				if(eles.moving){
					fixTop = parseInt(obj.attr("data-fixTop"));
					toTop = parseInt(obj.attr("data-scrollTop"));
				}
				else{
					fixTop = eles.fixTop;
				}
				if (!((fixTop + obj.height()) <= winHeight && mainWidth <= winWidth)) {
					//console.log(fixTop + obj.height());
					obj.attr('style', '');
					return;
				}
				var top = $(this).scrollTop();
				var outHeight = typeof eles.outHeight === 'function' ? eles.outHeight() : eles.outHeight;
				if ((typeof eles.scrollTop) == "object") {
					toTop = eles.scrollTop.offset().top;
				}

				if (top > toTop) {
					obj.width(obj.width());
					objgroup.css("position", "fixed").css("top", fixTop);
				} else {
					objgroup.css("position", "static");
				}

				if (outHeight > 0) {
					if (top >= outHeight) {
						objgroup.hide();
					} else {
						objgroup.show();
					}
				}
			});
		});

	}

    /*
      过滤html标签，统计字数
     */
    function strip_tags(input, allowed) {
        allowed = (((allowed || '') + '').toLowerCase().match(/<[a-z][a-z0-9]*>/g) || []).join('')

        var tags = /<\/?([a-z][a-z0-9]*)\b[^>]*>/gi
        var commentsAndPhpTags = /<!--[\s\S]*?-->|<\?(?:php)?[\s\S]*?\?>/gi

        return input.replace(commentsAndPhpTags, '').replace(tags, function ($0, $1) {
            return allowed.indexOf('<' + $1.toLowerCase() + '>') > -1 ? $0 : ''
        })
    }

    return {
        autoFixTop: autoFixTop,
        strip_tags: strip_tags
    };
});
