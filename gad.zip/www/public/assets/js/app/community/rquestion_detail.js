define(['app/gad', 'jquery', 'message', 'tig-editor-v2', 'app/community/answer', 'vue', 'app/community/question', 'app/community/like',
  'app/community/share', 'app/community/relative_list','app/community/community', 'app/community/gallery/layoutrindex', 'autofixtop-v2'], 
    function(gad, $, Message, TIG, answer, Vue, question, like, share, relative_list, community, layout, Autofix){
      return {
        init: function (qdetail, order, controller, fid, islogin) {
          layout.init(islogin);
          Message.init();
          answer.init(qdetail.id, qdetail.comment_count, order, controller);
          question.init(qdetail.id,qdetail.title,qdetail.tag, qdetail.content,controller,qdetail.pid);
          relative_list.init(qdetail.id,true);

          new Vue({el:"#detailbox", data:{
              question_id:qdetail.id,
              question_id:qdetail.id,
              fav_id:fid,
              fav_count:qdetail.fav_count,
              fold_show: false,
          },methods: {
              updateCount: function (favCount,favId) {
                  this.fav_count = favCount;
                  this.fav_id = favId;
              }
          },ready: function(){
              if($(".ask-cont").height() > 100){
                  $("#js-line").removeClass("f-hide");
              }
              $(".btn-fold").click(function(){
                  $(this).removeClass("f-show");
                  $(".ask-cont").addClass("fixheight");
                  $(".btn-unfold").addClass("f-show");
              });
              $(".btn-unfold").click(function(){
                  $(this).removeClass("f-show");
                  $(".ask-cont").removeClass("fixheight");
                  $(".btn-fold").addClass("f-show");
              });
              if(window.location.hash == '#/edit') {
                  $('.ask-ucommpraise_update a').click();
              }
          }});
          //浮动
          var leftnav = Autofix.init({
              id:$("#left_floatitem"),//浮动元素
              scrollHeight:$('.js_leftparent'),//浮动元素非position父级
              mainWidth:1180,
              fixTop:30,
              fixLeft:'auto',
              outHeight:$('.js_relateparent')
          });
          var rightnav = Autofix.init({
              id:$("#right_floatitem"),//浮动元素
              scrollHeight:$('.js_rightparent'),//浮动元素非position父级
              mainWidth:1180,
              fixTop:30,
              fixRight:'auto',
              outHeight:$('.js_relateparent')
          });
          var related = Autofix.init({
              id:$("#relate_floatitem"),//浮动元素
              scrollHeight:$('.js_relateparent'),//浮动元素非position父级
              mainWidth:1180,
              fixTop:30,
              fixLeft:'auto'
          });
          $(window).on("scroll",function(){
              var top = $(this).scrollTop();
              if(top > 335){
                  $(".sticky").addClass("show-sticky");
                  Autofix.refresh(leftnav,{scrollHeight:335,fixTop:105});
                  Autofix.refresh(rightnav,{scrollHeight:335,fixTop:105});
                  Autofix.refresh(related,{fixTop:105});
              } else{
                  $(".sticky").removeClass("show-sticky");
                  Autofix.refresh(leftnav,{scrollHeight:119,fixTop:30});
                  Autofix.refresh(rightnav,{scrollHeight:119,fixTop:30});
                  Autofix.refresh(related,{fixTop:30});
              }
          });

          $(".ask-btnbox .m-btn-secondary").on("click", function() {
              $("#j-reportpop").hide();
          });
          $(".ask-btnbox .m-btn-primary, .sticky .m-btn-primary").on("click", function() {
              if($(this).hasClass("btnbox-ans-primary")) {
                  $(".replynewQuestion").toggle();
              } else {
                  $(".replynewQuestion").show();
                  window.location.hash = '#answer';
                  $("body").animate({scrollTop: $("#answer").offset().top - 88}, 500);
              }
          });

          $('.videoframe').each(function(){
              var src = unescape($(this).data('src'));
              var player = document.createElement('video');
              player.className = 'detail-video';
              player.controls = 'controls';
              var match = src.match(/video_id=([^&"]+)/);
              if(match && match[1]){
                  //player.poster = 'http://p.qpic.cn/wecam_pic/0/'+match[1]+'_1/0';
              }
              if(src){
                  if(src.indexOf('http://')==0){
                      player.src = src;
                  }else if(src.indexOf('https://')==0){
                      player.src = '';
                      player.rsrc = src;
                  }
              }
              $(this).replaceWith(player);
          });
        }
      }    
  });