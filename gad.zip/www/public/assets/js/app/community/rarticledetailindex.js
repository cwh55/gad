define(['vue', 'app/community/article_detail', 'app/community/like', 'app/community/share', 'app/community/comment', 'app/community/follow', 
    'app/community/relative_list', 'app/community/gallery/layoutrindex', 'app/community/community','app/preview_document'],
    function(Vue, article_detail, like, share, comment, follow, relative_list, layout){
    return {
        init: function (id, auth) {
            layout.init(auth);
            new Vue({el:"#likeandfav"});
            new Vue({el:"#j-sideLf"});
            new Vue({el:"#reply-list",
                events: {
                    'loadComplete': function(){
                        article_detail.init();
                    }
                }
            });
            new Vue({el:"#follow-div"});
            new Vue({el:'#previewDoc'});
            relative_list.init(id,false);
        }
    }  
});