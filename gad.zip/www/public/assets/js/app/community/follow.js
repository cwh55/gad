/**
 * Created by xiaolinwang on 17-5-6.
 *  <follow :follow-user="105" :is-followed="false"></follow>
 */
define(['vue','vue-resource','popup'],function(Vue,VueResource,popup){
    Vue.use(VueResource);
    Vue.component('follow',{
        template:'<span class="follow-btngroup">\
                  <button class="m-btn-primary follow-btn {{btnClass}} {{styleClass}}" @click="follow" type="button">{{btnText}}</button>\
                  </span>',
        props:['followUser','isFollowed', 'styleClass'],
        data:function(){
            return {
              btnClass:'',
              btnText:'关注',
              act:'follow',
              status:1
            };
        },
        ready:function(){
            if (this.isFollowed) {
                this.btnText = '已关注';
                this.btnClass = 'disabled';
                this.act = 'cancel';
            } else {
                this.btnText = '关注';
                this.btnClass = '';
                this.act = 'follow';
            }
        },
        methods:{
            follow:function(){
                if (this.status) {
                    this.status = 0;
                    this.$http.post('/follow/index',{
                        'followuser':this.followUser,
                        'act':this.act,
                        _token: $('[name="csrf-token"]').attr('content')
                    }).then(function(res){
                        if (res.data.code == 0) {
                            this.isFollowed = !this.isFollowed;
                            if (this.act == 'follow') {
                                this.act = 'cancel';
                                this.btnClass = 'disabled';
                                this.btnText = '已关注';
                            } else if (this.act == 'cancel') {
                                this.act = 'follow';
                                this.btnClass = '';
                                this.btnText = '关注';
                            }

                        } else {
                            if (res.data.code == -2) {
                                gad.login();
                            } else {
                                popup.showPopup('warn','提示',res.data.msg);
                            }
                        }
                        this.status = 1;
                    },function(res){
                        gad.login();
                    });
                }
            }
        }
    });


});