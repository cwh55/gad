define(['jquery', 'vue', 'app/community/community', 'popup'], function ($, Vue, community, popup) {
    Vue.component('v-captcha', {
        template: '<div class="m-verifycode m-mask js-m-verifycode" v-bind:class="{\'f-hide\':!captchaShow}">\
                    <div class="verifycode-wrap mask-inner">\
                        <div class="verifycode-head">验证码</div>\
                            <a class="verifycode-close" href="javascript:;" @click="cancel()"><i class="gicos-close-1"></i></a>\
                            <div class="verifycode-main">\
                                <div class="code-line">\
                                    <img class="codeimg" width="164" height="45" v-bind:src="src" alt="">\
                                    <a class="code-change" href="javascript:;" @click="changeCode()"><i class="gicos-change"></i></a>\
                                </div>\
                            <div class="code-input" v-bind:class="{\'show-error\':errText || errCaptchaShow}"><input class="verifycode-text" type="text" v-model="captcha" @focus="focus()" @keyup="focus()"><span class="status-suc gicos-suc-s"></span><span class="status-error" v-if="errText || errCaptchaShow">{{ errText ? errText : \'验证码输入有误，请重新输入\' }}</span></div>\
                            <div class="btn-line">\
                                <button class="m-btn-primary verifycode-btn" v-bind:class="{inactive:this.captcha.length == 0 || this.captcha.length > 6}" type="button" @click="save()">发表</button>\
                                <button class="m-btn-secondary verifycode-btn" type="button" @click="cancel()">取消</button>\
                            </div>\
                        </div>\
                    </div>\
                </div>',
        props: ['controller'],
        ready: function () {
        },
        data: function () {
            return {
                captchaShow: false,
                errCaptchaShow: false,
                src: '',
                captcha: '',
                errText: ''
            }
        },
        methods: {
            login: function () {
                gad.login();
            },
            focus: function () {
                if (this.captcha.length > 0) {
                    this.errText = '';
                }
            },
            cancel: function () {
                this.captchaShow = false;
            },
            changeCode: function () {
                var _that = this;
                _that.captcha = '';
                this.$http.get('/hatch_game/captcha-url', {}).then(function (data) {
                    if (data.data.code == 0) {
                        _that.src = data.data.data;
                    } else {
                        _that.errText = '请重新刷新验证码';
                    }
                });
            },
            save: function () {
                if (this.captcha.length == 0) {
                    this.errText = '请输入验证码';
                    return;
                }
                if (this.captcha.length > 6) {
                    this.captcha = '';
                    this.errText = '验证码长度不对';
                    return;
                }
                this.$emit('save', this.captcha);
            },
            showCode: function(captchaShow, errCaptchaShow){
                this.captchaShow = captchaShow;
                this.errCaptchaShow = errCaptchaShow;
                this.changeCode();
            }
        },
    });

    return {
    }
})
