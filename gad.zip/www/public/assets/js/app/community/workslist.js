define(['jquery', 'vue', 'vue-resource', 'app/community/community', 'app/community/like', 'app/community/comment', 'app/community/follow', 
    'app/community/workscomponents', 'app/community/components'], function ($, Vue, VueResource, community) {
    Vue.use(VueResource);

    return {
        init : function (ptag, ptype, psubtag, porder) {
            workslistvm = new Vue({
                el: '#app',
                ready: function () {
                    if (psubtag != 0) {
                        this.page += 1;
                    }
                    var _that = this;
                    //监听滚动操作，到底部时自动拉取数据。
                    $(document).scroll(function(){
                        if($(document).scrollTop()+$(window).height() > $(document).height() - 200){
                            _that.getWorksList();
                        }
                    });
                    //监听导师点评展开或者折叠
                    $('.js_optdown').click(function(){
                        $(this).parents('.js_commenttype').addClass('show-comment-detail');
                    });
                    $('.js_optup').click(function(){
                        $(this).parents('.js_commenttype').removeClass('show-comment-detail');
                    });
                    if($(".firstpage").length < this.pagesize){
                        this.status = 'nomore';
                        this.isEnd = true;
                    }
                    //为同屏出的第一页绑定图片点击事件
                    $(".js_liimg", $(".firstpage")).click(function(event){
                        _that.currentLiNo = $(this).data('liid');
                        _that.getPicDetail($(this).data('aid'), $(this).data('id'), true, true);
                        event.preventDefault();
                    });
                    //首屏点赞
                    $(".js_imglike", $(".firstpage")).click(function(event){
                        event.preventDefault();
                        event.stopPropagation();
                        var likeid = $(this).parents(".js_liimg").data('likeid');
                        var picid = $(this).parents(".js_liimg").data('id');
                        var likestatus = $(this).parents(".js_liimg").data('likestatus');
                        var likecount = $(this).siblings('.js_likecount').html();
                        var domitem = $(this);
                        if(_that.liking) return;
                        _that.liking = true;
                        var data = {};
                        data.model_type = 'Picture';
                        data.model_id = picid;
                        data._token = $('meta[name=csrf-token]').attr('content');
                        if (likeid != '0') {
                            data.status = likestatus == 'red' ? 0 : 1;
                            _that.$http.post('/nlike/edit/'+likeid, data).then(function(res){
                                var ret = res.data;
                                _that.liking = false;
                                if(ret.code == 0){
                                    if(likestatus == 'white'){
                                        domitem.parents(".js_liimg").data('likestatus', 'red');
                                        domitem.removeClass('cyico-like-s-white').addClass('cyico-like-s-red');
                                        if(likecount.match(/\d$/)){
                                            domitem.siblings('.js_likecount').html(parseInt(likecount)+1);
                                        }
                                    }else{
                                        domitem.parents(".js_liimg").data('likestatus', 'white');
                                        domitem.removeClass('cyico-like-s-red').addClass('cyico-like-s-white');
                                        if(likecount.match(/\d$/)){
                                            domitem.siblings('.js_likecount').html(parseInt(likecount)-1);
                                        }
                                    }
                                } else {
                                    popup.showPopup(1,'提示',data.message);
                                }
                            });
                        } else {
                            data.status = 1;
                            _that.$http.post('/nlike/create',data).then(function(res){
                                var ret = res.data;
                                _that.liking = false;
                                if(ret.code == 0){
                                    domitem.parents(".js_liimg").data('likestatus', 'red');
                                    domitem.removeClass('cyico-like-s-white').addClass('cyico-like-s-red');
                                    domitem.parents(".js_liimg").data('likeid', ret.data.id);
                                    if(likecount.match(/\d$/)){
                                        domitem.siblings('.js_likecount').html(parseInt(likecount)+1);
                                    }
                                } else {
                                    popup.showPopup(1,'提示',ret.message);
                                }
                            })
                        }
                    })
                },
                data: {
                    page: 1,
                    pagesize: 24,
                    lino: 0,         //计算插入节点的序号，用于左右切换图集判断
                    isEnd: false,   //是否还有图片
                    workslist1: [], //四列
                    workslist2: [],
                    workslist3: [],
                    workslist4: [],
                    workslist: [],  //服务器返回的作品list
                    itemCount: [],  //每次请求数据库后每列增加的图片数，辅助插入图片位置的计算，每次计算前清空。
                    isLoading: false,
                    liking: false,  //是否正在点赞
                    status: 'loading',
                    type: 2, //默认点评为2，佳作为1
                    order: 'hot',
                    host: location.href,
                    currentLiNo: 0,       //当前图集序号
                },
                computed: {
                    atlasEnd: function(){
                        return this.currentLiNo == $(".js_liimg").length-1;
                    },
                    pictureEnd: function(){
                        return this.atlas.pictures && (this.imgno == this.atlas.pictures.length-1);
                    }
                },
                methods: {
                    getWorksList:function(){
                        if(this.isEnd || this.isLoading){
                            return false;
                        }
                        this.isLoading = true;
                        this.status = 'loading';
                        var params = {};
                        params.page = this.page;
                        params.pagesize = this.pagesize;
                        params.order = porder;
                        params.type = ptype;
                        params.subtag = psubtag;
                        params.tag = ptag;
                        //params.tag = ptag;
                        this.$http.get('/gallery/list', {params: params}).then(function (res) {
                            var response = res.data;
                            setTimeout(function(){
                                workslistvm.isLoading = false;
                            },1000);
                            //this.isLoading = false;
                            this.status = '';
                            if(response.code == 0){
                                this.page++;
                                this.workslist = response.data;
                                if(this.workslist.length < this.pagesize){
                                    this.isEnd = true;
                                    this.status = 'nomore';
                                }
                                if(this.workslist.length){
                                    this.applyWorks();
                                }
                            }else{
                                popup.showPopup('warn','提示','数据拉取失败!');
                            }
                        });
                    },
                    judgePicType: function(url){
                        var patrn = /.gif/;
                        return url && patrn.test(url);
                    },
                    getMinHeightIndex: function(){
                        var min1 = $('.js_container1').height() + 200*this.itemCount[1];
                        var min2 = $('.js_container2').height() + 200*this.itemCount[2];
                        var min3 = $('.js_container3').height() + 200*this.itemCount[3];
                        var min4 = $('.js_container4').height() + 200*this.itemCount[4];
                        var arr = [min4, min1, min2, min3];
                        var minHeight = Math.min.apply(null, arr);
                        if(minHeight == min1) { return 1;}
                        if(minHeight == min2) { return 2;}
                        if(minHeight == min3) { return 3;}
                        if(minHeight == min4) { return 4;}
                        return 1;
                    },
                    applyWorks: function(){
                        this.itemCount = [0,0,0,0,0];
                        for (var i = 0; i < this.workslist.length; i++) {
                            this.workslist[i].lino = this.pagesize + this.lino;
                            this.lino++;
                            (function(x,_that){
                                setTimeout(function () {
                                    var index = _that.getMinHeightIndex();
                                    switch(index) {
                                        case 1:
                                            _that.workslist1.push(_that.workslist[x]);
                                            _that.itemCount[1]++;
                                            break;
                                        case 2:
                                            _that.workslist2.push(_that.workslist[x]);
                                            _that.itemCount[2]++;
                                            break;
                                        case 3:
                                            _that.workslist3.push(_that.workslist[x]);
                                            _that.itemCount[3]++;
                                            break;
                                        case 4:
                                            _that.workslist4.push(_that.workslist[x]);
                                            _that.itemCount[4]++;
                                            break;
                                        default:
                                    }
                                },x*10);
                            })(i,this);
                        }
                    },
                    changeType: function(type){
                        this.page = 0;
                        this.type = type;
                        this.clearContainers();
                        this.getWorksList();
                    },
                    changeOrder: function(order){
                        this.page = 0;
                        this.order = order;
                        this.clearContainers();
                        this.getWorksList();
                    },
                    changeUrl: function(url){
                        location.href = url;
                    },
                    clearContainers: function(){
                        $(".firstpage").remove();
                        this.workslist1= [];
                        this.workslist2= [];
                        this.workslist3= [];
                        this.workslist4= [];
                        this.isEnd = false;
                        this.isLoading = false;
                    },
                    getPicDetail: function(aid, id, historyflag, flowflag){
                        this.$broadcast('get-pic-detail', aid, id, historyflag, flowflag)
                    },
                    //切换图集
                    changeAtlas: function(direction){
                        if(direction){ //   后一个
                            if(this.currentLiNo >= $(".js_liimg").length-1){
                                return;
                            }
                            this.currentLiNo++;
                        }else{
                            if(this.currentLiNo <= 0){
                                return;
                            }
                            this.currentLiNo--;
                        }
                        var aid = $("#liimg"+this.currentLiNo).data('aid');
                        var id = $("#liimg"+this.currentLiNo).data('id');
                        this.getPicDetail(aid, id, true);
                    },
                    back: function(){
                        history.go(-1);
                    },
                    publish: function(){
                        window.location.href = "/gallery/edit";
                    }
                },
			    events: {
                    'picture-detail': function(liid){      //异步拉取图片点击事件在这里监听。
                        this.currentLiNo = liid;
                        var aid = $("#liimg"+liid).data('aid');
                        var id = $("#liimg"+liid).data('id');
                        this.getPicDetail(aid, id, true, true);
                    },
                    'change-altas': function (direction) {
                        this.changeAtlas(direction);
                    }
			    }
            });
        }
    }
});