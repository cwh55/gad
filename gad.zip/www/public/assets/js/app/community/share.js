/**
 * 使用样例
 * <share :share-style="'smallshare|bigshare|verticalshare' :url="url" :title="标题" :qrcode="二维码地址" :desc="描述"></share>
 *  smallshare:水平小弹窗样式;smallshare:水平大分享;verticalshare:垂直分享;
 */
define(['vue'],function(Vue){
    Vue.component('small-share',{
        template:'<div class="m-share ex-share-stylespop">\
                    <a class="share-tit" href="javascript:;" @mouseenter="init">分享</a>\
                    <div class="share-main">\
                        <div class="share-totext">分享到</div>\
                        <ul class="share-channel">\
                            <li class="channel-item channel-item-wx">\
                                <a class="share-ico-wechat-s"></a>\
                                <div class="channel-qrcode">\
                                    <img class="qrcode-img" :src="weixinUrl" width="76" height="76">\
                                    </div>\
                                </li>\
                                <li class="channel-item">\
                                    <a class="share-ico-qzone-s" target="_blank" :href="qzoneUrl"></a>\
                                </li>\
                                <li class="channel-item">\
                                    <a class="share-ico-weibo-s" target="_blank" :href="weiboUrl"></a>\
                                </li>\
                            </ul>\
                    </div>\
                </div>',
        props:['qrcode','qzoneUrl','weiboUrl'],
        data:function(){
            return {
                weixinUrl:''
            }
        },
        methods:{
            init:function(){
                if (this.weixinUrl == '') {
                    this.weixinUrl = this.qrcode;
                }
            }
        }
    });
    Vue.component('big-share',{
        template:'<div class="m-share ex-share-stylelh" :class="classname">\
                    <div class="share-main">\
                    <div class="share-totext">分享到</div>\
                    <ul class="share-channel">\
                    <li class="channel-item channel-item-wx">\
                        <a class="share-ico-wechat"></a>\
                        <div class="channel-qrcode">\
                            <img class="qrcode-img" :src="qrcode" width="76" height="76">\
                            </div>\
                        </li>\
                        <li class="channel-item">\
                            <a class="share-ico-qzone" target="_blank" :href="qzoneUrl"></a>\
                        </li>\
                        <li class="channel-item">\
                            <a class="share-ico-weibo" target="_blank" :href="weiboUrl"></a>\
                        </li>\
                    </ul>\
                    </div>\
                </div>',
        props:['qrcode','qzoneUrl','weiboUrl','classname']
    });
    Vue.component('vertical-share',{
        template:'<div class="m-share ex-share-stylelv">\
                    <div class="share-main">\
                    <div class="share-totext">分享到</div>\
                    <ul class="share-channel">\
                    <li class="channel-item channel-item-wx">\
                        <a class="share-ico-wechat"></a>\
                        <div class="channel-qrcode">\
                            <img class="qrcode-img" :src="qrcode" width="76" height="76">\
                            </div>\
                        </li>\
                        <li class="channel-item">\
                            <a class="share-ico-qzone" target="_blank" :href="qzoneUrl"></a>\
                        </li>\
                        <li class="channel-item">\
                            <a class="share-ico-weibo" target="_blank" :href="weiboUrl"></a>\
                        </li>\
                    </ul>\
                    </div>\
                </div>',
        props:['qrcode','qzoneUrl','weiboUrl']
    });
    Vue.component('share',{
        template:'<small-share :qrcode="qrcodeUrl" :qzone-url="qzoneUrl" :weibo-url="weiboUrl"  v-if="shareStyle == \'smallshare\'" ></small-share>\
                  <big-share :qrcode="qrcodeUrl" :qzone-url="qzoneUrl" :weibo-url="weiboUrl" :classname="classname" v-if="shareStyle == \'bigshare\'"></big-share>\
                  <vertical-share :qrcode="qrcodeUrl" :qzone-url="qzoneUrl" :weibo-url="weiboUrl" v-if="shareStyle == \'verticalshare\'"></vertical-share>\
                  ',
        props:['title','desc','url','shareStyle','qrcode','classname'],
        data:function(){
            return {
                qzoneUrl:'',
                weiboUrl:'',
                qrcodeUrl:''

            }
        },
        computed:{
            qzoneUrl:function(){
                return 'https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url='+this.url+'&desc='+this.desc+'&title='+this.title+'&site=腾讯游戏开发者平台&summary='+this.desc;
            },
            qrcodeUrl:function(){
                return '/qrcode/index?url='+encodeURI(this.qrcode);
            },
            weiboUrl:function(){
                return 'http://service.weibo.com/share/share.php?appkey=1793213633&title='+this.title+'&url='+this.url+'&language=zh_cn';
            }
        }

    });

});