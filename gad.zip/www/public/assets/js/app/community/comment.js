/**
 * Created by xiaolinwang on 17-4-26.
 * <comment-list :obj-id="1" :obj-type="'App\Entities\Archive'" :is-login="{{Auth::check()}}" :avatar="'{{Auth::check()?Auth::user()->getAvatar():''}}'">
 *    </comment-list>
 */
define(['jquery','vue','vue-resource','popup','moment', 'app/community/community','pan_upload', 'app/community/captcha'],function($,Vue,VueResource,popup,moment){
    Vue.use(VueResource);
    Vue.filter('time-format', function (value) {
        var time = moment(value, "YYYY-MM-DD hh:mm:ss").unix();
        var passhours = (new Date().getTime()/1000 - time)/60/60;
        if (passhours > 24) {
            return value.substring(0, 10);
        }else if (1 < passhours && passhours < 24) {
            return parseInt(passhours) + "小时前";
        }else if (parseInt(passhours * 60)) {
            return parseInt(passhours * 60) + "分钟前";
        }else {
            return "刚刚";
        }
        return value;
    });
    Vue.filter('toHtml', function (value) {
        var tmp = value.replace(/\n/g,'<br>');
        return tmp.replace(/ /g,'&nbsp;');
    });
    Vue.filter('num-format', function (value) {
        if (typeof value === 'number') {
            if (value <= 999) {
                return value;
            }
            if (value < 10000) {
                if (value > 9950) {
                    return '1w';
                } else {
                    var tmp = (value / 1000 ).toFixed(1);
                    var fl = tmp.substr(2, 1);
                    if (fl == 0) {
                        return tmp.substr(0, 1) + 'k';
                    } else {
                        return tmp.substr(0, 3) + 'k';
                    }
                }
            }
            if (value >= 10000) {
                var tmp = (value/10000).toFixed(1);
                var index = tmp.indexOf('.');
                var fl = tmp.substr(index+1,1);
                if (fl == 0) {
                    return tmp.substr(0,index) + 'w';
                } else {
                    return tmp.substr(0,index) + tmp.substr(index,2) + 'w';
                }
            }
        }
        return value;
    });
    Vue.component('get-more-comment',{
        template:'<div class="m-dlmore {{showClass}}">\
                    <a class="dlmore-btn" href="javascript:;" @click="getMoreComment">加载更多</a>\
                        <span class="dlmore-loading gico-loading loading-20">加载中...</span>\
                    <span class="dlmore-nomore">没有更多消息了...</span>\
                  </div>',
        props:['showClass'],
        methods:{
            getMoreComment:function(){
                this.$dispatch('getMoreComment');
            }

        }
    });
    //获取更多二级评论
    Vue.component('get-more-reply', {
        template:'<div class="m-dlmore {{comment.loadClass}}">\
                     <a class="dlmore-btnsec" href="javascript:;" @click="getMoreReply(comment)">查看更多回复<span class="dlmore-ico gicos-arrow-down"></span></a>\
                        <span class="dlmore-loading gico-loading loading-20">加载中...</span>\
                  </div>',
        props:['comment'],
        methods:{
            getMoreReply:function(comment){
                this.$dispatch('getMoreReply',comment);
            }
        }
    });
    //上传图片
    Vue.component('pic-upload', {
        template:   '<div class="picup {{isShow?\'\':\'f-hide\'}}">\
                        <div class="picup-ico"><i class="gicos-pic"><!--上传图标--></i></div>\
                            <div class="picup-layer">\
                                <div class="picup-tips">本地上传</div>\
                                <div class="edmedia {{showClass}}">\
                                    <label class="default" for="js_picupload{{objId}}">\
                                        <span class="default-ico"><i class="gicos-photo"><!--照片--></i></span>\
                                        <span class="default-txt">添加点评图片</span>\
                                        <input id="js_picupload{{objId}}" class="f-hide" accept="image/jpg,image/png,image/gif" type="file">\
                                    </label>\
                                    <div class="updateload">\
                                        <div class="updateload-process"><span class="process-inner" style="width:10%"><!--进度条--></span></div>\
                                        <div class="updateload-txt">上传中<span class="updateload-ico"><span class="gicos-del-2" @click="delPic"><!--删除--></span></span></div>\
                                    </div>\
                                    <div class="errortips">\
                                        <div class="errortips-txt"><span class="errortips-ico cyico-error"><!--错误图标--></span>上传失败</div>\
                                        <div class="btngroup">\
                                            <button class="m-btn-primary m-btn-small reup-btn" type="button">重新上传</button>\
                                            <button class="m-btn-secondary m-btn-small reup-btn" type="button">取消</button>\
                                        </div>\
                                    </div>\
                                    <div class="upldone">\
                                        <div class="upldone-pic"><img width="190" height="117" :src="image" alt=""></div>\
                                        <div class="upldone-mask m-mask">\
                                            <div class="operatools mask-inner">\
                                                <span class="gicos-del" @click="delPic"><!--删除--></span>\
                                                <span class="gicos-edit" @click="editPic"><!--编辑--></span>\
                                            </div>\
                                        </div>\
                                    </div>\
                                </div>\
                            </div>\
                        </div>\
                    </div>',
        props: ['isShow', 'objId', 'image'],
        data: function () {
            return {
                showClass: "show-edmedia-default",
                view_upload: {percent:0}
            };
        },
        ready: function () {
            if (this.image) {
                this.showClass = "show-edmedia-upldone";
            }
            var _that = this;
            $("#js_picupload"+this.objId).pan_upload_raw({
                multipart_params: {csrf: $('meta[name="csrf-token"]').attr('content')}, max_file_count: 1, multi_selection: false, flash_swf_url: '/assets/js/Moxie.swf',
                filters: {max_file_size: '10mb', mime_types: [{title: "图片", extensions: "jpg,png"}]},
                events: {
                    Init: function(up) {
                        _that.view_upload.uploader = up;
                    }, 
                    FilesAdded: function (up, files) {
                        _that.showClass = "show-edmedia-updateload";
                        _that.view_upload.percent = 0;
                        _that.view_upload.uploading = true;
                        _that.view_upload.id = files[0].id;
                        _that.view_upload.name = files[0].name;
                        if (!window.FileReader && files[0].size > 2 * 1024 * 1024) {
                            popup.showPopup('warn','提示','您的浏览器可能无法完成超过2M的文件上传，建议更换Chrome等现代浏览器完成大文件的上传哈');
                        }
                        up.disableBrowse(true);
                    }, 
                    UploadProgress: function (up, file) {
                        _that.view_upload.percent = file.percent;
                    },
                    FileUploaded: function (up, file, info) {
                        try {
                            up.disableBrowse (false);
                            _that.view_upload.uploading = false;
                            var data = JSON.parse(info.response);
                            if(!data.success) {
                                popup.showPopup('warn','提示',"上传失败");
                            } else {
                                _that.showClass = "show-edmedia-upldone";
                                _that.image = data.image_url;
                            }
                        } catch (e) {
                            popup.showPopup('warn','提示',"上传失败");
                        }
                    },
                    Error: function(up, error) {
                        _that.view_upload.uploading = false;
                        _that.showClass = "show-edmedia-default";
                        up.files.length && popup.showPopup('warn','提示',error.message);
                    }
                }
            });
        },
        methods: {
            delPic: function() {
                this.image = "";
                this.showClass = "show-edmedia-default";
            },
            editPic: function () {
                $("#js_picupload"+this.objId).trigger('click');
            }
        },
        events:{
            'addSuccess': function () {
                this.image = "";
                this.showClass = "show-edmedia-default";
            }
        }
    })
    //一级评论添加、编辑共用
    Vue.component('edit',{
        template:'<div class="info-text replynew {{showClass}}">\
                    <div class="commit-userinput">\
                    <div class="replynew-area {{textClass}}" >\
                    <span v-if="showLoginTips" class="replynew-notlogged">赶快<a class="commit-link" href="javascript:;" @click="login">登录</a>发表评论吧</span>\
                     <textarea class="replynew-textarea g-scrollbar" @focus="focus" @blur="blur" placeholder="{{editTips}}" v-model="content"></textarea>\
                    <button class="replynew-btn-reply m-btn-primary m-btn-small inactive" @click="save" type="button">{{btnText}}</button>\
                    </div>\
                    <pic-upload :is-show="needPic&isLogin" :obj-id="objId" :image.sync="image"></pic-upload>\
                </div>\
                <v-captcha v-ref:captcha v-on:save="save2"></v-captcha>',
        props:['content','callBack','editTips','btnText','showClass','showLoginTips','isLogin', 'needPic', 'objId', 'image'],
        data:function(){
            return {
                publishStatus:true,
                textClass:'',
            }
        },
        ready:function(){
            if (this.isMultiLine() || this.charLen()>60) {
                this.textClass='status-morecol';
            } else {
                this.textClass='';
            }
        },
        watch:{
            content:function(){
                if (this.content!='') {
                    this.showClass = 'show-replynew-apply';
                } else {
                    this.showClass = "show-replynew-inputonly";
                }

                if (this.isMultiLine() || this.charLen()>60) {
                    this.textClass='status-morecol';
                } else {
                    this.textClass='';
                }
            }
        },
        methods:{
            login:function(){
                gad.login();
            },
            charLen:function(){
                var l = this.content.length;
                var blen = 0;
                for(var i=0; i<l; i++) {
                    if ((this.content.charCodeAt(i) & 0xff00) != 0) {
                        blen ++;
                    }
                    blen ++;
                }
                return blen;
            },
            focus:function(){
                if (!this.isLogin) {
                    gad.login();
                    return;
                }
                if (this.isMultiLine() || this.charLen()>60) {
                    this.textClass='status-morecol';
                } else {
                    this.textClass='';
                }
            },
            blur:function(){
                   var _this = this;
                   setTimeout(function(){
                       if (_this.isMultiLine()|| _this.charLen()>60) {
                       _this.textClass="status-morecol focus-out";
                       } else {
                           this.textClass='';
                       }

                   },200)

            },
            isMultiLine:function(){
                if (this.content.match('\n') !=null) {
                    return true;
                } else {
                    return false;
                }
            },
            save:function(){
                this.$dispatch(this.callBack,this.content, this.image, '');
                this.focus();
            },
            save2: function(code){
                this.$dispatch(this.callBack,this.content, this.image, code);
                this.focus();
            }
        },
        events: {   //验证码
            'popCode': function () {
                this.$refs.captcha.showCode(true, false);
            },
            'errorCode': function () {
                this.$refs.captcha.showCode(true, true);
            },
            'clearContent': function () {
                this.content = '';
                this.$refs.captcha.showCode(false, false);
            }
        }
    });
    //编辑评论
    Vue.component('edit-comment',{
        template:'<edit :call-back="callBack" :edit-tips="editTips" :btn-text="btnText" :need-pic="needPic" :obj-id="objId" :content="content" :image="comment.image" :show-class="showClass" :is-login="isLogin"></edit>',
        props:['comment','content','objId','objType','isLogin', 'needPic'],
        data:function(){
            return {
                callBack:'modifyComment',
                publishStatus:true,
                btnText:'评论',
                showClass:'show-replynew-apply',
                editType:'modifyComment'
            }
        },
        methods:{
            modifyComment:function(content, image){
                if (content == '' || content.trim('\n') == '') {
                    popup.showPopup('warn','提示','请填写评论!');
                    return;
                }
                if (this.publishStatus) {
                    this.publishStatus = false;
                    this.btnText = '发表中...';
                    var params = {
                        id:this.objId,
                        comment:content,
                        image: image,
                        _token: $('[name="csrf-token"]').attr('content')
                    };
                    this.$http.post('/ncomment/edit', params)
                        .then(function(res){
                            if (res.data.code == 0) {
                                this.comment.showModifyComment =false;
                                this.comment.comment = content;
                                this.comment.editComment = content;
                                this.comment.image = image;
                                this.content ='';
                            } else {
                                this.content=content;
                                popup.showPopup('warn','提示',res.data.msg);
                            }
                            this.publishStatus = true;
                            this.btnText = '评论';
                        },function(res){
                            this.content=content;
                            this.publishStatus = true;
                            this.btnText = '评论';
                            popup.showPopup('warn','提示',res.data.msg);
                        });
                }
            }
        },
        events:{
            'modifyComment':function(content, image){
                this.modifyComment(content, image);
            }
        }
    });

    //添加一级评论
    Vue.component('add-comment',{
        template:'<div class="replynew {{showClass}}">\
                        <div class="commit-user g-badge">\
                            <img class="commit-headpic f-circle" width="40" height="40" :src="avatar">\
                            <i v-if="userType == 1" class="gicos-bluev-shadow-s"></i>\
                            <i v-if="userType == 2" class="gicos-redv-shadow-s"></i>\
                        </div>\
                        <edit :call-back="callBack"\
                         :edit-tips="editTips" \
                         :btn-text="btnText" \
                         :content="content"\
                         :show-login-tips="showLoginTips"\
                         :is-login="isLogin"\
                         :need-pic="needPic"\
                         :obj-id="0"\
                         </edit>\
                   </div>',
        props:['objId','objType','avatar','userType','isLogin', 'needPic'],
        data:function() {
            return {
                showClass:'',
                publishStatus:true,
                btnText:'评论',
                editTips:'发表评论',
                callBack:'addComment',
                showLoginTips:true,
                content:''
            }
        },
        ready:function(){
            if (this.isLogin) {
                this.showClass = "show-replynew-inputonly";
            }
        },
        methods:{
            addComment:function(content, image, code){
                if (content == '' || content.trim('\n') == '') {
                    popup.showPopup('warn','提示','请填写评论!');
                    return;
                }
                if (this.publishStatus) {
                    this.publishStatus = false;
                    this.btnText = '发表中...';
                    var params = {
                        objid:this.objId,
                        objtype:this.objType,
                        comment:content,
                        image: image,
                        _token: $('[name="csrf-token"]').attr('content')
                    }
                    if (code) {
                        params.captcha = code;
                    }
                    this.$http.post('/ncomment/add', params)
                        .then(function(res){
                            if (res.data.code == 0) {
                                var comment = res.data.comment;
                                comment.showModifyComment =false;
                                comment.showReply = false;
                                comment.loadClass = '';
                                comment.editComment =comment.comment;
                                comment.newReplyContent = '';
                                comment.replyTips = comment.comment_count;
                                comment.replyList = [];
                                comment.replyPage = 0;
                                comment.isAllowUpdate = true;
                                comment.liked = false;
                                this.$dispatch('newComment',res.data.comment);
                                this.$broadcast('addSuccess');
                                this.$broadcast('clearContent');
                            } else if (res.data.code == 10001) {//需要弹验证码
                                this.$broadcast('popCode');
                            } else if (res.data.code == 10002) {//验证码错误
                                this.$broadcast('errorCode');
                            } else {
                                this.content=content;
                                popup.showPopup('warn','提示',res.data.msg);
                            }
                            this.publishStatus = true;
                            this.btnText = '评论';
                        },function(res){
                            this.content=content;
                            this.publishStatus = true;
                            this.btnText = '评论';
                            popup.showPopup('warn','提示',res.data.msg);
                        });
                }
            }
        },
        events:{
            'addComment':function(content, image, code){
                this.addComment(content, image, code);
            },
            'randomTips':function(count){
                if (count == 0) {
                    this.editTips = '快来抢沙发...';
                } else {
                    var tips = ['点赞都是套路，评论才叫真诚','知音难觅聊一句','据说评论才是发表文章的最大动力'];
                    var index = parseInt(Math.random()*10 % 3);
                    this.editTips = tips[index];
                }
            }
        }
    });

    //添加二级评论
    Vue.component('reply-to',{
        template:'<edit :call-back="callBack"\
                     :edit-tips="editTips"\
                     :btn-text="btnText" \
                     :content="content"\
                     :is-login="isLogin"\
                   </edit>',
        props:['objId','atUser','isLogin','atName','comment','index','reply'],
        data:function(){
            return {
                publishStatus:true,
                btnText:'回复',
                editTips:'回复'+this.atName,
                callBack:'replyTo',
                objType:'App\\Entities\\Comment',
                content:''
            }
        },
        methods:{
            replyTo:function(content, code){
                if (content == '' || content.trim('\n') == '') {
                    popup.showPopup('warn','提示','请填写评论!');
                    return;
                }
                if (this.publishStatus) {
                    this.publishStatus = false;
                    this.btnText = '发表中...';
                    var params = {
                        objid:this.objId,
                        objtype:this.objType,
                        comment:content,
                        atuser:this.atUser,
                        atname:this.atName,
                        _token: $('[name="csrf-token"]').attr('content')
                    };
                    if (code) {
                        params.captcha = code;
                    }
                    this.$http.post('/ncomment/add',params)
                        .then(function(res){
                            if (res.data.code == 0) {
                                res.data.comment.isAllowUpdate = true;
                                res.data.comment.liked = false;
                                res.data.comment.showReplyTo = false;
                                this.comment.subcomments.push(res.data.comment);
                                this.comment.comment_count +=1;
                                //全部展开并滚动
                                this.comment.showReplyNum = this.comment.comment_count;
                                this.comment.loadClass = "dl-nomore";
                                var oldh = $(".js_replylist" + this.comment.id).height();
                                var that = this;
                                setTimeout(function () {
                                    var newh = $(".js_replylist" + that.comment.id).height();
                                    $(window).scrollTop($(window).scrollTop() + newh - oldh);
                                })
                                this.content ='';
                                if (this.reply) {
                                    this.reply.showReplyTo = false;
                                }
                                this.$broadcast('clearContent');
                            } else if (res.data.code == 10001) {//需要弹验证码
                                this.$broadcast('popCode');
                            } else if (res.data.code == 10002) {//验证码错误
                                this.$broadcast('errorCode');
                            } else {
                                this.content=content;
                                popup.showPopup('warn','提示',res.data.msg);
                            }
                            this.publishStatus = true;
                            this.btnText = '回复';
                        },function(res){
                            this.content=content;
                            this.publishStatus = true;
                            this.btnText = '回复';
                            popup.showPopup('warn','提示','保存失败');
                        });
                }
            }
        },
        events:{
            'replyTo':function(content, image, code){
                this.replyTo(content, code);
            }
        }

    });
    
    //每个评论的二级评论
    Vue.component('reply',{
        template:'<div class="replylist js_replylist{{comment.id}}" v-show="showreply">\
                    <div class="replylist-tit"><em class="sumnum">{{comment.comment_count|num-format}}</em>回复</div>\
                    <ul class="replylist-main">\
                    <li class="replylist-item">\
                        <div class="replynew">\
                            <div class="commit-user g-badge">\
                            <img class="commit-headpic f-circle" width="24" height="24" :src="avatar">\
                            <i v-if="comment.user.type == 1" class="gicos-bluev-shadow-s"></i>\
                            <i v-if="comment.user.type == 2" class="gicos-redv-shadow-s"></i>\
                            </div>\
                            <reply-to :index="0" :is-login="isLogin" :comment="comment"  :obj-id="comment.id" :at-user="comment.user_id" :at-name="comment.user_name"></reply-to>\
                        </div>\
                    </li>\
                    <li class="replylist-item" v-for="(rindex, reply) in replyList" v-show="rindex < comment.showReplyNum">\
                            <a class="commit-user  g-badge" href="http://gad.qq.com/user?id={{reply.user_id}}" target="_blank">\
                                <img class="commit-headpic f-circle" :src="reply.avatar" width="24" height="24">\
                                <i v-if="reply.user.type == 1" class="gicos-bluev-shadow-s"></i>\
                                <i v-if="reply.user.type == 2" class="gicos-redv-shadow-s"></i>\
                            </a>\
                            <div class="item-info">\
                                <div class="info-data">\
                                    <a class="data-name" href="javascript:;" title="{{reply.user_name}}">{{reply.user_name}}</a>\
                                    <span class="data-s" v-if="comment.user_name!=reply.at_name">回复</span>\
                                    <span class="data-name" v-if="comment.user_name!=reply.at_name">{{reply.at_name}}</span>\
                                    <span class="data-time">{{reply.created_at|time-format}}</span>\
                                </div>\
                                <p class="info-text">{{{reply.comment|toHtml}}}</p>\
                                <div class="ucommpraise">\
                                    <a class="ucommpraise-item" @click="replyTo(reply)">\
                                        <i class="ucommpraise-ico cyico-commt-s-gray"></i>\
                                        <span class="item-txt">{{reply.comment_count|num-format}}</span>\
                                    </a>\
                                    <a class="ucommpraise-item" @click="like(reply)">\
                                        <i class="ucommpraise-ico cyico-like-s-{{reply.liked ? \'red\':\'gray\'}}"></i>\
                                        <span class="item-txt">{{reply.like_count|num-format}}</span>\
                                    </a>\
                                    <a class="ucommpraise-item" v-if="reply.isAllowUpdate" @click="delReply(reply)">\
                                            <i class="ucommpraise-ico cyico-del-s"></i>\
                                        <span class="item-txt">删除</span>\
                                    </a>\
                                </div>\
                                <reply-to v-if="reply.showReplyTo" :is-login="isLogin" :reply="reply" :comment="comment" :index="rindex+1" :obj-id="comment.id" :at-user="reply.user_id" :at-name="reply.user_name" ></reply-to>\
                            </div>\
                        </li>\
                        </ul>\
                        <get-more-reply :comment="comment" ></get-more-reply>\
                    </div>',
        props:['avatar','comment','replyList','isLogin','showreply'],
        methods:{
            replyTo :function(reply){
                if (typeof(reply.showReplyTo) == "undefined") {
                    Vue.set(reply, 'showReplyTo', true);
                } else {
                    reply.showReplyTo = !reply.showReplyTo;
                }
            },
            delReply :function(reply){
                var _this = this;
                popup.showPopup('warn','提示','确认删除评论？',function(){
                    _this.$http.post('/ncomment/del/'+reply.id,{_token: $('[name="csrf-token"]').attr('content')})
                        .then(function(res){
                            if (res.data.code == 0) {
                                _this.replyList.$remove(reply);
                                _this.comment.comment_count -=1;
                                _this.$dispatch('delReply');
                            }
                            else {
                                popup.showPopup('warn','提示',res.data.msg);
                            }
                        },function(res){
                            popup.showPopup('warn','提示',res.data.msg);
                        });
                });
            },
            like:function(reply){
                var data = {};
                data.model_type = 'Comment';
                data.model_id = reply.id;
                data._token = $('meta[name=csrf-token]').attr('content');
                data.status = 1 == reply.liked ? 0 : 1;
                data._token = $('[name="csrf-token"]').attr('content');
                this.$http.post('/nlike/create',data)
                    .then(function(response){
                        if (response.data.code == 0) {
                            reply.liked = !reply.liked;
                            if(reply.liked){
                                reply.like_count +=1;
                            }
                            else {
                                reply.like_count -=1;
                            }
                        }
                    });
            }
        }
    });
    //一级评论列表
    Vue.component('comment',{
        template:'<ul class="commit-list">\
                    <li class="commit-item" v-for="comment in comments">\
                    <div class="item-side">\
                    <a class="commit-user g-badge" href="http://gad.qq.com/user?id={{comment.user_id}}" target="_blank">\
                        <img class="commit-headpic f-circle" :src="comment.avatar" width="40" height="40">\
                        <i v-if="comment.user.type == 1" class="gicos-bluev-shadow-s"></i>\
                        <i v-if="comment.user.type == 2" class="gicos-redv-shadow-s"></i>\
                    </a>\
                    </div>\
                    <div class="item-info">\
                    <div class="info-data">\
                        <a class="data-name" href="http://gad.qq.com/user?id={{comment.user_id}}" :title="comment.name">{{comment.user_name}}</a>\
                        <span class="data-time">{{comment.created_at|time-format}}</span>\
                        <span class="data-floor">{{commentCount-$index}}楼</span>\
						<div class="taglist">\
							<i class="gicos-lighttag dp-tag" v-if="isDianPing == 2 && comment.user.TutorStatus == 2">专家点评</i>\
						</div>\
                    </div>\
                    <p class="info-text g-imgpreview" v-show="!comment.showModifyComment">{{{comment.comment|toHtml}}}\
                    <scalable-img :imgsrc="comment.image" :oid="comment.id" v-if="comment.image"></scalable-img></p>\
                    <edit-comment :content="comment.editComment" :comment="comment" :need-pic="needPic" :is-login="isLogin" :obj-id="comment.id" v-if="comment.showModifyComment" ></edit-comment>\
                    <div class="ucommpraise">\
                        <a class="ucommpraise-item" @click="reply(comment)">\
                            <i class="ucommpraise-ico cyico-commt-s-gray"></i>\
                            <span class="item-txt">{{comment.replyTips|num-format}}</span>\
                        </a>\
                        <a class="ucommpraise-item" @click="like(comment)">\
                            <i class="ucommpraise-ico cyico-like-s-{{comment.liked ?\'red\':\'gray\'}}"></i>\
                            <span class="item-txt">{{comment.like_count|num-format}}</span>\
                        </a>\
                        <a class="ucommpraise-item" v-if="comment.isAllowUpdate" @click="delComment(comment)">\
                        <i class="ucommpraise-ico cyico-del-s"></i>\
                        <span class="item-txt">删除</span>\
                        </a>\
                        <a class="ucommpraise-item" v-if="comment.isAllowUpdate" @click="modifyComment(comment)">\
                        <i class="ucommpraise-ico cyico-edit-s"></i>\
                        <span class="item-txt">修改</span>\
                        </a>\
                    </div>\
                    <reply :reply-list="comment.subcomments" :is-login="isLogin" :avatar="avatar" :showreply="comment.showReply" :comment="comment" ></reply>\
                    </div>\
                    </li>\
                </ul>',
        props:['objId','objType','avatar','comments','isLogin','commentCount','isDianPing', 'needPic'],
        data:function(){
            return {
                replyPageSize:10
            }
        },
        methods:{
            login:function(){
                if(!this.isLogin) {
                    gad.login();
                    return;
                }
            },
            saveComment:function(comment){
                if (!this.isLogin) {
                    gad.login();
                    return ;
                }
                var html = comment.editComment;
                this.$http.post('/comment/edit/',{
                    id:comment.id,
                    comment:html,
                    _token: $('[name="csrf-token"]').attr('content')
                })
                    .then(function(response){
                        if (response.data.code == 0) {
                            comment.comment = html;
                            this.cancelComment(comment);
                        }

                    })
            },
            cancelComment:function(comment){
                comment.showModifyComment = false;
                comment.editComment = comment.comment;
            },
            delComment:function(comment){
                if (!this.isLogin) {
                    gad.login();
                    return ;
                }
                var _this=this;
                popup.showPopup('warn','提示','确认删除评论？',function(){
                    _this.$http.post('/ncomment/del/'+comment.id,{_token: $('[name="csrf-token"]').attr('content')})
                        .then(function(response){
                            if (response.data.code == 0) {
                                _this.comments.$remove(comment);
                                _this.$dispatch('delComment');
                            }
                            else {
                                popup.showPopup('warn','提示',response.data.msg);
                            }
                        },function(res){
                            popup.showPopup('warn','提示',res.data.msg);
                        });
                });
            },
            modifyComment:function(comment){
                if (!this.isLogin) {
                    gad.login();
                    return ;
                }
                comment.showModifyComment = !comment.showModifyComment;
            },
            like:function(comment){
                if (!this.isLogin) {
                    gad.login();
                    return ;
                }
                var data = {};
                data.model_type = 'Comment';
                data.model_id = comment.id;
                data._token = $('meta[name=csrf-token]').attr('content');
                data.status = 1 == comment.liked ? 0 : 1;
                data._token = $('[name="csrf-token"]').attr('content');
                this.$http.post('/nlike/create',data)
                    .then(function(response){
                        if (response.data.code == 0) {
                            comment.liked = !comment.liked;
                            if(comment.liked){
                                comment.like_count +=1;
                            }
                            else {
                                comment.like_count -=1;
                            }
                        }
                    });
            },
            reply:function(comment){
                    if (comment.replyTips == comment.comment_count) {
                        comment.showReply = true;
                        comment.replyTips = '收起回复';
                    } else {
                        comment.showReply = false;
                        comment.replyTips = comment.comment_count;
                    }
            },
            getReplyList: function (comment) {
                if (comment.showReplyNum + 10 < comment.comment_count) {
                    comment.showReplyNum += 10;
                } else {
                    comment.showReplyNum = comment.comment_count;
                    comment.loadClass = "dl-nomore";
                }
                
            }
        },
        events:{
            'getMoreReply':function(comment){
                this.getReplyList(comment);
            }
        }
    });
    //最外层组件
    Vue.component("comment-list",{
        template:'\
            <div class="m-commit">\
            <div class="commit-head">\
            <div class="commit-tit"><em class="sumnum">{{commentCount|num-format}}</em>评论</div>\
            <add-comment :is-login="isLogin" :need-pic="needPic" :obj-id="objId" :obj-type="objType" :avatar="avatar" :user-type="userType"></add-comment>\
            </div>\
            <div class="commit-main">\
            <comment :is-login="isLogin" :comments="comments" :is-dian-ping="isDianPing" :need-pic="needPic" :comment-count="commentCount" :obj-id="objId" :obj-type="objType" :avatar="avatar" ></comment>\
            <get-more-comment :show-class="showClass"></get-more-comment>\
            </div>\
            </div>',
        props:['objId','objType','avatar','userType','isLogin','isDianPing', 'needPic'],
        data:function(){
            return {
                page:0,
                pageSize:10,
                commentCount:0,
                comments:[],
                showClass:'dl-loading'
            }
        },
        ready:function(){
            if (!this.isLogin) {
                this.avatar = 'http://gad.qpic.cn/assets/v2/web/img/global/default_headpic.jpg';
            }

            this.getCommentList();
        },
        watch:{
            objId:function(){
                this.page = 0;
                this.commentCount = 0;
                this.comments = [];
                this.showClass = 'dl-loading';
                this.getCommentList();
            },
            objType:function(){
                this.page = 0;
                this.commentCount = 0;
                this.comments = [];
                this.showClass = 'dl-loading';
                this.getCommentList();
            }
        },
        methods:{
            getCommentList:function(){
                this.showClass = 'dl-loading';
                this.$http.get('/ncomment/list',{
                    params:{
                        objid:this.objId,
                        objtype:this.objType,
                        page:this.page,
                        pagesize:this.pageSize
                    }
                }).then(function(res){
                            if (res.body.comment_cnt >= 0) {
                                this.commentCount = res.body.comment_cnt;
                                res.body.comments.map(function(comment){
                                    comment.showModifyComment =false;
                                    if (comment.comment_count) {
                                        comment.showReply = true;
                                        comment.replyTips = "收起回复";
                                        if (comment.comment_count > 3) {
                                            comment.showReplyNum = 3;
                                            comment.loadClass = "dl-goto";
                                        } else {
                                            comment.showReplyNum = comment.comment_count;
                                            comment.loadClass = "dl-nomore";
                                        }
                                        comment.showReplyNum = comment.comment_count > 3 ? 3 : comment.comment_count;
                                    } else {
                                        comment.replyTips = comment.comment_count;
                                        comment.showReply = false;
                                        comment.showReplyNum = 0;
                                    }
                                    comment.editComment = comment.comment;
                                    comment.newReplyContent = '';
                                    //comment.replyList = [];
                                    //comment.replyPage = 0;
                                })
                                this.comments = this.comments.concat(res.body.comments);
                                this.$dispatch('loadComplete');
                                if (res.body.comment_cnt > ((this.page + 1) * this.pageSize)) {
                                    this.page += 1;
                                    this.showClass = 'dl-goto';
                                } else {
                                    this.showClass = 'dl-nomore';
                                }
                            }
                            if (this.page == 0 || this.page == 1) {
                                this.$broadcast('randomTips',this.commentCount);
                            }
                        },
                        function(res){
                            this.showClass = 'dl-nomore';
                        }
                    );
                }
        },
        events:{
            'newComment':function(comment){
                this.comments.splice(0,0,comment);
                this.commentCount +=1;
            },
            'getMoreComment':function(){
                this.getCommentList();
            },
            'delComment':function(){
                this.commentCount -=1;
            }
        }
    });
});