define(['jquery', 'vue', 'vue-resource', 'popup', 'moment', 'tig-editor-v2', 'app/community/like','app/community/community','app/hatch/project_list','app/community/captcha'], function ($, Vue, VueResource, popup, moment, TIG, like, community) {
  Vue.filter('time-format', function (value) {
      var time = moment(value, "YYYY-MM-DD hh:mm:ss").unix();
      var passhours = (new Date().getTime()/1000 - time)/60/60;
      if (passhours > 24) {
          return value.substring(0, 10);
      }else if (1 < passhours && passhours < 24) {
          return parseInt(passhours) + "小时前";
      }else if (parseInt(passhours * 60)) {
          return parseInt(passhours * 60) + "分钟前";
      }else {
          return "刚刚";
      }
      return value;
  });
  Vue.filter('view-format', function(value) {
      var str = ''+value;
      value = parseInt(value);
      if(value >= 10000) {
          var pre = parseInt(value / 10000);
          var sub = parseInt(value % 10000 / 1000);
          str = sub == 0 ? pre + 'w' : pre + '.' + sub + 'w';
      } else if(value >= 1000) {
          var pre = parseInt(value / 1000);
          var sub = parseInt(value % 1000 / 100);
          str = sub == 0 ? pre + 'k' : pre + '.' +sub + 'k';
      }
      return str;
  });
  Vue.component('tig-edit', {
          template: '<div class="askeditor" v-bind:class="{\'f-hidden\':!textShow}">\
                    <div class="m-tigeditor">\
                        <textarea class="tigeditor-textarea" id="{{type}}_desc{{objId}}" v-bind:foccs="focus" name="desc" data-markdown="content_md">{{{value}}}</textarea>\
                    </div>\
                    <div class="askeditor-submit">\
                        <span class="error-tips">{{errText}}</span>\
                        <button class="m-btn-primary askeditor-btn" v-bind:class="{inactive:publishStatus == false}" v-on:click="submitAnswer()" type="button">{{btnText}}</button>\
                    </div>\
                </div>\
                <v-captcha v-ref:captcha v-on:save="submitAnswer"></v-captcha>',
          props: ['objId', 'isLogin', 'value', 'type', 'textShow', 'errText', 'controller', 'projectId'],
          ready: function () {
              var _that = this;
              setTimeout(function () {
                  TIG.editor({
                      id: _that.type + '_desc' + _that.objId,
                      height: 160,
                      width: 610,
                      value: '',
                      showRelativePath: false,
                      docToHtmlPath: '/course/doc2Html',
                      imageUploadPath: '/article/editorUploadImage',
                      buttons: ['bold', 'italic', 'h2', 'blockquote', 'insertorderedlist',
                          'insertunorderedlist', 'emoticons', 'addsource', 'link', 'table', 'image', 'video']
                  });
                  $('#editor-' + _that.type + '_desc' + _that.objId).on('contentchange.editor.tfl', function (res) {
                      var length = _that.charLen(true);
					  _that.focus(length);
                      if (length > 5000) {
                          _that.errText = '限5千字，已超出' + (length - 5000) + '字';
                      } else {
                          _that.errText = '';
                      }
                  });
              }, 100);
          },
          data: function () {
              return {
                  publishStatus: false,
				  submitStatus: false,
                  btnText: '提交回答',
                  num: 0,
                  editor: ''
              }
          },
          methods: {
              login: function () {
                  gad.login();
              },
              charLen: function (strip) {
                  this.editor = TIG.editor.getInstance(this.type + '_desc' + this.objId);
                  var editor_value = this.editor.html();
                  if (strip == true) {
                      editor_value = community.strip_tags(editor_value);
                  }
                  return editor_value.length;
              },
              focus: function (length) {
                  if (length > 0) {
                      this.publishStatus = true;
                  } else {
                      this.publishStatus = false;
                  }
              },
              blur: function () {
                  if (this.isMultiLine()) {
                      this.textClass = "status-morecol focus-out";
                  }
              },
              projectSelect: function (id) {
                  this.projerctId = id;
              },
              submitAnswer: function (captcha) {
                  if (this.charLen(false) <= 0) {
                      popup.showPopup('warn', '提示', '请填写回答!');
                      return;
                  }
                  if (this.charLen(true) > 5000) {
                      popup.showPopup('warn', '', '回答超出字数');
                      return;
                  }
                  this.editor = TIG.editor.getInstance(this.type + '_desc' + this.objId);
                  var _that = this;
                  if (this.submitStatus === false) {
                      this.submitStatus = true;
                      this.publishStatus = false;
                      this.btnText = '发表中...';
                      var answer_id = '';
                      if (this.type == 'update') {
                          answer_id = '/' + this.objId;
                      }
                      this.$http.post('/' + this.controller + '/answer' + answer_id, {
                          id: this.objId,
                          type: this.type,
                          answer: this.editor.html(),
                          at_user_id: 0,
                          at_user_name: '',
                          projectId: 1,
                          _token: $('[name="csrf-token"]').attr('content'),
                          captcha: captcha
                      })
                          .then(function (res) {
                              if (res.data.code == 0) {
                                  if (this.type == 'update') {
                                      _that.$emit('changedata', res.data.data);
                                  } else {
                                      $('.replynewQuestion').hide();
                                      _that.editor.setHtml('');
                                  }
                                  _that.$emit('updateanswer', res.data.data);
                              } else if (res.data.code == 10001) {
                                  this.$refs.captcha.showCode(true, false);
                              } else if (res.data.code == 10002) {
                                  this.$refs.captcha.showCode(true, true);
                              } else {
                                  popup.showPopup('warn', '提示', res.data.msg);
                              }
                              this.submitStatus = false;
                              this.btnText = '提交回答';
                          }, function (res) {
                              this.submitStatus = false;
                              this.btnText = '提交回答';
                              popup.showPopup('warn', '提示', '登录态失效，请重新登录后发表!');
                          });
                  }
              }
      },
      events: {
          'replyTo': function (content) {
              this.replyTo(content);
          }
      }
  });
  Vue.component('reply-list', {
      template: '<ul class="replylist-main">\
                    <li class="replylist-item">\
                        <div class="replynew" v-bind:class="show-replynew-apply">\
                            <div class="commit-user g-badge" v-if="user && isLogin">\
                                <img class="commit-headpic f-circle" width="24" height="24" v-bind:src="user.Avatar" alt="">\
                                <i v-if="user.type == 1" class="gicos-bluev-shadow-s"></i>\
                                <i v-if="user.type == 2" class="gicos-redv-shadow-s"></i>\
                            </div>\
                            <div class="replynew-area g-scrollbar">\
                                <textarea class="replynew-textarea g-scrollbar" id="replynew-textarea{{answerId}}" v-on:keyup="focus(replyList)" v-on:blur="blur(replyList)" placeholder="写下你的评论"></textarea>\
                                <button class="replynew-btn-reply m-btn-primary m-btn-small" v-bind:class="{inactive:!replyList.pushState}" v-on:click="submitAnswer()" type="button">评论</button><!--未激活态 inactive-->\
                            </div>\
                        </div>\
                    </li>\
                    <li class="replylist-item" v-for="reply in replyList.data">\
                        <a class="commit-user g-badge" v-bind:href="\'http://gad.qq.com/user?id=\'+reply.user_id" target="_blank">\
                            <img class="commit-headpic f-circle" v-bind:src="reply.avatar" width="24" height="24">\
                            <i v-if="reply.user.type == 1" class="gicos-bluev-shadow-s"></i>\
                            <i v-if="reply.user.type == 2" class="gicos-redv-shadow-s"></i>\
                        </a>\
                        <div class="item-info">\
                            <div class="info-data">\
                                <a class="data-name" v-bind:href="\'http://gad.qq.com/user?id=\'+reply.user_id"  title="{{ reply.user_name }}">{{ reply.user_name }}</a>\
                                <span class="data-s" v-if="reply.at_name != \'\'">回复</span>\
                                <span class="data-name">{{ reply.at_name }}</span>\
                                <span class="data-time">{{ reply.created_at | time-format}}</span>\
                            </div>\
                            <p class="info-text">{{{ reply.answer }}}</p>\
                            <div class="ucommpraise">\
                                <a class="ucommpraise-item" v-if="isLogin && reply.hasPermit" v-on:click="delAnswer(replyList,reply,reply.id)">\
                                    <i class="ucommpraise-ico cyico-del-s"></i>\
                                    <span class="item-txt">删除</span>\
                                </a>\
                                <a class="ucommpraise-item" v-if="!isLogin || (isLogin && user.UserId != reply.user_id)" v-on:click="replyTo(reply.user_id, reply.user_name,reply.id)">\
                                    <i class="ucommpraise-ico cyico-commt-s-gray">\
                                    <!--回复--></i>\
                                    <span class="item-txt"></span>\
                                </a>\
                                <v-like model-type="Answer" :model-id="reply.id" :like-count="reply.like_count" :like-status="reply.likefav.status"></v-like>\
                            </div>\
							<div class="replynew-area g-scrollbar" style="display:none;" id="replynew-area_{{reply.id}}">\
                                <textarea class="replynew-textarea g-scrollbar" id="replynew-textarea{{reply.id}}" v-on:keyup="focus(reply)" v-on:blur="blur(reply)" v-bind:placeholder="\'回复\'+reply.user.NickName"></textarea>\
                                <button class="replynew-btn-reply m-btn-primary m-btn-small" v-bind:class="{inactive:!reply.pushState}" v-on:click="submitAnswer(\'\',\'replynew-textarea\',reply)" type="button">回复</button><!--未激活态 inactive-->\
						    </div>\
                        </div>\
                    </li>\
                </ul>\
                <div class="m-dlmore" v-bind:class="loadmore">\
                    <a class="dlmore-btnsec" href="javascript:;" v-on:click="showReply(answerId, false)">查看更多评论<span\
                     class="dlmore-ico gicos-arrow-down"></span></a>\
                    <span class="dlmore-loading gico-loading loading-20">加载中...</span>\
                </div>\
                <v-captcha v-ref:captcha v-on:save="submitAnswer"></v-captcha>',
      props: ['answerId', 'isLogin', 'user', 'orderBy', 'replyCount', 'replyList', 'loading', 'controller', 'answerName'],
      ready: function () {
          this.showReply(this.answerId, true);
      },
      data: function () {
          return {
              at_user_id: 0,
              at_user_name: '',
              token: $('meta[name="csrf-token"]').attr('content')
          }
      },
      methods: {
          showReply: function (id, first) {
              if (this.loading == true) {
                  return;
              }
              if (this.replyCount == 0) {
                  return;
              }
              this.loading = true;
              var pagesize = 3;
              if (first != true) {
                  pagesize = 10;
              }
              this.$http.get('/' + this.controller + '/reply-list/' + id, {
                  params: {
                      'page': this.replyList.current_page + 1,
                      'pageSize': pagesize,
					  'orderBy': 'new'					  
                  }
              }).then(function (res) {
                  this.loading = false;
                  var data = res.data;
                  if (data.code == 0) {
                      var _data = this.replyList.data;
                      _data = _data.concat(data.data.data);
                      data.data.data = _data;
                      this.replyList.per_page = pagesize;
                      this.replyList.data = data.data.data;
                      this.replyList.total = data.data.total;
                      this.replyList.current_page = this.replyList.current_page + 1;
                      this.$nextTick(function(){
                          $(".item-info").each(function () {
                              var _that = this;
                              if ($(this).height() > 600) {
                                  $(this).addClass('status-fold');
                                  console.log($(this).get(0));
                                  $(this).find(".fold-btn").removeClass("f-hide");
                                  $(this).find(".fold-btn").click(function () {
                                      $(_that).addClass("status-fold");
                                  });
                                  $(this).find(".unfold-btn").click(function () {
                                      $(_that).removeClass("status-fold");
                                  });
                              }
                          })
                      });
                  }
              });
          },
          replyTo: function (at_user_id, at_user_name, id) {
              this.at_user_id = at_user_id;
              this.at_user_name = at_user_name;
              $('#replynew-textarea' + id).val('');
              $('#replynew-textarea' + id).focus();
              $('#replynew-area_' + id).toggle();
          },
          delAnswer: function (answerList, reply, id) {
              var data = {};
              data.type = 'del';
              data.id = id;
              data._token = $('meta[name=csrf-token]').attr('content');

              if (id > 0) {
                  var _that = this;
                  popup.showPopup(1, '提示', '您确定要删除吗?', function () {
                      _that.$http.post('/' + _that.controller + '/answer/' + id, data).then(function (res) {
                          var ret = res.data;
                          if (ret.code == 0) {
                              answerList.data.$remove(reply);
                              _that.replyCount = _that.replyCount - 1;
                              _that.$emit('decrementcount');
                          } else {
                              popup.showPopup(1, '提示', ret.message);
                          }
                      });
                  });
              }
          },
          charLen: function (reply) {
              return $('#replynew-textarea' + (reply.id == undefined ? this.answerId : reply.id)).val().length;
          },
          focus: function (reply) {
              if (this.charLen(reply) > 0) {
                  reply.pushState = true;
              } else {
                  reply.pushState = false;
              }
          },
          blur: function (reply) {
              if (this.charLen(reply) > 0) {
                  reply.pushState = true;
              } else {
                  reply.pushState = false;
              }
          },
          submitAnswer: function (captcha, replyTextArea, replyList) {
              var data = {};
              data.type = 'answer';
              data.id = this.answerId;
              data.at_user_id = this.at_user_id;
              data.at_user_name = this.at_user_name;
              data._token = this.token;
              data.captcha = captcha;
			  var thatReplyList = this.replyList;
			  var replyTextAreaId = '#replynew-textarea' + this.answerId;
			  if(replyTextArea != undefined){
				  replyTextAreaId = '#'+replyTextArea+replyList.id;
				  $('#replynew-area_' + replyList.id).hide();
				  thatReplyList = replyList;
			  }
			  data.answer = $(replyTextAreaId).val();

              if (this.answerId > 0) {
                  var _that = this;
                  this.$http.post('/' + this.controller + '/answer', data).then(function (res) {
                      var ret = res.data;
                      if (ret.code == 0) {
                          if (_that.replyList.data == undefined) {
                              _that.replyList.data = [];
                          }
                          _that.replyList.data.splice(this.index, 0, ret.data);
                          _that.replyCount = _that.replyCount + 1;
                          _that.$emit('updatecount');
                          $(replyTextAreaId).val('');
                          thatReplyList.pushState = false;
                          //popup.showPopup(1,'提示','操作成功');
                      } else if(res.data.code == 10001) {
                          _that.$refs.captcha.showCode(true, false);
                      } else if(res.data.code == 10002) {
                          _that.$refs.captcha.showCode(true, true);
                      } else {
                          popup.showPopup(1, '提示', ret.message);
                      }
                  });
              }
          }
      },
      computed: {
          loadmore: function () {
              return {
                  'dl-goto': this.replyList && this.replyList.total > this.replyList.current_page * this.replyList.per_page,
                  'dl-nomore': this.replyList && this.replyList.total <= this.replyList.current_page * this.replyList.per_page,
                  'dl-loading': this.loading
              }
          }
      },
      events: {
          'replyTo': function (content) {
              this.replyTo(content);
          }
      }
  });

  return {
    init: function(id,answerCount,orderBy,controller){
        var vue = new Vue({
            el: '#answer',
            data: {
                question_id: id,
                answerCount: answerCount,
                dataList: {
                  answer_count: answerCount,
                  answerList: {
                      current_page: 1,
                      per_page: 20,
                      total: 0,
                      data: []
                  }
                },
                orderBy: orderBy,
                controller: controller,
                user: {},
                isLogin: false,
                loading: true,
                at_user_id: 0,
                at_user_name: '',
                isLoading: false,
                noMoreData: false,
                token: $('meta[name="csrf-token"]').attr('content'),
            },
            methods: {
                delAnswer : function(answerList, reply, id){
                    var data = {};
                    data.type = 'del';
                    data.id = id;
                    data._token = $('meta[name=csrf-token]').attr('content');

                    if(id > 0){
                        var _that = this;
                        popup.showPopup(1,'提示','您确定要删除吗?', function(){
                            _that.$http.post('/'+_that.controller+'/answer/'+id,data).then(function(res){
                                var ret = res.data;
                                if(ret.code == 0){
                                    answerList.answerList.data.$remove(reply);
                                    answerList.answer_count = answerList.answer_count - 1;
                                } else {
                                    popup.showPopup(1,'提示',ret.message);
                                }
                            });
                        });
                    }
                },
                showReply: function(answer){
                    answer.loading = true;
                    if (answer.replyList.first == true || answer.answer_count == 0) {
                        answer.loading = false;
                        return;
                    }
                    this.$http.get('/'+this.controller+'/reply-list/' + answer.id, {
                        params: {
                            'page': 1,
                            'pageSize': answer.replyList.per_page,
						    'orderBy': 'new'
                        }
                    }).then(function (res) {
                        var data = res.data;
                        if (data.code == 0) {
                            answer.replyList.data = data.data.data;
                            answer.replyList.per_page = 10;
                            answer.replyList.current_page = answer.replyList.current_page + 1;
                            answer.replyList.first = true;
                            answer.replyList.total = data.data.total;
                        }
                        answer.loading = false;
                    });
                },
                textShow: function(answer,type){
                    if(type != '' && this.answerData != ''){
                        answer.answer = this.answerData;
                        this.answerData = '';
                    }
                   answer.textShow = !answer.textShow;
                },
                changedata: function(data){
                    this.answerData = data;
                },
                updateAnswer: function(data){
                    this.dataList.answerList.data.splice(this.index,0,data);
                    this.dataList.answer_count = this.dataList.answer_count + 1;
                },
                submitAnswer : function(answerList, id, type) {
                    var data = {};
                    data.type = type;
                    data.id = id;
                    data.at_user_id = this.at_user_id;
                    data.at_user_name = this.at_user_name;
                    data._token = this.token;
                    if(type == 'answer'){
                        data.answer = $('#replynew-textarea'+id).val();
                    } else if(type == 'question'){
                        data.answer = '';
                    } else {
                        return '';
                    }

                    if(id > 0){
                        this.$http.post('/'+this.controller+'/answer',data).then(function(res){
                            var ret = res.data;
                            if(ret.code == 0){
                                if(answerList.answerList.data == undefined){
                                    answerList.answerList.data = [];
                                }
                                answerList.answerList.data.splice(this.index,0,ret.data);
                                answerList.answer_count = answerList.answer_count + 1;
                                $('#replynew-textarea'+id).val('');
                                answerList.pushState = false;
                                //popup.showPopup(1,'提示','操作成功');
                            } else {
                                popup.showPopup(1,'提示',ret.message);
                            }
                        });
                    }
                },
                showAnswer: function(dataList){
                  this.loading = true;
                  this.$http.get('/'+this.controller+'/answer-list/'+this.question_id,{
                      params:{
                        'page' : dataList.answerList.current_page + 1,
                        'pageSize' : dataList.answerList.per_page,
                        'orderBy' : this.orderBy
                      }
                  }).then(function(res){
                    this.loading = false;
                    var data = res.data;
                    if(data.code == 0){
                         var _data = dataList.answerList.data;
                         _data = _data.concat(data.data.answerList.data);
                         data.data.answerList.data = _data;
                         this.dataList = data.data;
                    }
                  });
                },
                charLen: function(reply){
                    return $('#replynew-textarea'+reply.id).val().length;
                },
                focus: function(reply){
                    if (this.charLen(reply) > 0) {
                        reply.pushState = true;
                    } else {
                        reply.pushState = false;
                    }
                },
                blur: function(reply){
                    if (this.charLen(reply) > 0) {
                        reply.pushState = true;
                    } else {
                        reply.pushState = false;
                    }
                },
                updateCount: function(answer) {
                    answer.answer_count = answer.answer_count + 1;
                },
                decrementCount: function(answer) {
                    answer.answer_count = answer.answer_count - 1;
                },
                getAnswer: function(order){
                    var _that = this;
                  this.loading = true;
                  this.dataList.answerList = [];
                  this.$http.get('/'+this.controller+'/answer-list/'+this.question_id,{
                    params:{
                    'page' : 1,
                    'pageSize' : 20,
                    'orderBy' : order
                  }
                  }).then(function(res){
                    this.loading = false;
                    var data = res.data;
                    if(data.code == 0){
                        this.orderBy = order;
                        this.user = data.data.user;
                        this.isLogin = data.data.isLogin;

                        this.dataList = data.data;
                        this.dataList.answer_count = this.answerCount;
                        _that.$nextTick(function() {
                            $(".item-info").each(function () {
                                var _that = this;
                                if ($(this).height() > 600) {
                                    $(this).addClass('status-fold');
                                    $(this).find(".fold-btn").removeClass("f-hide");
                                    $(this).find(".fold-btn").click(function(){
                                        var height = $(_that).height();
                                        var scrollTop = $(document).scrollTop();
                                        $(_that).addClass("status-fold");
                                        scrollTop = scrollTop - height + $(_that).height();
                                        window.scrollTo(0,scrollTop);
                                    });
                                    $(this).find(".unfold-btn").click(function(){
                                        $(_that).removeClass("status-fold");
                                    });
                                }
                            })
                        });
                    }
                  });
                },
                updown: function(id,updown,answer) {
                    if($(id).is(':hidden')){
                        $(id).toggle();
                        $(updown+' span').html('收起评论');
                        //this.showReply(answer);
                    } else {
                      $(id).toggle();
                      if(answer.answer_count > 0){
                        $(updown+' span').html(answer.answer_count);
                      } else {
                        $(updown+' span').html(answer.answer_count);
                      }
                    }
                }

          },
          computed: {
            showLogin: function(){
              return {
                'show-replynew-apply': this.isLogin,
              }
            },
            loadmore: function(){
              return {
                'dl-goto': !this.loading && this.dataList.answerList.total >= this.dataList.answerList.current_page * this.dataList.answerList.per_page,
                'dl-loading': this.loading,
                'dl-nomore': !this.loading && this.dataList.answerList.total < this.dataList.answerList.current_page * this.dataList.answerList.per_page
              }
            }
          },ready: function(){
                var _that = this;
              this.$http.get('/'+this.controller+'/answer-list/'+id, {
                  params: { orderBy : this.orderBy }}).then(function(res){
                  var data = res.data;
                  if(data.code == 0) {
                      this.loading = false;
                      this.user = data.data.user;
                      this.isLogin = data.data.isLogin;
                      this.dataList.answerList = data.data.answerList;
                      _that.$nextTick(function() {
                          $(".item-info").each(function () {
                              var _that = this;
                              if ($(this).height() > 600) {
                                  $(this).addClass('status-fold');
                                  $(this).find(".fold-btn").removeClass("f-hide");
                                  $(this).find(".fold-btn").click(function(){
                                      var height = $(_that).height();
                                      var scrollTop = $(document).scrollTop();
                                      $(_that).addClass("status-fold");
                                      scrollTop = scrollTop - height + $(_that).height();
                                      window.scrollTo(0,scrollTop);
                                  });
                                  $(this).find(".unfold-btn").click(function(){
                                      $(_that).removeClass("status-fold");
                                  });
                              }
                          })
                      });
                  }
                  $('.commit-item_top').hide();
              });
          }
        })
    }
  }
})
