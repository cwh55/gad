define(['jquery', 'vue', 'tig-editor-v2', 'popup', 'vue-resource', 'app/community/tag', 'pan_upload', 'app/hatch/project_list', 'app/community/captcha'], function($, Vue, TIG, popup, VueResource) {
    Vue.use(VueResource);
    var isIE89 = navigator.appVersion.indexOf("MSIE 9")>=0 || navigator.appVersion.indexOf("MSIE 8")>=0;
    function generateEditor(content,domid){
        TIG.editor({
            id: domid,
            height: 128,
            width: 322,
            minWidth: 300,
            value: content,
            showRelativePath: false,
            buttons: [ 'emoticons', 'link']
        });
    }

   
    return {
        init: function(id, atitle, projectid){
            var vm = new Vue({
                el: '#app',
                data: {
                    newid: 0,   //新分配的domid值
                    uploadedid: 0,  //记录每次上传之前的newid的值
                    atitle: atitle,
                    piclist: [],
                    atlas: new Object(),
                    id: id,
                    token: $('meta[name="csrf-token"]').attr('content'),
                    upload: [], //用数组来管理每个图片的上传状态和进度
                    type: 2,
                    status: 1,   //保存时所选择的类型，1草稿，2发表，3预览
                    isSaving: false,     //是否正在保存
                    projectid: parseInt(projectid)        //项目id
                },
                computed: {
                    canPublic: function () {
                        var picnum = 0;
                        for (var i = 0; i < this.piclist.length-1; i++) {
                            if(this.piclist[i].status!=-1){
                                picnum++;
                                break;
                            }
                        }
                      return picnum && this.atitle;
                    }
                },
                ready: function(){
                    //ie中placeholder不可用。
                    if(isIE89){
                        $('textarea[placeholder], input[placeholder]').each(function(){
                            var placeholder = $(this).attr('placeholder');
                            $(this).click(function(){
                                if($(this).val() == placeholder){
                                    $(this).val('');
                                }
                            });
                            $(this).blur(function(){
                                var element = $(this);
                                setTimeout(function(){
                                    if(!element.val()){
                                        element.val(placeholder);
                                    }
                                }, 100);
                            }).trigger('blur');
                        });
                    }
                    var _that = this;
                    if(parseInt(id)){
                        this.$http.get('/gallery/detail-list', {params: {id:id}}).then(function (res) {
                            var response = res.data;
                            if(response.code == 0){
                                _that.piclist = response.data;
                                /*if(_that.piclist.length){
                                    _that.type = _that.piclist[0].type;
                                }*/
                                for (var i = 0; i < _that.piclist.length; i++) {
                                    _that.piclist[i].jsid = i;
                                    this.upload.push({ //只是为了生成对应数量的进度对象。
                                        uploading: false,
                                        percent: 0
                                    });
                                    (function(x, that){
                                        setTimeout(function(){
                                            generateEditor(_that.piclist[x].content,"desc"+x);
                                            that.bindUpload(x);
                                        },0);
                                    }(i, _that))
                                }
                                _that.newid = _that.piclist.length;
                                _that.addItem(0);
                            }else{
                                popup.showPopup('warn','提示','数据拉取失败!');
                            }
                        });
                    }else{
                        this.addItem(0);
                    };
                    $(".js_title").focus();
                },
                methods: {
                    deletePic: function(index){
                        for (var j = 0; j < this.piclist.length; j++) {
                            if(this.piclist[j].jsid == index){
                                this.piclist[j].url = "";
                            }
                        }
                        pan_upload_remove(this.upload[index].uploader, this.upload[index].id);
                         if(isIE89){
                            this.$nextTick(function(){
                                this.upload[index].uploader.refresh();
                            });
                        }
                    },
                    deleteItem: function(index){
                        this.piclist[index].status = -1;
                    },
                    judgePicType: function(url){
                        var patrn = /gif$/;
                        return url && patrn.test(url);
                    },
                    bindUpload: function(index){  //新添加图片，重新编辑图片上传事件的绑定
                        var name = "js_uploadpic";
                        var _that = this;
                        $("#"+name+index).pan_upload_raw({
                            multipart_params: {csrf: this.token}, max_file_count: 10, multi_selection: true, flash_swf_url: '/assets/js/Moxie.swf',
                            filters: {max_file_size: '10mb', mime_types: [{title: "图片", extensions: "jpg,png,gif,tif,webp"}]},
                            events: {
                                Init: function(up) {
                                    _that.upload[index].uploader = up;
                                }, 
                                FilesAdded: function(up, files) {
                                    for (var i = 0; i < files.length; i++) {
                                        if (!window.FileReader && files[i].size > 2 * 1024 * 1024) {
                                            popup.showPopup('warn','提示','您的浏览器可能无法完成超过2M的文件上传，建议更换Chrome等现代浏览器完成大文件的上传哈');
                                        }
                                        if(i){  //第一张图片索引为index，其余皆为新生成的
                                            for (var j = 0; j < _that.piclist.length; j++) {
                                                if(_that.piclist[j].jsid == index){
                                                    _that.addItem(j+1);
                                                }
                                            }
                                            _that.upload[_that.uploadedid+i].id = files[i].id;
                                            _that.upload[_that.uploadedid+i].uploading = true;
                                        }else{
                                            _that.uploadedid = _that.newid-1;
                                            _that.upload[index].id = files[i].id;
                                            _that.upload[index].uploading = true;
                                        }
                                        /*if(i){  //第一张图片索引为index，其余皆为新生成的
                                            _that.addItem(index+i);
                                        }*/
                                        //_that.upload[index+i].id = files[i].id;
                                        //_that.upload[index+i].uploading = true;
                                    }
                                    up.disableBrowse(true);
                                }, 
                                UploadProgress: function(up, file) {
                                    for (var i = 0; i < _that.upload.length; i++) {
                                        if(file.id == _that.upload[i].id){
                                            _that.upload[i].percent = file.percent;
                                        }
                                    }
                                },
                                FileUploaded: function(up, file, info) {
                                    try {
                                        up.disableBrowse(false);
                                        _that.upload[index].uploading = false;
                                        var data = JSON.parse(info.response);
                                        if (!data.success) {
                                            popup.showPopup('warn','提示',"上传失败");
                                        } else {
                                            for (var i = _that.upload.length-1; i >= 0; i--) {
                                                if(file.id == _that.upload[i].id){
                                                    _that.upload[i].uploading = false;
                                                    for (var j = 0; j < _that.piclist.length; j++) {
                                                        if(_that.piclist[j].jsid == i){
                                                            _that.piclist[j].url = data.image_url;
                                                            var sizeurl = data.image_url + '?imageInfo';
                                                            _that.$http.get(sizeurl, {}).then(function (ress) {
                                                                if (ress.data) {
                                                                    var imginfo = JSON.parse(ress.data);
                                                                    _that.piclist[j].width = imginfo.width;
                                                                    _that.piclist[j].height = imginfo.height;
                                                                }
                                                            });
                                                            if(j == _that.piclist.length-1){
                                                                _that.addItem(0);
                                                            }
                                                            break;
                                                        }
                                                    }
                                                    break;
                                                }
                                            } 
                                        }
                                    } catch (e) {
                                        popup.showPopup('warn','提示',"上传失败");
                                    }
                                },
                                Error: function(up, error) {
                                    _that.upload[index].uploading = false;
                                    popup.showPopup('warn','提示',error.message);
                                }
                            }
                        });
                    },
                    save: function (code) {
                        this.saveReal(2, code);
                    },
                    saveReal: function(status, captcha){
                        if(!this.canPublic || this.isSaving) {
                            return;
                        }
                        this.isSaving = true;
                        this.status = status;
                        var params = this.formatData();
                        if (captcha) {
                            params.captcha = captcha;
                        }
                        if(!params){
                            return;
                        }
                        var _that = this;
                        this.$http.post('/gallery/save-atlas', params).then(function (res) {
                            _that.isSaving = false;
                            var response = res.data;
                            if (response.code == 0 && response.id) {
                                _that.$refs.captcha.showCode(false, false);
                                if(status == 3){    //预览
                                    history.go(0);
                                    window.open('/gallery/detail/'+response.id);
                                }else if(status == 2){  //发表
                                    location.href = '/gallery/detail/'+response.id;
                                }else{  //保存
                                    popup.showPopup('ok','提示',response.message, function(){
                                        location.href = '/gallery/edit/'+response.id;//history.go(0);
                                    });
                                }
                            } else if (response.code == 10001) {//需要弹验证码
                                if (status == 2) {
                                    _that.$refs.captcha.showCode(true, false);
                                }
                            } else if (response.code == 10002) {//验证码错误
                                _that.$refs.captcha.showCode(true, true);
                            } 
                            else{
                                popup.showPopup('warn','提示',response.message);
                            }
                        });
                    },
                    dropEdit: function(){
                        popup.showPopup('warn','提示','确定要放弃编辑的内容么？', function(){
                            if (history.length > 2) {
                                history.go(-1);
                            } else {
                                location.href = '/';
                            }
                        });
                    },
                    editUploadPic: function(index){
                        if(isIE89){
                            popup.showPopup('info','您的浏览器无法支持直接修改图片，请删除后重新上传');
                        }else{
                            $("#js_uploadpic"+index).click();
                        }
                    },
                    formatData: function(){
                        var picnum = 0;
                        var sort = 0;
                        for (var i = 0; i < this.piclist.length-1; i++) {
                            this.piclist[i].content = TIG.editor.getInstance('desc'+this.piclist[i].jsid).html();
                            if(this.piclist[i].status!=-1){
                                picnum++;
                                this.piclist[i].sort = sort;
                                sort++;
                            }
                        }
                        var params = {
                            id: id,
                            projectid: this.projectid,
                            piclist: this.piclist.slice(0, this.piclist.length-1),
                            _token: this.token,
                            title: $(".js_title").val(),
                            tags: $("#tags-input").val(),
                            type: this.type,
                            status: this.status
                        }
                        if(!params.title){
                            popup.showPopup('warn','提示','请填写标题!');
                            return false;
                        }
                        if(!picnum){
                            popup.showPopup('warn','提示','请至少上传一张图片!');
                            return false;
                        }
                        return params;
                    },
                    addItem: function(position){
                        var picobj = {
                            url: '', 
                            content: '',
                            jsid: this.newid,
                            id: 0,
                            status: 0
                        }
                        if(position){
                            this.piclist.splice(position, 0, picobj);
                        }else{
                            this.piclist.push(picobj);
                        }
                        this.upload.push({ //只是为了生成对应数量的进度对象。
                            uploading: false,
                            percent: 0
                        });
                        this.newid++;
                        var _that = this;
                        (function(x){
                            _that.$nextTick(function(){
                                generateEditor('',"desc"+(x-1));
                                _that.bindUpload(x-1);
                            })
                        }(this.newid))
                            
                    },
                    projectSelect: function(id){
                        this.projectid = id;
                    }
                }
            })
        }
    };
});