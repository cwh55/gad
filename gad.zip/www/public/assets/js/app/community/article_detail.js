define(['jquery', 'popup', 'vendor/plyr/plyr', 'codemirror', 'ui/autofixtop', 'imgzoom'], function($, popup, plyr, CodeMirror) {
    $('video[rsrc]').each(function(){
        var src = $(this).attr('rsrc');
        var match = src.match(/uuid=(\w+)/);
        if(match && match[1]){
            $(this).attr('src', 'http://file.gad.qq.com/attachment/video?video_id='+match[1]);
        }
    });
    plyr.gadInit();
    $('iframe.detail-video').each(function(){
        var match = $(this).attr('src').match(/http[s]?:\/\/v.qq.com\/iframe\/player\.html\?vid=(\w+)/);
        if(match && match[1]){
            $(this).attr('src', 'http://v.qq.com/iframe/txp/player.html?vid='+match[1]);
        }
    });
    $('.code').each(function() {
        var $this = $(this),$code = $this.html();
        var lang = $this.data('lang');
        if(lang){
            require(['codemirror/mode/'+lang+'/'+lang], function(){
                $this.empty();
                CodeMirror($this[0], {
                    value: $code,
                    mode: lang,
                    lineNumbers: !$this.is('.inline'),
                    readOnly: true,
                    viewportMargin: Infinity
                });
            }, function(){
                var s = $('<textarea class="default-code" style="width: 100%;"></textarea>').val($code);
                $this.replaceWith(s);
                s.height(s[0].scrollHeight);
            });
        }
    });
   
    $('#delete-btn').click(function(){
        var id = $(this).data('id');
		var url = $(this).data('del') == '1' ? '/game/article-delete' : '/article/delete';
        popup.showPopup('warn','提示','确定删除吗',function(){
            $.ajax({url: url, type: 'post', headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}, data: {id: id}, dataType: 'json', complete: function(resp){
                var recv = resp.responseJSON;
                if(recv && recv.code == 0){
                    window.location = '/community';
                }else{
                    popup.showPopup('warn','操作失败', recv.msg || (recv.message instanceof Object ? JSON.stringify(recv.message) : recv.message) || '删除出错');
                }
            }});
        });
    });
    
    return {
        init: function(){
            //滚动到相关推荐的位置，左右侧内容相继消失
            autoFixTop({scrollTop: 119, fixTop: 30, mainWidth: 1180, outHeight: function(){
                return $('.detail-related').offset().top - $('.detail-side .fixarea').height();
            }, objgroup: $(".detail-side .fixarea")});
            autoFixTop({scrollTop: 119, fixTop: 30, mainWidth: 1180, outHeight: function(){
                return $('.detail-related').offset().top - $('.detail-comshare .fixarea').height();
            }, objgroup: $('.detail-comshare .fixarea')});
            autoFixTop({scrollTop: $('.detail-related'), fixTop: 30, mainWidth: 1180, outHeight: -1, objgroup: $('.detail-related .fixarea')});
        }
    };
});