define(['jquery', 'vue', 'tig-editor-v2', 'popup', 'app/community/tag', 'pan_upload', 'app/community/components'], function($, Vue, TIG, popup, community) {
    var token = $('meta[name="csrf-token"]').attr('content');
    var isIE89 = navigator.appVersion.indexOf("MSIE 9")>=0 || navigator.appVersion.indexOf("MSIE 8")>=0;
    var init_upload = function() {
        $("#test_js_fileload").pan_upload_raw({
            multipart_params: {csrf: token}, max_file_count: 1, multi_selection: false, flash_swf_url: '/assets/js/Moxie.swf',
            filters: {max_file_size: '10mb', mime_types: [{title: "图片", extensions: "jpg,png,gif,tif,webp"}]},
            events: {
                Init: function(up) {
                    view.upload.uploader = up;
                }, FilesAdded: function(up, files) {
                    view.upload.percent = 0;
                    view.upload.uploading = true;
                    view.upload.id = files[0].id;
                    if (!window.FileReader && files[0].size > 2 * 1024 * 1024) {
                        popup.showPopup('warn','提示','您的浏览器可能无法完成超过2M的文件上传，建议更换Chrome等现代浏览器完成大文件的上传哈');
                    }
                    up.disableBrowse(true);
                }, UploadProgress: function(up, file) {
                    view.upload.percent = file.percent;
                },
                FileUploaded: function(up, file, info) {
                    try {
                        up.disableBrowse(false);
                        view.upload.uploading = false;
                        var data = JSON.parse(info.response);
                        if (!data.success) {
                            popup.showPopup('warn','提示',"上传失败");
                        } else {
                            view.archive.cover = data.image_url+'?imageMogr2/gravity/Center/crop/190x115';
                        }
                    } catch (e) {
                        popup.showPopup('warn','提示',"上传失败");
                    }
                },
                Error: function(up, error) {
                    if(up.files.length){
                        view.upload.file_error = error.message;
                        view.upload.uploading = false;
                    }else{
                        popup.showPopup('warn','提示',error.message);
                    }
                }
            }
        });
    };
    var init_scroll = function(){
        var nav = {element: $('.editart .ph-headnav'), top: 44, time: 0, state: 0};
        var toolbar = {element: $('.editart .editor-toolbar'), top: 320, time: 0, state: 0};
        var editorArea = $('.editor-area');
        var interval = 100; //ms
        $(window).on("scroll", function() {
            var now = (new Date()).valueOf();
            var scrollTop = $(this).scrollTop();
            var navState = scrollTop>=nav.top ? 1 : 0;
            var toolbarState = scrollTop>=toolbar.top ? 1 : 0;
            if(now - nav.time >= interval && navState.state !== navState){
                if(navState){
                    nav.element.css({"position": "fixed", "top": 0, "left": 0, width: document.body.clientWidth+'px'});
                }else{
                    nav.element.css({"position": "static"});
                }
                nav.time = editorArea.height() < 800 ? now : 0; //避免晃动问题
                navState.state = navState;
            }
            if(now - toolbar.time >= interval && toolbar.state !== toolbarState){
                if(toolbarState){
                    toolbar.element.css({"position": "fixed", "top": '65px', width: '790px'});
                }else{
                    toolbar.element.css({"position": "relative", "top": 'auto', width: 'auto'});
                }
                toolbar.time = editorArea.height() < 800 ? now : 0;
                toolbar.state = toolbarState;
            }
        });
    };
    
    var view;
    
    return {
        init: function(archive){
            view = new Vue({
                el: '#main-div',
                data: {upload: {uploader: null, percent: 0, uploading: false, id: '', file_error:''}, archive: archive, pptFiles: [], saving: false, previewing: false, timer: null, saved: false, previewAddr: 'javascript:;', pptFolded: false, captchaShow: false, errCaptchaShow: false, isEdit: !!archive.article.content},
                methods: {
                    _save: function(callback){
                        var vue = this;
                        vue.saving = true;
                        $.ajax({url: '/article/save', type: 'post', headers: {'X-CSRF-TOKEN': token}, dataType: 'json', data: this.gatherData(), complete: function(resp){
                            var recv = resp.responseJSON;
                            vue.saving = false;
                            if(recv && recv.code == 0){
                                view.archive.id = recv.data;
                                callback && callback(recv.data, recv.needReview);
                                vue.saved = true;
                            }else if (recv.code == 10001) {//需要弹验证码
                                vue.$refs.captcha.showCode(true, false);
                            } else if (recv.code == 10002) {//验证码错误
                                vue.$refs.captcha.showCode(true, true);
                            } else{
                                popup.showPopup('warn','保存失败', recv ? (recv.msg || (recv.message instanceof Object ? JSON.stringify(recv.message) : recv.message)) : '提交出错');
                            }
                        }});
                    },
                    removeFile: function(){
                        pan_upload_remove(this.upload.uploader, this.upload.id);
                        this.archive.cover = '';
                        this.upload.uploading = false;
                        this.upload.file_error = '';
                        if(isIE89){
                            this.$nextTick(function(){
                                this.upload.uploader.refresh();
                            });
                        }
                    },
                    replaceFile: function(){
                        if(isIE89){
                            popup.showPopup('info','您的浏览器无法支持直接修改图片，请删除后重新上传');
                        }else{
                            $("#test_js_fileload").click();
                        }
                    },
                    retryFile: function(){
                        if(this.upload.uploader){
                            this.upload.uploader.start();
                            this.upload.uploading = true;
                            this.upload.file_error = '';
                        }
                    },
                    gatherData: function(){
                        this.archive.cover = $('#cover').attr('src') || '';
                        this.archive.tags = $('#tags-input').val();
                        
                        var editor = TIG.editor.getInstance('content');
                        var mkeditor = $('#content_md').data('editor');
                        this.archive.article.content_type = !editor.editor.data('is-markdown') ? 0 : 1;
                        if(this.archive.article.content_type === 1){
                            this.archive.article.content = mkeditor.getHTML();
                            this.archive.article.content_md = mkeditor.getMarkdown();
                        }else{
                            this.archive.article.content = editor.html();
                            this.archive.article.content_md = '';
                        }
                        
                        var div = $('<div>').hide().appendTo('body');
                        div.html(this.archive.article.content);
                        
                        this.archive.is_video = $('iframe.video', div).length > 0 ? 1 : 0;
                        if(!this.archive.cover && this.archive.status == 2){
                            if(this.archive.is_video){
                                //如果是视频，且未上传封面，则自动取视频的第一张截图
                                var match = $('iframe.video', div).first().attr('src').match(/video_id%3D([^&"]+)/);
                                this.archive.cover = match ? "http://p.qpic.cn/wecam_pic/0/"+match[1]+"_1/0" : 'http://gad.qpic.cn/assets/v2/web/img/global/default_video_preview.png';
                            }else{
                                //如果是普通文章，且未上传封面，则自动取文章的第一张图
                                this.archive.cover = $('img:not(.emoticon)[src]', div).first().attr('src');
                            }
                        }
                        if(this.archive.cover && this.archive.cover.indexOf('image.myqcloud.com')>0 && !this.archive.cover.match(/imageMogr2\/gravity\/Center\/crop/i)){
                            this.archive.cover += (this.archive.cover.indexOf('?')>0 ? '&' : '?') + 'imageMogr2/gravity/Center/crop/190x115'; 
                        }
                        $('img:not(.emoticon)[src]', div).attr('title', this.archive.title).attr('alt', this.archive.title); //图片（非表情）加上title和alt(SEO)
                        if(archive.article.type == 1){
                            //转载的文章加上nofollow(SEO)
                            $('a', div).attr('rel', "nofollow");
                        }
                        this.archive.article.content = div.html();
                        div.remove();
                        
                        this.archive.article.attachments = [];
                        for(var i=0;i<this.pptFiles.length;i++){
                            var p = this.pptFiles[i];
                            if(!p.uploading){
                                this.archive.article.attachments.push({url: p.url, name: p.name, downLoadCount: 0, id: p.file_id, size: p.size});
                            }
                        }
                        return this.archive;
                    },
                    giveUp: function(){
                        popup.showPopup('warn','提示','确定放弃编辑吗?', function(){
                            window.location.href="about:blank";
                            window.close();
                        });
                    },
                    saveDraft: function(){
                        if(!this.canSave()){
                            return;
                        }
                        this.archive.status = 1;
                        this.setTimer();
                        this._save();
                    },
                    previewDraft: function(){
                        if(!this.canSave()){
                            return;
                        }
                        this.gatherData();
                        this.archive.status = 1;
                        this.setTimer();
                        var vue = this;
                        this._save(function(id){
                            if(id){
                                vue.previewing = true;
                                vue.previewAddr = '/article/preview/'+id+'?_r'+Math.random();
                            }
                        });
                    },
                    save: function(captcha){
                        if(!this.canSave()){
                            return;
                        }
                        this.archive.status = 2;
                        this.archive.captcha = captcha;
                        var _this = this;
                        var _save = function(){
                            _this._save(function(id, needReview){
                                if(!needReview){
                                    window.location.href = '/article/detail/'+id;
                                }else{
                                    var dialog = _this.isEdit ? '您修改的内容正在审核中，通过后会更新原发表内容，您可在首页-草稿箱中查看审核进度' : '您发表的日志/作品正在审核中，您可在首页-草稿箱中查看审核进度';
                                    popup.dialog(dialog, [
                                        {text: '回社区', class: 'btn-blue', callback: function(){window.location.href="/community";}}, 
                                        {text: '查看状态', callback: function(){window.location.href="/draft?status=-1"}}
                                    ], '提示', 'warn', true);
                                }
                            });
                        }
                        if(TIG.checkOAImg(TIG.editor.getInstance('content'))){
                            popup.showPopup('info','提示','您发表的内容含有外部图片地址，请转换后发表',function(){
                                TIG.tranlateOAImg(TIG.editor.getInstance('content'), function(){
                                    _save();
                                });
                            });
                        }else{
                            _save();
                        }
                    },
                    removePPT: function(index){
                        pan_upload_remove(view.pptFiles[index].uploader, view.pptFiles[index].id);
                        view.pptFiles.splice(index, 1);
                        view.pptFiles.length<10 && (TIG.disablePPT = false);
                    },
                    retryPPT: function(index){
                        if(view.pptFiles[index].uploader){
                            view.pptFiles[index].uploader.start();
                            view.pptFiles[index].uploading = true;
                            view.pptFiles[index].file_error = '';
                        }
                    },
                    canSave: function(){
                        return !!(this.archive.title && this.archive.title.length<=50);
                    },
                    setTimer: function(){
                        if(this.timer){
                            clearInterval(this.timer);
                        }
                        var vue = this;
                        this.timer = setInterval(function(){
                            vue.saveDraft();
                        }, 300*1000);
                    },
                    projectSelect: function(id){
                        this.archive.project_id = id;
                    },
                    checkDraft: function(){
                        if(!archive.id){
                            $.ajax({url: '/draft/list', type: 'get', data: {page: 0, classId: 1, status: 1}, dataType: 'json', 
                                complete: function(resp) {
                                    var recv = resp.responseJSON;
                                    if (typeof recv === 'object' && recv.length) {
                                        var id = recv[0].id;
                                        popup.dialog('检测到有未发布的草稿内容，是否继续编辑', [{text: '编辑', class: 'btn-blue', callback: function(){window.location.href="/article/edit/"+id}}, {text: '忽略'}], '提示', 'warn');
                                    }
                                }
                            });
                        }
                    }
                },ready: function(){
                    //标题控制
                    var that = this;
                    $(".js_moretextplace").width($(".js_moretext").width());
                    $(".js_moretext").keyup(function(){
                        var inputStr = that.archive.title.replace(/\r|\n/g,"");
                        $(".js_moretextplace").html(inputStr.replace(/\s/g,"&nbsp;"));
                        if($(".js_moretextplace").height() > 0){
                            $(this).height($(".moretext-place").height());
                        } else {
                            $(this).height(45);
                        }
                        if(inputStr.length > 50){
                            $(".js_errortips").removeClass("f-hide");
                            $(".errortips .num").text(inputStr.length - 50);
                        } else {
                            console.log(inputStr.length);
                            $(".js_errortips").addClass("f-hide");
                        }
                    });

                    this.setTimer();
                    this.checkDraft();
                    $('#previeFrame').height($('#main-div').height()-80);
                    for(var i=0;archive.article.attachments && i<archive.article.attachments.length;i++){
                        this.pptFiles.push({uploader: null, percent: 0, name: archive.article.attachments[i].name, uploading: false, file_id: archive.article.attachments[i].id, file_error:'', 
                            url: archive.article.attachments[i].url, id: '', size: archive.article.attachments[i].size});
                    }
                    TIG.editor({
                        id: 'content',
                        height: 400,
                        width: 720,
                        value: archive.article.content,
                        showRelativePath: false,
                        docToHtmlPath: '/course/doc2Html',
                        imageUploadPath: '/article/editorUploadImage',
                        buttons: ['fontfunc','emoticons', 'addsource', 'link', 'table', 'image','video','audio','ppt','|','word', 'switchmarkdown'],
                        placeholder: '请输入正文',
                        wrapperClass: 'tig-image-center',
                        pptFilesAdded: function(up, files){
                            up.pptIndex = view.pptFiles.length;
                            view.pptFiles.push({uploader: up, percent: 0, name: files[0].name, uploading: true, id: files[0].id, file_error:'', url: '', file_id: 0, size: files[0].size});
                            view.pptFiles.length>=10 && (TIG.disablePPT = true);
                        },pptUploadProgress: function(up, file){
                            view.pptFiles[up.pptIndex].percent = file.percent;
                        },pptFileUploaded: function(up, file, resp){
                            view.pptFiles[up.pptIndex].uploading = false;
                            view.pptFiles[up.pptIndex].url = resp.image_url;
                            view.pptFiles[up.pptIndex].file_id = resp.data;
                        },pptError: function(up, msg){
                            view.pptFiles[up.pptIndex].file_error = msg;
                        },
                        afterCreate: function(){
                            var editor = this;
                            var func = function(){
                                var cont = $(editor.iframe).parent();
                                var h1 = cont.height();
                                var h2 = editor.doc.body.scrollHeight;
                                (h1 - h2 > 0.1 || h1 - h2 < -0.1) && cont.height(h2);
                            };
                            $(editor.doc).on('scroll paste keyup input', func);
                            setTimeout(func, 3000);
                            func();
                            init_scroll();
                            editor.toolbar.children('.editor-ico-fontfunc').click();
                        }
                    });
                    if(archive && archive.article.content_type == 1){
                        TIG.switchmarkdown('content_md', $('#editor-content'));
                    }
                    init_upload();
                    $('#title').focus();
                    if(isIE89){
                        $('textarea[placeholder], input[placeholder]').each(function(){
                            var placeholder = $(this).attr('placeholder');
                            $(this).click(function(){
                                if($(this).val() == placeholder){
                                    $(this).val('');
                                }
                            });
                            $(this).blur(function(){
                                var element = $(this);
                                setTimeout(function(){
                                    if(!element.val()){
                                        element.val(placeholder);
                                    }
                                }, 100);
                            }).trigger('blur');
                        });
                    }
                }
            });
        }
    };
});