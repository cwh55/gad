define(['vue', 'jquery', 'popup', 'app/community/community'], function(Vue, $, popup) {
    var vue = new Vue({
        el: '#main-app',
        data: {
            list: [],
            page: 0,
            pageSize: 20,
            classId: '',
            loadStatus: '',
            status: 1,
        },
        methods: {
            getList: function(refresh, status) {
                var vue = this;
                if(refresh){
                    vue.loadStatus = '';
                    vue.list = [];
                    vue.page = 0;
                }
                if (vue.loadStatus) {
                    return;
                }
                if(status){
                    vue.status = status;
                }
                vue.loadStatus = 'loading';
                $.ajax({
                    url: '/draft/list', type: 'get', data: {page: this.page, classId: this.classId, status: this.status}, dataType: 'json', 
                    complete: function(resp) {
                        vue.loadStatus = '';
                        var recv = resp.responseJSON;
                        if (typeof recv === 'object') {
                            vue.loadStatus = recv.length < vue.pageSize ? 'nomore' : '';
                            vue.list = vue.list.concat(recv);
                            vue.page++;
                        }
                    }
                });
            },
            deleteDraft: function(index){
                var vue = this;
                var archive = vue.list[index];
                var url = archive.class_id == 1 ? '/article/delete' : '/gallery/delete-atlas';
                popup.showPopup('warn','提示','确定删除吗',function(){
                    $.ajax({url: url, type: 'post', headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}, data: {id: archive.id}, dataType: 'json', complete: function(resp){
                        var recv = resp.responseJSON;
                        if(recv && recv.code == 0){
                            vue.list.splice(index, 1);
                        }else{
                            popup.showPopup('warn','操作失败', recv.msg || (recv.message instanceof Object ? JSON.stringify(recv.message) : recv.message) || '删除出错');
                        }
                    }});
                });
            }
        },
        ready: function(){
            var vue = this;
            $(window).scroll(function() {
                var sHeight = document.documentElement.scrollTop || document.body.scrollTop;
                var wHeight = document.documentElement.offsetHeight;
                var dHeight = document.documentElement.scrollHeight;
                if (dHeight - (sHeight + wHeight) < 50) {
                    vue.getList();
                }
            });
            var paras = window.location.search.match(/[?&]status=([-]?\d+)/i);
            if(paras && paras[1]){
                vue.status = paras[1]*1;
            }
            vue.getList();
        }
    });
});