define(['vue', 'jquery'], function(Vue, $) {
        
    return {
        init: function(isLogin){
            if(!isLogin){
                return;
            }
            var tt = localStorage['show_guid_tt2'];
            //如果没有设置标签，一个月检查一次
            if(tt && (new Date()).valueOf() - tt < 1000*3600*24*30){
                return;
            }
            if(!$('#m-guide').length){
                return;
            }
            var vm = new Vue({
                el: '#m-guide',
                data: {
                    list: [],
                    selectCount: {plan: 0, art:0, program: 0, vr: 0},
                    selectTab: '',
                    selectList: [],
                    dict: {10001: 'plan', 10396: 'art', 10591: 'program', 10877: 'vr'}, //游戏策划 10001,游戏美术 10396,游戏开发 10591,VR/AR 10877
                    isLoading: false,
                    step: 1,
                    isSubmiting: false,
                    followList: [],
                    followListPage: 0,
                    showFollowList: [],
                    selectFollowList: []
                },
                methods: {
                    init: function(myList, myFollowList, recommendOperation) {
                        for(var i=0;myList && i<myList.length;i++){
                            vm.selectList.push(myList[i].id*1);
                        }
                        for(var i=0;i<myFollowList.length;i++){
                            vm.selectFollowList.push(myFollowList[i].follow_user*1);
                        }
                        if(myList.length){
                            vm.step = 2;
                        }
                        $('#m-guide').removeClass('f-hide');
                        vm.isLoading = true;
                        $.ajax({url: '/article/recommend-info', type: 'get', dataType: 'json', success: function(recv) {
                            if (recv.code == 0) {
                                vm.isLoading = false;
                                vm.list = recv.data.tagList;
                                vm.followList = recv.data.followList;
                                vm.genShowFollowList();
                                var listIds = {};
                                for(var i=0;i<vm.list.length;i++){
                                    listIds[vm.list[i].id*1] = 1;
                                }
                                for(var i=0;myList && i<myList.length;i++){
                                    if(myList[i].p1 * 1 && listIds[myList[i].id*1]){
                                        vm.selectCount[vm.dict[myList[i].p1*1]]++;
                                    }
                                }
                            } else {
                                vm.hideGuid();
                            }
                        }, error: function() {
                            vm.hideGuid();
                        }});
                    }, hideGuid: function(){
                        localStorage['show_guid_tt2'] = (new Date()).valueOf();
                        $('#m-guide').hide();
                    }, goHome: function(){
                        localStorage['show_guid_tt2'] = (new Date()).valueOf();
                        window.location.href = '/community';
                    }, selectTag: function(tagItem){
                        var selectIndex = vm.selectList.indexOf(tagItem.id*1);
                        var type = vm.dict[tagItem.p1*1];
                        if(selectIndex<0){
                            vm.selectCount[type]++
                            vm.selectList.push(tagItem.id*1);
                        }else{
                            vm.selectCount[type]--;
                            vm.selectList.splice(selectIndex, 1);
                        }
                    }, submitTag: function(){
                        if(vm.isSubmiting){
                            return;
                        }
                        vm.isSubmiting = true;
                        $.ajax({url: '/article/set-my-tags', type: 'post', headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}, dataType: 'json', data: {list: vm.selectList}, success: function(recv) {
                            vm.isSubmiting = false;
                            if (recv.code == 0) {
                                vm.step = 2;
                            }else{
                                alert(recv.msg);
                            }
                        }, error: function() {
                            alert('提交出错');
                            vm.isSubmiting = false;
                        }});
                    }, genShowFollowList: function(){
                        this.showFollowList = [];
                        this.followList.sort(function(){ return 0.5 - Math.random();});
                        for(var i=this.followListPage*8;i<(this.followListPage+1)*8;i++){
                            var j = i;
                            if(i>=this.followList.length){
                                //按顺序拉取下一批8个用户，不足八个的再从第一个开始补足八个展示；
                                j = i - this.followList.length;
                            }
                            this.showFollowList.push(this.followList[j]);
                        }
                    },
                    nextfollowListPage: function(){
                        if(++this.followListPage*8 > this.followList.length){
                            this.followListPage = 0;
                        }
                        this.genShowFollowList();
                    },
                    selectFollowUser: function(id){
                        var id = id*1;
                        var index = this.selectFollowList.indexOf(id)
                        if(index >= 0){
                            this.selectFollowList.splice(index, 1);
                        }else{
                            this.selectFollowList.push(id);
                        }
                    },
                    submitFollowUser: function(){
                        if(vm.isSubmiting){
                            return;
                        }
                        localStorage['show_guid_tt2'] = (new Date()).valueOf();
                        vm.isSubmiting = true;
                        $.ajax({url: '/article/follow-users', type: 'post', headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}, dataType: 'json', data: {list: vm.selectFollowList}, success: function(recv) {
                            vm.isSubmiting = false;
                            if (recv.code == 0) {
                                vm.step = 3;
                            }else{
                                alert(recv.msg);
                            }
                        }, error: function() {
                            alert('提交出错');
                            vm.isSubmiting = false;
                        }});
                    }
                }
            });
            $.get('/article/my-recommend-info', '', function(recv){
                if(recv.code == 0 && (!recv.data.recommendOperation.follow || !recv.data.recommendOperation.tag)){
                    vm.init(recv.data.tagList, recv.data.myFollowList, recv.data.recommendOperation);
                }
            }, 'json');
        }
    };
});