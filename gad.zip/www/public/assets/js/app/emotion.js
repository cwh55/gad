/**
 * 使用样例: <emotion v-on:emotionclick="emotionClick"></emotion>，其中emotionClick(emtionName)是自定义方法，emtionName是字符串
 * 注：需引入样式：
 */
define(['vue', 'jquery'],function(Vue, $){
    var imageList = {
        '微笑':'http://gad.qpic.cn/assets/images/face/0.gif',
        '撇嘴':'http://gad.qpic.cn/assets/images/face/1.gif',
        '色':'http://gad.qpic.cn/assets/images/face/2.gif',
        '发呆':'http://gad.qpic.cn/assets/images/face/3.gif',
        '得意':'http://gad.qpic.cn/assets/images/face/4.gif',
        '流泪':'http://gad.qpic.cn/assets/images/face/5.gif',
        '害羞':'http://gad.qpic.cn/assets/images/face/6.gif',
        '闭嘴':'http://gad.qpic.cn/assets/images/face/7.gif',
        '大哭':'http://gad.qpic.cn/assets/images/face/8.gif',
        '尴尬':'http://gad.qpic.cn/assets/images/face/9.gif',
        '发怒':'http://gad.qpic.cn/assets/images/face/10.gif',
        '调皮':'http://gad.qpic.cn/assets/images/face/11.gif',
        '龇牙':'http://gad.qpic.cn/assets/images/face/12.gif',
        '惊讶':'http://gad.qpic.cn/assets/images/face/13.gif',
        '难过':'http://gad.qpic.cn/assets/images/face/14.gif',
        '酷':'http://gad.qpic.cn/assets/images/face/15.gif',
        '冷汗':'http://gad.qpic.cn/assets/images/face/16.gif',
        '抓狂':'http://gad.qpic.cn/assets/images/face/17.gif',
        '吐':'http://gad.qpic.cn/assets/images/face/18.gif',
        '偷笑':'http://gad.qpic.cn/assets/images/face/19.gif',
        '可爱':'http://gad.qpic.cn/assets/images/face/20.gif',
        '白眼':'http://gad.qpic.cn/assets/images/face/21.gif',
        '傲慢':'http://gad.qpic.cn/assets/images/face/22.gif',
        '饥饿':'http://gad.qpic.cn/assets/images/face/23.gif',
        '困':'http://gad.qpic.cn/assets/images/face/24.gif',
        '惊恐':'http://gad.qpic.cn/assets/images/face/25.gif',
        '流汗':'http://gad.qpic.cn/assets/images/face/26.gif',
        '憨笑':'http://gad.qpic.cn/assets/images/face/27.gif',
        '大兵':'http://gad.qpic.cn/assets/images/face/28.gif',
        '奋斗':'http://gad.qpic.cn/assets/images/face/29.gif',
        '咒骂':'http://gad.qpic.cn/assets/images/face/30.gif',
        '疑问':'http://gad.qpic.cn/assets/images/face/31.gif',
        '嘘':'http://gad.qpic.cn/assets/images/face/32.gif',
        '晕':'http://gad.qpic.cn/assets/images/face/33.gif',
        '折磨':'http://gad.qpic.cn/assets/images/face/34.gif',
        '衰':'http://gad.qpic.cn/assets/images/face/35.gif',
        '骷髅':'http://gad.qpic.cn/assets/images/face/36.gif',
        '敲打':'http://gad.qpic.cn/assets/images/face/37.gif',
        '再见':'http://gad.qpic.cn/assets/images/face/38.gif',
        '擦汗':'http://gad.qpic.cn/assets/images/face/39.gif',
        '抠鼻':'http://gad.qpic.cn/assets/images/face/40.gif',
        '鼓掌':'http://gad.qpic.cn/assets/images/face/41.gif',
        '糗大了':'http://gad.qpic.cn/assets/images/face/42.gif',
        '坏笑':'http://gad.qpic.cn/assets/images/face/43.gif',
        '左哼哼':'http://gad.qpic.cn/assets/images/face/44.gif',
        '右哼哼':'http://gad.qpic.cn/assets/images/face/45.gif',
        '哈欠':'http://gad.qpic.cn/assets/images/face/46.gif',
        '鄙视':'http://gad.qpic.cn/assets/images/face/47.gif',
        '委屈':'http://gad.qpic.cn/assets/images/face/48.gif',
        '快哭了':'http://gad.qpic.cn/assets/images/face/49.gif',
        '阴险':'http://gad.qpic.cn/assets/images/face/50.gif',
        '亲亲':'http://gad.qpic.cn/assets/images/face/51.gif',
        '吓':'http://gad.qpic.cn/assets/images/face/52.gif',
        '可怜':'http://gad.qpic.cn/assets/images/face/53.gif',
        '菜刀':'http://gad.qpic.cn/assets/images/face/54.gif',
        '西瓜':'http://gad.qpic.cn/assets/images/face/55.gif',
        '啤酒':'http://gad.qpic.cn/assets/images/face/56.gif',
        '篮球':'http://gad.qpic.cn/assets/images/face/57.gif',
        '乒乓':'http://gad.qpic.cn/assets/images/face/58.gif',
        '拥抱':'http://gad.qpic.cn/assets/images/face/59.gif',
        '握手':'http://gad.qpic.cn/assets/images/face/60.gif',
        '睡觉':'http://gad.qpic.cn/assets/images/face/61.gif',
        '饭':'http://gad.qpic.cn/assets/images/face/62.png',
        '猪头':'http://gad.qpic.cn/assets/images/face/63.png',
        '玫瑰':'http://gad.qpic.cn/assets/images/face/64.png',
        '凋谢':'http://gad.qpic.cn/assets/images/face/65.png',
        '爱心':'http://gad.qpic.cn/assets/images/face/66.png',
        '闪电':'http://gad.qpic.cn/assets/images/face/67.png',
        '炸弹':'http://gad.qpic.cn/assets/images/face/68.png',
        '月亮':'http://gad.qpic.cn/assets/images/face/69.png',
        '太阳':'http://gad.qpic.cn/assets/images/face/70.png',
        '礼物':'http://gad.qpic.cn/assets/images/face/71.png',
        'OK':'http://gad.qpic.cn/assets/images/face/72.png',
        '飞吻':'http://gad.qpic.cn/assets/images/face/73.png',
        '发抖':'http://gad.qpic.cn/assets/images/face/74.png'
    };
    Vue.component('emotion',{
        template: 
                '<button class="icon-emjoy">{{counter}}'+
                    '<div class="show-face-box">'+
                        '<div class="faceDiv g-scrollbar"><img v-for="image in imageList" v-bind:title="$key" v-bind:src="image""></div>'+
                    '</div>'+
                '</button>',
        data: function(){
            return {imageList: imageList};
        }, 
        ready: function(){
            var vm = this;
            var container = $(this.$el);
            //点击显示表情选择框
            container.on("click", function(e) {
                e.stopPropagation();
                $(".show-face-box", container).show();
                vm.$emit('emotionpop');
            });
            $('body').click(function(){
                $(".show-face-box", container).hide();
            });
            $('img', container).click(function(e){
                e.stopPropagation();
                $(".show-face-box", container).hide();
                vm.$emit('emotionclick', $(this).attr('title'));
            });
        }
    });
    return {
        toHtml: function(text){
            var reg = /\[[^\]]+\]/g;
            return text.replace(reg, function(match){
                var m = match.substr(1, match.length-2);
                if(imageList[m]){
                    return '<img class="emotion" title="'+m+'" src="'+imageList[m]+'" />';
                }else{
                    return match;
                }
            });
        }
    };
});