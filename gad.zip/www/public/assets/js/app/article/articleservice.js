define(['jquery', 'angular'], function ($, angular) {
    var service = angular.module('gad.article.service', []);

    //Article Service
    service.factory('Article', ['$http', function ($http) {
        return {
            save: function (article) {
                if (article.id) {
                    return $http.post('/article/edit/' + article.id, article);
                } else {
                    return $http.post('/article/create', article);
                }
            }
        }
    }]);
});
