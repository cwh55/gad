define(['jquery', 'angular', 'lodash', 'require','markdown-libs','angular-sanitize', 'ui-select', 'ng-file-upload', 'tig-editor', 'app/article/articleservice'], function ($, angular, _, require) {
    function getUrlParam(name){
		var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
		var r = window.location.search.substr(1).match(reg);
		if (r != null) return unescape(r[2]); return null;
    }
    var app = angular.module('gad.article', ['ngSanitize', 'ngFileUpload', 'ui.select', 'gad.article.service']);

    var article = {title: '', content: '', contents: '', label: '',channel_id: '',class_id: '',attachments: [],imgfile:{}};
    var testEditor;
    var ismarkdown = false;
    function changeToMarkdown(content){
        $("#editor-article-desc").hide();
        $("#article-editormd").show();
        ismarkdown = true;
        if(testEditor){

        }else{
            require(markdowndeps, function(editormd) {
                testEditor = editormd("article-editormd", {
                    width: "89%",
                    height: 640,
                    value: content,
                    imageUpload : true,
                    imageFormats : ["jpg", "jpeg", "gif", "png"],
                    imageUploadURL : "/article/editorUploadImage",
                    onload : function() {
                        //this.setMarkdown(content);
                    }
                });
            });
        }   
    }
    app.controller('CreateArticleCtrl', ['$scope', 'Upload', 'Article', function ($scope, Upload, Article) {
        $scope.article = article;
        $scope.modal = {
            isOpened: false,
            messages: [],
            show: function () {
                this.isOpened = true;
            },
            close: function () {
                this.isOpened = false;
                this.messages = [];
            }
        };
		$scope.upFile = function(files){
			_.forEach(files, function(img){
				var imgfile = {name:img.name, state:'false'}
				$scope.article.imgfile = imgfile;
				Upload.upload({
					url:"/article/editorUploadImage",
					data:{
						Filedata:img,
						_token:$('meta[name="scrf-token"]').attr('content'),
					}
				}).then(function(res){
					if(!res.data){
						alert(res.data.message);
						return;
					}
					imgfile.state = 'true';
					imgfile.cover = res.data;
				},function(res){
					alert('上传文件出错');
				},function(evt){
					imgfile.progress = parseInt(100 * evt.loaded / evt.total) + '%';
				});
			});
		};
        //上传附件
        $scope.uploadFile = function (files) {
			console.log('in');
            _.forEach(files, function (_file) {
                var attachment = {name: _file.name, state: 'uploading', progress: '0%'};
                $scope.article.attachments.push(attachment);
                Upload.upload({
                    url: '/article/uploadAttachment',
                    data: {
                        file: _file,
                        _token: $('meta[name="csrf-token"]').attr('content')
                    }
                }).then(function (res) {
                    if (res.data.code) {
                        alert(res.data.message);
                        return;
                    }

                    attachment.url = res.data.url;
                    attachment.state = 'uploaded';
                    attachment.size = res.data.size;
                }, function (res) {
                    alert('附件上传出错');
                }, function (evt) {
                    attachment.progress = parseInt(100 * evt.loaded / evt.total) + '%';
                });
            });
        };

        $scope.changeMarkdown = function(){
            changeToMarkdown();
        }
        $scope.changeTigeditor = function(){
            $("#editor-article-desc").show();
            $("#article-editormd").hide();
            ismarkdown = false;
        }
        $scope.deleteAttachment = function (attachment, index) {
            if (confirm('您确定要删除附件[' + attachment.name + ']？')) {
                $scope.article.attachments.splice(index, 1);
            }
        };

        $scope.saveArticle = function(){
			if(!$scope.article.class_id){
				$scope.article.class_id = getUrlParam('classid');
			}
            if(isNaN($scope.article.class_id)){
                valid = false;
                $scope.modal.messages.push('分类不合法');
            }
            var editor = TIG.editor.getInstance('article-desc');
            if(ismarkdown){
                $scope.article.content = testEditor.getHTML();
                $scope.article.contents = testEditor.getMarkdown();
            }else{
                $scope.article.content = editor.html();
            }
			$scope.article.cover = $scope.article.imgfile.cover;
            $scope.article.label = $("#tag").val();
            var valid = true;
            if (!$scope.article.title) {
                valid = false;
                $scope.modal.messages.push('文章标题不能为空');
            }
            if (!$scope.article.content) {
                valid = false;
                $scope.modal.messages.push('文章内容不能为空');
            }
            if (!$scope.article.label) {
                valid = false;
                $scope.modal.messages.push('文章标签不能为空');
            }
            if (!valid) {
                return $scope.modal.show();
            }
            _.forEach($scope.article.attachments, function (attachment) {
                _.unset(attachment, 'state');
                _.unset(attachment, 'progress');
            });

            Article.save($scope.article).success(function(data){
                if(data.code < 0){
                    if(data.code==-1111){
                        location.href="/login";
                    }
                    $scope.modal.messages.push(data.message);
                }else{
                    location.href = '/article/detail/'+data.code;
                }
                if ($scope.modal.messages.length) {
                    $scope.modal.show();
                }
            }).error(function(res){
                if (res.code == 422) {
                    angular.forEach(res.message, function (messages, field) {
                        angular.forEach(messages, function (message) {
                            $scope.modal.messages.push(message);
                        });
                    });
                } else {
                    $scope.modal.messages.push(res.message ? res.message : '参数错误');
                }

                if ($scope.modal.messages.length) {
                    $scope.modal.show();
                }
            });
        }
        $scope.cancelSave = function(){
            history.go(-1);
        }
    }]);

    

    return {
        init: function (_article) {
            if (_article) {
                article = _article;
                if(article.attachments){
                    article.attachments = JSON.parse(article.attachments);
                }else{
                    article.attachments = [];
                }
            }
            TIG.editor({
                id: 'article-desc',
                height: 300,
                width: 940,
                value: article.content,
                showRelativePath: false,
                docToHtmlPath:'/course/doc2Html',
                imageUploadPath: '/article/editorUploadImage',
                buttons: [ 'bold','italic','underline','font','size','color','insertorderedlist',
                    'insertunorderedlist','justify', 'link','table','image','word', 'source', 'fullscreen']
            });
            if(article.contents!=""){
                changeToMarkdown(article.contents);
            }
			if(article.cover){
				article.imgfile = {'cover':article.cover,'state':'true'};
			}
            
            angular.bootstrap(document, ['gad.article']);
        }
    };
});
