'use strict';

/**
 * @ngdoc function
 * @name yoApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the yoApp
 */
angular.module('angularWaterfallApp',["angular-loading-bar","ngWaterfall", "ui.router"])
    .config(['$stateProvider', '$urlRouterProvider','cfpLoadingBarProvider',
        function ($stateProvider,   $urlRouterProvider, cfpLoadingBarProvider) {
            //cfpLoadingBarProvider.spinnerTemplate = '<div><span class="fa fa-spinner">Loading...</div>';
            cfpLoadingBarProvider.parentSelector = '.m_loader';
            cfpLoadingBarProvider.spinnerTemplate = '<div class="inner">数据加载中</div>';
    }])
    .factory("myService",function($http){
        return {
            getImages : function(page, order){
                function parseUrlParam(name) {
                    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)","i");
                    var r = window.location.search.substr(1).match(reg);
                    if (r!=null) return (r[2]); return null;
                }
                return $http.get('/art/getlist?page='+page+'&order='+order+'&id='+parseUrlParam('classid'));
            }
        }
    })
  .controller('MainCtrl', function ($scope,$rootScope,$state,$location,$timeout,myService) {
        $scope.page = 1;
        $scope.images = [];
        $scope.total = 0;
        $scope.order = 'new';
        $scope.newclass = 'cur';
        $scope.hotclass = '';

        $scope.text = "点我加载更多"
        $scope.loadMore = true;
        
        $scope.changeTab = function(order) {
            $scope.newclass = '';
            $scope.hotclass = '';
            $scope[order+'class'] = 'cur';

            $scope.order = order;
            //$scope.images.length = 0;
            $scope.images = [];
            $scope.total = 0;
            $scope.page = 1;
            $scope.loadMore = true;
            $scope.loadMoreData();
        }

        $scope.loadMoreData = function(){
            $scope.text = "加载中，请稍后···";
            $timeout(function(){
                myService.getImages($scope.page, $scope.order).success(function(data) {
                    $scope.page++;
                    if(data.data.length>0) {
                        $scope.images = $scope.images.concat(data.data);
                    } else {
                        $scope.text = "内容已经全部加载完毕";
                        $scope.loadMore = false;
                    }
                    $scope.total = data.total;
                    //$(".waterfalldiv").show();
                    document.getElementById('waterfalldiv').style.display = 'block';
                });
                $scope.text = "点我加载更多···"
            },50);
        };

        $scope.loadMoreData();

        $scope.$on("waterfall:loadMore",function(){//滚动自动填充事件
           if($scope.loadMore) {
                $scope.loadMoreData();
           }
        });
  });
 
 angular.bootstrap(document, ['angularWaterfallApp']);

