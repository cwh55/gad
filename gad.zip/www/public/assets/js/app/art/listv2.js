define(['mustache', 'jq-waterfall'], function(Mustache) {
	var artList = {
		changeTab: function(link) {
			$(".filter-type a").removeClass('cur');
			$(link).addClass('cur');
			$('#container').waterfall('reset', function() {
                //$('#waterfall-message').html('<p style="color:#666;">没有更多数据了</p>');
                
            });
		},
		init: function() {
			$(".filter-type a").on('click', function(e) {
				artList.changeTab(e.target);
			});
			artList.show();
		},
		parseUrlParam: function(name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)","i");
            var r = window.location.search.substr(1).match(reg);
            if (r!=null) return (r[2]); return null;
        },
		show: function() {

			$('#container').waterfall({
                itemCls: 'item',
                colWidth: 262.5,  
                gutterWidth: 5,
                gutterHeight: 10,
                fitWidth: true,
                minCol: 4,
                resizable: false,
                checkImagesLoaded: false,
                align: 'left',
                path: function(page) {
                    var p = (page-1).toString();
                    var order = $('.filter-type a.cur').data('order');
					var classid = artList.parseUrlParam('classid');
                    return '/art/getlist?&order='+order+'&id='+classid+'&page='+p;
                },
                callbacks: {
                   renderData: function (data) {
                       if(data.data.length<=0) {
                       	 $('#container').waterfall('pause', function() {
		                    $('#waterfall-message').html('<p style="color:#666;">没有更多数据了</p>');
		                });
                       } else {
                       		var template = $('#waterfall-tpl').html();
                       		return Mustache.to_html(template, data).replace(/^\s*/mg, '');
                       }
                   }
                }
            });
		}
	}
	return artList;
});