define(['jquery', 'angular', 'lodash', 'angular-sanitize', 'ui-select', 'ng-file-upload', 'tig-editor', 'app/art/service'], function ($, angular, _) {
    var app = angular.module('gad.art', ['ngSanitize', 'ngFileUpload', 'ui.select', 'gad.art.service']);
    //var types = [];
    var artwork = {title: '', content: [], description: '', label:''};
        //qq_qun: '', qq_qun_name: '', teachers: [], assistants: []};

    app.controller('CreateArtWorkCtrl', ['$scope', 'Upload', 'ArtWork', function ($scope, Upload, ArtWork) {
        $scope.artwork = artwork;
        //$scope.types = types;
        //$scope.selected = {teachers: course.teachers ? course.teachers : []};
        //$scope.teachers = [];

        var thumbnailBox = $('.create-thumbnail-img');
        //if ($scope.course.thumbnail) {
            //thumbnailBox.css('background-image', 'url(' + $scope.course.thumbnail + ')');
        //}

        $scope.uploadThumb = function (file) {
            if (!file) {
                return;
            }

            thumbnailBox.addClass('img-uploading');
            Upload.upload({
                url: '/art/uploadImage',
                data: {
                    file: file,
                    _token: $('meta[name="csrf-token"]').attr('content')
                }
            }).then(function (res) {
                if (res.data.code) {
                    var message = res.data.message == 'ERROR_PHOTO_COMPRESS' ? '图片格式错误' : '图片上传出错';
                    thumbnailBox.removeClass('img-uploading')
                    alert(message);
                    return;
                }

                //$scope.course.thumbnail = res.data.data.downloadUrl;
                $scope.artwork.content.push(res.data.data.downloadUrl);
                thumbnailBox.removeClass('img-uploading').css('background-image', 'url(' + $scope.course.thumbnail + ')');
            }, function (res) {
                thumbnailBox.removeClass('img-uploading');
                alert('图片上传出错');
            });
        };

        $scope.modal = {
            isOpened: false,
            messages: [],
            show: function () {
                this.isOpened = true;
            },
            close: function () {
                this.isOpened = false;
                this.messages = [];
            }
        };

        $scope.removeWork = function(link) {
            if(confirm('确定删除?')) {
                $scope.artwork.content.splice($(link).siblings('img').attr('src'), 1);
            }
        }

        $scope.parseUrlParam = function(name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)","i");
            var r = window.location.search.substr(1).match(reg);
            if (r!=null) return (r[2]); return null;
        }

        $scope.saveArtWork = function () {
            var valid = true;
            $scope.artwork.class_id = $scope.parseUrlParam('classid');
            if ($scope.artwork.content.length<=0) {
                valid = false;
                $scope.modal.messages.push('作品未上传');
            } else {
                //$scope.artwork.content = $scope.artwork.works;
            }

            if(!$scope.artwork.title) {
                 valid = false;
                $scope.modal.messages.push('标题未填写');
            }

            var editor = TIG.editor.getInstance('artwork-desc');
            if (editor.isEmpty()) {
                valid = false;
                $scope.modal.messages.push('详细描述未填写');
            } else {
                $scope.artwork.description = editor.html();
            }

            $scope.artwork.label = $("#tag").val();

            if(!$scope.artwork.label) {
                valid = false;
                $scope.modal.messages.push('标签未填写');
            }

            if (!valid) {
                return $scope.modal.show();
            }

            ArtWork.save($scope.artwork).success(function (res) {
                //alert('保存成功');
                location.href = '/art/detail/' + res.id;
            }).error(function (res) {
                if (res.code == 422) {
                    angular.forEach(res.message, function (messages, field) {
                        angular.forEach(messages, function (message) {
                            $scope.modal.messages.push(message);
                        });
                    });

                } else if(res.code == 423) {

                    $scope.modal.messages.push(res.msg);
                    
                } else {
                    $scope.modal.messages.push(res.message ? res.message : '系统错误，请联系管理员');
                }

                if ($scope.modal.messages.length) {
                    $scope.modal.show();
                }
            });
        };
    }]);

    app.filter('firstType', function () {
        return function (types, topTypeId) {
            var select = _.find(types, {id: topTypeId});
            if (!select) {
                return [];
            }

            return select.subs;
        }
    });

    app.directive('ngMaxwidth', function () {
        var castStrWidth = function (str) {
            var len = str.length;
            var width = 0;
            var i = 0;
            for (; i < len; i++) {
                if (str.charCodeAt(i) > 256) {
                    width++;
                } else {
                    width += 0.5;
                }
            }

            return width;
        };

        return {
            restrict: 'A',
            require: '?ngModel',
            link: function(scope, elm, attr, ctrl) {
                if (!ctrl) return;

                var maxwidth = -1;
                attr.$observe('ngMaxwidth', function(value) {
                    var intVal = parseInt(value, 10);
                    maxwidth = isNaN(intVal) ? -1 : intVal;
                    ctrl.$validate();
                });
                ctrl.$validators.maxwidth = function(modelValue, viewValue) {
                    return (maxwidth < 0) || ctrl.$isEmpty(viewValue) || (castStrWidth(viewValue) <= maxwidth);
                };
            }
        };
    });

    return {
        init: function (_artwork) {
            //types = _types;
            if (_artwork) {
                artwork = _artwork;
            }

            TIG.editor({
                id: 'artwork-desc',
                height: 300,
                value: artwork.description,
                showRelativePath: false,
                docToHtmlPath:'/course/doc2Html',
                imageUploadPath: '/course/editorUploadImage',
                buttons: [ 'bold','italic','underline','font','size','color','insertorderedlist',
                    'insertunorderedlist','justify', 'link','table','image','word', 'source', 'fullscreen']
            });

            angular.bootstrap(document, ['gad.art']);
        }
    };
});
