define(['jquery', 'angular'], function ($, angular) {
    var service = angular.module('gad.art.service', []);

    //Article Service
    service.factory('ArtWork', ['$http', function ($http) {
        return {
            save: function (artwork) {
                if (artwork.id) {
                    return $http.post('/art/edit/' + artwork.id, artwork);
                } else {
                    return $http.post('/art/create', artwork);
                }
            },
            getList: function(page) {
                return $http.get('/art/getlist?page='+page);
            }
        }
    }]);
});
