/**
 * 使用样例
 * <project-list :id="1"></project-list>
 */
define(['vue', 'jquery'], function(Vue, $) {
    
    var getList = function(vue, callback) {
        if (vue.noMoreData || vue.isLoading) {
            return;
        }
        vue.isLoading = true;
        $.ajax({url: '/hatch/project/my-list', type: 'get', data: {page: vue.page}, dataType: 'json', success: function(recv) {
            vue.isLoading = false;
            if (recv.code == 0) {
                vue.page++;
                vue.list = vue.list.concat(recv.data);
                vue.isLoading = false;
                vue.noMoreData = recv.data.length < 20;
                callback && callback(recv.data);
            }
        }, error: function() {
            vue.isLoading = false;
        }});
    };
    
    Vue.component('project-list',{
        template: '<div class="m-quickfill" v-show="list.length>0 && !hideMe">\n\
            <div class="choice-tip" v-show="fadeouting">成功，你仍然可以继续完善资料。</div>\n\
            <div class="quickfill-wrap" v-show="!fadeouting">\n\
              <div class="quickfill-head">\n\
                <h4 class="quickfill-title">快速填写</h4>\n\
                <span class="quickfill-close gicos-close-1" @click="hide"></span>\n\
              </div>\n\
              <p class="quickfill-tip">你已经创建过以下项目，可以从中选择一个项目作为填表资料，无需重复填写。</p>\n\
              <ul class="quickfill-list f-clearfix js-project-list">\n\
                <li v-for="(index, li) in list" class="quickfill-item f-clearfix" :class="{\'active\': index==selectIndex}" @click="selectProject(index)">\n\
                  <a href="javascript:;">\n\
                    <div class="img-wrap">\n\
                      <img :src="li.logo" width="150" height="107" :alt="li.name">\n\
                    </div>\n\
                    <div class="info-wrap">\n\
                      <h6 class="item-title">{{li.name}}</h6>\n\
                      <div class="create-place">创建于 {{getCreatedFrom(li.created_from)}}</div>\n\
                      <div class="create-time">更新于 {{li.updated_at ? li.updated_at.substr(0,10) : "---"}}</div>\n\
                    </div>\n\
                  </a>\n\
                </li>\n\
                <li>\n\
                    <div class="m-dlmore" :class="{\'dl-loading\': isLoading, \'dl-nomore\': noMoreData}">\n\
                    <span class="dlmore-loading gico-loading loading-20">加载中</span>\n\
                    <span class="dlmore-nomore">没有更多项目</span>\n\
                  </div>\n\
                </li>\n\
              </ul>\n\
              <div class="quickfill-btn-group">\n\
                <button class="m-btn-primary quickfill-btn-suc" type="button" @click="confirmProject">确定</button>\n\
                <button class="m-btn-secondary quickfill-btn-new" type="button" @click="hide">我要重新填写</button>\n\
              </div>\n\
            </div>\n\
          </div>',
        props: {
            id: {type: Number, default: 0}
        }, 
        data: function(){
            return {list: [], page: 0, isLoading: false, noMoreData: false, selectIndex: -1, hideMe: false, fadeouting: false};
        },
        methods: {
            getList: function() {
                getList(this);
            },
            getCreatedFrom: function(id){
                var dict = ['手动创建', '项目扶持', '晨星计划', '大赛', '组队项目'];
                return dict[id*1] || '其他';
            },
            selectProject: function(index){
                this.selectIndex = index;
            },
            hide: function(){
                this.hideMe = true;
            },
            confirmProject: function(){
                var vue = this;
                if(this.selectIndex<0){
                    alert('请选择一个项目');
                    return;
                }else{
                    this.$emit('confirmproject', this.list[this.selectIndex]);
                    this.fadeouting = true;
                    setTimeout(function(){
                        vue.hide();
                    }, 3000);
                }
            }
        },
        ready: function(){
            var cssload = false;
            $('link[rel="stylesheet"]').each(function(){
                if($(this).attr('href') && $(this).attr('href')=='http://gad.qpic.cn/assets/v2/web/css/mod/quickfill/quickfill.css'){
                    cssload = true;
                }
            });
            if(!cssload){
                $('head').append('<link rel="stylesheet" href="http://gad.qpic.cn/assets/v2/web/css/mod/quickfill/quickfill.css" type="text/css" />');
            }
            var container = $(this.$el);
            var vue = this;
            $('.js-project-list', container).scroll(function() {
                if (this.scrollHeight - (this.scrollTop + this.offsetHeight) < 50 && !this.noMoreData) {
                    vue.getList();
                }
            });
            if(!this.id){
                this.getList();
            }
        }
    });
    
    Vue.component('project-push',{
        template: '<div class="edit-syn" v-show="list.length>0">\n\
                    <div class="m-synhatch">\n\
                        <div class="synhatch-selected">\n\
                            <label class="form-checkbox-wrap" @click="show"><span class="form-checkbox" :class="{\'checkbox-active\': needPush}" @click="togglePush($event)"></span>推送到我的项目</label>\n\
                            <a class="synhatch-explain f-hide" href="javascript:;">这是什么？</a>\n\
                            <a class="synhatch-name" href="javascript:;" v-show="selectedProject.id">《<span class="syntext">{{selectedProject.name}}</span>》</a>\n\
                        </div>\n\
                        <div class="synhatch-layer m-mask" v-show="!hideMe">\n\
                            <div class="synhatch-main mask-inner">\n\
                                <div class="synhatch-seltit">选择一个同步的项目</div>\n\
                                <a class="synhatch-selclose" href="javascript:;" @click="hide"><i class="gicos-close-1"></i></a>\n\
                                <ul class="synhatch-pjs">\n\
                                    <li v-for="(index, li) in list" class="pjitem" @click="selectProject(index)"><label class="form-radio-wrap"><span class="form-radio" :class="{\'radio-active\': selectIndex==index}"></span>{{li.name}}</label></li>\n\
                                </ul>\n\
                                <div class="synhatch-btnline">\n\
                                    <button class="m-btn-primary synhatch-btn" type="button" @click="confirmProject">确定</button>\n\
                                    <button class="m-btn-secondary synhatch-btn" type="button" @click="hide">取消</button>\n\
                                </div>\n\
                            </div>\n\
                        </div>\n\
                    </div>\n\
		</div>',
        props: {
            id: {type: Number, default: 0}
        },
        data: function(){
            return {list: [], page: 0, isLoading: false, noMoreData: false, selectIndex: -1, hideMe: true, selectedProject: {}, needPush: false};
        },
        methods: {
            getList: function() {
                var vue = this;
                getList(this, function(){
                    for(var i=0;i<vue.list.length;i++){
                        if(vue.list[i].id == vue.id){
                            vue.selectIndex = i;
                            vue.selectedProject = vue.list[i];
                        }
                    }
                });
            },
            selectProject: function(index){
                this.selectIndex = index;
            },
            hide: function(){
                this.hideMe = true;
            },
            show: function(){
                this.hideMe = false;
            },
            confirmProject: function(){
                if(this.selectIndex<0){
                    alert('请选择一个项目');
                }else{
                    this.selectedProject = this.list[this.selectIndex];
                    this.hide();
                    this.needPush = true;
                    this.emitConfirm();
                }
            },
            togglePush: function(e){
                if(this.selectIndex>=0){
                    e.stopPropagation();
                    this.needPush = !this.needPush;
                    this.emitConfirm();
                }
            },
            emitConfirm: function(){
                var id = this.needPush ? this.selectedProject.id : 0;
                this.$emit('projectselect', id);
            }
        },
        ready: function(){
            var container = $(this.$el);
            var vue = this;
            $('.synhatch-pjs', container).scroll(function() {
                if (this.scrollHeight - (this.scrollTop + this.offsetHeight) < 50 && !vue.noMoreData) {
                    vue.getList();
                }
            });
            this.getList();
            if(this.id){
                this.needPush = true;
            }
        }
    });
});