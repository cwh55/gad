define(['vue', 'jquery'], function(Vue, $) {
    var vue = new Vue({
        el: '#main-div',
        data: {
            category: '',
            list: [],
            page: 2,
            pageSize: 12,
            isLoading: false,
            noMoreData: false
        },
        methods: {
            getFeedList: function() {
                if (vue.noMoreData || vue.isLoading) {
                    return;
                }
                vue.isLoading = true;
                $.ajax({url: '/hatch/expert-plan/expert-list', type: 'get', data: {page: this.page, pageSize: this.pageSize, category: this.category}, dataType: 'json', success: function(recv) {
                        if (recv.code == 0) {
                            vue.page++;
                            vue.list = vue.list.concat(recv.data.data);
                            vue.isLoading = false;
                            vue.noMoreData = recv.data.data.length < vue.pageSize;
                        } else {
                            //alert('获取列表失败：'+recv.msg);
                        }
                    }, error: function() {
                        //alert('获取列表失败');
                    }});
            },
            swithCategory: function(category){
                this.category = category;
                this.list = [];
                this.page = 1;
                this.isLoading = false;
                this.noMoreData = false;
                $('#expert-list .expert-item-old').remove();
                this.getFeedList();
            }
        }
    });
    $(window).scroll(function() {
        var sHeight = document.documentElement.scrollTop || document.body.scrollTop;
        var wHeight = document.documentElement.offsetHeight;
        var dHeight = document.documentElement.scrollHeight;
        if (dHeight - (sHeight + wHeight) < 50) {
            vue.getFeedList();
        }
    });
    return list = {
        vue: vue
    };
});