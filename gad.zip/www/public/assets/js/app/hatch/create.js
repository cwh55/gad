define(['jquery', 'angular', 'lodash', 'require','popup', 'angular-sanitize', 'ui-select', 'ng-file-upload', 'tig-editor', 'app/hatch/hatchservice'], function ($, angular, _, require,popup) {  
    
    $('#main_form').show();
    
    var app = angular.module('gad.hatch', ['ngSanitize', 'ngFileUpload', 'ui.select', 'gad.hatch.service']);

    var hatch = {
        name: '',
        logo: [],
        type: 0,
        content: '',
        platform: 0,
        video: [],
        pic: [],
        ppt: [],
        ppt_pub: 0,
        demo: [],
        demo_pub: 0,
        cooperation: '',
    };
    
    var upload_failed_msg = '附件上传出错，请联系管理员1694008364协助上传。';
    
    app.controller('CreateHatchCtrl', ['$scope', 'Upload', 'Hatch', function($scope, Upload, Hatch) {
        $scope.hatch = hatch;
        $scope.hatch.type = "-1";
        $scope.hatch.platform = "-1";
        var picNum = hatch.pic.length;
        $scope.uploadLogo = function (files) {
            _.forEach(files, function (_file) {
                var attachment = {name: _file.name, state: 'uploading', progress: '0%'};
                $scope.hatch.logo = [attachment];

                Upload.upload({
                    url: '/hatch/uploadAttachment',
                    data: {
                        file: _file,
                        _token: $('meta[name="csrf-token"]').attr('content')
                    }
                }).then(function (res) {
                    if (res.data.code) {
                        popup.showPopup('warn','提示',res.data.message);
                        $scope.hatch.logo.pop();
                        return;
                    }

                    attachment.url = res.data.url;
                    attachment.state = 'uploaded';
                    attachment.size = res.data.size;

                }, function (res) {
                    popup.showPopup('error','提示',upload_failed_msg);
                    $scope.hatch.logo.pop();
                }, function (evt) {
                    attachment.progress = parseInt(100 * evt.loaded / evt.total) + '%';
                });
            });
        };
        $scope.deleteLogo = function (attachment, index) {
            if (confirm('您确定要删除附件[' + attachment.name + ']？')) {
                $scope.hatch.logo.splice(index, 1);
            }
        };


        $("#uploadVideoBtn").pan_upload({
            multipart_params: {csrf: $('meta[name="csrf-token"]').attr('content'), is_video: 1}, max_file_count: 1, multi_selection: false,
            filters: {max_file_size: '1000mb', mime_types: [{title: "视频文件", extensions: "mp4,flv,avi"}]}, flash_swf_url: '/assets/js/Moxie.swf',
            events: {
                FileUploaded: function(up, file, info) {
                    try{
                        var data = JSON.parse(info.response);
                        if(!data.success){
                            popup.showPopup('error','提示',upload_failed_msg);
                        }else{
                            if($scope.hatch.video.length>=3){
                                popup.showPopup('warn','提示','最多上传3个视频文件');
                                return;
                            }
                            $scope.$apply(function(){
                                var attachment = {name: file.name};
                                attachment.url =  'http://file.gad.qq.com/attachment/download?file_id='+data.data;
                                attachment.state = 'uploaded';
                                attachment.size = file.size;
                                attachment.uuid = data.video_id;
                                $scope.hatch.video.push(attachment);
                            });
                        }
                    }catch(e){
                        popup.showPopup('error','提示',upload_failed_msg);
                    }
                }, error: function(up, error, error_dealt){
                    !error_dealt && pan_alert(error.message);
                },
            }
        });
        $scope.deleteVideo = function (attachment, index) {
            if (confirm('您确定要删除附件[' + attachment.name + ']？')) {
                $scope.hatch.video.splice(index, 1);
            }
        };


        $scope.uploadPic = function (files) {
            if(picNum+files.length>10){
                popup.showPopup('warn','提示','图片数量不能超过十张');
                return;
            }
            _.forEach(files, function (_file) {
                var attachment = {name: _file.name, state: 'uploading', progress: '0%'};
                if($scope.hatch.pic.length>=10){
                    popup.showPopup('warn','提示','最多上传10张图片');
                    return;
                }
                if(_file.size > 10*1024*1024){
                    popup.showPopup('warn','提示','图片大小不能超过10MB');
                    return;
                }
                $scope.hatch.pic.push(attachment);

                Upload.upload({
                    url: '/hatch/uploadAttachment',
                    data: {
                        file: _file,
                        _token: $('meta[name="csrf-token"]').attr('content')
                    }
                }).then(function (res) {
                    if (res.data.code) {
                        popup.showPopup('error','提示',res.data.message);
                        $scope.hatch.pic.pop();
                        return;
                    }

                    attachment.url = res.data.url;
                    attachment.state = 'uploaded';
                    attachment.size = res.data.size;

                }, function (res) {
                    popup.showPopup('error','提示',upload_failed_msg);
                    $scope.hatch.pic.pop();
                }, function (evt) {
                    attachment.progress = parseInt(100 * evt.loaded / evt.total) + '%';
                });
            });
            picNum = picNum+files.length;
        };
        $scope.deletePic = function (attachment, index) {
            if (confirm('您确定要删除附件[' + attachment.name + ']？')) {
                $scope.hatch.pic.splice(index, 1);
                picNum = picNum-1;
            }
        };


        $scope.uploadPPT = function (files) {
            _.forEach(files, function (_file) {
                if(_file.size > 20*1024*1024){
                    popup.showPopup('warn','提示','PPT文件不能超过20MB');
                    return;
                }
                var attachment = {name: _file.name, state: 'uploading', progress: '0%'};
                $scope.hatch.ppt = [attachment];

                Upload.upload({
                    url: '/hatch/uploadAttachment',
                    data: {
                        file: _file,
                        _token: $('meta[name="csrf-token"]').attr('content')
                    }
                }).then(function (res) {
                    if (res.data.code) {
                        popup.showPopup('error','提示',res.data.message);
                        $scope.hatch.ppt.pop();
                        return;
                    }

                    attachment.url = res.data.url;
                    attachment.state = 'uploaded';
                    attachment.size = res.data.size;

                }, function (res) {
                    popup.showPopup('error','提示',upload_failed_msg);
                    $scope.hatch.ppt.pop();
                }, function (evt) {
                    attachment.progress = parseInt(100 * evt.loaded / evt.total) + '%';
                });
            });
        };
        $scope.deletePPT = function (attachment, index) {
            if (confirm('您确定要删除附件[' + attachment.name + ']？')) {
                $scope.hatch.ppt.splice(index, 1);
            }
        };

        $("#uploadGameBtn").pan_upload({
            multipart_params:  {csrf: $('meta[name="csrf-token"]').attr('content')}, max_file_count: 1, multi_selection: false,
            filters: {max_file_size: '3000mb', mime_types: [{title: "压缩包", extensions: "zip,rar"}]},
            flash_swf_url: '/assets/js/Moxie.swf',
            events: {
                FilesAdded: function(){$("#gameFileContainer").html('');},
                FileUploaded: function(up, file, info) {
                    try{
                        var data = $.parseJSON(info.response);
                        if(!data.success){
                            popup.showPopup('error','提示',upload_failed_msg);
                        }else{
                            $scope.$apply(function(){
                                var attachment = {name: file.name};
                                attachment.url =  'http://file.gad.qq.com/attachment/download?file_id='+data.data;
                                attachment.state = 'uploaded';
                                attachment.size = file.size;
                                $scope.hatch.demo = [attachment];
                            });
                        }
                    }catch(e){
                        popup.showPopup('error','提示',upload_failed_msg);
                    }
                }, error: function(up, error, error_dealt){
                    !error_dealt && pan_alert(error.message);
                }
            }
        });
        $scope.deleteDemo = function (attachment, index) {
            if (confirm('您确定要删除附件[' + attachment.name + ']？')) {
                $scope.hatch.demo.splice(index, 1);
            }
        };


        $(".u-checkbox :radio").click(function() {
            if ($(this).parent().hasClass("u-checked")) {
                $(this).parent().removeClass("u-checked");
            } else {
                $(this).parent().addClass("u-checked");
            }
        });
        $(".u-checkbox :checkbox").click(function() {
            if ($(this).parent().hasClass("u-checked")) {
                $(this).parent().removeClass("u-checked");
            } else {
                $(this).parent().addClass("u-checked");
            }
        });

        $scope.saveHatch = function () {
            $scope.hatch.name = $("#title").val();
            $scope.hatch.type = $("#gametype").val();
            $scope.hatch.platform = $("#platform").val();

            if (!$scope.hatch.name) {
                popup.showPopup('warn','信息不完整',"游戏名称不能为空");
                return;
            }
            if ($scope.hatch.type == -1) {
                popup.showPopup('warn','信息不完整',"请选择游戏类别");
                //alert("请选择游戏类别");
                return;
            }
            if ($scope.hatch.platform == -1) {
                popup.showPopup('warn','信息不完整',"请选择游戏平台");
                //alert("请选择游戏平台");
                return;
            }

            var editor = TIG.editor.getInstance('desc');
            $scope.hatch.content = editor.html();
            if (!$scope.hatch.content) {
                popup.showPopup('warn','信息不完整',"游戏简介不能为空");
                return;
                //alert("游戏简介不能为空");
            }            

            if (!$scope.hatch.logo[0]) {
                popup.showPopup('warn','信息不完整',"请上传Logo");
                //alert("请上传Logo");
                return;
            }
            if (!$scope.hatch.ppt[0]) {
                popup.showPopup('warn','信息不完整',"请上传ppt");
                //alert("请上传ppt");
                return;
            }

            $scope.hatch.ppt_pub = $("#ppub").hasClass('u-checked') ? 1 : 0;
            $scope.hatch.demo_pub = $("#dpub").hasClass('u-checked') ? 1 : 0;

            coop1 = $("#coop1").hasClass('u-checked') ? 1 : 0;
            coop2 = $("#coop2").hasClass('u-checked') ? 1 : 0;
            coop3 = $("#coop3").hasClass('u-checked') ? 1 : 0;
            $scope.hatch.cooperation = coop1+'|'+coop2+'|'+coop3;

            Hatch.save($scope.hatch).success(function(data){
                if(data.code < 0){
                    popup.showPopup('error','提示',data.message);
                }else{
                    location.href = '/hatch/detail/'+data.code;
                }
            }).error(function(res){
                console.log(res);
            });
            

        }
        $scope.cancelSave = function(){
            history.go(-1);
        }
        

    }]);
    /*

    var article = {title: '', content: '', contents: '', label: '',channel_id: '',class_id: '',attachments: []};
    var testEditor;
    var ismarkdown = false;
    function changeToMarkdown(content){
        $("#editor-article-desc").hide();
        $("#article-editormd").show();
        ismarkdown = true;
        if(testEditor){

        }else{
            require(markdowndeps, function(editormd) {
                testEditor = editormd("article-editormd", {
                    width: "89%",
                    height: 640,
                    value: content,
                    imageUpload : true,
                    imageFormats : ["jpg", "jpeg", "gif", "png"],
                    imageUploadURL : "/article/editorUploadImage",
                    onload : function() {
                        //this.setMarkdown(content);
                    }
                });
            });
        }   
    }
    app.controller('CreateArticleCtrl', ['$scope', 'Upload', 'Article', function ($scope, Upload, Article) {
        $scope.article = article;
        $scope.modal = {
            isOpened: false,
            messages: [],
            show: function () {
                this.isOpened = true;
            },
            close: function () {
                this.isOpened = false;
                this.messages = [];
            }
        };
        //上传附件
        $scope.uploadFile = function (files) {
            _.forEach(files, function (_file) {
                var attachment = {name: _file.name, state: 'uploading', progress: '0%'};
                $scope.article.attachments.push(attachment);
                Upload.upload({
                    url: '/article/uploadAttachment',
                    data: {
                        file: _file,
                        _token: $('meta[name="csrf-token"]').attr('content')
                    }
                }).then(function (res) {
                    if (res.data.code) {
                        alert(res.data.message);
                        return;
                    }

                    attachment.url = res.data.url;
                    attachment.state = 'uploaded';
                    attachment.size = res.data.size;
                }, function (res) {
                    alert('附件上传出错');
                }, function (evt) {
                    attachment.progress = parseInt(100 * evt.loaded / evt.total) + '%';
                });
            });
        };

        $scope.changeMarkdown = function(){
            changeToMarkdown();
        }
        $scope.changeTigeditor = function(){
            $("#editor-article-desc").show();
            $("#article-editormd").hide();
            ismarkdown = false;
        }
        $scope.deleteAttachment = function (attachment, index) {
            if (confirm('您确定要删除附件[' + attachment.name + ']？')) {
                $scope.article.attachments.splice(index, 1);
            }
        };

        $scope.saveArticle = function(){
            $scope.article.class_id = $.getUrlParam('classid');
            if(isNaN($scope.article.class_id)){
                valid = false;
                $scope.modal.messages.push('分类不合法');
            }
            var editor = TIG.editor.getInstance('article-desc');
            if(ismarkdown){
                $scope.article.content = testEditor.getHTML();
                $scope.article.contents = testEditor.getMarkdown();
            }else{
                $scope.article.content = editor.html();
            }
            $scope.article.label = $("#tag").val();
            var valid = true;
            if (!$scope.article.title) {
                valid = false;
                $scope.modal.messages.push('文章标题不能为空');
            }
            if (!$scope.article.content) {
                valid = false;
                $scope.modal.messages.push('文章内容不能为空');
            }
            if (!$scope.article.label) {
                valid = false;
                $scope.modal.messages.push('文章标签不能为空');
            }
            if (!valid) {
                return $scope.modal.show();
            }
            _.forEach($scope.article.attachments, function (attachment) {
                _.unset(attachment, 'state');
                _.unset(attachment, 'progress');
            });

            Article.save($scope.article).success(function(data){
                if(data.code < 0){
                    $scope.modal.messages.push(data.message);
                }else{
                    location.href = '/article/'+data.code;
                }
                if ($scope.modal.messages.length) {
                    $scope.modal.show();
                }
            }).error(function(res){
                if (res.code == 422) {
                    angular.forEach(res.message, function (messages, field) {
                        angular.forEach(messages, function (message) {
                            $scope.modal.messages.push(message);
                        });
                    });
                } else {
                    $scope.modal.messages.push(res.message ? res.message : '参数错误');
                }

                if ($scope.modal.messages.length) {
                    $scope.modal.show();
                }
            });
        }
        $scope.cancelSave = function(){
            history.go(-1);
        }
    }]);
    */
    

    return {
        init: function(_hatch) {
            if (_hatch) {
                hatch = _hatch;

                if(hatch.logo){
                    hatch.logo = JSON.parse(hatch.logo);
                }else{
                    hatch.logo = [];
                }
                if(hatch.videos){
                    hatch.video = JSON.parse(hatch.videos);
                }else{
                    hatch.video = [];
                }
                if(hatch.pictures){
                    hatch.pic = JSON.parse(hatch.pictures);
                }else{
                    hatch.pic = [];
                }
                if(hatch.ppt){
                    hatch.ppt = JSON.parse(hatch.ppt);
                }else{
                    hatch.ppt = [];
                }
                if(hatch.demo){
                    hatch.demo = JSON.parse(hatch.demo);
                }else{
                    hatch.demo = [];
                }

                hatch.type = hatch.game_type.toString();
                hatch.platform = hatch.os;
                
                coop = hatch.cooperation.split("|");
                if (coop[0] == 1) {
                    $("#coop1").addClass('u-checked');
                } else {
                    $("#coop1").removeClass('u-checked');
                }
                if (coop[1] == 1) {
                    $("#coop2").addClass('u-checked');
                } else {
                    $("#coop2").removeClass('u-checked');
                }
                if (coop[2] == 1) {
                    $("#coop3").addClass('u-checked');
                } else {
                    $("#coop3").removeClass('u-checked');
                }

                if (hatch.ppt_pub == 1) {
                    $("#ppub").addClass('u-checked');
                } else {
                     $("#ppub").removeClass('u-checked');
                }
                if (hatch.demo_pub == 1) {
                    $("#dpub").addClass('u-checked');
                } else {
                    $("#dpub").removeClass('u-checked');
                } 
            }

            TIG.editor({
                id: 'desc',
                height: 300,
                width: 700,
                value: hatch.description,
                showRelativePath: false,
                docToHtmlPath:'/course/doc2Html',
                imageUploadPath: '/article/editorUploadImage',
                buttons: [ 'bold','italic','underline','font','size','color','insertorderedlist',
                    'insertunorderedlist','justify', 'link','table','image','word', 'source', 'fullscreen']
            });
            angular.bootstrap(document, ['gad.hatch']);
        }

    };

});
