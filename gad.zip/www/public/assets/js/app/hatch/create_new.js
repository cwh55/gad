define(['jquery', 'vue', 'popup', 'pan_upload', 'cityselect'], function($, Vue, popup) {
    var token = $('meta[name="csrf-token"]').attr('content');
    var isIE89 = navigator.appVersion.indexOf("MSIE 9")>=0 || navigator.appVersion.indexOf("MSIE 8")>=0;
    var init_upload_temp = function(id, filters, view_upload, callback){
        if(view_upload.uploader || (isIE89 && !$("#"+id).is(':visible'))){
            return;
        }
        $("#"+id).pan_upload_raw({
            multipart_params: {csrf: token}, max_file_count: 1, multi_selection: false, flash_swf_url: '/assets/js/Moxie.swf',
            filters: filters,
            events: {
                Init: function(up) {
                    view_upload.uploader = up;
                }, FilesAdded: function(up, files) {
                    view_upload.percent = 0;
                    view_upload.uploading = true;
                    view_upload.id = files[0].id;
                    view_upload.name = files[0].name;
                    view_upload.files && view_upload.files.push(files[0].id);
                    if (!window.FileReader && files[0].size > 2 * 1024 * 1024) {
                        popup.showPopup('warn','提示','您的浏览器可能无法完成超过2M的文件上传，建议更换Chrome等现代浏览器完成大文件的上传哈');
                    }
                    up.disableBrowse(true);
                }, UploadProgress: function(up, file) {
                    view_upload.percent = file.percent;
                },
                FileUploaded: function(up, file, info) {
                    try {
                        up.disableBrowse(false);
                        view_upload.uploading = false;
                        var data = JSON.parse(info.response);
                        if (!data.success) {
                            popup.showPopup('warn','提示',"上传失败");
                        } else {
                            callback(data);
                        }
                    } catch (e) {
                        popup.showPopup('warn','提示',"上传失败");
                    }
                },
                Error: function(up, error) {
                    view_upload.uploading = false;
                    popup.showPopup('warn','提示',error.message);
                }
            }
        });
    };
    
    var view;
    
    var init_upload = function(view) {
//        init_upload_temp('id_card_picture', {max_file_size: '10mb', mime_types: [{title: "图片", extensions: "jpg,png"}]}, view.upload.id_card_picture, function(data){
//            view.register.id_card_picture = data.image_url;
//        });
//        init_upload_temp('business_license_pic', {max_file_size: '10mb', mime_types: [{title: "图片", extensions: "jpg,png"}]}, view.upload.business_license_pic, function(data){
//            view.register.business_license_pic = data.image_url;
//        });
        init_upload_temp('demo', {max_file_size: '3000mb', mime_types: [{title: "压缩包", extensions: "zip,rar"}] }, view.upload.demo, function(data){
            view.game.project.demo = [{url: 'http://file.gad.qq.com/attachment/download?file_id='+data.data, name: view.upload.demo.name}];
        });
        init_upload_temp('videos', {max_file_size: '2000mb', mime_types: [{title: "视频", extensions: "mp4,flv"}] }, view.upload.videos, function(data){
            view.game.project.videos = [{url: 'http://file.gad.qq.com/attachment/download?file_id='+data.data, name: view.upload.videos.name, uuid: data.video_id}];
        });
        init_upload_temp('logo', {max_file_size: '2mb', mime_types: [{title: "图片", extensions: "jpg,png"}]}, view.upload.logo, function(data){
            view.game.project.team_logo = data.image_url;
        });
        init_upload_temp('logo2', {max_file_size: '2mb', mime_types: [{title: "图片", extensions: "jpg,png"}]}, view.upload.logo2, function(data){
            view.game.project.team_logo = data.image_url;
        });
        init_upload_temp('other_attachment', {max_file_size: '1000mb', mime_types: [{title: "压缩包", extensions: "zip,rar"}] }, view.upload.other_attachment, function(data){
            view.game.project.other_attachment = [{url: 'http://file.gad.qq.com/attachment/download?file_id='+data.data, name: view.upload.other_attachment.name}];
        });
        init_upload_temp('pictures', {max_file_size: '10mb', mime_types: [{title: "图片", extensions: "jpg,png,bmp,gif"}]}, view.upload.pictures, function(data){
            view.game.project.pictures.push({url: data.image_url, name: view.upload.pictures.name});
        });
    };
    
    return {
        init: function(game){
            var blur = {game: {}, SMSCode: false};
            for(var i in game){
                if(i=='project'){
                    blur.game[i] = {};
                    for(var j in game[i]){
                        blur.game[i][j] = false;
                    }
                }else{
                    blur.game[i] = false;
                }
            }
            var upload = {
                //id_card_picture: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:''},
                //business_license_pic: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:''},
                demo: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:''},
                videos: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:''},
                logo: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:''},
                logo2: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:''},
                other_attachment: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:''},
                pictures: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:'', files: []}
            };
            if(!game.project){
                game.project = {
                    id: 0, name: '', platform: [], intro: '', demo:[], videos: [], other_attachment: [], pictures: [],
                    "team_type": '', "team_business_license": '', "team_name": '', "team_logo": '', "team_contacts": '', "team_id_card": '', "team_phone": '', "team_email": '', "team_weixin": ''
                };
            }
            
            $(".citySelect").each(function(){
                $(this).citySelect({nodata: "none", prov: game.project.team_province, city: game.project.team_city, required: false});
            });
            
            $('.citySelect .prov').change(function(){
                game.project.team_city = '';
            });
            
            window.onbeforeunload = function(){
                typeof pgvSendClick === 'function' && pgvSendClick({hottag:'sup.apply.enroll.pv', virtualDomain: 'gad.qq.com'});
                if(game.reg_step <= 4 && game.reg_step > 1){
                    return '您的资料尚未填写完成，是否离开？';
                }
            };
            
            view = new Vue({
                el: '#main-div',
                data: {upload: upload, game: game, blur: blur, SMSCounter: 0, SMSCode: ''},
                methods: {
                    _save: function(callback){
                        $.ajax({url: '/narticle/save', type: 'post', headers: {'X-CSRF-TOKEN': token}, data: this.gatherData(), dataType: 'json', success: function(recv){
                            if(recv.code == 0){
                                callback && callback(recv.data);
                            }else{
                                popup.showPopup('warn','保存失败',recv.msg);
                            }
                        }});
                    },
                    checkPhone: function(phone){
                        return phone && (phone+'').match(/^\d{11}$/);
                    },
                    checkIdCard: function(card){
                        if(game.project.team_province != '国外'){
                            return card && (card+'').match(/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/);
                        }else{
                            return !!card;
                        }
                    },
                    checkEmail: function(email){
                        /*
                            Email的规则: name@domain
                            name最长64，domain最长253，总长最长256
                            name可以使用任意ASCII字符:
                              大小写英文字母 a-z,A-Z
                              数字 0-9
                              字符 !#$%&'*+-/=?^_`{|}~
                              字符 .不能是第一个和最后一个，不能连续出现两次
                              但是有些邮件服务器会拒绝包含有特殊字符的邮件地址
                              domain仅限于26个英文字母、10个数字、连词号-
                              连词号-不能是第一个字符
                              顶级域名（com、cn等）长度为2到6个
                          */
                        return email && (email+'').match(/^([\w-_]+(?:\.[\w-_]+)*)@((?:[a-z0-9]+(?:-[a-zA-Z0-9]+)*)+\.[a-z]{2,6})$/i);
                    },
                    removeFile: function(event, id, clear, index){
                        event && (event.preventDefault ? event.preventDefault() : (event.returnValue = false));
                        if(this.upload[id]){
                            if(this.upload[id].files){
                                pan_upload_remove(this.upload[id].uploader, this.upload[id].files[index]);
                                this.upload[id].files.splice(index, 1);
                            }else{
                                pan_upload_remove(this.upload[id].uploader, this.upload[id].id);
                            }
                            this.upload[id].uploading = false;
                            this.upload[id].file_error = '';
                        }
                        if(clear){
                            if(id==='demo' || id==='videos' || id==='other_attachment'){
                                this.game.project[id] = [];
                            }else if(id==='pictures'){
                                this.game.project.pictures.splice(index, 1);
                            }else if(id==='logo' || id==='logo2'){
                                this.game.project.team_logo = '';
                            }
                        }
                    },
                    replaceFile: function(event, id){
                        event.preventDefault ? event.preventDefault() : (event.returnValue = false);
                        if(isIE89){
                            this.removeFile(null, id, true);
                        }else{
                            $("#"+id).click();
                        }
                    },
                    retryFile: function(event, id){
                        event.preventDefault ? event.preventDefault() : (event.returnValue = false);
                        if(this.upload[id].uploader){
                            this.upload[id].uploader.start();
                            this.upload[id].uploading = true;
                            this.upload[id].file_error = '';
                        }
                    },
                    prevStep: function(){
                        this.game.reg_step--;
                    },
                    nextStep: function(e){
                        var currentTarget = e.currentTarget;
                        if($(currentTarget).hasClass('disabled')){
                            return;
                        }
                        var div = $(currentTarget).parents('.form-inner').first();
                        var einputs = $('select.error, input.error, textarea.error', div);
                        if(einputs.length){
                            einputs.each(function(){
                                typeof pgvSendClick === 'function' && $(this).data('tag') && pgvSendClick({hottag:$(this).data('tag'), virtualDomain: 'gad.qq.com'});
                            });
                            popup.showPopup('warn','提示','请补全必填信息');
                        }else{
                            $(currentTarget).addClass('disabled');
                            //this.register.member_count = this.register.member_count*1;
                            $.ajax({url: '/hatch/save', type: 'post', headers: {'X-CSRF-TOKEN': token}, data: {game: this.game, SMSCode: this.SMSCode}, dataType: 'json', complete: function(resp){
                                var recv = resp.responseJSON;
                                $(currentTarget).removeClass('disabled');
                                if(recv && recv.code == 0){
                                    view.game.reg_step++;
                                    view.game.project.id = view.game.project_id = recv.project_id;
                                }else{
                                    popup.showPopup('warn','操作失败', recv.msg || (recv.message instanceof Object ? JSON.stringify(recv.message) : recv.message) || '提交出错');
                                }
                            }});
                        }
                    },
                    sendSMS: function(event){
                        event.preventDefault ? event.preventDefault() : (event.returnValue = false);
                        if(!this.checkPhone(view.game.project.team_phone)){
                            popup.showPopup('warn','提示','手机号码填写有误');
                            return;
                        }
                        $.ajax({url: '/hatch/getsmscode', type: 'post', headers: {'X-CSRF-TOKEN': token}, data: {phone:view.game.project.team_phone}, dataType: 'json', complete: function(resp){
                            var recv = resp.responseJSON;
                            if(recv && recv.code == 0){
                                view.SMSCounter = 60;
                                var timer = setInterval(function(){
                                    --view.SMSCounter || clearInterval(timer);
                                }, 1000);
                            }else{
                                popup.showPopup('warn','保存失败', recv.msg || (recv.message instanceof Object ? JSON.stringify(recv.message) : recv.message) || '提交出错');
                            }
                        }});
                    },
                    confirmProject: function(project){
                        this.game.project = project;
                        this.game.project_id = project.id;
                    }
                },
                ready: function(){
                    if(isIE89){
                        $('#demo, #videos, #logo, #logo2, #pictures, #other_attachment').click(function(){
                            init_upload(view);
                            view.upload[$(this).attr('id')].uploader && view.upload[$(this).attr('id')].uploader.refresh();
                        });
                        $('.placeholder').each(function(){
                            var placeholder = $(this).attr('placeholder');
                            $(this).click(function(){
                                if($(this).val() == placeholder){
                                    $(this).val('');
                                }
                            });
                            $(this).blur(function(){
                                var element = $(this);
                                setTimeout(function(){
                                    if(!element.val()){
                                        element.val(placeholder);
                                    }
                                }, 100);
                            }).trigger('blur');
                        });
                        $('#logo, #logo2').css({width: '80px', height: '80px'});
                    }else{
                        init_upload(this);
                    }
                }
            });
        }
    };
});