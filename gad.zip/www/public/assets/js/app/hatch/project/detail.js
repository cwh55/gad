define(['jquery','vue','swiper','popup','vendor/plyr/plyr','app/preview_document','app/community/community'], function($, Vue, Swiper, popup, plyr) {
    
    Vue.component('archive-article', {
        template: '#tpl-article',
        props: ['archive']
    });

    Vue.component('archive-gallery', {
        template: '#tpl-gallery',
        props: ['archive']
    });

    Vue.component('archive-question', {
        template: '#tpl-question',
        props: ['archive']
    });
    
    Vue.component('archive-topic', {
        template: '#tpl-topic',
        props: ['archive']
    });
    
    Vue.component('blog-live', {
        template: '#blog-live',
        props: ['archive']
    });
    
    Vue.component('blog-course', {
        template: '#blog-course',
        props: ['archive']
    });
            
    return {
        init: function (project, pictures, isLogin, orderBy, userComment, experte) {
            var getQueryString = function(name) {
                var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
                var r = window.location.search.substr(1).match(reg);
                if (r != null) return unescape(r[2]); return null;
            }
            var tab = getQueryString('tab') || 'intro';
            new Vue({
                el: "#main-app",
                data: {
                    tab: tab, pictures: pictures, type: 'video', img_url: '', url: '', 
                    blogCount: {1: 0, 2: 0, 3: 0, 4: 0, live: 0, course: 0}, blogTab: 1, blogPage: 0, blogList: [], blogLoadStatus: '', blogCountAll: 0,
                    inputComment: false, message: '', submittingComment: false,
                    newsTab: 'hatch', newsCount: {hatch: 0, team: 0}, newsCountAll: 0, newsList: [], newsgLoadStatus: '',
                    projectId: project.id, orderBy: orderBy, userComment: userComment, experte: experte, project: project, loading: true, isLogin: isLogin,expertComment:{},
                    expertcomments: {
                        current_page: 1,
                        per_page: 20,
                        total: 0,
                        data: []
                    },
                },
                methods: {
                    preview: function (item) {
                        this.type = $('.js-link' + item).data('pictype');
                        this.img_url = $('.js-link' + item).data('picimgurl');
                        this.url = $('.js-link' + item).data('picurl');
                        $('.js-link').removeClass('cur');
                        $('.js-link' + item).addClass('cur');
                    },
                    switchTab: function(tab){
                        this.tab = tab;
                    },
                    swithBlogTab: function(tab){
                        if(this.blogTab != tab){
                            this.blogLoadStatus = '';
                            this.blogPage = 0;
                            this.blogList = [];
                        }
                        this.blogTab = tab;
                        this.getBlog();
                    },
                    getBlogCount: function(){
                        var vue = this;
                        $.ajax({
                            url: '/hatch/project/blog-count/'+project.id, type: 'get', data: {}, dataType: 'json', 
                            complete: function(resp) {
                                var recv = resp.responseJSON;
                                if (typeof recv === 'object') {
                                    vue.blogCount = recv;
                                    for(var i in vue.blogCount){
                                        if(vue.blogCount[i]>0){
                                            vue.blogTab = i;
                                            vue.getBlog();
                                            break;
                                        }
                                    }
                                    vue.blogCountAll = (vue.blogCount[1]*1 || 0)+(vue.blogCount[2]*1 || 0)+(vue.blogCount[3]*1 || 0)+(vue.blogCount[4]*1 || 0)+(vue.blogCount['live']*1 || 0)+(vue.blogCount['course']*1 || 0);
                                }
                            }
                        });
                    },
                    getArchiveComponent: function (archive) {
                        var archiveType = ['', 'article', 'gallery', 'question', 'topic'];
                        if(this.blogTab == 'live'){
                            return 'blog-live'; 
                        }else if(this.blogTab == 'course'){
                            return 'blog-course'; 
                        }else{
                            return 'archive-' + archiveType[archive.class_id];
                        }
                    },
                    getBlog: function(){
                        var vue = this;
                        if (vue.blogLoadStatus) {
                            return;
                        }
                        vue.blogLoadStatus = 'loading';
                        $.ajax({
                            url: '/hatch/project/blogs', type: 'get', data: {id: project.id, page: this.blogPage, type: this.blogTab}, dataType: 'json', 
                            complete: function(resp) {
                                vue.blogLoadStatus = '';
                                var recv = resp.responseJSON;
                                if (typeof recv === 'object') {
                                    vue.blogPage++;
                                    vue.blogLoadStatus = recv.length < 20 ? 'nomore' : '';
                                    vue.blogList = vue.blogList.concat(recv);
                                }
                            }
                        });
                    },
                    sumbitComment: function(){
                        if(this.submittingComment){
                            return;
                        }
                        if(!this.message){
                            popup.showPopup('warn', '操作失败', '请填写留言内容');
                            return;
                        }
                        var token = $('meta[name="csrf-token"]').attr('content');
                        var vue = this;
                        vue.submittingComment = true;
                        $.ajax({url: '/ncomment/add', type: 'post', headers: {'X-CSRF-TOKEN': token}, data: {objid: project.id, objtype: 'App\\Entities\\Project', comment: this.message}, dataType: 'json', complete: function(resp){
                            var recv = resp.responseJSON;
                            vue.submittingComment = false;
                            if(recv && recv.code == 0){
                                vue.closeComment();
                                popup.showPopup('info', '成功', '留言成功，我们会尽快审核');
                            }else{
                                popup.showPopup('warn','操作失败', recv.msg || (recv.message instanceof Object ? JSON.stringify(recv.message) : recv.message) || '留言出错');
                            }
                        }});
                    },
                    closeComment: function(){
                        this.inputComment = false;
                    },
                    openComment: function(){
                        if(!isLogin){
                            gad.login();
                            return;
                        }
                        this.inputComment = true;
                    },
                    swithNewsTab: function(tab){
                        if(this.newsTab != tab){
                            this.newsLoadStatus = '';
                            this.newsList = [];
                        }
                        this.newsTab = tab;
                        this.getNews();
                    },
                    getNewsCount: function(){
                        var vue = this;
                        $.ajax({
                            url: '/hatch/project/news-count/'+project.id, type: 'get', data: {}, dataType: 'json', 
                            complete: function(resp) {
                                var recv = resp.responseJSON;
                                if (typeof recv === 'object') {
                                    vue.newsCount = recv;
                                    var hasGotNews = false;
                                    for(var i in vue.newsCount){
                                        vue.newsCountAll += vue.newsCount[i]*1;
                                        if(!hasGotNews && vue.newsCount[i]>0){
                                            vue.newsTab = i;
                                            vue.getNews();
                                            hasGotNews = true;
                                        }
                                    }
                                }
                            }
                        });
                    },
                    getNews: function(clear){
                        var vue = this;
                        if (vue.newsLoadStatus) {
                            return;
                        }
                        vue.newsLoadStatus = 'loading';
                        $.ajax({
                            url: '/hatch/project/news', type: 'get', data: {id: project.id, type: this.newsTab}, dataType: 'json', 
                            complete: function(resp) {
                                vue.newsLoadStatus = '';
                                var recv = resp.responseJSON;
                                if (typeof recv === 'object') {
                                    vue.newsLoadStatus = recv.length < 20 ? 'nomore' : '';
                                    vue.newsList = vue.newsList.concat(recv);
                                }
                            }
                        });
                    },
                    getNewsDict: function(type){
                        var dict = {hatch: '项目扶持', team: '组队'};
                        return dict[type];
                    },
                    delExpertComment: function () {
                        var data = {};
                        data._token = $('meta[name=csrf-token]').attr('content');

                        var _that = this;
                        popup.showPopup(1, '提示', '您确定要删除吗?', function () {
                            _that.$http.post('/hatch/project' + '/del-expert-comment/' + _that.projectId, data).then(function (res) {
                                var ret = res.data;
                                if (ret.code == 0) {
                                    popup.showPopup(1,'信息','删除成功');
                                    //_that.project.expert_comment_count = _that.project.expert_comment_count - 1;
                                    _that.up();
                                } else {
                                    popup.showPopup(1, '提示', ret.message);
                                }
                            });
                        });
                    },
                    changedata: function (data) {
                        this.userComment = data;
                        this.id = data.id;
                        this.up();
                    },
                    apply: function () {
                        var _that = this;
                        var data = {};
                        data._token = $('meta[name=csrf-token]').attr('content');
                        this.$http.post('/hatch/project/apply-expert-comment/' + this.projectId, data).then(function (res) {
                            var data = res.data;
                            if (data.code == 0) {
                                _that.project.push_email_status = 2;
                            }
                        });
                    },
                    getExpertComment: function (order) {
                        this.loading = true;
                        var _that = this;
                        this.$http.get('/hatch/project/expert-comment-list' + this.projectId, {
                            params: {
                                'page': this.expertcomments.current_page + 1,
                                'pageSize': this.expertcomments.per_page,
                                'orderBy': this.orderBy
                            }
                        }).then(function (res) {
                            _that.loading = false;
                            var data = res.data;
                            if (data.code == 0) {
                                this.orderBy = order;
                                var _data = _that.expertcomments.data;
                                _data = _data.concat(data.data);
                                _that.expertcomments = _data;
                            }
                        });
                    },
                    up: function () {
                        if ($('.vu-edit').hasClass('f-hide')){
                            $('.vu-edit').removeClass('f-hide');
                            $('.vu-comment').addClass('f-hide');
                        } else {
                            $('.vu-edit').addClass('f-hide');
                            $('.vu-comment').removeClass('f-hide');
                        }
                    },
                    getExpert: function(){
                        var _that = this;
                        this.$http.get('/hatch/project/expert-comment-list/' + this.projectId, {
                            params: {
                                'page': 1,
                                'pageSize': this.expertcomments.per_page,
                                'orderBy': this.orderBy
                            }
                        }).then(function (res) {
                            var data = res.data;
                            if (data.code == 0) {
                                _that.loading = false;
                                _that.expertcomments = data.data;
                                _that.expertcomments.data = [];
                            }
                        });
                        this.$http.get('/hatch/project/detail-expert/'+this.projectId, {
                            params: {
                                'orderBy': this.orderBy
                            }
                        }).then(function (res) {
                            var data = res.data;
                            if (data.code == 0) {
                                _that.expertComment = data.data;
                            }
                        });
                    }
                },
                computed: {
                    expertloadmore: function () {
                        return {
                            'dl-goto': !this.loading && this.expertcomments.total >= this.expertcomments.current_page * this.expertcomments.per_page,
                            'dl-loading': this.loading,
                            'dl-nomore': !this.loading && this.expertcomments.total < this.expertcomments.current_page * this.expertcomments.per_page
                        }
                    }
                },
                ready: function () {
                    var vue = this;
                    if (this.pictures[0]) {
                        this.type = this.pictures[0]['type'];
                        this.img_url = this.pictures[0]['img_url'];
                        this.url = this.pictures[0]['url'];
                    }
                    new Swiper('.swiper-container',{
                        direction: 'vertical',
                        slidesPerView: 'auto',
                        prevButton: '.swiper-button-prev',
                        nextButton: '.swiper-button-next',
                    });
                    $(window).scroll(function() {
                        var sHeight = document.documentElement.scrollTop || document.body.scrollTop;
                        var wHeight = document.documentElement.offsetHeight;
                        var dHeight = document.documentElement.scrollHeight;
                        if (dHeight - (sHeight + wHeight) < 100) {
                            if(vue.tab == 'blog'){
                                vue.getBlog();
                            }
                        }
                    });
                    this.getBlogCount();
                    this.getNewsCount();
                    this.getExpert();
                    plyr.gadInit();
                }
            });
        }
    }
});