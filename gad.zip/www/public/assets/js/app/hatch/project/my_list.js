define(['vue', 'jquery', 'popup', 'vue-validator', 'pan_upload'], function(Vue, $, popup, VueValidator) {
    var token = $('meta[name="csrf-token"]').attr('content');
    var isIE89 = navigator.appVersion.indexOf("MSIE 9")>=0 || navigator.appVersion.indexOf("MSIE 8")>=0;
    var init_upload_temp = function(id, filters, view_upload, callback){
        if(view_upload.uploader || (isIE89 && !$("#"+id).is(':visible'))){
            return;
        }
        $("#"+id).pan_upload_raw({
            multipart_params: {csrf: token}, max_file_count: 1, multi_selection: false, flash_swf_url: '/assets/js/Moxie.swf',
            filters: filters,
            events: {
                Init: function(up) {
                    view_upload.uploader = up;
                }, FilesAdded: function(up, files) {
                    view_upload.percent = 0;
                    view_upload.uploading = true;
                    view_upload.id = files[0].id;
                    view_upload.name = files[0].name;
                    if (!window.FileReader && files[0].size > 2 * 1024 * 1024) {
                        popup.showPopup('warn','提示','您的浏览器可能无法完成超过2M的文件上传，建议更换Chrome等现代浏览器完成大文件的上传哈');
                    }
                    up.disableBrowse(true);
                }, UploadProgress: function(up, file) {
                    view_upload.percent = file.percent;
                },
                FileUploaded: function(up, file, info) {
                    try {
                        up.disableBrowse(false);
                        view_upload.uploading = false;
                        var data = JSON.parse(info.response);
                        if (!data.success) {
                            popup.showPopup('warn','提示',"上传失败");
                        } else {
                            callback(data);
                        }
                    } catch (e) {
                        popup.showPopup('warn','提示',"上传失败");
                    }
                },
                Error: function(up, error) {
                    view_upload.file_error = error.message;
                    !up.files.length && popup.showPopup('warn','提示',error.message);
                }
            }
        });
    };
    var init_upload = function(vue){
        init_upload_temp('logo', {max_file_size: '10mb', mime_types: [{title: "图片", extensions: "jpg,png,gif,bmp"}]}, vue.upload.logo, function(data){
            vue.project.logo = data.image_url;
        });
        init_upload_temp('pictures', {max_file_size: '10mb', mime_types: [{title: "图片", extensions: "jpg,png,bmp,gif"}]}, vue.upload.pictures, function(data){
            vue.project.pictures.push({url: data.image_url, name: vue.upload.pictures.name});
        });
        init_upload_temp('videos', {max_file_size: '2000mb', mime_types: [{title: "视频", extensions: "mp4,flv"}]}, vue.upload.videos, function(data){
            vue.project.videos.push({url: 'http://file.gad.qq.com/attachment/download?file_id='+data.data+'&video_id='+data.video_id, name: vue.upload.videos.name, uuid: data.video_id});
        });
        init_upload_temp('demo', {max_file_size: '3000mb', mime_types: [{title: "压缩包", extensions: "rar,zip"}]}, vue.upload.demo, function(data){
            vue.project.demo = [{url: 'http://file.gad.qq.com/attachment/download?file_id='+data.data, name: vue.upload.demo.name}];
        });
        init_upload_temp('ppt', {max_file_size: '100mb', mime_types: [{title: "PPT", extensions: "ppt,pptx"}]}, vue.upload.ppt, function(data){
            vue.project.ppt.push({url: data.image_url, name: vue.upload.ppt.name});
        });
        init_upload_temp('team_logo', {max_file_size: '10mb', mime_types: [{title: "图片", extensions: "jpg,png,gif,bmp"}]}, vue.upload.team_logo, function(data){
            vue.project.team_logo = data.image_url;
        });
    };
    Vue.use(VueValidator);
    return {
        init: function(){
            var pageSize = 20;
            var defaultProject = function(){ 
                return {
                    'id': 0, "created_from": 0, "is_public": 1, "name":'', "logo":'', "type": [],"progress": '策划中', "team_num": 1, "pictures": [], "intro": '',
                    "platform": [], "demo": [], "videos": [], "ppt": [], "team_type": '', "team_business_license": '', "team_name": '', "team_logo": '', "team_contacts": '',
                    "team_id_card": '', "team_phone": '', "team_email": '', "team_weixin": '', old_phone: '', "is_public_demo": 0
                };
            };
            var upload = {
                logo: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:''},
                pictures: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:'', files: []},
                videos: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:'', files: []},
                demo: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:'', files: []},
                ppt: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:'', files: []},
                team_logo: {uploader: null, percent: 0, uploading: false, id: '', name: '', file_error:''},
            };
            var vue = new Vue({
                el: '#list-app',
                data: {list: [], page: 0, isLoading: false, noMoreData: false, submitting: false, isEditting: false, project: defaultProject(), upload: upload, SMSCounter: 0, SMSCode: '', SMSTouched: false},
                validators: {
                    email: function (val) {
                        return /^([\w-_]+(?:\.[\w-_]+)*)@((?:[a-z0-9]+(?:-[a-zA-Z0-9]+)*)+\.[a-z]{2,6})$/i.test(val);
                    }
                },
                methods: {
                    getList: function() {
                        var vue = this;
                        if (vue.noMoreData || vue.isLoading) {
                            return;
                        }
                        vue.isLoading = true;
                        $.ajax({url: '/hatch/project/my-list', type: 'get', data: {page: vue.page, private: 1}, dataType: 'json', success: function(recv) {
                            vue.isLoading = false;
                            if (recv.code == 0) {
                                vue.page++;
                                vue.list = vue.list.concat(recv.data);
                                vue.isLoading = false;
                                vue.noMoreData = recv.data.length < pageSize;
                            }
                        }, error: function() {
                            vue.isLoading = false;
                        }});
                    },
                    getCreatedFrom: function(id){
                        var dict = {0: '手动创建', 1: '项目扶持', 2: '晨星计划', 3: '大赛', 4: '组队项目', 11: '独立游戏大赛', 12: '高校游戏创意大赛', 13: '故宫游戏创意大赛',
                            14: '第一届创新大赛', 15: 'VR游戏大赛', 16: '第二届创新大赛'};
                        return dict[id*1] || '其他';
                    },
                    getProject: function(id, returnIndex){
                        for(var i=0;i<this.list.length;i++){
                            if(vue.list[i].id == id){
                                return returnIndex ? i : vue.list[i];
                            }
                        }
                    },
                    saveProject: function(data, callback){
                        var vue = this;
                        if (vue.submitting) {
                            return;
                        }
                        data.SMSCode = this.SMSCode;
                        $.ajax({url: '/hatch/project/save', type: 'post', headers: {'X-CSRF-TOKEN': token}, data: data, dataType: 'json', complete: function(resp) {
                            var recv = resp.responseJSON;
                            vue.submitting = false;
                            if (recv.code == 0) {
                                callback && callback(recv.data);
                            }else{
                                popup.showPopup('warn','操作失败', recv.msg || (recv.message instanceof Object ? JSON.stringify(recv.message) : recv.message) || '删除出错');
                            }
                        }});
                    },
                    deleteProject: function(id){
                        var vue = this;
                        popup.showPopup('warn','提示','确定删除该项目？', function(){
                            if (vue.submitting) {
                                return;
                            }
                            var projectIndex = vue.getProject(id, true);
                            $.ajax({url: '/hatch/project/delete', type: 'post', headers: {'X-CSRF-TOKEN': token}, data: {id: id}, dataType: 'json', success: function(recv) {
                                vue.submitting = false;
                                if (recv.code == 0) {
                                    vue.list.splice(projectIndex, 1);
                                }else{
                                    popup.showPopup('warn','操作失败', recv.msg || (recv.message instanceof Object ? JSON.stringify(recv.message) : recv.message) || '删除出错');
                                }
                            }, error: function(recv) {
                                vue.submitting = false;
                                popup.showPopup('warn','提示', recv.responseJSON ? recv.responseJSON.message : '操作失败');
                            }});
                        });
                    },
                    togglePublic: function(id){
                        var project = this.getProject(id);
                        var isPublic = project.is_public ? 0 : 1;
                        this.saveProject({id: id, is_public: isPublic}, function(){
                            project.is_public = isPublic;
                        });
                    },
                    submitProject: function(event){
                        event.preventDefault ? event.preventDefault() : (event.returnValue = false);
                        if($(event.target).hasClass('disabled')){
                            return;
                        }
                        if($(event.target).hasClass('inactive1')){
                            popup.showPopup('warn','操作失败', '请补全必填信息');
                            return;
                        }
                        var shouldRefresh = !this.project.id;
                        var vue = this;
                        this.saveProject(this.project, function(){
                            if(shouldRefresh){
                                window.location.reload();
                            }else{
                                vue.closeEdit();
                            }
                        });
                    },
                    editProject: function(id){
                        this.SMSTouched = false;
                        if(!id){
                            this.project = defaultProject();
                        }else{
                            this.project = this.getProject(id);
                            this.project.old_phone = this.project.team_phone;
                        }
                        this.isEditting = true;
                    },
                    closeEdit: function(){
                        this.isEditting = false;
                    },
                    formatTime: function(time) {
                        var $t0 = isNaN(time) ? new Date(time).valueOf() : (time*1000);
                        var $t = (new Date().valueOf() - $t0) / 1000;
                        if ($t < 3600) {
                            return Math.round($t / 60) + '分钟前';
                        } else if ($t < 24 * 3600) {
                            return Math.round($t / 3600) + '小时前';
                        } else if ($t < 3 * 24 * 3600) {
                            return Math.round($t / 24 / 3600) + '天前';
                        } else {
                            return time.substr(0, 10);
                        }
                    },
                    removeFile: function(id, clear, index){
                        if(this.upload[id]){
                            pan_upload_remove(this.upload[id].uploader, this.upload[id].id);
                            this.upload[id].uploading = false;
                            this.upload[id].file_error = '';
                        }
                        if(clear){
                            if(id == 'logo'){
                                this.project[id] = '';
                            }else if(id == 'pictures' || id == 'videos' || id == 'demo' || id == 'ppt'){
                                this.project[id].splice(index, 1);
                            }
                        }
                    },
                    retryFile: function(id){
                        if(this.upload[id].uploader){
                            this.upload[id].uploader.start();
                            this.upload[id].uploading = true;
                            this.upload[id].file_error = '';
                        }
                    },
                    replaceFile: function(id){
                        if(isIE89){
                            this.removeFile(id, true);
                        }else{
                            $("#"+id).click();
                        }
                    },
                    checkPhone: function(phone){
                        return phone && (phone+'').match(/^\d{11}$/);
                    },
                    sendSMS: function(){
                        var view = this;
                        if(this.SMSCounter > 0){
                            return;
                        }
                        if(!this.checkPhone(view.project.team_phone)){
                            popup.showPopup('warn','提示','手机号码填写有误');
                            return;
                        }
                        this.SMSCounter = 60;
                        $.ajax({url: '/hatch/getsmscode', type: 'post', headers: {'X-CSRF-TOKEN': token}, data: {phone: view.project.team_phone}, dataType: 'json', complete: function(resp){
                            var recv = resp.responseJSON;
                            if(recv && recv.code == 0){
                                var timer = setInterval(function(){
                                    --view.SMSCounter || clearInterval(timer);
                                }, 1000);
                            }else{
                                view.SMSCounter = 0;
                                popup.showPopup('warn','保存失败', recv.msg || (recv.message instanceof Object ? JSON.stringify(recv.message) : recv.message) || '提交出错');
                            }
                        }});
                    },
                    cannotSubmit: function(valid){
                        return !valid || (this.project.old_phone != this.project.team_phone && (!this.SMSCode || this.SMSCode.length<6)) || !this.project.type.length || !this.project.logo || !this.project.platform.length || !this.project.pictures.length;
                    }
                },
                ready: function(){
                    var vue = this;
                    this.getList();
                    $(window).scroll(function() {
                        var sHeight = document.documentElement.scrollTop || document.body.scrollTop;
                        var wHeight = document.documentElement.offsetHeight;
                        var dHeight = document.documentElement.scrollHeight;
                        if (dHeight - (sHeight + wHeight) < 50) {
                            vue.getList();
                        }
                    });
                    $('.form-errortips').click(function(){
                        $('input, textarea', $(this).parents('.form-line').first()).focus();
                    });
                    if(isIE89){
                        $('#logo, #pictures, #videos, #demo, #ppt, #team_logo').click(function(){
                            init_upload(vue);
                            vue.upload[$(this).attr('id')].uploader && vue.upload[$(this).attr('id')].uploader.refresh();
                        });
                    }else{
                        init_upload(vue);
                    }
                }
            });
        }
    }
});
