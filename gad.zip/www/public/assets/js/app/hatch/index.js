$(function(){
    var slide = $("#slide");
    var slideUl = slide.find("ul");
    var len= slideUl.find("li").length;
    var index = 0;
    var timer = null;
    var dotList = "";
    for(var i=0; i<len; i++){
        dotList += '<li>'+(i+1)+'</li>';
    }
    slide.find('ol').html(dotList);
    //初始化轮播图状态
    slide.find('ol>li').eq(index).addClass("cur");
    slide.find("li").eq(0).show();

    slide.on("click","ol>li",function(){
        index = $(this).index();
        play();
    });

    slide.on('mouseover',"ol>li",function(){
        //鼠标移入清除定时器
        clearInterval(timer);
    });
    slide.on('mouseout',"ol>li",function(){
        timer = setInterval(function(){
            index++;
            if(index == len) index = 0;
            play();
        },5000);
    });
    slide.find("ol>li:eq(0)").trigger("mouseout");

    function play(){
        slide.find('ol>li').removeClass("cur").eq(index).addClass("cur");
        slideUl.find("li").fadeOut(500).eq(index).fadeIn(1200);
    }
});