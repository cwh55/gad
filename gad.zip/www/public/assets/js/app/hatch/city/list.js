define(['vue', 'jquery'], function(Vue, $) {
    return {
        init: function(requestUrl, ulElement, requestData){
            requestData = requestData || {};
            var pageSize = 20;
            var vue = new Vue({
                el: '#list-app',
                data: {
                    list: [],
                    page: 1,
                    isLoading: false,
                    noMoreData: (ulElement && ($(ulElement).children('li').length < pageSize)) || false
                },
                methods: {
                    getList: function() {
                        if (vue.noMoreData || vue.isLoading) {
                            return;
                        }
                        vue.isLoading = true;
                        $.ajax({url: requestUrl, type: 'get', data: $.extend(requestData, {page: vue.page}), dataType: 'json', success: function(recv) {
                            vue.isLoading = false;
                            if (recv.code == 0) {
                                vue.page++;
                                vue.list = vue.list.concat(recv.data);
                                vue.isLoading = false;
                                vue.noMoreData = recv.data.length < pageSize;
                            }
                        }, error: function() {
                            vue.isLoading = false;
                        }});
                    },
                    formatTime: function(time) {
                        /* 时间标记规则；
                         1小时内：显示 XX分钟前
                         1天内：显示 XX小时前
                         3天内：显示 X天前
                         超过3天：显示日期  2017-3-17
                         */
                        var $t0 = isNaN(time) ? new Date(time).valueOf() : (time*1000);
                        var $t = (new Date().valueOf() - $t0) / 1000;
                        if ($t < 3600) {
                            return Math.round($t / 60) + '分钟前';
                        } else if ($t < 24 * 3600) {
                            return Math.round($t / 3600) + '小时前';
                        } else if ($t < 3 * 24 * 3600) {
                            return Math.round($t / 24 / 3600) + '天前';
                        } else {
                            return time.substr(0, 10);
                        }
                    },
                    formatNumber: function ($number){
                        /*
                         * 小于999显示30
                         * 1k-9999: 2.3k
                         * 10000以上：2.3w
                         */
                        if($number <= 999){
                            return $number;
                        }else if($number <= 9999){
                            return (($number/1000).toFixed(1)+'k').replace('.0','');
                        }else{
                            return (($number/10000).toFixed(1)+'w').replace('.0','');
                        }
                    }
                },
                ready: function(){
                    $(window).scroll(function() {
                        var sHeight = document.documentElement.scrollTop || document.body.scrollTop;
                        var wHeight = document.documentElement.offsetHeight;
                        var dHeight = document.documentElement.scrollHeight;
                        if (dHeight - (sHeight + wHeight) < 50) {
                            vue.getList();
                        }
                    });
                }
            });
        }
    }
});
