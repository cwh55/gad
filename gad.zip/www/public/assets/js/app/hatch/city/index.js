define(['jquery', 'swiper', 'vue', 'popup', 'vendor/plyr/plyr'], function($, Swiper, Vue, popup, plyr) {
    var isLogin;
    var player = plyr.setup('#main-video', {height: 600})[0];
    function bannerInit(){
        var mySwiper = new Swiper('#js-banner-swiper', {
            width: window.innerWidth,
            pagination: '.swiper-pagination',
            autoplay: 5000,
            loop: $('#js-banner-swiper li').length > 1,
            preventClicks: false
        });
        $(window).resize(function() {
            mySwiper.width = window.innerWidth;
            mySwiper.onResize();
        });
        $('.js-banner-prev').click(function() {
            mySwiper.slidePrev();
        });
        $('.js-banner-next').click(function() {
            mySwiper.slideNext();
        });
    }
    function commentInit(){
        $(".link-toadd").click(function(event) {
            if(!isLogin){
                gad.login();
                return;
            }else{
                $("#comment-form").removeClass("f-hide")
            }
        });
        $("#comment-form .gicos-close-1").click(function(event) {
            $("#comment-form").addClass("f-hide");
        });
    }
    function placeInit(){
        new Swiper('#city-places', {
            effect: 'coverflow',
            loop: true,
            centeredSlides: true,
            slidesPerView: 2,
            initialSlide: 3,
            keyboardControl: true,
            lazyLoading: true,
            preventClicks: false,
            preventClicksPropagation: false,
            lazyLoadingInPrevNext: true,
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev',
            coverflow: {
                rotate: 0,
                stretch: 0,
                depth: 250,
                modifier: 1,
                slideShadows: false,
            },
            onSlideChangeEnd: function(swiper){
                $("#places .js-place-text").addClass('f-hide').eq(swiper.realIndex).removeClass('f-hide');
            }
        });
        $('#places .js-slide img').each(function(){
            if($(this).data('type')=='video'){
                var src = $(this).attr('src');
                $(this).data('src', src);
                var match = src.match(/video_id=([^&"]+)/);
                $(this).attr('src', match ? "http://p.qpic.cn/wecam_pic/0/"+match[1]+"_1/0" : 'http://gad.qpic.cn/assets/v2/web/img/global/default_video_preview.png');
            }
        });
        $('#places .js-play').click(function(e) {
            e.preventDefault();
            e.stopPropagation();
            $('#video-div').removeClass('f-hide');
            player.source({
                type: 'video',
                sources: [{src: $(this).data('src')}]
            });
            player.play();
        });
        $('#video-div').click(function(){
            $('#video-div').addClass('f-hide');
            player.pause();
        });
        $('#video-div .content-join').click(function(e){
            e.stopPropagation();
        });
    }
    
    return {
        init: function(_isLogin, cityId){
            new Vue({
                el: '#comment-form',
                data: {message: '', submitting: false},
                methods: {
                    closeForm: function(){
                        $("#comment-form").addClass("f-hide");
                    },
                    sumbitForm: function(){
                        if(this.submitting){
                            return;
                        }
                        if(!this.message){
                            popup.showPopup('warn', '操作失败', '请填写留言内容');
                            return;
                        }
                        var token = $('meta[name="csrf-token"]').attr('content');
                        var vue = this;
                        vue.submitting = true;
                        $.ajax({url: '/ncomment/add', type: 'post', headers: {'X-CSRF-TOKEN': token}, data: {objid: cityId, objtype: 'App\\Entities\\City', comment: this.message}, dataType: 'json', complete: function(resp){
                            var recv = resp.responseJSON;
                            vue.submitting = false;
                            if(recv && recv.code == 0){
                                vue.closeForm();
                                popup.showPopup('info', '成功', '留言成功，我们会尽快审核');
                            }else{
                                popup.showPopup('warn','操作失败', recv.msg || (recv.message instanceof Object ? JSON.stringify(recv.message) : recv.message) || '留言出错');
                            }
                        }});
                    }
                }
            });
            $(".service-item").mouseover(function() {
                $(".service-item").removeClass("cur");
                $(this).addClass("cur");
            });
            $(".city-item").click(function() {
                $(".city-item").removeClass("on");
                $(this).addClass("on");
            });
            bannerInit();
            commentInit();
            placeInit();
            
            isLogin = _isLogin;
            $('#place-detail').click(function(){
                popup.showPopup('info', '提示', '请发送商务合作邮件到：gad@tencent.com');
            });            
        }
    }
});