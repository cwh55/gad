define(['jquery', 'vue2', 'pan_upload', 'swiper', 'gad'], function($, Vue, pan, Swiper, gad){
    var maxFileCount = 5;
    var isHoverHolding = false;

    var sigunp = {
        init: function(signup_info){
            if(!signup_info){
                signup_info = {id: '', city_id: 1, type: '', group_type: 1, name: '', position: '', qq: '', mobile: '', corp: '', members: '', game_name: '', game_os: '', game_type: '', description: '', game_att: []};
            }
            if(!(signup_info.game_att instanceof Array)){
                signup_info.game_att = [];
            }
            var blur_info = {};
            for(var i in signup_info){
                blur_info[i] = false;
            }
            var view = new Vue({
                el: '#sign-up-form',
                data: {info: signup_info, blur: blur_info, token: $('meta[name="csrf-token"]').attr('content'), file_error: '', uploader: null},
                methods: {
                    checkPhone: function(phone){
                        return phone && (phone+'').match(/^\d{11}$/);
                    },
                    checkQQ: function(qq){
                        return qq && (qq+'').match(/^\d{5,12}$/);
                    },
                    removeFile: function(file_id){
                        pan_upload_remove(this.uploader, file_id);
                        for(var i=0;i<signup_info.game_att.length;i++){
                            if(signup_info.game_att[i].id == file_id){
                                if(!signup_info.game_att[i].done){
                                    this.file_error = '';
                                }
                                signup_info.game_att.splice(i, 1);
                                break;
                            }
                        }
                        if(signup_info.game_att.length<maxFileCount){
                            this.uploader.disableBrowse(false);
                        }
                    },
                    retryFile: function(){
                        if(this.uploader){
                            this.uploader.start();
                            this.file_error = '';
                        }
                    }
                }
            });
            var uiInit = function(){
                var a2 = window.innerHeight / 1080;
                a2 = a2 < 0.7 ? 0.7 : a2;
                a2 = a2 > 1 ? 1 : a2;
                var fullCoreH = $(window).height() - $(".cyheadnav").height() * a2;

                //大小屏适配
                (function(w) {
                    var e = ("onorientationchange" in w) ? "orientationchange" : "resize";
                    w.addEventListener(e, function() {
                        setTimeout(function() {
                            s();
                        }, 200)
                    }, false);
                    s();
                    function s() {
                        if(isIE() || navigator.userAgent.toLowerCase().indexOf('firefox') > 0){
                            if(w.innerHeight < 780){
                                $('.cyapply-form').addClass('cyapply-media');
                            }else{
                                $('.cyapply-form').removeClass('cyapply-media');
                            }
                        }

                        var a = w.innerHeight / 1080;
                        if (a < 0.7)
                            a = 0.7;
                        if (a > 1)
                            a = 1;
                        $('.form-select').css('font-size', Math.ceil((2 - a) * 12));
                        var el = document.getElementsByClassName('slide-adaptation');
                        for (var i = 0; i < el.length; i++) {
                            el[i].style.zoom = (parseInt(a * 100)) + "%";

                            if ($(el[i]).parents('.swiper-slide').hasClass('swiper-slide-1') || $(el[i]).hasClass('slide3-bg') || $(el[i]).hasClass('silde-building5')) {
                                el[i].style.MozTransformOrigin = '50% 100%';
                            } else {
                                el[i].style.MozTransformOrigin = '50% 0';
                            }
                            if(navigator.userAgent.toLowerCase().indexOf('firefox') > 0){ //Firefox
                                if($(el[i]).hasClass('cyheadnav')){
                                    el[i].style.MozTransformOrigin = '0 0';
                                    //$(el[i]).css({width:$(window).width()/(parseInt(a*100)/100)});
                                }
                                if(!$(el[i]).hasClass('cyapply-form') && !$(el[i]).hasClass('cyheadnav')){
                                    if ($(el[i]).hasClass('slide3-bg')) {
                                        el[i].style.MozTransform = 'scaleY(' + a + ')';
                                    } else {
                                        el[i].style.MozTransform = 'scale(' + a + ')';
                                    }
                                }
                            }
                            if (isIE()) {
                                var width = $(el[i]).width();
                                if ($(el[i]).hasClass('silde-building') || el[i].id == 'slide3Bg') {
                                    var h = $(el[i]).height();
                                    if (el[i].id == 'slide3Bg') {
                                        $(el[i]).css({bottom: -(h - h * a), left: 0, zoom: '100%'});
                                    } else {
                                        $(el[i]).css({bottom: -(h - h * a), left: '50%', marginLeft: -width * a / 2});
                                    }
                                } else if ($(el[i]).hasClass('slide-zoom-cont')) {
                                    $(el[i]).css({position: 'relative', left: 0, 'transform': 'none', 'width': $(window).width() / (parseInt(a * 100) / 100)});
                                } else if ($(el[i]).hasClass('cyheadnav')) {
                                    $(el[i]).css({position: 'relative', right: 0, width: $(window).width() / (parseInt(a * 100) / 100), 'transform-origin': '0 0 0'});
                                } else if ($(el[i]).hasClass('style-wrap')) {
                                    $(el[i]).css({marginTop: -250 * a, marginLeft: -167 * a});
                                } else if ($(el[i]).hasClass('cyapply-form')) {
                                    el[i].style.zoom = 1; //xingsongpan: 解决IE光标、滚动条问题
                                }
                            }
                        }
                        //私有设置，复用可删除
                        $(".enrolon>div").height(fullCoreH - Math.round(198 * a) + 5);

                    }
                })(window);

                //兼容火狐等
                $('.bj-preach .swiper-slide-1 .logo, .bj-preach .textIn, .bj-preach .swiper-slide-1 .title, .bj-preach .swiper-slide-1 .time, .bj-preach .swiper-slide-1 .doubt').each(function(){
                    var s = getComputedStyle(this);
                    if(!s.animation){
                        this.style.opacity = 1;
                    }
                });
                //兼容ie的流程
                function isIE(){
                    return !!window.ActiveXObject || "ActiveXObject" in window || document.documentMode==10 || document.documentMode==11 ;
                }

                if (isIE()) {
                    $('.cyapply').css("transform","translateY(0)");
                    $('.cyapply').show();
                    $('.cyapply-slide-2').hide();
                    $(".show-signup-normal").on("click", function() {
                        $('.cyapply-slide-1').show();
                        $('.cyapply-slide-2').hide();
                    });
                    //hover
                    $('.style-listeners .idcard').on('mouseenter', function() {
                        if(isHoverHolding){
                            return;
                        }
                        $('.cyapply-slide-1').addClass('cyapply-mouse-enter').removeClass('cyapply-mouse-enter2');
                        var p = $(this).parents('.style-wrap');
                        var zoom = p.css('zoom');
                        var top = p.css('margin-top');
                        $(this).parents('.style-wrap').removeAttr('style').css({marginTop:top, zoom:zoom,marginLeft:-375*(parseInt(zoom)/100)});
                        $('.style-preacher .style-wrap').css({marginLeft:-167*(parseInt(zoom)/100)});
                    });
                    $('.style-preacher .idcard').on('mouseenter', function() {
                        $('.cyapply-slide-1').addClass('cyapply-mouse-enter2').removeClass('cyapply-mouse-enter');
                        var p = $(this).parents('.style-wrap');
                        var zoom = p.css('zoom');
                        var top = p.css('margin-top');
                        $(this).parents('.style-wrap').removeAttr('style').css({marginTop:top, zoom:zoom,marginLeft:-375*(parseInt(zoom)/100)});
                        $('.style-listeners .style-wrap').css({marginLeft:-167*(parseInt(zoom)/100)});
                    });
                    $('.style-wrap .idcard').on('click', function() {
                        var type = $(this).data('type');
                        if(type == '1') {
                            $('#sign-up-type-label').text('宣讲报名');
                        } else {
                            $('#sign-up-type-label').text('听众报名');
                        }
                                        signup_info.type = type;
                        $('.cyapply-slide-1').hide();
                        if ($(this).parents('.style-listeners').length) {
                            $('.cyapply-slide-2').show().removeClass('roleinfo-preacher').addClass('roleinfo-listeners');
                        } else {
                            $('.cyapply-slide-2').show().removeClass('roleinfo-listeners').addClass('roleinfo-preacher');
                        }
                    });
                    $('#test_step1_prev, #salon-btn').on('click', function() {
                        $('.cyapply-slide-1').show();
                        $('.cyapply-slide-2').hide().removeClass('roleinfo-preacher roleinfo-listeners');
                    });
                } else {
                    $('.cyapply').show();
                    $(".style-preacher").mouseover(function() {
                        $(".rolestyle").removeClass("rolestyle-listeners");
                        $(".rolestyle").addClass("rolestyle-preacher");
                    });
                    $(".style-listeners").mouseover(function() {
                        if(isHoverHolding){
                            return;
                        }
                        $(".rolestyle").removeClass("rolestyle-preacher");
                        $(".rolestyle").addClass("rolestyle-listeners");
                    });
                    $(".style-preacher .idcard").click(function() {
                        $(".cyapply-slide-1").addClass("show-slide-1-out");
                        $(".cyapply-slide-2").removeClass("roleinfo-listeners").addClass("roleinfo-preacher").removeClass("f-hide");
                        signup_info.type = $(this).data('type');
                        $('#sign-up-type-label').text('宣讲报名');
                    })
                    $(".style-listeners .idcard").click(function() {
                        $(".cyapply-slide-1").addClass("show-slide-1-out");
                        $(".cyapply-slide-2").removeClass("roleinfo-preacher").addClass("roleinfo-listeners").removeClass("f-hide");
                        signup_info.type = $(this).data('type');
                        $('#sign-up-type-label').text('听众报名');
                    });
                    $("#test_step1_prev, #salon-btn").click(function() {
                        $(".cyapply-slide-1").removeClass("show-slide-1-out");
                        $(".cyapply-slide-2").addClass("f-hide").removeClass("roleinfo-preacher").removeClass("roleinfo-listeners");
                    });
                }

                var directSignup = function(force){
                    if(force || signup_info.id){
                        if(isIE()){
                            $('.cyapply-slide-1').hide();
                        }
                        if(signup_info.type == 1){
                            $(".cyapply-slide-2").removeClass("roleinfo-listeners").addClass("roleinfo-preacher").removeClass("f-hide");
                            $('#sign-up-type-label').text('宣讲报名');
                        }else{
                            $(".cyapply-slide-2").removeClass("roleinfo-preacher").addClass("roleinfo-listeners").removeClass("f-hide");
                            $('#sign-up-type-label').text('听众报名');
                        }
                    }
                };

                var submitForm = function(callback, step){
                    $.ajax({url: '/city/storeInfo?step='+step, type: 'post', headers: {'X-CSRF-TOKEN': view.token}, data: signup_info, dataType: 'json', complete: function(resp){
                        var recv = resp.responseJSON;
                        if(recv && recv.code == 0){
                            !signup_info.id && (signup_info.id = recv.data);
                            callback && callback(true);
                        }else{
                            alert(recv.msg || (recv.message instanceof Object ? JSON.stringify(recv.message) : recv.message) || '提交出错');
                            callback && callback(false);
                        }
                    }});
                };

                $("#test_step1_next").click(function() {
                    if($('#info-step-1 .form-error:visible').length){
                        return;
                    }
                    if($('#info-step-1 input.input-error:visible').length){
                        alert('请补齐必填信息');
                        return;
                    }
                    var div = $(this).parent('.form-element');
                    div.addClass('loading');
                    submitForm(function(success){
                        div.removeClass('loading');
                        if(success){
                            $(".infoinput-wrap").addClass("step-2").removeClass("step-1");
                            if(isIE()){
                                if($("#attr_upload").is(':visible') && !$("#attr_upload").data('pan-init')){
                                    $("#attr_upload").data('pan-init', 1);
                                    init_upload();
                                }
                            }
                        }
                    }, 1);
                });
                $("#test_step2_prev").click(function() {
                    $(".infoinput-wrap").addClass("step-1").removeClass("step-2");
                });
                $("#test_step2_next").click(function() {
                    var div = $(this).parent('.form-element');
                    for(var i=0;i<signup_info.game_att.length;i++){
                        if(!signup_info.game_att[i].done){
                            alert('请耐心等待所有附件上传完毕哈');
                            return;
                        }
                    }
                    if($('#info-step-2 .form-error:visible').length){
                        return;
                    }
                    if($('#info-step-2 .input-error:visible').length){
                        alert('请补齐必填信息');
                        return;
                    }
                    if(signup_info.type==1 && !signup_info.game_att.length){
                        alert('请上传至少一份游戏展示资料');
                        return;
                    }
                    submitForm(function(success){
                        div.removeClass('loading');
                        if(success){
                            $(".infoinput-wrap").addClass("step-3").removeClass("step-2");
                        }
                    }, 2);
                });

                $(".devstyle-team").click(function() {
                    $(".infoinput").removeClass("role-single").addClass("role-team");
                });
                $(".devstyle-single").click(function() {
                    $(".infoinput").removeClass("role-team").addClass("role-single");
                });
                $('.signup-btn-2, .signup-btn-1').click(function(){
                    signup_info.type = $(this).hasClass('signup-btn-1') ? 1 : 2;
                    $('#sign-up-type-label').text(signup_info.type == 1 ? '宣讲报名' : '听众报名');
                    directSignup(1);
                    setTimeout(function(){
                        $(".signup-btn").first().click();
                    }, 500);
                });        
                var init_upload = function(){
                    $("#attr_upload").pan_upload_raw({
                        multipart_params: {csrf: view.token}, max_file_count: 1, multi_selection: false,  flash_swf_url: '/assets/js/Moxie.swf',
                        filters: {max_file_size: '2000mb', mime_types: [{title: "压缩包", extensions: "zip,rar"}] },
                        events: {
                            Init: function(up){
                                view.uploader = up;
                                if(signup_info.game_att.length>=maxFileCount){
                                    up.disableBrowse(true);
                                }
                            },FilesAdded: function(up, files){
                                signup_info.game_att.push({id: files[0].id, progress: 0, size: plupload.formatSize(files[0].size), name: files[0].name, url: '', done: false});
                                view.$nextTick(function(){
                                    $('.g-scrollbar').scrollTop($('.g-scrollbar').height());
                                });
                                if(!window.FileReader && files[0].size > 2*1024*1024){
                                    pan_alert('您的浏览器可能无法完成大文件的上传，建议更换Chrome等现代浏览器完成大文件的上传哈');
                                }
                            }, UploadProgress: function(up, file){
                                for(var i=0;i<signup_info.game_att.length;i++){
                                    if(signup_info.game_att[i].id == file.id){
                                        signup_info.game_att[i].progress =  file.percent;
                                        view.$set(signup_info.game_att[i], 'progress', file.percent);
                                        break;
                                    }
                                }
                            },
                            FileUploaded: function(up, file, info) {
                                try{
                                    var data = JSON.parse(info.response);
                                    if(!data.success){
                                        pan_alert("上传失败");
                                    }else{
                                        for(var i=0;i<signup_info.game_att.length;i++){
                                            if(signup_info.game_att[i].id == file.id){
                                                var url = 'http://file.gad.qq.com/attachment/download?file_id='+data.data;
                                                signup_info.game_att[i].progress =  100;
                                                signup_info.game_att[i].done =  true;
                                                signup_info.game_att[i].url =  url;
                                                view.$set(signup_info.game_att[i], 'progress', file.percent);
                                                break;
                                            }
                                        }
                                        setTimeout(function(){
                                            if(signup_info.game_att.length>=maxFileCount){
                                                up.disableBrowse(true);
                                            }
                                        }, 200);
                                    }
                                }catch(e){
                                    pan_alert("上传失败");
                                }
                            },
                            Error: function(up, error){
                                if(up.files.length){
                                    view.file_error = error.message;
                                }else{
                                    pan_alert(error.message);
                                }
                            }
                        }
                    });
                };
                if (!isIE()) {
                    //在IE浏览器中，绑定的上传按钮必须在初始化的时候可见
                    init_upload();
                }

                $('#ploading-core').css({width: '100%'});
                $('body').removeClass('lazy-ploading');
                $(".signup-btn").click();
            };
            uiInit();
        }
    };

    return sigunp;
});