define(['jquery', 'angular'], function ($, angular) {
    var service = angular.module('gad.hatch.service', []);

    //Article Service
    service.factory('Hatch', ['$http', function ($http) {
        return {
            save: function (hatch) {
                if (hatch.id) {
                    return $http.post('/hatch/edit/' + hatch.id, hatch);
                } else {
                    return $http.post('/hatch/create', hatch);
                }
            }
        }
    }]);
});
 