define(['jquery', 'vue', 'vue-resource', 'popup', 'tig-editor-v2', 'app/community/community'], function ($, Vue, VueResource, popup, TIG, community) {
  Vue.component('tig-edit-expert',{
      template: '<div class="askeditor">\
                    <div class="exp-grade">\
                        <span class="grade-txt">打分:</span>\
                        <div class="m-score exp-score">\
                            <span class="score-star">\
                              <i class="gicos-star-empty-b score-star1" @click="starScore(1)"></i>\
                              <i class="gicos-star-empty-b score-star2" @click="starScore(2)"></i>\
                              <i class="gicos-star-empty-b score-star3" @click="starScore(3)"></i>\
                              <i class="gicos-star-empty-b score-star4" @click="starScore(4)"></i>\
                              <i class="gicos-star-empty-b score-star5" @click="starScore(5)"></i>\
                            </span>\
                            <span class="score-num exp-grade-num">{{score/10}}</span>\
                        </div>\
                    </div>\
                    <div class="m-tigeditor">\
                        <textarea class="tigeditor-textarea" id="{{type}}_desc{{projectId}}" v-bind:focujs="focus" name="desc" data-markdown="content_md">{{{value}}}</textarea>\
                    </div>\
                    <button class="m-btn-primary publish-btn" v-bind:class="{inactive:publishStatus}" v-on:click="submitComment" type="button">{{btnText}}</button>\
                </div>',
      props: ['projectId', 'isLogin', 'value', 'type', 'errText', 'controller','score'],
      ready: function () {
          var _that = this;
          setTimeout(function () {
              TIG.editor({
                  id: _that.type + '_desc' + _that.projectId,
                  height: 160,
                  width: 820,
                  value: '',
                  showRelativePath: false,
                  docToHtmlPath: '/course/doc2Html',
                  imageUploadPath: '/article/editorUploadImage',
                  buttons: ['bold', 'italic', 'h2', 'blockquote', 'insertorderedlist',
                      'insertunorderedlist', 'emoticons', 'addsource', 'link', 'table', 'image', 'video']
              });
              $('#editor-' + _that.type + '_desc' + _that.projectId).on('contentchange.editor.tfl', function (res) {
                  var length = _that.charLen(true);
                  if (length > 10000) {
                      _that.errText = '限1万字，已超出' + (length - 10000) + '字';
                  } else {
                      _that.errText = '';
                  }
              });
          }, 100);
          this.starScore(parseInt((this.score = (this.score == null ? 0 : this.score))/10));
          this.click = this.score;
      },
      data: function () {
          return {
              publishStatus: false,
              btnText: '提交点评',
              num: 0,
              editor: '',
              click:0
          }
      },
      methods: {
          login: function () {
              gad.login();
          },
          charLen: function (strip) {
              this.editor = TIG.editor.getInstance(this.type + '_desc' + this.projectId);
              var editor_value = this.editor.html();
              if (strip == true) {
                  editor_value = community.strip_tags(editor_value);
              }
              return editor_value.length;
          },
          focus: function () {
              if (!this.isLogin) {
                  gad.login();
                  return;
              }
              if (this.charLen(false) > 0) {
                  this.publishStatus = true;
              } else {
                  this.publishStatus = false;
              }
              if (this.charLen(true) > 10000) {
                  this.num = this.charLen(true) - 10000;
              } else {
                  this.num = 0;
              }
          },
          submitComment: function () {
              if (this.charLen(false) <= 0) {
                  popup.showPopup('warn', '提示', '请填写点评!');
                  return;
              }
              if (this.charLen(true) > 10000) {
                  popup.showPopup('warn', '', '点评超出字数');
                  return;
              }
              this.editor = TIG.editor.getInstance(this.type + '_desc' + this.projectId);
              var _that = this;
              if (this.publishStatus === false) {
                  this.publishStatus = true;
                  this.btnText = '发表中...';
                  var answer_id = '';
                  answer_id = '/' + this.projectId;
                  this.$http.post('/hatch/project/'+this.controller + answer_id, {
                      id: this.projectId,
                      comment: this.editor.html(),
                      score: this.score,
                      _token: $('[name="csrf-token"]').attr('content')
                  })
                      .then(function (res) {
                          if (res.data.code == 0) {
                              _that.$emit('changedata', res.data.data);
                              $(".js-exp-edit").addClass("f-hide");
                          } else {
                              popup.showPopup('warn', '提示', res.data.message);
                          }
                          this.publishStatus = false;
                          this.btnText = '提交点评';
                      }, function (res) {
                          this.publishStatus = false;
                          this.btnText = '提交点评';
                          popup.showPopup('warn', '提示', '你已被禁言，无法发表!');
                      });
              }
          },
          starScore: function(score){
              if(score == 0) {
                  return;
              }
              $(".score-star i").removeClass("gicos-star-full-b");
              $(".score-star i").removeClass("gicos-star-half-b");
              if(this.click == score*10 - 5) {//第二次点击
                  for(var i=1;i<=score;i++) {
                      $(".score-star"+i).addClass("gicos-star-full-b");
                  }
                  this.click=score*10;
                  this.score = score*10;
              } else {//第一次点击
                  for(var i = 1; i<=score-1; i++) {
                      $(".score-star"+i).addClass("gicos-star-full-b");
                  }
                  $(".score-star"+score).addClass("gicos-star-half-b");
                  this.click= score*10 - 5;
                  this.score = score*10 - 5;
              }
          }
      },
      events: {
          'replyTo': function (content) {
              this.replyTo(content);
          }
      }
  });

  return {
      init: function ( ) {
      }
  }
})
