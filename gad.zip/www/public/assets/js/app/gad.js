define(['jquery', 'badjs','tlog'], function ($, BJ_REPORT) {
    BJ_REPORT.init({id: 132, furl: location.host+location.pathname});

    $(function () {
        $('#go-top').click(function () {
            $(window).scrollTop(0);
        });

        $('#show-flag').click(function () {
            $(this).toggleClass('active');
            var flag = $(this).hasClass('active') ? 1 : 0;
            var expires = new Date();
            expires.setMonth(expires.getMonth() + 3);
            document.cookie = 'rcode-show-flag=' + flag + ';expires=' + expires.toGMTString();
        });

        $('.login-link .loginbtn').click(function (evt) {
            evt.preventDefault();
            gad.login();
        });
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
       //为添加了_hottag 属性的标签绑定click事件
       $('body').on('click','[_HOTTAG]',function(){
           var hottag = $(this).attr('_HOTTAG');
           //console.log(hottag);
           pgvSendClick({hottag: hottag, virtualDomain: 'gad.qq.com'});
           if(window.tlog)
               tlog(hottag,$(this).attr('href'));
       });
       //为添加了_hottag_h 属性的标签绑定hover事件
       $('body').on('hover','[_HOTTAG_H]',function(){
           var hottag = $(this).attr('_HOTTAG_H');
           pgvSendClick({hottag: hottag, virtualDomain: 'gad.qq.com'});
           if(window.tlog)
               tlog(hottag,$(this).attr('href'));
       });

        $('body').on('click','[_NAVTAG]',function(){
            //获取当前链接  匹配上传 tag
            var  _navurl = window.location.href;
            var _navtag = $(this).attr('_NAVTAG');
            if(window.tlog){
            if (_navurl.indexOf('lore/catalog') > -1) tlog( 'MANU.CATA.'+_navtag,$(this).attr(_navurl));
            if (_navurl.indexOf('lore/index') > -1) tlog( 'MANU.INDEX.'+_navtag,$(this).attr(_navurl));
            if (_navurl.indexOf('wenda/activity') > -1) tlog( 'DKDY.LIST.'+_navtag,$(this).attr(_navurl));
            if (_navurl.indexOf('wenda/detail') > -1) tlog( 'DKDY.DT.'+_navtag,$(this).attr(_navurl));
            }

        });
        
    });


    gad.login = function (type,tag) {
        var tgdHost = location.host == 'gad.qq.com' ? 'tgd.qq.com' : 'dev.tgd.qq.com';
        var body = $('body');
        var modal = $('<div style="position:fixed;top:50%;left:50%;width:622px;height:414px;margin-left:-311px;margin-top:-206px;background: #ffffff;z-index: 9999;overflow: hidden;box-shadow: 0 0 20px rgba(0,0,0,0.2);"></div>');
        var close = $('<a href="javascript:;" style="position:absolute;right:12px;top:8px;display:block;width:25px;height:25px;background-image: url(http://gad.qpic.cn/assets/images/infodelete.png)"></a>');
        var loginType = type ? ('&loginType='+type) : '';
        var frame = $('<iframe src="http://' + tgdHost + '/auth/login?platformId=100002&frame=1'+loginType+'&backUrl=http://' + location.host + '/auth/callback?frame=1" width="100%" height="100%" frameborder="0"></iframe>');
        var mask = $('<div style="position: fixed;top: 0;left: 0;overflow: hidden;opacity:0.4;width: 100%;height: 100%;background: #dedede;z-index: 9998"></div>');
        modal.append(close);
        modal.append(frame);
        body.append(modal);
        body.append(mask);
        close.click(function () {
            modal.hide();
            mask.hide();
        });

        document.domain = 'qq.com';

        gad.hideLogin = gad.hideLogin || function () {
            modal.hide();
            mask.hide();
            //添加 登入TAG
            if(tag != undefined)
                if (window.tlog)
                    window.tlog(tag,'');
        }
    };

    return gad;
});
