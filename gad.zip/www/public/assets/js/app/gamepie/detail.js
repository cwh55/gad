define(['jquery', 'vue', 'tig-editor-v2', 'popup', 'vue-resource', 'swiper', 'vue-validator', 'zeroclipboard', 'vendor/plyr/plyr', 'app/community/community', 
    'app/community/like', 'app/community/comment', 'imgzoom'], function($, Vue, TIG, popup, VueResource, Swiper, VueValidator, ZeroClipboard, plyr) {
    Vue.use(VueResource);
    Vue.use(VueValidator);
    Vue.validator('tel', function (val) {
      return /^[0-9]{11}$/.test(val)
    });
    Vue.validator('qqno', function (val) {
      return /^[0-9]{5,12}$/.test(val)
    });

    var clip = new ZeroClipboard(document.getElementById("d_clip_button"), {
      moviePath: "http://gad.qpic.cn/assets/js/vendor/zeroclipboard/ZeroClipboard.swf"
    });

    clip.on( 'complete', function(client, args) {
       $(".js_copycodetips").removeClass("f-hide");
    });
    return {
        init: function(id, signinfo, tabClass, isLogin){
            var info = {
                user_name: '',
                qq: '',
                tel: '',
                company: '',
                game_type: '',
                game_desc: ''
            };
            if(signinfo){
                info = signinfo;
            };
            var vm = new Vue({
                el: '#app',
                ready: function(){
                    //图文资料图片集
                    if ($(".swiper-container").length) {
                        var mySwiper = new Swiper('.swiper-container', {
                            width:252,
                            height:150,
                            slidesPerView:'auto',
                            prevButton:'.swiper-button-prev',
                            nextButton:'.swiper-button-next'
                        });
                        mySwiper.disableTouchControl();
                    }
                    
                    if($(".js_articlesec").height()<400){
                        this.isShowArticleMore = false;
                    };
                    if($(".js_dianpingsec").height()<400){
                        this.isShowDianMore = false;
                    };
                    plyr.gadInit();
                },
                data:{
                    tabClass: tabClass,     //当前选中tab
                    fullArticle: true,     //图文全部显示/折叠
                    fullDianping: false,    //点评够长
                    isShowVideo: false,     //视频弹窗
                    isShowSign: false,      //报名弹窗
                    isShowOk: false,        //报名成功弹窗
                    isShowCode: false,      //邀请码弹窗
                    signInfo: info,         //报名信息
                    isSending: false,       //正在提交post请求
                    inviteCode: '',         //邀请码
                    videosrc: '',           //视频地址
                    isShowArticleMore: false,//图文显示更多按钮
                    isShowDianMore: true,   //点评是否展开
                    isLogin: isLogin        //是否已登录
                },
                methods: {
                    changeTab: function (tabname) {
                        $(".js_tabname").removeClass('show-sec-video show-sec-article show-sec-gamedata show-sec-dianping').addClass('show-sec-'+tabname);
                        this.tabClass = tabname;
                    },
                    showVideo: function(item){
                        this.isShowVideo = true;
                        this.videosrc = $(item.target).data('vsrc');
                    },
                    showSign: function () {
                        if(!this.isLogin) {
                            gad.login();
                            return;
                        }
                        this.isShowSign = true;
                    },
                    signup: function(){
                        if (this.isSending) {
                            return;
                        }
                        this.isSending = true;
                        var params = this.signInfo;
                        var _that = this;
                        params._token = $('meta[name="csrf-token"]').attr('content');
                        this.$http.post('/gamepie/signup/' + id, params).then(function (res) {
                            this.isSending = false;
                            var response = res.data;
                            if(response.code == 0){
                                _that.isShowSign = false;
                                _that.isShowOk = true;
                            }else{
                                popup.showPopup('warn','提示',response.msg);
                            }
                        });
                    },
                    getCode: function (num) {
                        if (this.isSending || !num) {
                            return;
                        }
                        this.isSending = true;
                        var _that = this;
                        this.$http.post('/gamepie/sms-code/' + id, {_token: $('meta[name="csrf-token"]').attr('content')}).then(function (res) {
                            this.isSending = false;
                            var response = res.data;
                            if(response.code == 0){
                                _that.inviteCode = response.data;
                                _that.isShowCode = true;
                            }else{
                                popup.showPopup('warn','提示',response.message);
                            }
                        });
                    },
                    closeShowCode: function () {
                        this.isShowCode = false;
                        $(".js_copycodetips").addClass("f-hide");
                    }
                }
            });
        }
    };
});