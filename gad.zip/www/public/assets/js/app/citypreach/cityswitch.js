(function(root, factory) {
    if (typeof define === "function" && define.amd) {
        define(["jquery"], function($) {
            return factory($);
        });
    } else if (typeof exports === "object") {
        module.exports = factory(require("jquery"));
    } else {
        factory(jQuery);
    }
})(this, function($) {
    var long = $(".city-change .cychange-item").width() + parseInt($(".city-change .cychange-item:last-child").css("paddingLeft"));
    var currStep = 0;
    var maxStep = $('.city-change .cychange-item').length - 3;
    var display = function(){
        var cychangeMove1 = 0 - currStep * long;
        var next = $(".city-change .cychange-handle.handle-next");
        var prev = $(".city-change .cychange-handle.handle-prev");
        $(".city-change .cychange-list").css({"transform": "translateX(" + cychangeMove1 + "px)", "-ms-transform": "translateX(" + cychangeMove1 + "px)"});
        currStep<maxStep ? next.removeClass('off') : next.addClass('off');
        currStep>0 ? prev.removeClass('off') : prev.addClass('off');
    };
    $(".cychange-handle.handle-next").on("click", function () {
        if(currStep<maxStep){
            currStep++;
            display();
        }
    });
    $(".cychange-handle.handle-prev").on("click", function () {
        if(currStep>0){
            currStep--;
            display();
        }  
    });
    window.AutoMoveCitySwitch = function(cityid){
        var index = $('.city-change .cychange-item.cychange-item-'+cityid).index();
        var maxIndex = Math.min(index + 2, $('.city-change .cychange-item').length - 1);
        currStep = maxIndex - 2;
        setTimeout(function(){
            display();
        }, 200);
    };
    return {
        moveTo: window.AutoMoveCitySwitch
    }
}); 