define(['jquery','angular'],function($,angular){
	var app=angular.module('gad.fame',[]);
    var pasize = 8;
    var page = 1;
    var total = 0;
    var ishasmore = true;
    var isloading = false;
    var setLoadStatus = function(){
		if(ishasmore){
			if(isloading)
				$(".js-morediv").removeClass('dl-goto').removeClass('dl-no-more').addClass('dl-loading');
			else
				$(".js-morediv").removeClass('dl-loading').removeClass('dl-no-more').addClass('dl-goto');
		}else{
			$(".js-morediv").removeClass('dl-loading').removeClass('dl-goto').addClass('dl-no-more');
		}
	}
	
	app.controller('fameListCtrl',function($scope,$http,$location){ 
    	$scope.famelist = [];
		if(page*pasize >= total){
			ishasmore = false;
		}
		setLoadStatus();
		var url="/fame/listdata";
		$(".js-more").click(function(){
			$(".js-morelist").removeClass('f-hide');
			getfamelist();
		});
		//获取数据  
		var getfamelist = function(){
			isloading = true;
			setLoadStatus();
			$http.get(url+"?page="+page+"&pasize="+pasize).success(function(res){  
				if(res.code==0){
					$scope.famelist = $scope.famelist.concat(res.famelist);
					isloading = false;
					page++;
					if(page*pasize > total){
						ishasmore = false;
					}
					setLoadStatus();
				}else{
					alert(res.message);
				}  
			});   
		}
	});
	
    return {
        init:function(totalc){
        	total = totalc;
            angular.bootstrap(document,['gad.fame']);
        }
    }
});